#engine v8

#feature-id AstroMark : SetiAstro > AstroMark Signature and Insert Adder
#feature-icon  astromark.svg
#feature-info This script allows users to overlay their signature image on top of another image.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * AstroMark
 * Version: V1.4
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "AstroMark - Signature and Insert Adder"
#define VERSION "V1.4"

let parameters = {
    targetWindow:         null,
    signatureWindow:      null,
    signaturePosition:    new Point(0, 0),
    signatureScale:       1.0,
    signatureRotation:    0.0,
    signatureOpacity:     1.0,
    signaturePositioning: "Lower Right",
    signatureOffset:      10,
    previewZoomFactor:    1.0,
    blendMode:            "Normal",
    borderEnabled:        false,
    borderWidth:          3,
    borderColor:          0x00000000,

    save: function()
    {
        Parameters.set( "signatureScale",       this.signatureScale );
        Parameters.set( "signatureRotation",    this.signatureRotation );
        Parameters.set( "signatureOpacity",     this.signatureOpacity );
        Parameters.set( "signaturePositioning", this.signaturePositioning );
        Parameters.set( "signatureOffset",      this.signatureOffset );
        Parameters.set( "blendMode",            this.blendMode );
        Parameters.set( "borderEnabled",        this.borderEnabled );
        Parameters.set( "borderWidth",          this.borderWidth );
        Parameters.set( "borderColor",          this.borderColor );
    },

    load: function()
    {
        if ( Parameters.has( "signatureScale" ) )       this.signatureScale       = Parameters.getReal(    "signatureScale" );
        if ( Parameters.has( "signatureRotation" ) )    this.signatureRotation    = Parameters.getReal(    "signatureRotation" );
        if ( Parameters.has( "signatureOpacity" ) )     this.signatureOpacity     = Parameters.getReal(    "signatureOpacity" );
        if ( Parameters.has( "signaturePositioning" ) ) this.signaturePositioning = Parameters.getString(  "signaturePositioning" );
        if ( Parameters.has( "signatureOffset" ) )      this.signatureOffset      = Parameters.getInteger( "signatureOffset" );
        if ( Parameters.has( "blendMode" ) )            this.blendMode            = Parameters.getString(  "blendMode" );
        if ( Parameters.has( "borderEnabled" ) )        this.borderEnabled        = Parameters.getBoolean( "borderEnabled" );
        if ( Parameters.has( "borderWidth" ) )          this.borderWidth          = Parameters.getInteger( "borderWidth" );
        if ( Parameters.has( "borderColor" ) )          this.borderColor          = Parameters.getInteger( "borderColor" );
    }
};

// ============================================================================
// ScrollControl
// V8 notes:
//  - All viewport.onXxx handlers converted to arrow functions (no this.parent needed)
//  - _cachedMainBitmap / _cachedSigBitmap prevent render() being called every frame
//  - invalidateRenderCache() calls bitmap.clear() for explicit V8 deallocation
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.signaturePosition  = new Point(0, 0);
        this.signatureScale     = parameters.signatureScale;
        this.signatureRotation  = parameters.signatureRotation;
        this.signatureOpacity   = parameters.signatureOpacity;
        this.blendMode          = parameters.blendMode;

        this.autoScroll = true;
        this.tracking   = true;

        this.mainImage          = null;
        this.signatureImage     = null;
        this.dragging           = false;
        this.dragOrigin         = new Point(0, 0);
        this.isTransforming     = false;
        this.transformCenter    = null;
        this.initialDistance    = null;

        this.zoomFactor    = 1.0;
        this.minZoomFactor = 0.1;
        this.maxZoomFactor = 10.0;

        this.cachedSignatureImage = null;

        // V8 render caches
        this._cachedMainBitmap = null;
        this._cachedSigBitmap  = null;

        // ---- Viewport handlers (arrow functions — no this.parent needed) ----

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            let zf = this.zoomFactor;
            let ax = (x / zf) + this.scrollPosition.x;
            let ay = (y / zf) + this.scrollPosition.y;

            if ( modifiers === 1 ) // Shift — move signature
            {
                this.dragging = true;
                this.dragOrigin.x = ax;
                this.dragOrigin.y = ay;
            }
            else if ( modifiers === 2 ) // Ctrl — resize
            {
                this.isTransforming = true;
                this.transformCenter = new Point(
                    this.signaturePosition.x + (this.signatureImage.width  * this.signatureScale) / 2,
                    this.signaturePosition.y + (this.signatureImage.height * this.signatureScale) / 2 );
                this.initialDistance = this.calculateDistance( ax, ay, this.transformCenter.x, this.transformCenter.y );
            }
            else if ( modifiers === 4 ) // Alt — rotate
            {
                this.isTransforming = true;
                this.transformCenter = new Point(
                    this.signaturePosition.x + (this.signatureImage.width  * this.signatureScale) / 2,
                    this.signaturePosition.y + (this.signatureImage.height * this.signatureScale) / 2 );
                this.initialAngle    = this.calculateAngle( this.transformCenter.x, this.transformCenter.y, ax, ay );
                this.initialDistance = this.calculateDistance( ax, ay, this.transformCenter.x, this.transformCenter.y );
            }
            else // Default — scroll
            {
                this.dragging = true;
                this.dragOrigin.x = x;
                this.dragOrigin.y = y;
            }
            this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            let zf = this.zoomFactor;
            let ax = (x / zf) + this.scrollPosition.x;
            let ay = (y / zf) + this.scrollPosition.y;

            if ( this.dragging )
            {
                if ( modifiers === 1 ) // Shift — move signature
                {
                    let dx = ax - this.dragOrigin.x;
                    let dy = ay - this.dragOrigin.y;
                    this.signaturePosition.x += dx;
                    this.signaturePosition.y += dy;
                    this.dragOrigin.x = ax;
                    this.dragOrigin.y = ay;
                }
                else // Default — scroll
                {
                    let dx = (x - this.dragOrigin.x) / zf;
                    let dy = (y - this.dragOrigin.y) / zf;
                    this.scrollPosition = new Point(
                        this.scrollPosition.x - dx,
                        this.scrollPosition.y - dy );
                    this.dragOrigin.x = x;
                    this.dragOrigin.y = y;
                }
                if ( this.viewport ) this.viewport.update();
            }
            else if ( this.isTransforming ) // Ctrl — resize
            {
                let currentDistance = this.calculateDistance( ax, ay, this.transformCenter.x, this.transformCenter.y );
                this.signatureScale *= currentDistance / this.initialDistance;
                this.initialDistance = currentDistance;
                this.invalidateSigCache();
                this.cacheResampledSignature( "NearestNeighbor" );
                if ( this.viewport ) this.viewport.update();
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.dragging = false;
            if ( this.isTransforming )
            {
                this.isTransforming = false;
                this.invalidateSigCache();
                this.cacheResampledSignature( "Bilinear" );
                if ( this.viewport ) this.viewport.update();
            }
            this.viewport.cursor = new Cursor( StdCursor.Arrow );
        };

        this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
        {
            if ( delta > 0 ) this.zoomFactor = Math.min( this.zoomFactor * 1.25, this.maxZoomFactor );
            else             this.zoomFactor = Math.max( this.zoomFactor * 0.8,  this.minZoomFactor );
            this.initScrollBars();
            if ( this.viewport ) this.viewport.update();
        };

        // onPaint: uses cached bitmaps — render() only called when cache is null
        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this.viewport );

            if ( !this.mainImage )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
                g.end();
                return;
            }

            // Rebuild main bitmap cache only when invalidated
            if ( !this._cachedMainBitmap )
                this._cachedMainBitmap = this.mainImage.render();

            g.scaleTransformation( this.zoomFactor );
            g.translateTransformation( -this.scrollPosition.x, -this.scrollPosition.y );
            g.drawBitmap( 0, 0, this._cachedMainBitmap );

            let sigImage = this.cachedSignatureImage;
            if ( sigImage )
            {
                // Rebuild sig bitmap cache only when invalidated
                if ( !this._cachedSigBitmap )
                    this._cachedSigBitmap = sigImage.render();

                let posX = this.signaturePosition.x;
                let posY = this.signaturePosition.y;
                let w = sigImage.width, h = sigImage.height;
                let centerX = posX + w / 2, centerY = posY + h / 2;

                g.translateTransformation( centerX, centerY );
                g.rotateTransformation( this.signatureRotation * Math.PI / 180 );
                g.translateTransformation( -centerX, -centerY );

                g.opacity = this.signatureOpacity;
                g.drawBitmap( posX, posY, this._cachedSigBitmap );

                if ( parameters.borderEnabled )
                {
                    let borderColor = parameters.borderColor | 0xFF000000;
                    let borderWidth = parameters.borderWidth;
                    g.pen   = new Pen( borderColor, borderWidth );
                    g.brush = new Brush( 0x00000000 );
                    g.drawRect( posX - borderWidth/2, posY - borderWidth/2,
                                posX + w + borderWidth/2, posY + h + borderWidth/2 );
                }
                g.opacity = 1.0;
            }
            g.end();
        };

        this.initScrollBars();
    }

    // ---- Cache management ----

    invalidateMainCache()
    {
        if ( this._cachedMainBitmap )
        { this._cachedMainBitmap.clear(); this._cachedMainBitmap = null; }
    }

    invalidateSigCache()
    {
        if ( this._cachedSigBitmap )
        { this._cachedSigBitmap.clear(); this._cachedSigBitmap = null; }
    }

    invalidateAllCaches()
    {
        this.invalidateMainCache();
        this.invalidateSigCache();
    }

    // ---- Core methods ----

    getImage() { return this.mainImage; }

    doUpdateImage( mainImage, signatureImage )
    {
        this.invalidateAllCaches();
        this.mainImage      = mainImage;
        this.signatureImage = signatureImage;
        this.cacheResampledSignature();
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    initScrollBars( scrollPoint )
    {
        let image = this.getImage();
        if ( !image || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange(   0, 0 );
            this.scrollPosition = new Point( 0, 0 );
        }
        else
        {
            let zf = this.zoomFactor;
            this.setHorizontalScrollRange( 0, Math.max(0, 4*image.width *zf) );
            this.setVerticalScrollRange(   0, Math.max(0, 4*image.height*zf) );
            if ( scrollPoint )
                this.scrollPosition = scrollPoint;
            else
                this.scrollPosition = new Point(
                    Math.min(this.scrollPosition.x, 4*image.width *zf),
                    Math.min(this.scrollPosition.y, 4*image.height*zf) );
        }
        if ( this.viewport ) this.viewport.update();
    }

    cacheResampledSignature( interpolationMethod )
    {
        if ( !this.signatureImage ) return;

        let tempWindow = new ImageWindow(
            this.signatureImage.width, this.signatureImage.height,
            this.signatureImage.numberOfChannels, this.signatureImage.bitsPerSample,
            this.signatureImage.isReal, this.signatureImage.isColor );

        tempWindow.mainView.beginProcess();
        tempWindow.mainView.image.assign( this.signatureImage );
        tempWindow.mainView.endProcess();

        let P = new Resample;
        P.xSize = this.signatureScale; P.ySize = this.signatureScale;
        P.mode            = Resample.RelativeDimensions;
        P.absoluteMode    = Resample.ForceWidthAndHeight;
        P.xResolution     = 72; P.yResolution = 72;
        P.metric          = false; P.forceResolution = false;
        P.interpolation   = Resample.Auto;
        P.clampingThreshold = 0.30; P.smoothness = 1.50;
        P.gammaCorrection = false; P.noGUIMessages = true;
        P.executeOn( tempWindow.mainView );

        // V8 fix: copy then close immediately
        this.invalidateSigCache();
        this.cachedSignatureImage = new Image( tempWindow.mainView.image );
        tempWindow.forceClose();
    }

    calculateDistance( x1, y1, x2, y2 )
    { return Math.sqrt( Math.pow(x2-x1,2) + Math.pow(y2-y1,2) ); }

    calculateAngle( cx, cy, px, py )
    { return Math.atan2( py-cy, px-cx ); }

    zoomIn()
    {
        this.zoomFactor = Math.min( this.zoomFactor*1.25, this.maxZoomFactor );
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    zoomOut()
    {
        this.zoomFactor = Math.max( this.zoomFactor*0.8, this.minZoomFactor );
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }
};

// ============================================================================
// SignatureAdderDialog
// ============================================================================

var SignatureAdderDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.signaturePosition = new Point(0, 0);
        this.signatureScale    = parameters.signatureScale;
        this.signatureRotation = parameters.signatureRotation;
        this.signatureOpacity  = parameters.signatureOpacity;
        this.blendMode         = parameters.blendMode || "Normal";
        this.cachedSignatureImage = null;

        // ---- Title ----
        this.title_Lbl = new Label( this );
        this.title_Lbl.frameStyle    = FrameStyle.Box;
        this.title_Lbl.margin        = 6;
        this.title_Lbl.useRichText   = true;
        this.title_Lbl.text          = "<b>AstroMark - Signature and Insert Adder " + VERSION + "</b>";
        this.title_Lbl.textAlignment = TextAlignment.Center;

        // ---- Instructions ----
        this.instructions_Lbl = new TextBox( this );
        this.instructions_Lbl.readOnly   = true;
        this.instructions_Lbl.frameStyle = FrameStyle.Box;
        this.instructions_Lbl.text =
            "Instructions:\n\n" +
            "1. Select the target image.\n" +
            "2. Select the signature image.\n" +
            "3. Select a blend mode (Preview does not support blend modes but your executed image will)\n" +
            "4. Adjust the position (shift+click and drag) of the signature using mouse controls.\n" +
            "5. Click 'Execute' to overlay the signature onto the target image.";
        this.instructions_Lbl.setScaledMinWidth( 450 );

        // ---- Image selectors ----
        this.targetWindow_Label = new Label( this );
        this.targetWindow_Label.text = "Select Image:";
        this.targetWindow_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.signatureWindow_Label = new Label( this );
        this.signatureWindow_Label.text = "Select Signature:";
        this.signatureWindow_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.targetWindowSelector_Cb    = new ComboBox( this );
        this.signatureWindowSelector_Cb = new ComboBox( this );

        for ( let i = 0; i < ImageWindow.windows.length; i++ )
        {
            let windowId = ImageWindow.windows[i].mainView.id;
            this.targetWindowSelector_Cb.addItem( windowId );
            this.signatureWindowSelector_Cb.addItem( windowId );
        }
        this.signatureWindowSelector_Cb.insertItem( 0, "Select Image" );
        this.signatureWindowSelector_Cb.currentItem = 0;

        this.targetWindowSelector_Cb.onItemSelected = index =>
        {
            if ( index >= 0 )
            {
                let windowId = this.targetWindowSelector_Cb.itemText( index );
                parameters.targetWindow = ImageWindow.windowById( windowId );
                this.updatePreview();
            }
        };

        this.signatureWindowSelector_Cb.onItemSelected = index =>
        {
            if ( index >= 1 )
            {
                let windowId = this.signatureWindowSelector_Cb.itemText( index );
                parameters.signatureWindow = ImageWindow.windowById( windowId );
                this.cacheResampledSignature();
                this.updatePreview();
            }
            else
            {
                parameters.signatureWindow = null;
                this.cachedSignatureImage = null;
            }
        };

        let activeWindow = ImageWindow.activeWindow;
        if ( !activeWindow.isNull )
            this.targetWindowSelector_Cb.currentItem =
                this.targetWindowSelector_Cb.findItem( activeWindow.mainView.id );
        else
            this.targetWindowSelector_Cb.currentItem = 0;

        // ---- Blend mode ----
        this.blendMode_Label = new Label( this );
        this.blendMode_Label.text = "Blend Mode:";
        this.blendMode_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.blendMode_Cb = new ComboBox( this );
        ["Normal","Replacement","Lighten","Multiply","Screen","Overlay","Difference","Darken"]
            .forEach( m => this.blendMode_Cb.addItem(m) );
        this.blendMode_Cb.currentItem = this.blendMode_Cb.findItem( this.blendMode );
        this.blendMode_Cb.onItemSelected = index =>
        {
            this.blendMode = this.blendMode_Cb.itemText( index );
            parameters.blendMode = this.blendMode;
            this.previewControl.viewport.update();
        };

        this.blendModeHelp_Lbl = new Label( this );
        this.blendModeHelp_Lbl.useRichText = true;
        this.blendModeHelp_Lbl.text = "<a href=\"https://www.setiastro.com/blendmodes\">Help With Different Blend Modes</a>";
        this.blendModeHelp_Lbl.toolTip = "Click for help with different blend modes.";
        this.blendModeHelp_Lbl.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.blendModeHelp_Lbl.onMousePress = () =>
        { Dialog.openBrowser( "https://www.setiastro.com/blendmodes" ); };

        this.blendModeSizer = new HorizontalSizer;
        this.blendModeSizer.spacing = 4;
        this.blendModeSizer.add( this.blendMode_Label );
        this.blendModeSizer.add( this.blendMode_Cb );
        this.blendModeSizer.addSpacing( 20 );
        this.blendModeSizer.add( this.blendModeHelp_Lbl );
        this.blendModeSizer.addStretch();

        // ---- Sliders ----
        this.signatureSize_Slider = new NumericControl( this );
        this.signatureSize_Slider.label.text = "Signature Size:";
        this.signatureSize_Slider.setRange( 0.01, 5 );
        this.signatureSize_Slider.slider.setRange( 1, 500 );
        this.signatureSize_Slider.setPrecision( 2 );
        this.signatureSize_Slider.setValue( parameters.signatureScale );

        let signatureScaleUpdateTimer = new Timer;
        this.signatureSize_Slider.onValueUpdated = value =>
        {
            signatureScaleUpdateTimer.stop();
            signatureScaleUpdateTimer.interval   = 1.0;
            signatureScaleUpdateTimer.singleShot = true;
            signatureScaleUpdateTimer.onTimeout  = () =>
            {
                this.previewControl.signatureScale = value;
                this.previewControl.invalidateSigCache();
                this.previewControl.cacheResampledSignature( "Bilinear" );
                this.previewControl.viewport.update();
            };
            signatureScaleUpdateTimer.start();
            parameters.signatureScale = value;
        };

        this.signatureRotation_Slider = new NumericControl( this );
        this.signatureRotation_Slider.label.text = "Signature Rotation:";
        this.signatureRotation_Slider.setRange( 0.0, 360.0 );
        this.signatureRotation_Slider.slider.setRange( 0, 3600 );
        this.signatureRotation_Slider.setPrecision( 1 );
        this.signatureRotation_Slider.setValue( parameters.signatureRotation );
        this.signatureRotation_Slider.onValueUpdated = value =>
        {
            this.previewControl.signatureRotation = value;
            this.previewControl.viewport.update();
            parameters.signatureRotation = value;
        };

        this.signatureOpacity_Slider = new NumericControl( this );
        this.signatureOpacity_Slider.label.text = "Signature Opacity:";
        this.signatureOpacity_Slider.setRange( 0.01, 1.00 );
        this.signatureOpacity_Slider.slider.setRange( 1, 1000 );
        this.signatureOpacity_Slider.setPrecision( 2 );
        this.signatureOpacity_Slider.setValue( parameters.signatureOpacity );
        this.signatureOpacity_Slider.onValueUpdated = value =>
        {
            this.previewControl.signatureOpacity = value;
            this.previewControl.viewport.update();
            parameters.signatureOpacity = value;
        };

        // ---- Positioning ----
        this.positioningLabel = new Label( this );
        this.positioningLabel.text = "Position:";
        this.positioningLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.positioningComboBox = new ComboBox( this );
        ["Upper Left","Upper Center","Upper Right","Left","Center","Right","Lower Left","Lower Center","Lower Right"]
            .forEach( p => this.positioningComboBox.addItem(p) );
        this.positioningComboBox.currentItem =
            this.positioningComboBox.findItem( parameters.signaturePositioning );
        this.positioningComboBox.onItemSelected = index =>
        {
            parameters.signaturePositioning = this.positioningComboBox.itemText( index );
            this.updateSignaturePosition();
        };

        this.offsetLabel = new Label( this );
        this.offsetLabel.text = "Offset (px):";
        this.offsetLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.offsetInput = new Edit( this );
        this.offsetInput.text = parameters.signatureOffset.toString();
        this.offsetInput.onEditCompleted = () =>
        {
            let offsetValue = parseInt( this.offsetInput.text.trim() );
            if ( !isNaN(offsetValue) )
            {
                parameters.signatureOffset = offsetValue;
                this.updateSignaturePosition();
            }
        };

        this.positioningSizer = new HorizontalSizer;
        this.positioningSizer.spacing = 6;
        this.positioningSizer.add( this.positioningLabel );
        this.positioningSizer.add( this.positioningComboBox );
        this.positioningSizer.add( this.offsetLabel );
        this.positioningSizer.add( this.offsetInput );
        this.positioningSizer.addStretch();

        // ---- Border controls ----
        this.borderCheckbox = new CheckBox( this );
        this.borderCheckbox.text    = "Add Border";
        this.borderCheckbox.checked = parameters.borderEnabled;
        this.borderCheckbox.toolTip = "Enable or disable border around the signature/image.";

        this.borderWidthSlider = new NumericControl( this );
        this.borderWidthSlider.label.text = "Border Width:";
        this.borderWidthSlider.setRange( 1, 20 );
        this.borderWidthSlider.slider.setRange( 1, 200 );
        this.borderWidthSlider.setPrecision( 0 );
        this.borderWidthSlider.setValue( parameters.borderWidth );
        this.borderWidthSlider.enabled = parameters.borderEnabled;

        const presetColors = {
            "Black":   0x000000, "White":   0xFFFFFF,
            "Red":     0xFF0000, "Orange":  0xFFA500,
            "Yellow":  0xFFFF00, "Green":   0x00FF00,
            "Blue":    0x0000FF, "Cyan":    0x00FFFF,
            "Magenta": 0xFF00FF
        };

        this.borderColor_Label = new Label( this );
        this.borderColor_Label.text = "Border Color:";
        this.borderColor_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.borderColorDropdown = new ComboBox( this );
        for ( let colorName in presetColors )
            this.borderColorDropdown.addItem( colorName );

        let currentColor = parameters.borderColor;
        let defaultColorIndex = 0, ci = 0;
        for ( let colorName in presetColors )
        {
            if ( presetColors[colorName] === currentColor ) { defaultColorIndex = ci; break; }
            ci++;
        }
        this.borderColorDropdown.currentItem = defaultColorIndex;
        this.borderColorDropdown.enabled     = parameters.borderEnabled;

        this.borderCheckbox.onCheck = checked =>
        {
            parameters.borderEnabled             = checked;
            this.borderWidthSlider.enabled       = checked;
            this.borderColorDropdown.enabled     = checked;
            this.previewControl.viewport.update();
        };

        this.borderWidthSlider.onValueUpdated = value =>
        {
            parameters.borderWidth = value;
            this.previewControl.viewport.update();
        };

        this.borderColorDropdown.onItemSelected = index =>
        {
            let colorName = this.borderColorDropdown.itemText( index );
            parameters.borderColor = presetColors[colorName] | 0xFF000000;
            this.previewControl.viewport.update();
        };

        this.borderSizer = new VerticalSizer;
        this.borderSizer.spacing = 4;
        this.borderSizer.add( this.borderCheckbox );
        this.borderSizer.add( this.borderWidthSlider );
        this.borderSizer.add( this.borderColor_Label );
        this.borderSizer.add( this.borderColorDropdown );

        // ---- Zoom buttons ----
        this.zoomInButton = new PushButton( this );
        this.zoomInButton.text    = "";
        this.zoomInButton.icon    = this.scaledResource( ":/icons/zoom-in.png" );
        this.zoomInButton.toolTip = "Zoom In";
        this.zoomInButton.onClick = () => { this.previewControl.zoomIn(); };

        this.zoomOutButton = new PushButton( this );
        this.zoomOutButton.text    = "";
        this.zoomOutButton.icon    = this.scaledResource( ":/icons/zoom-out.png" );
        this.zoomOutButton.toolTip = "Zoom Out";
        this.zoomOutButton.onClick = () => { this.previewControl.zoomOut(); };

        this.zoomLabel = new Label( this );
        this.zoomLabel.text = "Zoom In/Out (Mouse Wheel Supported)";

        this.zoomSizer = new HorizontalSizer;
        this.zoomSizer.spacing = 6;
        this.zoomSizer.add( this.zoomInButton );
        this.zoomSizer.add( this.zoomOutButton );
        this.zoomSizer.add( this.zoomLabel );
        this.zoomSizer.addStretch();

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth( 640 );
        this.previewControl.setMinHeight( 450 );

        // ---- Buttons ----
        this.execute_Btn = new PushButton( this );
        this.execute_Btn.text    = "Execute";
        this.execute_Btn.toolTip = "Apply the signature overlay to the target image.";
        this.execute_Btn.onClick = () =>
        {
            this.applySignatureOverlay();
            this.ok();
        };

        this.newInstance_Btn = new ToolButton( this );
        this.newInstance_Btn.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstance_Btn.setScaledFixedSize( 24, 24 );
        this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
        this.newInstance_Btn.onMousePress = () =>
        { parameters.save(); this.newInstance(); };

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.spacing = 6;
        this.buttonSizer.add( this.newInstance_Btn );
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.execute_Btn );

        // ---- Authorship ----
        this.authorship_Lbl = new Label( this );
        this.authorship_Lbl.frameStyle    = FrameStyle.Box;
        this.authorship_Lbl.margin        = 6;
        this.authorship_Lbl.useRichText   = true;
        this.authorship_Lbl.text          = "Written by Franklin Marek 2026<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
        this.authorship_Lbl.textAlignment = TextAlignment.Center;
        this.authorship_Lbl.onMousePress  = () => { Dialog.openBrowser( "http://www.setiastro.com" ); };

        // ---- Layout ----
        this.leftSizer = new VerticalSizer;
        this.leftSizer.spacing = 6;
        this.leftSizer.add( this.title_Lbl );
        this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.instructions_Lbl );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.targetWindow_Label );
        this.leftSizer.add( this.targetWindowSelector_Cb );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.signatureWindow_Label );
        this.leftSizer.add( this.signatureWindowSelector_Cb );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.blendModeSizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.signatureSize_Slider );
        this.leftSizer.add( this.signatureRotation_Slider );
        this.leftSizer.add( this.signatureOpacity_Slider );
        this.leftSizer.add( this.positioningSizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.borderSizer );
        this.leftSizer.addStretch();
        this.leftSizer.add( this.authorship_Lbl );
        this.leftSizer.add( this.buttonSizer );

        this.leftPanel = new Control( this );
        this.leftPanel.sizer = this.leftSizer;
        this.leftPanel.setFixedWidth( 450 );

        this.rightSizer = new VerticalSizer;
        this.rightSizer.spacing = 6;
        this.rightSizer.add( this.zoomSizer );
        this.rightSizer.add( this.previewControl, 1 );

        this.mainSizer = new HorizontalSizer;
        this.mainSizer.spacing = 4;
        this.mainSizer.add( this.leftPanel );
        this.mainSizer.add( this.rightSizer, 1 );

        this.sizer = this.mainSizer;

        // Init
        parameters.targetWindow   = ImageWindow.windowById(
            this.targetWindowSelector_Cb.itemText( this.targetWindowSelector_Cb.currentItem ) );
        parameters.signatureWindow = null;
        this.updatePreview();
        this.updateSignaturePosition();

        this.windowTitle = TITLE;
        this.adjustToContents();
    }

    // ---- Preview helpers ----

    updatePreview()
    {
        if ( parameters.targetWindow && this.cachedSignatureImage )
        {
            this.previewControl.doUpdateImage(
                parameters.targetWindow.mainView.image,
                this.cachedSignatureImage );
        }
    }

    cacheResampledSignature()
    {
        if ( parameters.signatureWindow )
        {
            let signatureImage = new Image( parameters.signatureWindow.mainView.image );
            signatureImage.resample( this.signatureScale );
            this.cachedSignatureImage = signatureImage;
        }
    }

    updateSignaturePosition()
    {
        let offset        = parameters.signatureOffset;
        let mainImage     = this.previewControl.mainImage;
        let signatureImage = this.previewControl.cachedSignatureImage;
        if ( !mainImage || !signatureImage ) return;

        let x, y;
        switch ( parameters.signaturePositioning )
        {
        case "Upper Left":   x = offset; y = offset; break;
        case "Upper Center": x = (mainImage.width - signatureImage.width) / 2; y = offset; break;
        case "Upper Right":  x = mainImage.width - signatureImage.width - offset; y = offset; break;
        case "Left":         x = offset; y = (mainImage.height - signatureImage.height) / 2; break;
        case "Center":       x = (mainImage.width - signatureImage.width) / 2; y = (mainImage.height - signatureImage.height) / 2; break;
        case "Right":        x = mainImage.width - signatureImage.width - offset; y = (mainImage.height - signatureImage.height) / 2; break;
        case "Lower Left":   x = offset; y = mainImage.height - signatureImage.height - offset; break;
        case "Lower Center": x = (mainImage.width - signatureImage.width) / 2; y = mainImage.height - signatureImage.height - offset; break;
        case "Lower Right":  x = mainImage.width - signatureImage.width - offset; y = mainImage.height - signatureImage.height - offset; break;
        default:             x = 0; y = 0;
        }
        this.previewControl.signaturePosition = new Point( x, y );
        this.previewControl.viewport.update();
    }

    // ---- Apply overlay ----

    applySignatureOverlay()
    {
        if ( !parameters.targetWindow || !this.cachedSignatureImage )
        {
            new MessageBox( "Please select both main and signature images.", TITLE,
                StdIcon.Error, StdButton.Ok ).execute();
            return;
        }

        let targetImage           = parameters.targetWindow.mainView.image;
        let cachedSignatureImage  = this.cachedSignatureImage;

        // Convert main image to RGB if needed
        if ( !targetImage.isColor )
        {
            let conv = new ConvertToRGBColor;
            conv.executeOn( parameters.targetWindow.mainView );
            targetImage = parameters.targetWindow.mainView.image;
        }

        // Convert signature to RGB if needed
        if ( !cachedSignatureImage.isColor )
        {
            let tempWindow = new ImageWindow(
                cachedSignatureImage.width, cachedSignatureImage.height,
                cachedSignatureImage.numberOfChannels, cachedSignatureImage.bitsPerSample,
                cachedSignatureImage.isReal, cachedSignatureImage.isColor );
            tempWindow.mainView.beginProcess();
            tempWindow.mainView.image.assign( cachedSignatureImage );
            tempWindow.mainView.endProcess();
            let conv = new ConvertToRGBColor;
            conv.executeOn( tempWindow.mainView );
            cachedSignatureImage = new Image( tempWindow.mainView.image );
            tempWindow.forceClose();
        }

        function normalizeAngle( angle )
        {
            while ( angle >  Math.PI ) angle -= 2*Math.PI;
            while ( angle < -Math.PI ) angle += 2*Math.PI;
            return angle;
        }

        let signaturePosition = this.previewControl.signaturePosition;
        let signatureScale    = this.previewControl.signatureScale;
        let signatureRotation = normalizeAngle( this.previewControl.signatureRotation * Math.PI / 180 );
        let signatureOpacity  = this.previewControl.signatureOpacity;
        let blendMode         = parameters.blendMode || "Normal";

        // Resample signature
        let resampledSignatureWindow = new ImageWindow(
            cachedSignatureImage.width, cachedSignatureImage.height,
            cachedSignatureImage.numberOfChannels, cachedSignatureImage.bitsPerSample,
            cachedSignatureImage.isReal, cachedSignatureImage.isColor );
        resampledSignatureWindow.mainView.beginProcess();
        resampledSignatureWindow.mainView.image.assign( cachedSignatureImage );
        resampledSignatureWindow.mainView.endProcess();

        let P = new Resample;
        P.xSize = signatureScale; P.ySize = signatureScale;
        P.mode            = Resample.RelativeDimensions;
        P.absoluteMode    = Resample.ForceWidthAndHeight;
        P.xResolution = 72; P.yResolution = 72;
        P.metric = false; P.forceResolution = false;
        P.interpolation   = Resample.Auto;
        P.clampingThreshold = 0.30; P.smoothness = 2.00;
        P.gammaCorrection = true; P.noGUIMessages = true;
        P.executeOn( resampledSignatureWindow.mainView );

        let resampledSignatureImage = resampledSignatureWindow.mainView.image;

        // Apply border if enabled
        if ( parameters.borderEnabled )
        {
            let borderWidth = parameters.borderWidth;
            let borderColor = parameters.borderColor;
            let epsilon = 0;
            let red   = ((borderColor >> 16) & 0xFF) / 255.0 + epsilon;
            let green = ((borderColor >>  8) & 0xFF) / 255.0 + epsilon;
            let blue  = ( borderColor        & 0xFF) / 255.0 + epsilon;

            let expandedWidth  = resampledSignatureImage.width  + 2*borderWidth;
            let expandedHeight = resampledSignatureImage.height + 2*borderWidth;

            let expandedWindow = new ImageWindow(
                expandedWidth, expandedHeight,
                resampledSignatureImage.numberOfChannels, resampledSignatureImage.bitsPerSample,
                resampledSignatureImage.isReal, resampledSignatureImage.isColor );
            let expandedImage = expandedWindow.mainView.image;
            expandedWindow.mainView.beginProcess();
            expandedImage.fill(1);

            let sigBitmap = resampledSignatureImage.render();
            expandedImage.selectedPoint = new Point( borderWidth, borderWidth );
            expandedImage.blend( sigBitmap );
            sigBitmap.clear(); // explicit dealloc

            for ( let b = 0; b < borderWidth; b++ )
            {
                for ( let x = b; x < expandedWidth-b; x++ )
                { expandedImage.setSample(red,x,b,0); expandedImage.setSample(green,x,b,1); expandedImage.setSample(blue,x,b,2);
                  expandedImage.setSample(red,x,expandedHeight-1-b,0); expandedImage.setSample(green,x,expandedHeight-1-b,1); expandedImage.setSample(blue,x,expandedHeight-1-b,2); }
                for ( let y = b; y < expandedHeight-b; y++ )
                { expandedImage.setSample(red,b,y,0); expandedImage.setSample(green,b,y,1); expandedImage.setSample(blue,b,y,2);
                  expandedImage.setSample(red,expandedWidth-1-b,y,0); expandedImage.setSample(green,expandedWidth-1-b,y,1); expandedImage.setSample(blue,expandedWidth-1-b,y,2); }
            }
            expandedWindow.mainView.endProcess();
            resampledSignatureImage = expandedImage;
            resampledSignatureWindow.forceClose();
            resampledSignatureWindow = expandedWindow;
        }

        // Apply rotation
        let rotationProcess = new Rotation;
        rotationProcess.angle              = signatureRotation;
        rotationProcess.optimizeFast       = true;
        rotationProcess.interpolation      = Rotation.Auto;
        rotationProcess.clampingThreshold  = 0.30;
        rotationProcess.smoothness         = 1.50;
        rotationProcess.gammaCorrection    = false;
        rotationProcess.red = 0; rotationProcess.green = 0; rotationProcess.blue = 0; rotationProcess.alpha = 1;
        rotationProcess.noGUIMessages      = true;
        rotationProcess.executeOn( resampledSignatureWindow.mainView );
        resampledSignatureImage = resampledSignatureWindow.mainView.image;

        // Build temp result window
        let tempImageWindow = new ImageWindow(
            targetImage.width, targetImage.height,
            targetImage.numberOfChannels, targetImage.bitsPerSample,
            targetImage.isReal, targetImage.isColor );
        let tempImage = tempImageWindow.mainView.image;
        tempImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
        tempImage.assign( targetImage );

        let centerX = signaturePosition.x + resampledSignatureImage.width  / 2;
        let centerY = signaturePosition.y + resampledSignatureImage.height / 2;

        for ( let y = 0; y < resampledSignatureImage.height; y++ )
            for ( let x = 0; x < resampledSignatureImage.width; x++ )
            {
                let alphaIdx  = resampledSignatureImage.numberOfChannels - 1;
                let alpha     = resampledSignatureImage.sample(x,y,alphaIdx) * signatureOpacity;
                let isBlack   = true;
                for ( let c = 0; c < 3; c++ )
                    if ( resampledSignatureImage.sample(x,y,c) !== 0 ) { isBlack = false; break; }

                if ( !isBlack && alpha > 0 )
                {
                    let tx = Math.round( centerX + (x - resampledSignatureImage.width /2) );
                    let ty = Math.round( centerY + (y - resampledSignatureImage.height/2) );
                    if ( tx >= 0 && tx < tempImage.width && ty >= 0 && ty < tempImage.height )
                    {
                        for ( let c = 0; c < tempImage.numberOfChannels; c++ )
                        {
                            let sp = resampledSignatureImage.sample(x,y,c);
                            let cp = tempImage.sample(tx,ty,c);
                            let bp;
                            switch ( blendMode )
                            {
                            case "Lighten":     bp = Math.max(sp*alpha,cp); break;
                            case "Multiply":    bp = sp*cp; break;
                            case "Screen":      bp = 1-(1-sp*alpha)*(1-cp); break;
                            case "Overlay":     bp = cp<0.5 ? 2*cp*sp*alpha : 1-2*(1-cp)*(1-sp*alpha); break;
                            case "Difference":  bp = Math.abs(cp-sp*alpha); break;
                            case "Darken":      bp = Math.min(sp*alpha,cp); break;
                            case "Replacement": bp = (sp*signatureOpacity)+(cp*(1-signatureOpacity)); break;
                            default:            bp = (sp*alpha)+(cp*(1-alpha)); // Normal
                            }
                            tempImage.setSample( bp, tx, ty, c );
                        }
                    }
                }
            }

        tempImageWindow.mainView.endProcess();

        // Copy result back to target via PixelMath
        let pixelMath = new PixelMath;
        pixelMath.expression = tempImageWindow.mainView.id;
        pixelMath.useSingleExpression = true;
        pixelMath.clearImageCacheAndExit = false; pixelMath.cacheGeneratedImages = false;
        pixelMath.generateOutput = true;  pixelMath.singleThreaded = false; pixelMath.optimization = true;
        pixelMath.use64BitWorkingImage = false; pixelMath.rescale = false;
        pixelMath.rescaleLower = 0; pixelMath.rescaleUpper = 1;
        pixelMath.truncate = true; pixelMath.truncateLower = 0; pixelMath.truncateUpper = 1;
        pixelMath.createNewImage = false; pixelMath.showNewImage = false;
        pixelMath.newImageId = ""; pixelMath.newImageWidth = 0; pixelMath.newImageHeight = 0; pixelMath.newImageAlpha = false;
        pixelMath.newImageColorSpace   = PixelMath.SameAsTarget;
        pixelMath.newImageSampleFormat = PixelMath.SameAsTarget;
        pixelMath.executeOn( parameters.targetWindow.mainView );

        resampledSignatureWindow.forceClose();
        tempImageWindow.forceClose();

        console.noteln( "Signature overlay applied successfully!" );
        this.ok();
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );
    console.writeln( "AstroMark Loading..." );
    parameters.load();
    let dialog = new SignatureAdderDialog();
    dialog.execute();
}

main();
