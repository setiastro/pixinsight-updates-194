#engine v8

#feature-id BlemishBlaster : SetiAstro > Blemish Blaster
#feature-icon  blemishblaster.svg
#feature-info This script allows blemish removal in astrophotographic images by averaging the surrounding area to replace the selected spot.

#include <pjsr/BitmapInterpolation.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/DataType.jsh>

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Blemish Blaster Pro
 * Version: V1.3.1  Built from V2.4.1
 * Author: Franklin Marek
 * Contributions by: Lamar McLouth
 * Website: www.setiastro.com
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "Blemish Blaster Pro"
#define VERSION "V1.3.1"

// Match PixInsight's linked AutoSTF behavior for normal astronomical images.
// Uses the native avgDev-based clipping statistics and 0.25 target background.

const BB_SETTINGS_PREFIX = "SetiAstro/BlemishBlasterPro/";

function writePersistentSetting( name, value )
{
    try
    {
        Settings.write( BB_SETTINGS_PREFIX + name, DataType_String, String(value) );
    }
    catch ( e )
    {
        console.warningln( "Blemish Blaster: unable to save setting '" + name + "': " + e );
    }
}

function readPersistentSetting( name )
{
    try
    {
        return Settings.read( BB_SETTINGS_PREFIX + name, DataType_String );
    }
    catch ( e )
    {
        console.warningln( "Blemish Blaster: unable to load setting '" + name + "': " + e );
        return null;
    }
}

let parameters = {
    targetWindow:          null,
    previewZoomLevel:      "Fit to Preview",
    autoSTFApplied:        false,
    drawingMode:           "Circle",
    wheelDirection:        "Forward",
    feather:               0.5,
    opacity:               1.0,
    satelliteTrailWidth:   5,

    save: function()
    {
        // Parameters is intentionally not used for these preferences: it is
        // associated with script/process instance parameter handling. Settings
        // provides persistent application preferences across fresh script runs.
        writePersistentSetting( "WheelDirection", this.wheelDirection );
        writePersistentSetting( "Feather", this.feather.toString() );
        writePersistentSetting( "Opacity", this.opacity.toString() );
        writePersistentSetting( "SatelliteTrailWidth", this.satelliteTrailWidth.toString() );
    },

    load: function()
    {
        const wheel = readPersistentSetting( "WheelDirection" );
        if ( wheel === "Forward" || wheel === "Backward" )
            this.wheelDirection = wheel;

        const feather = readPersistentSetting( "Feather" );
        if ( feather !== null && feather !== "" )
            this.feather = parseFloat( feather );

        const opacity = readPersistentSetting( "Opacity" );
        if ( opacity !== null && opacity !== "" )
            this.opacity = parseFloat( opacity );

        const width = readPersistentSetting( "SatelliteTrailWidth" );
        if ( width !== null && width !== "" )
            this.satelliteTrailWidth = parseInt( width, 10 );

        // Defensive range checks for persisted values.
        if ( !isFinite(this.feather) || this.feather < 0.01 || this.feather > 1 )
            this.feather = 0.5;
        if ( !isFinite(this.opacity) || this.opacity < 0 || this.opacity > 1 )
            this.opacity = 1.0;
        if ( !isFinite(this.satelliteTrailWidth) || this.satelliteTrailWidth < 1 || this.satelliteTrailWidth > 20 )
            this.satelliteTrailWidth = 5;
    }
};

// Load script UI preferences before constructing the dialog.
parameters.load();

// ============================================================================
// Satellite trail detection helpers
// ============================================================================

function detectAndDrawSatelliteTrail( parent, startX, startY )
{
    const searchRadius = 20;
    const brightnessThreshold = 1.5 * parent.displayImage.median();
    let allTrailPoints = [{ x: startX, y: startY }];
    const imageWidth  = parent.displayImage.width;
    const imageHeight = parent.displayImage.height;
    const maxSteps = 10 * FMath.floor(
        FMath.sqrt( imageWidth*imageWidth + imageHeight*imageHeight ) / searchRadius );
    searchTrail( parent, startX, startY, searchRadius, brightnessThreshold, -1, allTrailPoints, maxSteps );
    searchTrail( parent, startX, startY, searchRadius, brightnessThreshold,  1, allTrailPoints, maxSteps );
    allTrailPoints.sort( (a,b) => (a.x-b.x) || (a.y-b.y) );
    if ( allTrailPoints.length > 1 )
    {
        parent.satelliteTrails.push( { start: allTrailPoints[0], end: allTrailPoints[allTrailPoints.length-1] } );
        parent.invalidateRenderCache();
        parent.viewport.update();
    }
}

function searchTrail( parent, startX, startY, searchRadius, brightnessThreshold, dir, trailPoints, maxSteps )
{
    let endX = startX, endY = startY, steps = 0;
    while ( steps < maxSteps )
    {
        const direction = findTrailDirection( parent, endX, endY, searchRadius, brightnessThreshold, dir*FMath.PI, FMath.PI );
        if ( !direction ) break;
        let nextX = FMath.round( endX + dir*direction.dx );
        let nextY = FMath.round( endY + dir*direction.dy );
        if ( !isPointWithinImageBounds( parent.displayImage, nextX, nextY ) ) break;
        let brightestY = nextY, brightestBrightness = getPointBrightness( parent.displayImage, nextX, nextY );
        for ( let offsetY = -5; offsetY <= 5; offsetY++ )
        {
            let checkY = nextY + offsetY;
            if ( isPointWithinImageBounds( parent.displayImage, nextX, checkY ) )
            {
                let b = getPointBrightness( parent.displayImage, nextX, checkY );
                if ( b > brightestBrightness ) { brightestBrightness = b; brightestY = checkY; }
            }
        }
        endX = nextX; endY = brightestY;
        if ( isBrightPoint( parent.displayImage, nextX, endY, brightnessThreshold ) )
            trailPoints.push( { x: endX, y: endY } );
        steps++;
    }
}

function findTrailDirection( parent, startX, startY, searchRadius, brightnessThreshold, startAngle, angleRange )
{
    const numDirections = 18, angleIncrement = angleRange / numDirections;
    let bestDirection = null, bestSum = 0;
    for ( let i = 0; i <= numDirections; i++ )
    {
        const angle = startAngle + i * angleIncrement;
        const d = { dx: FMath.cos(angle), dy: FMath.sin(angle) };
        let sum = 0, valid = 0;
        for ( let step = -searchRadius; step <= searchRadius; step++ )
        {
            let x = startX + step*d.dx, y = startY + step*d.dy;
            if ( isPointWithinImageBounds( parent.displayImage, x, y ) )
            { sum += getPointBrightness( parent.displayImage, x, y ); valid++; }
        }
        if ( valid > 0 ) sum /= valid;
        if ( sum > bestSum ) { bestSum = sum; bestDirection = d; }
    }
    return (bestDirection && bestSum > brightnessThreshold) ? bestDirection : null;
}

function isPointWithinImageBounds( image, x, y )
{ return x >= 0 && x < image.width && y >= 0 && y < image.height; }

function getPointBrightness( image, x, y )
{
    let b = 0;
    for ( let c = 0; c < image.numberOfChannels; c++ ) b += image.sample(x,y,c);
    return b / image.numberOfChannels;
}

function isBrightPoint( image, x, y, threshold )
{ return getPointBrightness(image,x,y) > threshold; }

function isPointInShape( x, y, shape )
{
    let crossings = 0;
    for ( let i = 0; i < shape.length; i++ )
    {
        let x1 = shape[i].x, y1 = shape[i].y;
        let x2 = shape[(i+1)%shape.length].x, y2 = shape[(i+1)%shape.length].y;
        if ( ((y1<=y && y<y2)||(y2<=y && y<y1)) && (x < (x2-x1)*(y-y1)/(y2-y1)+x1) )
            crossings++;
    }
    return crossings%2 !== 0;
}

function calculateFreehandCenterAndRadius( shape )
{
    let sumX = 0, sumY = 0;
    const n = shape.length;
    for (let i = 0; i < n; ++i) { sumX += shape[i].x; sumY += shape[i].y; }

    const cx = sumX/n, cy = sumY/n;
    let maxD2 = 0;
    for (let i = 0; i < n; ++i)
    {
        const dx = shape[i].x-cx, dy = shape[i].y-cy;
        const d2 = dx*dx + dy*dy;
        if (d2 > maxD2) maxD2 = d2;
    }
    return { centerX:cx, centerY:cy, radius:FMath.sqrt(maxD2) };
}
function compileShape(shape)
{
    const n = shape.length;
    const edges = new Array(n);
    let minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;

    for (let i = 0; i < n; ++i)
    {
        const a = shape[i], b = shape[(i+1) % n];
        const dx=b.x-a.x, dy=b.y-a.y;
        edges[i] = {
            x1:a.x,y1:a.y,x2:b.x,y2:b.y,dx:dx,dy:dy,len2:dx*dx+dy*dy,
            minX:FMath.min(a.x,b.x), maxX:FMath.max(a.x,b.x),
            minY:FMath.min(a.y,b.y), maxY:FMath.max(a.y,b.y)
        };
        if (a.x < minX) minX=a.x;
        if (a.x > maxX) maxX=a.x;
        if (a.y < minY) minY=a.y;
        if (a.y > maxY) maxY=a.y;
    }
    return { edges:edges, minX:minX, minY:minY, maxX:maxX, maxY:maxY };
}

function isPointInCompiledShape(x, y, compiled)
{
    if (x < compiled.minX || x > compiled.maxX || y < compiled.minY || y > compiled.maxY)
        return false;

    let crossings = 0;
    const edges = compiled.edges;
    for (let i = 0, n = edges.length; i < n; ++i)
    {
        const e = edges[i];
        if (((e.y1 <= y && y < e.y2) || (e.y2 <= y && y < e.y1)) &&
            x < (e.x2-e.x1)*(y-e.y1)/(e.y2-e.y1) + e.x1)
            ++crossings;
    }
    return (crossings & 1) !== 0;
}

function getMinDistanceToCompiledEdge(x, y, compiled)
{
    let minD2 = Infinity;
    const edges = compiled.edges;
    for (let i = 0, n = edges.length; i < n; ++i)
    {
        const e = edges[i];
        const d = pointLineDistanceSquared(x,y,e.x1,e.y1,e.x2,e.y2);
        if (d < minD2) minD2 = d;
    }
    return FMath.sqrt(minD2);
}


// ============================================================================
// Fast math / local pixel-cache helpers
// ============================================================================

// PJSR exposes Image.getSamples(), which reads an entire rectangular channel
// in one native call. For the small/medium ROIs used by blemish correction,
// this is substantially faster than thousands of Image.sample() calls.
// We keep a size guard to avoid excessive JS heap use on unusually huge radii.
const FAST_CACHE_MAX_SAMPLES = 750000;

// Above this estimated tuple count, Freehand uses a frozen source image and
// tile-at-a-time writes instead of retaining the complete result in a JS array.
// This bounds JavaScript heap growth for very large Freehand regions.
const FREEHAND_STREAM_TUPLE_THRESHOLD = 300000;
const FREEHAND_STREAM_TILE = 256;

function medianArray(a)
{
    const n = a.length;
    if (n === 0) return NaN;
    if (n === 1) return a[0];
    if (n === 2) return (a[0] + a[1]) * 0.5;

    // V8's native Array.sort is substantially faster than a JavaScript
    // insertion sort for the larger local sample sets used by circle masks.
    a.sort(function(x, y) { return x - y; });
    const m = n >> 1;
    return (n & 1) ? a[m] : (a[m - 1] + a[m]) * 0.5;
}

function median3(a, b, c)
{
    let t1, t2, t3;
    if (a > b) { t1 = a; a = b; b = t1; }
    if (b > c) { t2 = b; b = c; c = t2; }
    if (a > b) { t3 = a; a = b; b = t3; }
    return b;
}

function median3OrLess(a, n)
{
    if (n === 1) return a[0];
    if (n === 2) return (a[0] + a[1]) * 0.5;
    return median3(a[0], a[1], a[2]);
}

function medianUpTo3(a, b, c, n)
{
    if (n === 0) return NaN;
    if (n === 1) return a;
    if (n === 2) return (a + b) * 0.5;
    return median3(a,b,c);
}

function median4(a,b,c,d)
{
    if (a>b) { let t=a;a=b;b=t; }
    if (c>d) { let t=c;c=d;d=t; }
    if (a>c) { let t=a;a=c;c=t; }
    if (b>d) { let t=b;b=d;d=t; }
    if (b>c) { let t=b;b=c;c=t; }
    return (b+c)*0.5;
}

function medianUpTo5(a,b,c,d,e,n)
{
    if (n === 0) return NaN;
    if (n === 1) return a;
    if (n === 2) return (a+b)*0.5;
    if (n === 3) return median3(a,b,c);
    if (n === 4) return median4(a,b,c,d);

    // Sorting network for five values; return the middle element.
    if (a>b) { let t=a;a=b;b=t; }
    if (d>e) { let t=d;d=e;e=t; }
    if (c>e) { let t=c;c=e;e=t; }
    if (c>d) { let t=c;c=d;d=t; }
    if (a>d) { let t=a;a=d;d=t; }
    if (a>c) { let t=a;a=c;c=t; }
    if (b>e) { let t=b;b=e;e=t; }
    if (b>d) { let t=b;b=d;d=t; }
    if (c>d) { let t=c;c=d;d=t; }
    if (b>c) { let t=b;b=c;c=t; }
    return c;
}

function makeDiskMask(radius, step)
{
    const out = [];
    const r2 = radius * radius;
    for (let dx = -radius; dx <= radius; dx += step)
        for (let dy = -radius; dy <= radius; dy += step)
        {
            const d2 = dx*dx + dy*dy;
            if (d2 <= r2)
                out.push({ dx:dx, dy:dy, d:FMath.sqrt(d2) });
        }
    return out;
}

function makeIntegerDiskMask(radius)
{
    const out = [];
    const r2 = radius * radius;
    for (let dx = -radius; dx <= radius; ++dx)
        for (let dy = -radius; dy <= radius; ++dy)
        {
            const d2 = dx*dx + dy*dy;
            if (d2 <= r2)
                out.push({ dx:dx, dy:dy, d:FMath.sqrt(d2) });
        }
    return out;
}

// Keep the reusable disk-mask cache bounded. Without a cap, a user who
// draws many different circle radii can accumulate large JavaScript arrays.
const DISK_MASK_CACHE_LIMIT = 16;
var _diskMaskCache = new Map;

function getDiskMask(radius, step)
{
    const key = step + ":" + radius;
    let m = _diskMaskCache.get(key);

    if (!m)
    {
        m = makeDiskMask(radius, step);
        _diskMaskCache.set(key, m);

        // FIFO eviction keeps the cache bounded in both entry count and memory.
        while ( _diskMaskCache.size > DISK_MASK_CACHE_LIMIT )
            _diskMaskCache.delete( _diskMaskCache.keys().next().value );
    }

    return m;
}


function sixRingOffsets(radius)
{
    const s = radius * FMath.sqrt(3);
    const k = FMath.PI / 3;
    const out = new Array(6);
    for (let i = 0; i < 6; ++i)
        out[i] = { x:FMath.cos(k*i)*s, y:FMath.sin(k*i)*s };
    return out;
}

function clampRectAround(x, y, extent, width, height)
{
    const x0 = FMath.max(0, FMath.floor(x - extent));
    const y0 = FMath.max(0, FMath.floor(y - extent));
    const x1 = FMath.min(width, FMath.ceil(x + extent) + 1);
    const y1 = FMath.min(height, FMath.ceil(y + extent) + 1);
    return new Rect(x0, y0, x1, y1);
}

function LocalImageCache(image, rect, channels)
{
    this.image = image;
    this.x0 = rect.x0;
    this.y0 = rect.y0;
    this.w  = rect.x1 - rect.x0;
    this.h  = rect.y1 - rect.y0;

    // getSamples() requires the entire Rect to be inside the image.
    // Freehand replacement-source tiles can legitimately extend outside the
    // image near an edge, so disable bulk caching for those tiles and let
    // sample() fall back to the native Image.sample() path.
    this.rectValid = this.x0 >= 0 && this.y0 >= 0 &&
                     rect.x1 <= image.width && rect.y1 <= image.height &&
                     this.w > 0 && this.h > 0;
    this.enabled = this.rectValid && this.w*this.h <= FAST_CACHE_MAX_SAMPLES;
    this.data = [];

    if (!this.enabled) return;

    for (let i = 0; i < channels.length; ++i)
    {
        const c = channels[i];
        const a = [];
        image.getSamples(a, rect, c);
        this.data[c] = a;
    }
}

LocalImageCache.prototype.sample = function(x, y, c)
{
    // All native Image.sample() calls go through one hard boundary check.
    // PJSR rejects coordinates equal to width/height, and some generated
    // floating-point coordinates can land a tiny amount outside the image.
    if (!isFinite(x) || !isFinite(y) || c < 0 || c >= this.image.numberOfChannels)
        return 0;

    const maxX = this.image.width - 1;
    const maxY = this.image.height - 1;
    const sx = FMath.min(maxX, FMath.max(0, x));
    const sy = FMath.min(maxY, FMath.max(0, y));
    const ix = FMath.floor(sx);
    const iy = FMath.floor(sy);

    if (!this.enabled)
        return this.image.sample(ix, iy, c);

    const lx = ix - this.x0, ly = iy - this.y0;
    if (lx < 0 || lx >= this.w || ly < 0 || ly >= this.h)
        return this.image.sample(ix, iy, c);

    const a = this.data[c];
    if (a) return a[ly*this.w + lx];
    return this.image.sample(ix, iy, c);
};

function makeReadCache(image, cx, cy, radius, channels, explicitExtent)
{
    const extent = explicitExtent === undefined ? radius * (1 + FMath.sqrt(3)) + 2 : explicitExtent;
    const rect = clampRectAround(cx, cy, extent, image.width, image.height);
    return new LocalImageCache(image, rect, channels);
}

// Bulk median reader for the Freehand source circles.
// The current optimized Freehand path uses integer addressing for these source
// pixels, then reads the required rectangular image data with getSamples().
// All seven source-circle medians for one channel are computed from the same
// bounded set of bulk reads.
const FREEHAND_MEDIAN_TILE_ROWS = 256;

function collectFreehandCircleMediansBulk(image, centerX, centerY, radius,
                                          ring, sourceDX, sourceDY, channels)
{
    const width=image.width, height=image.height;
    const nOffsets=sourceDX.length;
    const sourceCentersX=new Array(7);
    const sourceCentersY=new Array(7);

    let minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;

    for(let i=0;i<7;++i)
    {
        const sx=i===0 ? centerX : FMath.round(centerX+ring[i-1].x);
        const sy=i===0 ? centerY : FMath.round(centerY+ring[i-1].y);
        sourceCentersX[i]=sx;
        sourceCentersY[i]=sy;

        if(sx<0 || sx>=width || sy<0 || sy>=height)
            continue;

        for(let m=0;m<nOffsets;++m)
        {
            const rawX=sx+sourceDX[m], rawY=sy+sourceDY[m];
            if(rawX<0 || rawX>=width || rawY<0 || rawY>=height)
                continue;

            const ix=FMath.round(rawX), iy=FMath.round(rawY);
            if(ix<0 || ix>=width || iy<0 || iy>=height)
                continue;

            if(ix<minX) minX=ix;
            if(ix>maxX) maxX=ix;
            if(iy<minY) minY=iy;
            if(iy>maxY) maxY=iy;
        }
    }

    const result=[];
    for(let c=0;c<image.numberOfChannels;++c)
        result[c]=new Array(7);

    if(!isFinite(minX) || !isFinite(minY) || maxX<minX || maxY<minY)
    {
        for(let q=0;q<channels.length;++q)
        {
            const c=channels[q];
            for(let i=0;i<7;++i) result[c][i]=Number.NaN;
        }
        return result;
    }

    const rectW=maxX-minX+1;
    const rectH=maxY-minY+1;
    const tileRows=FREEHAND_MEDIAN_TILE_ROWS;

    for(let q=0;q<channels.length;++q)
    {
        const c=channels[q];
        const medVals=new Array(7);
        for(let i=0;i<7;++i) medVals[i]=[];

        // The full bounding rectangle is read in bounded-height tiles. Every
        // source point is mapped into the corresponding tile and read directly
        // from the native bulk array.
        for(let ty=minY;ty<=maxY;ty+=tileRows)
        {
            const ty1=FMath.min(maxY,ty+tileRows-1);
            const tileRect=new Rect(minX,ty,maxX+1,ty1+1);
            const tileH=ty1-ty+1;
            const data=[];

            image.getSamples(data,tileRect,c);

            for(let i=0;i<7;++i)
            {
                const sx=sourceCentersX[i], sy=sourceCentersY[i];
                if(sx<0 || sx>=width || sy<0 || sy>=height)
                    continue;

                for(let m=0;m<nOffsets;++m)
                {
                    const rawX=sx+sourceDX[m], rawY=sy+sourceDY[m];
                    if(rawX<0 || rawX>=width || rawY<0 || rawY>=height)
                        continue;

                    const ix=FMath.round(rawX), iy=FMath.round(rawY);
                    if(ix<minX || ix>maxX || iy<ty || iy>ty1)
                        continue;

                    medVals[i].push(data[(iy-ty)*rectW+(ix-minX)]);
                }
            }
        }

        for(let i=0;i<7;++i)
            result[c][i]=medianArray(medVals[i]);
    }

    return result;
}

function makeTrailReadCache(image, trail, size)
{
    const extent = 4*size + FMath.floor(size/2) + 3;
    const x0 = FMath.max(0, FMath.floor(FMath.min(trail.start.x, trail.end.x) - extent));
    const y0 = FMath.max(0, FMath.floor(FMath.min(trail.start.y, trail.end.y) - extent));
    const x1 = FMath.min(image.width,  FMath.ceil(FMath.max(trail.start.x, trail.end.x) + extent) + 1);
    const y1 = FMath.min(image.height, FMath.ceil(FMath.max(trail.start.y, trail.end.y) + extent) + 1);
    const channels = [];
    for (let c=0; c<image.numberOfChannels; ++c) channels.push(c);
    return new LocalImageCache(image, new Rect(x0,y0,x1,y1), channels);
}

// ============================================================================
// MedianCalculator
// ============================================================================

function MedianCalculator()
{
    this.calculate = medianArray;
}

// ============================================================================
// Star helpers
// ============================================================================

var _fwhmCircle = [];
for (let theta = 0; theta < 360; ++theta)
{
    const a = theta * FMath.PI / 180;
    _fwhmCircle.push({ x:FMath.cos(a), y:FMath.sin(a) });
}

function starCentroid( img_x, img_y, radius, image )
{
    let maxB = -Infinity, bestX = img_x, bestY = img_y;
    const r2 = radius * radius;
    const x0 = FMath.max(0, img_x - radius);
    const x1 = FMath.min(image.width, img_x + radius);
    const y0 = FMath.max(0, img_y - radius);
    const y1 = FMath.min(image.height, img_y + radius);
    const cache = makeReadCache(image, img_x, img_y, radius, [0]);

    for (let y = y0; y < y1; ++y)
        for (let x = x0; x < x1; ++x)
            if ((x-img_x)*(x-img_x) + (y-img_y)*(y-img_y) <= r2)
            {
                const b = cache.sample(x,y,0);
                if (b > maxB) { maxB = b; bestX = x; bestY = y; }
            }

    return { x:bestX, y:bestY, FWHM:calculateFWHM(bestX,bestY,image) };
}

function calculateFWHM( starX, starY, image )
{
    const radius = 50;
    const profile = new Array(radius + 1);
    const cache = makeReadCache(image, starX, starY, radius, [0], radius + 2);

    for (let r = 0; r <= radius; ++r)
    {
        let sum = 0, count = 0;
        for (let i = 0; i < 360; ++i)
        {
            const u = _fwhmCircle[i];
            const x = FMath.round(starX + r*u.x);
            const y = FMath.round(starY + r*u.y);
            if (x >= 0 && x < image.width && y >= 0 && y < image.height)
            {
                sum += cache.sample(x,y,0);
                ++count;
            }
        }
        profile[r] = count ? sum/count : 0;
    }

    let maxI = profile[0];
    for (let i = 1; i < profile.length; ++i)
        if (profile[i] > maxI) maxI = profile[i];

    const halfMax = maxI * 0.5;
    for (let r = 0; r < profile.length; ++r)
        if (profile[r] <= halfMax) return r;
    return radius;
}

function getMinDistanceToEdge( x, y, shape )
{
    let minD2 = Infinity;
    for (let i = 0, n = shape.length; i < n; ++i)
    {
        const a = shape[i], b = shape[(i+1)%n];
        const d = pointLineDistanceSquared(x,y,a.x,a.y,b.x,b.y);
        if (d < minD2) minD2 = d;
    }
    return FMath.sqrt(minD2);
}

function pointLineDistanceSquared( px,py, x1,y1, x2,y2 )
{
    const A = px-x1, B = py-y1, C = x2-x1, D = y2-y1;
    const len2 = C*C + D*D;
    if (len2 === 0) return A*A + B*B;

    let t = (A*C + B*D) / len2;
    if (t < 0) t = 0;
    else if (t > 1) t = 1;

    const dx = px - (x1 + t*C);
    const dy = py - (y1 + t*D);
    return dx*dx + dy*dy;
}

// Rasterize a polygon into horizontal pixel spans.
// rows[ y-minY ] = [ [x0,x1], [x0,x1], ... ]
// This is deliberately allocation-light: one intersections array per scanline.
function buildFreehandRows(compiled, minY, maxY, minX, maxX)
{
    const h=maxY-minY+1;
    const rows=new Array(h);
    const edges=compiled.edges;
    const eps=1e-12;

    for (let yy=minY; yy<=maxY; ++yy)
    {
        const scanY=yy+0.5;
        const xs=[];

        for (let i=0, n=edges.length; i<n; ++i)
        {
            const e=edges[i];
            const y1=e.y1, y2=e.y2;

            // Half-open edge rule prevents double-counting vertices.
            if ((y1 <= scanY && scanY < y2) || (y2 <= scanY && scanY < y1))
            {
                const t=(scanY-y1)/(y2-y1);
                const x=e.x1+t*(e.x2-e.x1);
                if (x>=minX-1 && x<=maxX+1) xs.push(x);
            }
        }

        xs.sort(function(a,b){ return a-b; });

        const spans=[];
        for (let i=0; i+1<xs.length; i+=2)
        {
            let x0=FMath.ceil(xs[i]-0.5);
            let x1=FMath.floor(xs[i+1]-0.5);

            if (x0<minX) x0=minX;
            if (x1>maxX) x1=maxX;

            if (x0<=x1) spans.push([x0,x1]);
        }

        rows[yy-minY]=spans;
    }

    return rows;
}

// ============================================================================
// configurePixelMath
// ============================================================================

function configurePixelMath( P )
{
    P.clearImageCacheAndExit=false; P.cacheGeneratedImages=false;
    P.generateOutput=true; P.singleThreaded=false; P.optimization=true;
    P.use64BitWorkingImage=false; P.rescale=false;
    P.rescaleLower=0; P.rescaleUpper=1; P.truncate=true; P.truncateLower=0; P.truncateUpper=1;
    P.createNewImage=false; P.showNewImage=false;
    P.newImageId=""; P.newImageWidth=0; P.newImageHeight=0; P.newImageAlpha=false;
    P.newImageColorSpace=PixelMath.SameAsTarget; P.newImageSampleFormat=PixelMath.SameAsTarget;
}

// ============================================================================
// ScrollControl
//
// V8 MEMORY FIX SUMMARY:
//  - _cachedBitmap stores the last render() result.
//  - onPaint reuses _cachedBitmap; only calls render() when cache is null.
//  - invalidateRenderCache() calls bitmap.clear() (explicit dealloc) before
//    nulling the reference — critical on V8/Apple Silicon where the GC will
//    NOT collect Bitmap objects promptly on its own.
//  - Every code path that changes displayImage calls invalidateRenderCache()
//    first, ensuring the old Bitmap is freed before the new one is allocated.
// ============================================================================

class ScrollControl extends ScrollBox
{
    constructor( parent )
    {
        super( parent );
        // Keep an explicit JavaScript reference to the owning dialog.
        // ScrollBox.parent is a native/control-parent property and is not
        // guaranteed to be the BlemishEraserDialog object.
        this._bbOwner = parent;
        this.autoScroll = true;
        this.tracking   = true;

        this.displayImage       = null;
        this.displayImageWindow = null;
        this.displaySTF         = null;
        // True when the source View STF is enabled. When false, the source
        // image is already being displayed in its native nonlinear state and
        // must not receive any STF transformation in the preview.
        this.displaySTFEnabled  = true;
        // Guard against queued paint events touching an Image whose native
        // instance was already destroyed with a temporary ImageWindow.
        this.displayImageValid  = false;
        this.dragging           = false;
        this.dragOrigin         = new Point(0,0);
        this.currentCircle      = null;
        this.currentLine        = null;
        this.satelliteTrails    = [];
        this.freehandShapes     = [];
        this.currentFreehandShape = null;
        this.blemishPoints      = [];

        // V8 render cache
        this._cachedBitmap = null;
        this._scaledBitmap = null;

        this.viewport.cursor = new Cursor( StdCursor.Cross );

        // Ctrl-Z is an application-level undo shortcut. PJSR controls can receive
        // either key-press or key-down events depending on which child has focus.
        // Handle both so the shortcut works while drawing, after Execute, and after Undo.
        this._isCtrlZ = function( key, modifiers )
        {
            let controlMask = 0x04000000;
            try { if ( typeof KeyboardModifier !== "undefined" && KeyboardModifier.ControlModifier !== undefined ) controlMask = KeyboardModifier.ControlModifier; } catch ( e ) {}
            try { if ( typeof KeyModifier !== "undefined" && KeyModifier.Control !== undefined ) controlMask = KeyModifier.Control; } catch ( e ) {}
            return (key===90 || key===122 || (typeof KeyCode !== "undefined" && key===KeyCode.Z)) && ((modifiers & controlMask) !== 0);
        };
        this.viewport.onKeyPress=(key, modifiers)=>
        {
            if ( this._bbOwner && this._isCtrlZ(key,modifiers) ) return this._bbOwner.undoLastBlemishRemoval(), false;
            return true;
        };
        this.viewport.onKeyDown=(key, modifiers)=>
        {
            if ( this._bbOwner && this._isCtrlZ(key,modifiers) ) return this._bbOwner.undoLastBlemishRemoval(), false;
            return true;
        };

        this.zoom = 1; this.scale = 1;
        this.zoomOutLimit = -5; this.minZoomFactor = 0.05; this.maxZoomFactor = 4;
        this.currentMousePosition = { x:0, y:0 };
        this.tempImageStack = []; this.undoStack = []; this.redoStack = [];
        this.executeCounter = 0;
        this.unappliedChanges = false;
        this.onStatusUpdate = null;

        this.viewport.onResize = () => { this.initScrollBars(); };
        this.onHorizontalScrollPosUpdated = x => { this.viewport.update(); };
        this.onVerticalScrollPosUpdated   = y => { this.viewport.update(); };

        this.viewportToImage = ( x, y ) =>
        {
            let ox = this.maxHorizontalScrollPosition > 0 ? -this.horizontalScrollPosition : (this.viewport.width - (this._scaledBitmap ? this._scaledBitmap.width : 0))/2;
            let oy = this.maxVerticalScrollPosition > 0 ? -this.verticalScrollPosition : (this.viewport.height - (this._scaledBitmap ? this._scaledBitmap.height : 0))/2;
            return new Point( (x-ox)/this.scale, (y-oy)/this.scale );
        };

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            let p = this.viewportToImage(x,y);
            let ax = p.x, ay = p.y;
            if ( modifiers===1 ) // Shift
            {
                if ( parameters.drawingMode==="Circle" )
                    this.currentCircle = { x:ax, y:ay, radius:0 };
                else if ( parameters.drawingMode==="Freehand" )
                    this.currentFreehandShape = [{ x:ax, y:ay }];
            }
            else if ( modifiers===4 ) { detectAndDrawSatelliteTrail( this, ax, ay ); } // Ctrl
            else if ( modifiers===2 ) // Alt
            {
                if ( !this.currentLine ) this.currentLine = { start:{x:ax,y:ay}, end:null };
                else { this.currentLine.end={x:ax,y:ay}; this.satelliteTrails.push(this.currentLine); this.currentLine=null; }
            }
            else if ( button===2 ) { this.removeClosestElement(ax,ay); }
            else { this.viewport.cursor=new Cursor(StdCursor.ClosedHand); this.dragOrigin.x=x; this.dragOrigin.y=y; this.dragging=true; }
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            let p = this.viewportToImage(x,y);
            let ax = p.x, ay = p.y;
            this.currentMousePosition = { x:ax, y:ay };
            if ( this.onStatusUpdate ) this.onStatusUpdate( this.getZoomText(), ax, ay );
            if ( this.currentCircle ) { let dx=ax-this.currentCircle.x, dy=ay-this.currentCircle.y; this.currentCircle.radius=FMath.sqrt(dx*dx+dy*dy); }
            if ( this.currentFreehandShape ) this.currentFreehandShape.push({x:ax,y:ay});
            if ( this.currentLine && modifiers===2 ) this.currentLine.end={x:ax,y:ay};
            if ( this.dragging )
            {
                let dx=(this.dragOrigin.x-x)/this.scale, dy=(this.dragOrigin.y-y)/this.scale;
                this.horizontalScrollPosition=this.horizontalScrollPosition+dx; this.verticalScrollPosition=this.verticalScrollPosition+dy;
                this.dragOrigin.x=x; this.dragOrigin.y=y;
            }
            this.viewport.update();
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.Cross );
            this.dragging = false;
            if ( this.currentCircle && this.currentCircle.radius>0 )
            { this.placeBlemishPoint(this.currentCircle.x,this.currentCircle.y,this.currentCircle.radius); this.currentCircle=null; }
            if ( this.currentFreehandShape && this.currentFreehandShape.length>2 )
            { this.currentFreehandShape.push(this.currentFreehandShape[0]); this.placeFreehandShape(this.currentFreehandShape); this.currentFreehandShape=null; }
            if ( this.currentLine && this.currentLine.end )
            { this.satelliteTrails.push(this.currentLine); this.currentLine=null; }
        };

        this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
        {
            if ( !this.displayImage || delta === 0 ) return;

            const refPoint = new Point(x,y);
            const forwardZoomsIn = parameters.wheelDirection === "Forward";
            const zoomIn = forwardZoomsIn ? delta > 0 : delta < 0;

            if ( zoomIn )
                this.UpdateZoom(this.zoom+1,refPoint);
            else
                this.UpdateZoom(this.zoom-1,refPoint);
        };

        // onPaint: V8 uses Graphics (VectorGraphics was removed in the V8 runtime).
        // The preview bitmap is already scaled, so overlays are converted directly
        // from image coordinates to viewport coordinates. This avoids graphics
        // transformation calls entirely and keeps zoom centered on the cursor.
        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let graphics = new Graphics( this.viewport );
            graphics.fillRect( x0, y0, x1, y1, new Brush( 0xff202020 ) );

            if ( !this.displayImageValid || !this._scaledBitmap )
            {
                graphics.end();
                return;
            }

            const offsetX = this.maxHorizontalScrollPosition > 0
                ? -this.horizontalScrollPosition
                : (this.viewport.width - this._scaledBitmap.width) / 2;
            const offsetY = this.maxVerticalScrollPosition > 0
                ? -this.verticalScrollPosition
                : (this.viewport.height - this._scaledBitmap.height) / 2;

            graphics.drawBitmap( offsetX, offsetY, this._scaledBitmap );

            // Convert image-space coordinates to viewport-space coordinates.
            const sx = (x) => offsetX + x * this.scale;
            const sy = (y) => offsetY + y * this.scale;

            graphics.antialiasing = true;
            graphics.pen = new Pen( 0xffffff00, 1 );

            if ( this.currentCircle )
                graphics.drawCircle(
                    sx( this.currentCircle.x ),
                    sy( this.currentCircle.y ),
                    this.currentCircle.radius * this.scale );

            if ( this.currentLine )
            {
                graphics.pen = new Pen( 0xffff00ff, 1 );
                const ex = this.currentLine.end ? this.currentLine.end.x : this.currentMousePosition.x;
                const ey = this.currentLine.end ? this.currentLine.end.y : this.currentMousePosition.y;
                graphics.drawLine(
                    sx( this.currentLine.start.x ), sy( this.currentLine.start.y ),
                    sx( ex ), sy( ey ) );
            }

            graphics.pen = new Pen( 0xffff00ff, 1 );
            for ( let i = 0; i < this.satelliteTrails.length; ++i )
            {
                const tr = this.satelliteTrails[i];
                graphics.drawLine(
                    sx( tr.start.x ), sy( tr.start.y ),
                    sx( tr.end.x ), sy( tr.end.y ) );
            }

            graphics.pen = new Pen( 0xff00ff00, 1 );
            for ( let i = 0; i < this.blemishPoints.length; ++i )
            {
                const bp = this.blemishPoints[i];
                graphics.drawCircle(
                    sx( bp.x ), sy( bp.y ), bp.radius * this.scale );
            }

            for ( let i = 0; i < this.freehandShapes.length; ++i )
            {
                const shp = this.freehandShapes[i];
                for ( let j = 0; j < shp.length - 1; ++j )
                    graphics.drawLine(
                        sx( shp[j].x ), sy( shp[j].y ),
                        sx( shp[j+1].x ), sy( shp[j+1].y ) );
            }

            if ( this.currentFreehandShape && this.currentFreehandShape.length > 1 )
                for ( let j = 0; j < this.currentFreehandShape.length - 1; ++j )
                    graphics.drawLine(
                        sx( this.currentFreehandShape[j].x ), sy( this.currentFreehandShape[j].y ),
                        sx( this.currentFreehandShape[j+1].x ), sy( this.currentFreehandShape[j+1].y ) );

            graphics.end();
        };


        this.initScrollBars();
    }

    // Apply the captured View STF to a display-only image without invoking
    // HistogramTransformation. This keeps the Process Console quiet while
    // preserving the STF's display mapping.
    applyDisplaySTF( image )
    {
        if ( !image || !this.displaySTF || !this.displaySTFEnabled )
            return;

        const stf = this.displaySTF;
        const count = image.numberOfNominalChannels;
        const I = new Array(count);
        for ( let c = 0; c < count; ++c )
            I[c] = new ImageIterator( image, c );

        for ( let c = 0; c < count; ++c )
        {
            const it = I[c];
            const row = stf[Math.min(c,2)];
            const c0 = row[1];
            const m  = row[0];
            const c1 = row[2];
            const r0 = row[3];
            const r1 = row[4];

            if ( c1 <= c0 )
            {
                const low = c0;
                const high = r1;
                const lowOut = r0;
                for ( let y = 0; y < it.height; ++y )
                    for ( let x = 0; x < it.width; ++x )
                    {
                        const v = it.toReal(it[y][x]);
                        const out = v < low ? lowOut : high;
                        it[y][x] = image.isInteger ? it.toSample(out) : out;
                    }
            }
            else if ( image.isInteger )
            {
                const invRange = 1 / (c1 - c0);
                const outRange = r1 - r0;
                for ( let y = 0; y < it.height; ++y )
                    for ( let x = 0; x < it.width; ++x )
                    {
                        let v = it.toReal(it[y][x]);
                        v = FMath.max(0, FMath.min(1, (v-c0)*invRange));
                        v = FMath.mtf(m, v);
                        v = r0 + outRange*v;
                        it[y][x] = it.toSample(v);
                    }
            }
            else
            {
                const invRange = 1 / (c1 - c0);
                const outRange = r1 - r0;
                for ( let y = 0; y < it.height; ++y )
                    for ( let x = 0; x < it.width; ++x )
                    {
                        let v = it[y][x];
                        v = FMath.max(0, FMath.min(1, (v-c0)*invRange));
                        v = FMath.mtf(m, v);
                        it[y][x] = r0 + outRange*v;
                    }
            }
        }
    }

    renderSTFBitmap()
    {
        // Always render the source image. If the source View STF is disabled,
        // render the image exactly as-is; do not apply any STF transformation.
        if ( !this.displayImage ) return null;

        let w = null;
        try
        {
            w = new ImageWindow(
                this.displayImage.width, this.displayImage.height,
                this.displayImage.numberOfChannels, this.displayImage.bitsPerSample,
                this.displayImage.isReal, this.displayImage.isColor, "BB_STF_Render" );

            w.mainView.beginProcess( UndoFlag.NoSwapFile );
            w.mainView.image.apply( this.displayImage );
            w.mainView.endProcess();

            // Transform only the disposable display copy when the source View
            // STF is enabled. With STF disabled, leave the image untouched.
            if ( this.displaySTFEnabled && this.displaySTF )
            {
                w.mainView.beginProcess( UndoFlag.NoSwapFile );
                this.applyDisplaySTF( w.mainView.image );
                w.mainView.endProcess();
            }

            let bmp = new Bitmap( this.displayImage.width, this.displayImage.height );
            bmp.assign( w.mainView.image.render() );
            return bmp;
        }
        catch ( e )
        {
            console.warningln( "Blemish Blaster STF preview render failed: ", e );
            return null;
        }
        finally
        {
            try { if ( w ) w.forceClose(); } catch ( e ) {}
        }
    }

    // Explicitly free the cached Bitmap — must be called before any image change
    invalidateRenderCache()
    {
        // Do not clear a bitmap synchronously while an onPaint may still be
        // using it. Drop the references; doUpdateImage() releases old bitmaps
        // only after a replacement has been built.
        this._scaledBitmap = null;
        this._cachedBitmap = null;
    }

    getImage() { return this.displayImage; }

    doUpdateImage( image )
    {
        // Replace the preview bitmap while preserving the user's current
        // zoom and image location.  On Execute/Undo the image dimensions do
        // not change, so the same image-space point can remain under the
        // center of the viewport.
        const hadView = !!this._cachedBitmap && !!this.displayImage;
        const oldZoom = this.zoom;
        const refPoint = new Point(this.viewport.width/2, this.viewport.height/2);
        const anchor = hadView ? this.viewportToImage(refPoint.x, refPoint.y) : null;

        this.displayImage = image;
        this.displayImageValid = !!image;

        let newBitmap = null;
        if ( image )
        {
            newBitmap = this.renderSTFBitmap();
            if ( !newBitmap )
                console.warningln( "Blemish Blaster: Preview bitmap was not generated." );
        }

        // Keep old bitmap objects alive until the new bitmap is completely
        // generated. This avoids a queued onPaint seeing an empty cache.
        const oldScaled = this._scaledBitmap;
        const oldCached = this._cachedBitmap;
        this._cachedBitmap = newBitmap;
        this._scaledBitmap = null;

        if ( image )
        {
            this.SetZoomOutLimitFromImage();
            if ( hadView )
            {
                // Rebuild at the previous zoom and restore the same image
                // coordinate beneath the viewport center.
                this.UpdateZoom(oldZoom, refPoint);
                if ( anchor )
                {
                    this.horizontalScrollPosition =
                        FMath.max(0, FMath.min(this.maxHorizontalScrollPosition,
                           anchor.x*this.scale - refPoint.x));
                    this.verticalScrollPosition =
                        FMath.max(0, FMath.min(this.maxVerticalScrollPosition,
                           anchor.y*this.scale - refPoint.y));
                }
            }
            else
            {
                // First image load: fit the whole image, as before.
                this.UpdateZoom(this.zoomOutLimit);
            }
        }
        else
        {
            this.maxHorizontalScrollPosition = 0;
            this.maxVerticalScrollPosition = 0;
            this.horizontalScrollPosition = 0;
            this.verticalScrollPosition = 0;
        }

        // New bitmap is installed and painted before old native bitmaps are
        // released.
        if ( oldScaled && oldScaled !== this._scaledBitmap )
            try { oldScaled.clear(); } catch ( e ) {}
        if ( oldCached && oldCached !== this._cachedBitmap )
            try { oldCached.clear(); } catch ( e ) {}

        if ( this.viewport ) this.viewport.update();
    }

    updateScaledBitmap()
    {
        if ( this._scaledBitmap )
        {
            this._scaledBitmap.clear();
            this._scaledBitmap = null;
        }
        if ( !this._cachedBitmap ) return;
        this._scaledBitmap = this._cachedBitmap.scaled(
            this.scale, this.scale,
            this.scale < 1 ? BitmapInterpolation_Bilinear : BitmapInterpolation_NearestNeighbor );
    }

    getZoomText()
    {
        if ( this.zoom > 0 )
            return format( "%d:1", FMath.round( this.zoom ) );
        return format( "1:%d", FMath.round( -this.zoom + 2 ) );
    }

    UpdateZoom( newZoom, refPoint )
    {
        newZoom = FMath.max(this.zoomOutLimit, FMath.min(4,newZoom));
        if ( newZoom === this.zoom && this._scaledBitmap ) return;

        if ( !refPoint )
            refPoint = new Point(this.viewport.width/2,this.viewport.height/2);

        // Always capture the image coordinate under the reference point, even
        // when the current image is smaller than the viewport and therefore
        // has no scrollable range.  This is essential for 1:1 from Full View:
        // otherwise there is no saved coordinate and the image jumps to (0,0).
        let oldOffsetX = this.maxHorizontalScrollPosition > 0
            ? -this.horizontalScrollPosition
            : (this.viewport.width - (this._scaledBitmap ? this._scaledBitmap.width : 0))/2;
        let oldOffsetY = this.maxVerticalScrollPosition > 0
            ? -this.verticalScrollPosition
            : (this.viewport.height - (this._scaledBitmap ? this._scaledBitmap.height : 0))/2;
        let imgx = this.displayImage ? (refPoint.x - oldOffsetX)/this.scale : null;
        let imgy = this.displayImage ? (refPoint.y - oldOffsetY)/this.scale : null;

        this.zoom = newZoom;
        if ( this.zoom > 0 )
            this.scale = this.zoom;
        else
            this.scale = 1/(-this.zoom + 2);

        this.updateScaledBitmap();

        const sb = this._scaledBitmap;
        const sw = sb ? sb.width : (this.displayImage ? this.displayImage.width*this.scale : 0);
        const sh = sb ? sb.height : (this.displayImage ? this.displayImage.height*this.scale : 0);
        this.maxHorizontalScrollPosition = FMath.max(0, sw-this.viewport.width);
        this.maxVerticalScrollPosition   = FMath.max(0, sh-this.viewport.height);
        this.setHorizontalScrollRange(0,this.maxHorizontalScrollPosition);
        this.setVerticalScrollRange(0,this.maxVerticalScrollPosition);

        if ( this.maxHorizontalScrollPosition > 0 && imgx !== null )
            this.horizontalScrollPosition = imgx*this.scale-refPoint.x;
        else if ( this.maxHorizontalScrollPosition === 0 )
            this.horizontalScrollPosition = 0;
        if ( this.maxVerticalScrollPosition > 0 && imgy !== null )
            this.verticalScrollPosition = imgy*this.scale-refPoint.y;
        else if ( this.maxVerticalScrollPosition === 0 )
            this.verticalScrollPosition = 0;

        this.horizontalScrollPosition = FMath.max(0,FMath.min(this.maxHorizontalScrollPosition,this.horizontalScrollPosition));
        this.verticalScrollPosition = FMath.max(0,FMath.min(this.maxVerticalScrollPosition,this.verticalScrollPosition));
        if ( this.onStatusUpdate ) this.onStatusUpdate( this.getZoomText(), this.currentMousePosition.x, this.currentMousePosition.y );
        if ( this.viewport ) this.viewport.update();
    }

    SetZoomOutLimitFromImage()
    {
        if ( !this.displayImage || !this.viewport || this.viewport.width <= 0 || this.viewport.height <= 0 )
        {
            this.zoomOutLimit = -5;
            return;
        }
        let scaleX = FMath.ceil( this.displayImage.width / this.viewport.width );
        let scaleY = FMath.ceil( this.displayImage.height / this.viewport.height );
        let scale = FMath.max( scaleX, scaleY );
    }

    initScrollBars( scrollPoint )
    {
        let image = this.getImage();
        if ( !image || image.width<=0 || image.height<=0 )
        {
            this.setHorizontalScrollRange(0,0);
            this.setVerticalScrollRange(0,0);
            this.horizontalScrollPosition=0; this.verticalScrollPosition=0;
        }
        else
        {
            const scaledWidth=image.width*this.scale;
            const scaledHeight=image.height*this.scale;
            const maxX=FMath.max(0,scaledWidth-this.viewport.width);
            const maxY=FMath.max(0,scaledHeight-this.viewport.height);
            this.setHorizontalScrollRange(0,maxX);
            this.setVerticalScrollRange(0,maxY);
            this.maxHorizontalScrollPosition=maxX;
            this.maxVerticalScrollPosition=maxY;
            if ( scrollPoint )
            {
                this.horizontalScrollPosition = scrollPoint.x;
                this.verticalScrollPosition = scrollPoint.y;
            }
            this.horizontalScrollPosition=FMath.max(0,FMath.min(maxX,this.horizontalScrollPosition));
            this.verticalScrollPosition=FMath.max(0,FMath.min(maxY,this.verticalScrollPosition));
        }
        if ( this.viewport ) this.viewport.update();
    }

    fullView()
    {
        // Fit the complete image in the preview and center it. This is the
        // equivalent of Mosaic Planner's initial fit-to-view operation.
        this.SetZoomOutLimitFromImage();
        this.UpdateZoom(this.zoomOutLimit);
        this.horizontalScrollPosition = 0;
        this.verticalScrollPosition = 0;
        if ( this.viewport ) this.viewport.update();
    }

    zoomIn()  { this.UpdateZoom(this.zoom+1); if(this.viewport) this.viewport.update(); }
    zoomOut() { this.UpdateZoom(this.zoom-1); if(this.viewport) this.viewport.update(); }

    placeBlemishPoint(x,y,radius)   { this.blemishPoints.push({x,y,radius}); if(this.viewport) this.viewport.update(); }
    placeFreehandShape(shape)        { this.freehandShapes.push(shape);        if(this.viewport) this.viewport.update(); }

    removeClosestElement( x, y )
    {
        let cd=Infinity, ci=-1, ct='';
        for(let i=0;i<this.blemishPoints.length;i++)
        { let d=FMath.sqrt((this.blemishPoints[i].x-x)*(this.blemishPoints[i].x-x)+(this.blemishPoints[i].y-y)*(this.blemishPoints[i].y-y)); if(d<cd){cd=d;ci=i;ct='blemish';} }
        for(let i=0;i<this.satelliteTrails.length;i++)
        { let t=this.satelliteTrails[i]; let d=FMath.min(FMath.sqrt((t.start.x-x)*(t.start.x-x)+(t.start.y-y)*(t.start.y-y)),FMath.sqrt((t.end.x-x)*(t.end.x-x)+(t.end.y-y)*(t.end.y-y))); if(d<cd){cd=d;ci=i;ct='trail';} }
        for(let i=0;i<this.freehandShapes.length;i++)
        { let s=this.freehandShapes[i]; for(let j=0;j<s.length-1;j++){let d=this.distanceToSegment({x,y},s[j],s[j+1]); if(d<cd){cd=d;ci=i;ct='freehand';}}}
        if(ct==='blemish') this.blemishPoints.splice(ci,1);
        else if(ct==='trail') this.satelliteTrails.splice(ci,1);
        else if(ct==='freehand') this.freehandShapes.splice(ci,1);
        if(this.viewport) this.viewport.update();
    }

    distanceToSegment( p, v, w )
    {
        const l2=(v.x-w.x)*(v.x-w.x)+(v.y-w.y)*(v.y-w.y);
        if(l2===0) return FMath.sqrt((p.x-v.x)*(p.x-v.x)+(p.y-v.y)*(p.y-v.y));
        const t=((p.x-v.x)*(w.x-v.x)+(p.y-v.y)*(w.y-v.y))/l2;
        if(t<0) return FMath.sqrt((p.x-v.x)*(p.x-v.x)+(p.y-v.y)*(p.y-v.y));
        if(t>1) return FMath.sqrt((p.x-w.x)*(p.x-w.x)+(p.y-w.y)*(p.y-w.y));
        return FMath.sqrt((p.x-(v.x+t*(w.x-v.x)))*(p.x-(v.x+t*(w.x-v.x)))+(p.y-(v.y+t*(w.y-v.y)))*(p.y-(v.y+t*(w.y-v.y))));
    }


    applyBlemishRemoval()
    {
        const hadCorrections = this.blemishPoints.length > 0 ||
                               this.freehandShapes.length > 0 ||
                               this.satelliteTrails.length > 0;
        const imageWindowId = this.displayImageWindow.mainView.id;
        if (typeof imageWindowId === 'string')
            this.undoStack.push({
                imageId: imageWindowId,
                blemishPoints: JSON.parse(JSON.stringify(this.blemishPoints)),
                satelliteTrails: JSON.parse(JSON.stringify(this.satelliteTrails)),
                freehandShapes: JSON.parse(JSON.stringify(this.freehandShapes))
            });

        this.redoStack = [];
        ++this.executeCounter;

        const tempImageWindow = new ImageWindow(
            this.displayImage.width, this.displayImage.height,
            this.displayImage.numberOfChannels, this.displayImage.bitsPerSample,
            this.displayImage.isReal, this.displayImage.isColor, "TempImage");

        // Register immediately. If Execute throws before normal completion, the
        // temporary window is still known to cleanupAndClose().
        this.tempImageStack.push(tempImageWindow.mainView.id);

        tempImageWindow.mainView.beginProcess(UndoFlag.NoSwapFile);
        tempImageWindow.mainView.image.assign(this.displayImage);
        tempImageWindow.mainView.endProcess();

        const image = tempImageWindow.mainView.image;
        const numChannels = image.numberOfChannels;
        const selectedChannel = parameters.selectedChannel || 0;
        const channelsToProcess = [];

        if (selectedChannel === 0 || numChannels === 1)
            for (let c = 0; c < numChannels; ++c) channelsToProcess.push(c);
        else
            channelsToProcess.push(selectedChannel - 1);

        const applyValues = values =>
        {
            if (values.length === 0) return;
            tempImageWindow.mainView.beginProcess(UndoFlag.NoSwapFile);
            for (let i = 0; i < values.length; i += 4)
                image.setSample(values[i+3], values[i], values[i+1], values[i+2]);
            tempImageWindow.mainView.endProcess();
        };

        const chooseThreeClosest = (circleMedians, centerMedians) =>
        {
            let d1=Infinity,d2=Infinity,d3=Infinity;
            let i1=1,i2=1,i3=1;

            for (let i=1; i<=6; ++i)
                for (let q=0; q<channelsToProcess.length; ++q)
                {
                    const c=channelsToProcess[q];
                    const d=FMath.abs(circleMedians[c][i]-centerMedians[c]);

                    if (d<d1)
                    {
                        d3=d2; i3=i2;
                        d2=d1; i2=i1;
                        d1=d;  i1=i;
                    }
                    else if (d<d2)
                    {
                        d3=d2; i3=i2;
                        d2=d;  i2=i;
                    }
                    else if (d<d3)
                    {
                        d3=d; i3=i;
                    }
                }

            return [i1,i2,i3];
        };

        const processCircle = (centerX, centerY, radius, correctStar, sourceFWHM) =>
        {
            const ring = sixRingOffsets(radius);
            const starFWHM = correctStar ? 0.75*sourceFWHM : 0;
            const readExtent = correctStar
                ? radius*FMath.sqrt(3) + starFWHM + 3
                : radius*(1+FMath.sqrt(3)) + 3;
            const cache = makeReadCache(image, centerX, centerY, radius, channelsToProcess, readExtent);

            const sampleMask = correctStar ? getDiskMask(starFWHM,3) : getDiskMask(radius,3);
            const circleMedians = [];
            for (let c=0; c<numChannels; ++c) circleMedians[c]=[];

            for (let i=0; i<7; ++i)
            {
                const sx=i===0 ? centerX : FMath.round(centerX+ring[i-1].x);
                const sy=i===0 ? centerY : FMath.round(centerY+ring[i-1].y);

                if (sx>=0 && sx<image.width && sy>=0 && sy<image.height)
                {
                    for (let q=0; q<channelsToProcess.length; ++q)
                    {
                        const c=channelsToProcess[q];
                        const vals=[];
                        for (let m=0; m<sampleMask.length; ++m)
                        {
                            const p=sampleMask[m];
                            const px=sx+p.dx, py=sy+p.dy;
                            if (px>=0 && px<image.width && py>=0 && py<image.height)
                                vals.push(cache.sample(px,py,c));
                        }
                        circleMedians[c][i]=medianArray(vals);
                    }
                }
                else
                {
                    for (let q=0; q<channelsToProcess.length; ++q)
                        circleMedians[channelsToProcess[q]][i]=Number.POSITIVE_INFINITY;
                }
            }

            const centerMedians=[];
            for (let q=0; q<channelsToProcess.length; ++q)
            {
                const c=channelsToProcess[q];
                centerMedians[c]=circleMedians[c][0];
            }

            const selected=chooseThreeClosest(circleMedians,centerMedians);
            const values=[];

            if (correctStar)
            {
                // Preserve the original loop's fractional start at
                // -surroundingRadius; only points inside the actual target
                // radius are retained.
                const surroundingRadius=radius*FMath.sqrt(3);
                const targetMask=getDiskMask(surroundingRadius,1);
                const fv=this.parent.featherSlider.value;

                for (let m=0; m<targetMask.length; ++m)
                {
                    const p=targetMask[m];
                    const dx=p.dx, dy=p.dy, dist=p.d;
                    if (dist===0 || dist>radius) continue;

                    const fp=dist<=starFWHM
                        ? (dist/starFWHM)*(dist/starFWHM)
                        : 1;
                    const eff=dist<=radius/2
                        ? 1
                        : 1-(dist-radius/2)/(radius/2);
                    const cff=fv*fp*eff;

                    const cx=FMath.round(centerX+dx);
                    const cy=FMath.round(centerY+dy);
                    if (cx<0 || cx>=image.width || cy<0 || cy>=image.height) continue;

                    for (let q=0; q<channelsToProcess.length; ++q)
                    {
                        const c=channelsToProcess[q];
                        let v0=0,v1=0,v2=0,n=0;

                        for (let k=0; k<3; ++k)
                        {
                            const r=selected[k]-1;
                            const sx=FMath.round(centerX+dx+ring[r].x);
                            const sy=FMath.round(centerY+dy+ring[r].y);

                            if (sx>=0 && sx<image.width && sy>=0 && sy<image.height)
                            {
                                const v=cache.sample(sx,sy,c);
                                if (v<=2*centerMedians[c])
                                {
                                    if (n===0) v0=v;
                                    else if (n===1) v1=v;
                                    else v2=v;
                                    ++n;
                                }
                            }
                        }

                        if(n>0)
                        {
                            const replacement=medianUpTo3(v0,v1,v2,n);
                            const original=cache.sample(cx,cy,c);
                            values.push(cx,cy,c,cff*replacement+(1-cff)*original);
                        }
                    }
                }
            }
            else
            {
                const fv=this.parent.featherSlider.value;
                const ov=this.parent.opacitySlider.value;
                const targetMask=getDiskMask(radius,1);

                for (let m=0; m<targetMask.length; ++m)
                {
                    const p=targetMask[m];
                    const dx=p.dx, dy=p.dy, dist=p.d;
                    if (dist>radius) continue;

                    const cx=FMath.round(centerX+dx);
                    const cy=FMath.round(centerY+dy);
                    if (cx<0 || cx>=image.width || cy<0 || cy>=image.height) continue;

                    const ff=fv===0
                        ? 1
                        : FMath.min(1,(1/fv)*(radius-dist)/radius);

                    for (let q=0; q<channelsToProcess.length; ++q)
                    {
                        const c=channelsToProcess[q];
                        let v0=0,v1=0,v2=0,n=0;

                        for (let k=0; k<3; ++k)
                        {
                            const r=selected[k]-1;
                            const sx=FMath.round(centerX+dx+ring[r].x);
                            const sy=FMath.round(centerY+dy+ring[r].y);

                            if (sx>=0 && sx<image.width && sy>=0 && sy<image.height)
                            {
                                const v=cache.sample(sx,sy,c);
                                if (n===0) v0=v;
                                else if (n===1) v1=v;
                                else v2=v;
                                ++n;
                            }
                        }

                        if(n>0)
                        {
                            const replacement=medianUpTo3(v0,v1,v2,n);
                            const original=cache.sample(cx,cy,c);
                            values.push(
                                cx,cy,c,
                                ov*(ff*replacement+(1-ff)*original)+(1-ov)*original
                            );
                        }
                    }
                }
            }

            applyValues(values);
        };

        // Sequential per-area application is intentional: every later area
        // must read the image after earlier areas have been applied.
        if (parameters.correctStar)
        {
            for (let i=0; i<this.blemishPoints.length; ++i)
            {
                const p=this.blemishPoints[i];
                const sc=starCentroid(p.x,p.y,p.radius,image);
                if (sc) processCircle(sc.x,sc.y,p.radius,true,sc.FWHM);
            }
        }
        else
        {
            for (let i=0; i<this.blemishPoints.length; ++i)
            {
                const p=this.blemishPoints[i];
                console.noteln("Blemish Blaster circle: x="+format("%.2f",p.x)+" y="+format("%.2f",p.y)+" radius="+format("%.2f",p.radius));
                processCircle(p.x,p.y,p.radius,false,0);
            }
        }

        // Freehand regions.
        //
        // IMPORTANT: This path intentionally preserves BBorig's pixel results.
        // It keeps the original integer-pixel polygon rule, the original exact
        // geometric point-to-segment distance, the original full-density source
        // median sampling, and the original feather/opacity equations.
        //
        // The speedup comes from:
        //   1) rasterizing polygon membership once per scanline using the exact
        //      same crossing rule as isPointInShape(), rather than testing every
        //      pixel against every edge;
        //   2) caching exact edge geometry constants;
        //   3) caching integer target/source reads with LocalImageCache; and
        //   4) avoiding per-pixel object/array allocation and one giant values[]
        //      array by writing compact primitive tuples in moderate batches.
        for (let si=0; si<this.freehandShapes.length; ++si)
        {
            const shape=this.freehandShapes[si];
            const compiled=compileShape(shape);
            const cr=calculateFreehandCenterAndRadius(shape);
            const centerX=cr.centerX, centerY=cr.centerY, radius=cr.radius;
            if (radius <= 0 || shape.length < 3) continue;

            const ring=sixRingOffsets(radius);
            const fv=this.parent.featherSlider.value;
            const ov=this.parent.opacitySlider.value;

            // BBorig's target loop uses Math.round(center + offset), with the
            // offset running from -radius through +radius in unit increments.
            // Because rounding preserves the unit step, the visited integer
            // coordinates are exactly round(center-radius) .. round(center+radius).
            const minX=FMath.max(0,FMath.round(centerX-radius));
            const maxX=FMath.min(image.width-1,FMath.round(centerX+radius));
            const minY=FMath.max(0,FMath.round(centerY-radius));
            const maxY=FMath.min(image.height-1,FMath.round(centerY+radius));
            if (minX>maxX || minY>maxY) continue;

            // Build exact integer-x spans for each integer y. For the original
            // isPointInShape(), a pixel x is inside between two crossings iff
            // x >= leftCrossing and x < rightCrossing. Therefore the first
            // integer x is ceil(leftCrossing) and the last is ceil(rightCrossing)-1.
            const rows=new Array(maxY-minY+1);
            const edges=compiled.edges;
            for (let y=minY; y<=maxY; ++y)
            {
                const xs=[];
                for (let ei=0; ei<edges.length; ++ei)
                {
                    const e=edges[ei];
                    const y1=e.y1, y2=e.y2;
                    if ((y1<=y && y<y2) || (y2<=y && y<y1))
                    {
                        const t=(y-y1)/(y2-y1);
                        const x=e.x1+t*(e.x2-e.x1);
                        // Keep every crossing. Crossings outside the target
                        // window still affect parity inside the window.
                        xs.push(x);
                    }
                }
                xs.sort(function(a,b){ return a-b; });
                const spans=[];
                for (let k=0; k+1<xs.length; k+=2)
                {
                    let x0=FMath.ceil(xs[k]);
                    let x1=FMath.ceil(xs[k+1])-1;
                    if (x0<minX) x0=minX;
                    if (x1>maxX) x1=maxX;
                    if (x0<=x1) spans.push([x0,x1]);
                }
                rows[y-minY]=spans;
            }

            // Generate the same source-disk offset sequence once. The bulk
            // reader then computes all seven source-circle medians for the
            // selected channels with bounded getSamples() reads.
            const sourceDX=[], sourceDY=[];
            const radius2=radius*radius;
            for (let dxC=-radius; dxC<=radius; ++dxC)
                for (let dyC=-radius; dyC<=radius; ++dyC)
                    if (dxC*dxC+dyC*dyC<=radius2)
                    {
                        sourceDX.push(dxC);
                        sourceDY.push(dyC);
                    }

            const freehandMedianData=collectFreehandCircleMediansBulk(
                image,centerX,centerY,radius,ring,sourceDX,sourceDY,channelsToProcess);

            const circleMedians=[];
            for(let c=0;c<numChannels;++c) circleMedians[c]=[];

            for(let i=0;i<7;++i)
            {
                const sx=i===0 ? centerX : FMath.round(centerX+ring[i-1].x);
                const sy=i===0 ? centerY : FMath.round(centerY+ring[i-1].y);

                if(sx>=0 && sx<image.width && sy>=0 && sy<image.height)
                {
                    for(let q=0;q<channelsToProcess.length;++q)
                    {
                        const c=channelsToProcess[q];
                        circleMedians[c][i]=freehandMedianData[c][i];
                    }
                }
                else
                {
                    for(let q=0;q<channelsToProcess.length;++q)
                        circleMedians[channelsToProcess[q]][i]=Number.POSITIVE_INFINITY;
                }
            }

            const centerMedians=[];
            for(let q=0;q<channelsToProcess.length;++q)
            {
                const c=channelsToProcess[q];
                centerMedians[c]=circleMedians[c][0];
            }

            // Preserve BBorig's exact source-circle selection, including its
            // stable ordering when distances tie across channels.
            const closestCircles=[];
            for(let i=1;i<7;++i)
                for(let q=0;q<channelsToProcess.length;++q)
                {
                    const c=channelsToProcess[q];
                    closestCircles.push({
                        index:i,
                        distance:FMath.abs(circleMedians[c][i]-centerMedians[c])
                    });
                }
            closestCircles.sort(function(a,b){ return a.distance-b.distance; });
            const selectedCircles=closestCircles.slice(0,3);
            const selectedR0=selectedCircles[0].index-1;
            const selectedR1=selectedCircles[1].index-1;
            const selectedR2=selectedCircles[2].index-1;
            const ox0=FMath.round(ring[selectedR0].x), oy0=FMath.round(ring[selectedR0].y);
            const ox1=FMath.round(ring[selectedR1].x), oy1=FMath.round(ring[selectedR1].y);
            const ox2=FMath.round(ring[selectedR2].x), oy2=FMath.round(ring[selectedR2].y);

            console.noteln(
                "Blemish Blaster freehand: center=(" +
                format("%.2f",centerX) + "," + format("%.2f",centerY) +
                ") radius=" + format("%.2f",radius) +
                " points=" + shape.length
            );

            // Cache the integer target/source samples used by the Freehand
            // replacement stage. LocalImageCache clamps all native sample
            // coordinates, so edge-touching regions cannot issue an invalid
            // Image.sample() call.
            const freehandReadExtent=radius*(1+FMath.sqrt(3))+3;
            const cache=makeReadCache(
                image,centerX,centerY,radius,channelsToProcess,freehandReadExtent);

            // The original loop computes the edge distance once per selected target
            // pixel, so a cache cannot actually reuse much here.  Calculate the
            // equivalent squared distance directly and take one sqrt at the end.
            // This avoids one sqrt for every polygon edge while preserving the same
            // geometric point-to-segment distance.
            const edgeCount=edges.length;
            const invFeatherRadius=fv===0 ? 0 : 1/(fv*radius);

            const bboxPixels=(maxX-minX+1)*(maxY-minY+1);
            const estimatedTuples=bboxPixels*channelsToProcess.length;
            const streamLargeFreehand=estimatedTuples>FREEHAND_STREAM_TUPLE_THRESHOLD;

            // For very large regions, freeze the original working image and write
            // the result directly in bounded tiles. This avoids an enormous JS
            // values[] array while preserving BBorig's read-before-write semantics.
            let frozenImage=null;

            if(streamLargeFreehand)
            {
                console.noteln(
                    "Blemish Blaster freehand: large region; using memory-safe tiled processing."
                );

                frozenImage=new Image(image);

                tempImageWindow.mainView.beginProcess(UndoFlag.NoSwapFile);

                const writeIterators=[];
                const iteratorByChannel=new Array(numChannels);
                if(!image.isInteger && image.isReal)
                {
                    for(let q=0;q<channelsToProcess.length;++q)
                    {
                        const c=channelsToProcess[q];
                        writeIterators[q]=new ImageIterator(image,c);
                        iteratorByChannel[c]=q;
                    }
                }

                try
                {
                    for(let ty=minY;ty<=maxY;ty+=FREEHAND_STREAM_TILE)
                    {
                        const y1=FMath.min(maxY,ty+FREEHAND_STREAM_TILE-1);

                        for(let tx=minX;tx<=maxX;tx+=FREEHAND_STREAM_TILE)
                        {
                            const x1=FMath.min(maxX,tx+FREEHAND_STREAM_TILE-1);
                            const tileW=x1-tx+1, tileH=y1-ty+1;

                            // Each cache is small enough to remain bulk-enabled.
                            // Source caches may be partially clipped at image edges.
                            const targetCache=new LocalImageCache(
                                frozenImage,new Rect(tx,ty,x1+1,y1+1),channelsToProcess);

                            const src0Rect=new Rect(
                                FMath.max(0,tx+ox0),FMath.max(0,ty+oy0),
                                FMath.min(frozenImage.width,x1+ox0+1),
                                FMath.min(frozenImage.height,y1+oy0+1));
                            const src1Rect=new Rect(
                                FMath.max(0,tx+ox1),FMath.max(0,ty+oy1),
                                FMath.min(frozenImage.width,x1+ox1+1),
                                FMath.min(frozenImage.height,y1+oy1+1));
                            const src2Rect=new Rect(
                                FMath.max(0,tx+ox2),FMath.max(0,ty+oy2),
                                FMath.min(frozenImage.width,x1+ox2+1),
                                FMath.min(frozenImage.height,y1+oy2+1));

                            const src0=new LocalImageCache(frozenImage,src0Rect,channelsToProcess);
                            const src1=new LocalImageCache(frozenImage,src1Rect,channelsToProcess);
                            const src2=new LocalImageCache(frozenImage,src2Rect,channelsToProcess);

                            for(let ry=ty;ry<=y1;++ry)
                            {
                                const row=ry-minY;
                                const spans=rows[row];

                                // Restrict each span to this tile.
                                for(let sp=0;sp<spans.length;++sp)
                                {
                                    let ax0=FMath.max(tx,spans[sp][0]);
                                    let ax1=FMath.min(x1,spans[sp][1]);
                                    if(ax0>ax1) continue;

                                    for(let cx=ax0;cx<=ax1;++cx)
                                    {
                                        const dx=cx-centerX, dy=ry-centerY;

                                        let minDist2=Infinity;
                                        for(let ei=0;ei<edgeCount;++ei)
                                        {
                                            const e=edges[ei];

                                            let bx=0, by=0;
                                            if(cx<e.minX) bx=e.minX-cx;
                                            else if(cx>e.maxX) bx=cx-e.maxX;
                                            if(ry<e.minY) by=e.minY-ry;
                                            else if(ry>e.maxY) by=ry-e.maxY;

                                            const bboxD2=bx*bx+by*by;
                                            if(bboxD2>=minDist2) continue;

                                            const A=cx-e.x1, B=ry-e.y1;
                                            const C=e.dx, D=e.dy, len2=e.len2;
                                            let ddx,ddy;

                                            if(len2===0)
                                            {
                                                ddx=cx-e.x1; ddy=ry-e.y1;
                                            }
                                            else
                                            {
                                                const param=(A*C+B*D)/len2;
                                                if(param<0)
                                                {
                                                    ddx=cx-e.x1; ddy=ry-e.y1;
                                                }
                                                else if(param>1)
                                                {
                                                    ddx=cx-e.x2; ddy=ry-e.y2;
                                                }
                                                else
                                                {
                                                    const qx=e.x1+param*C, qy=e.y1+param*D;
                                                    ddx=cx-qx; ddy=ry-qy;
                                                }
                                            }

                                            const d2=ddx*ddx+ddy*ddy;
                                            if(d2<minDist2) minDist2=d2;
                                        }

                                        const minDist=FMath.sqrt(minDist2);
                                        const ff=fv===0 ? 1 : FMath.min(1,minDist*invFeatherRadius);

                                        const sx0=cx+ox0, sy0=ry+oy0;
                                        const sx1=cx+ox1, sy1=ry+oy1;
                                        const sx2=cx+ox2, sy2=ry+oy2;

                                        const valid0=sx0>=0&&sx0<frozenImage.width&&sy0>=0&&sy0<frozenImage.height;
                                        const valid1=sx1>=0&&sx1<frozenImage.width&&sy1>=0&&sy1<frozenImage.height;
                                        const valid2=sx2>=0&&sx2<frozenImage.width&&sy2<frozenImage.height;
                                        const vs=(valid0?1:0)+(valid1?1:0)+(valid2?1:0);
                                        if(vs===0) continue;

                                        for(let q=0;q<channelsToProcess.length;++q)
                                        {
                                            const c=channelsToProcess[q];

                                            let v0=0,v1=0,v2=0,n=0;
                                            if(valid0)
                                            {
                                                const v=src0.sample(sx0,sy0,c);
                                                v0=v; ++n;
                                            }
                                            if(valid1)
                                            {
                                                const v=src1.sample(sx1,sy1,c);
                                                if(n===0) v0=v; else v1=v;
                                                ++n;
                                            }
                                            if(valid2)
                                            {
                                                const v=src2.sample(sx2,sy2,c);
                                                if(n===0) v0=v; else if(n===1) v1=v; else v2=v;
                                                ++n;
                                            }

                                            const replacement=medianUpTo3(v0,v1,v2,n);
                                            const original=targetCache.sample(cx,ry,c);
                                            const value=ov*(ff*replacement+(1-ff)*original)+(1-ov)*original;

                                            if(!image.isInteger && image.isReal)
                                                writeIterators[q][ry][cx]=value;
                                            else
                                                image.setSample(value,cx,ry,c);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                finally
                {
                    tempImageWindow.mainView.endProcess();
                    frozenImage=null;
                }
            }
            else
            {
                const values=[];

                for(let ry=0;ry<rows.length;++ry)
                {
                    const y=minY+ry;
                    const spans=rows[ry];

                    for(let sp=0;sp<spans.length;++sp)
                    {
                        const x0=spans[sp][0], x1=spans[sp][1];

                        for(let cx=x0;cx<=x1;++cx)
                        {
                            let minDist2=Infinity;
                            for(let ei=0;ei<edgeCount;++ei)
                            {
                                const e=edges[ei];

                                let bx=0, by=0;
                                if(cx<e.minX) bx=e.minX-cx;
                                else if(cx>e.maxX) bx=cx-e.maxX;
                                if(y<e.minY) by=e.minY-y;
                                else if(y>e.maxY) by=y-e.maxY;

                                const bboxD2=bx*bx+by*by;
                                if(bboxD2>=minDist2) continue;

                                const A=cx-e.x1, B=y-e.y1;
                                const C=e.dx, D=e.dy, len2=e.len2;
                                let ddx,ddy;

                                if(len2===0)
                                {
                                    ddx=cx-e.x1; ddy=y-e.y1;
                                }
                                else
                                {
                                    const param=(A*C+B*D)/len2;
                                    if(param<0)
                                    {
                                        ddx=cx-e.x1; ddy=y-e.y1;
                                    }
                                    else if(param>1)
                                    {
                                        ddx=cx-e.x2; ddy=y-e.y2;
                                    }
                                    else
                                    {
                                        const qx=e.x1+param*C, qy=e.y1+param*D;
                                        ddx=cx-qx; ddy=y-qy;
                                    }
                                }

                                const d2=ddx*ddx+ddy*ddy;
                                if(d2<minDist2) minDist2=d2;
                            }

                            const minDist=FMath.sqrt(minDist2);
                            const ff=fv===0 ? 1 : FMath.min(1,minDist*invFeatherRadius);

                            const sx0=cx+ox0, sy0=y+oy0;
                            const sx1=cx+ox1, sy1=y+oy1;
                            const sx2=cx+ox2, sy2=y+oy2;
                            const valid0=sx0>=0&&sx0<image.width&&sy0>=0&&sy0<image.height;
                            const valid1=sx1>=0&&sx1<image.width&&sy1>=0&&sy1<image.height;
                            const valid2=sx2>=0&&sx2<image.width&&sy2>=0&&sy2<image.height;
                            const vs=(valid0?1:0)+(valid1?1:0)+(valid2?1:0);
                            if(vs===0) continue;

                            const cacheEnabled=cache.enabled;
                            const targetBase=cacheEnabled ? (y-cache.y0)*cache.w+(cx-cache.x0) : 0;
                            const srcBase0=cacheEnabled ? (sy0-cache.y0)*cache.w+(sx0-cache.x0) : 0;
                            const srcBase1=cacheEnabled ? (sy1-cache.y0)*cache.w+(sx1-cache.x0) : 0;
                            const srcBase2=cacheEnabled ? (sy2-cache.y0)*cache.w+(sx2-cache.x0) : 0;

                            for(let q=0;q<channelsToProcess.length;++q)
                            {
                                const c=channelsToProcess[q];
                                const a=cache.data[c];

                                let v0=0,v1=0,v2=0,n=0;
                                if(valid0)
                                {
                                    v0=cacheEnabled && a ? a[srcBase0] : cache.sample(sx0,sy0,c);
                                    ++n;
                                }
                                if(valid1)
                                {
                                    const v=cacheEnabled && a ? a[srcBase1] : cache.sample(sx1,sy1,c);
                                    if(n===0) v0=v; else v1=v;
                                    ++n;
                                }
                                if(valid2)
                                {
                                    const v=cacheEnabled && a ? a[srcBase2] : cache.sample(sx2,sy2,c);
                                    if(n===0) v0=v; else if(n===1) v1=v; else v2=v;
                                    ++n;
                                }

                                const replacement=medianUpTo3(v0,v1,v2,n);
                                const original=cacheEnabled && a ? a[targetBase] : cache.sample(cx,y,c);
                                values.push(cx,y,c,ov*(ff*replacement+(1-ff)*original)+(1-ov)*original);
                            }
                        }
                    }
                }

                if(values.length>0)
                {
                    tempImageWindow.mainView.beginProcess(UndoFlag.NoSwapFile);

                    if(!image.isInteger && image.isReal)
                    {
                        const writeIterators=[];
                        const iteratorByChannel=new Array(numChannels);
                        for(let q=0;q<channelsToProcess.length;++q)
                        {
                            const c=channelsToProcess[q];
                            writeIterators[q]=new ImageIterator(image,c);
                            iteratorByChannel[c]=q;
                        }

                        for(let i=0;i<values.length;i+=4)
                        {
                            const x=values[i], y=values[i+1], c=values[i+2], v=values[i+3];
                            const q=iteratorByChannel[c];
                            if(q!==undefined) writeIterators[q][y][x]=v;
                        }
                    }
                    else
                    {
                        for(let i=0;i<values.length;i+=4)
                            image.setSample(values[i+3],values[i],values[i+1],values[i+2]);
                    }

                    tempImageWindow.mainView.endProcess();
                }
            }
        }

        // Satellite trail pass. In the original code iteration 0 uses pl=0,
        // so every source position is identical to the target pixel and the
        // median writes the same value back. It is a true no-op and can be
        // removed without changing the resulting image.
        const sz=this.parent.satelliteSizeSlider.value;
        const pl=2*sz;
        const half=FMath.floor(sz/2);

        for (let ti=0; ti<this.satelliteTrails.length; ++ti)
        {
            const trail=this.satelliteTrails[ti];
            const startX=trail.start.x, startY=trail.start.y;
            const endX=trail.end.x, endY=trail.end.y;

            console.noteln(
                "Blemish Blaster satellite: start=(" +
                format("%.2f",startX) + "," + format("%.2f",startY) +
                ") end=(" + format("%.2f",endX) + "," + format("%.2f",endY) + ")"
            );
            const dx=endX-startX, dy=endY-startY;
            const length=FMath.sqrt(dx*dx+dy*dy);
            if (length===0) continue;

            const stepX=dx/length, stepY=dy/length;
            const cache=makeTrailReadCache(image,trail,sz);
            const values=[];

            for (let i=0;i<=length;++i)
            {
                const cx=startX+i*stepX, cy=startY+i*stepY;
                const uux=cx-2*pl*stepY, uuy=cy+2*pl*stepX;
                const ux=cx-pl*stepY,     uy=cy+pl*stepX;
                const lx=cx+pl*stepY,     ly=cy-pl*stepX;
                const llx=cx+2*pl*stepY, lly=cy-2*pl*stepX;

                for (let dxs=-half;dxs<=half;++dxs)
                    for (let dys=-half;dys<=half;++dys)
                    {
                        const mx=FMath.round(cx+dxs);
                        const my=FMath.round(cy+dys);
                        if (mx<0 || mx>=image.width || my<0 || my>=image.height) continue;

                        const x0=FMath.round(uux+dxs), y0=FMath.round(uuy+dys);
                        const x1=FMath.round(ux +dxs), y1=FMath.round(uy +dys);
                        const x3=FMath.round(lx +dxs), y3=FMath.round(ly +dys);
                        const x4=FMath.round(llx+dxs), y4=FMath.round(lly+dys);

                        for (let c=0;c<numChannels;++c)
                        {
                            let v0=0,v1=0,v2=0,v3=0,v4=0,n=0;

                            if (x0>=0 && x0<image.width && y0>=0 && y0<image.height)
                            {
                                v0=cache.sample(x0,y0,c); ++n;
                            }
                            if (x1>=0 && x1<image.width && y1>=0 && y1<image.height)
                            {
                                if (n===0) v0=cache.sample(x1,y1,c);
                                else v1=cache.sample(x1,y1,c);
                                ++n;
                            }

                            if (n===0) v0=cache.sample(mx,my,c);
                            else if (n===1) v1=cache.sample(mx,my,c);
                            else v2=cache.sample(mx,my,c);
                            ++n;

                            if (x3>=0 && x3<image.width && y3>=0 && y3<image.height)
                            {
                                if (n===0) v0=cache.sample(x3,y3,c);
                                else if (n===1) v1=cache.sample(x3,y3,c);
                                else if (n===2) v2=cache.sample(x3,y3,c);
                                else v3=cache.sample(x3,y3,c);
                                ++n;
                            }
                            if (x4>=0 && x4<image.width && y4>=0 && y4<image.height)
                            {
                                if (n===0) v0=cache.sample(x4,y4,c);
                                else if (n===1) v1=cache.sample(x4,y4,c);
                                else if (n===2) v2=cache.sample(x4,y4,c);
                                else if (n===3) v3=cache.sample(x4,y4,c);
                                else v4=cache.sample(x4,y4,c);
                                ++n;
                            }

                            const v=medianUpTo5(v0,v1,v2,v3,v4,n);
                            if (isFinite(v)) values.push(mx,my,c,v);
                        }
                    }
            }

            applyValues(values);
        }

        console.noteln("Ready for more blemish removal.");
        this.displayImage=tempImageWindow.mainView.image;this.displayImageValid=!!this.displayImage;
        this.displayImageWindow=tempImageWindow;
        this.doUpdateImage(this.displayImage);
        this.blemishPoints=[];
        this.satelliteTrails=[];
        this.freehandShapes=[];
        if ( hadCorrections )
            this.unappliedChanges = true;
        this.refreshPreview();
    }


    undoLastBlemishRemoval()
    {
        if(this.undoStack.length>0)
        {
            let lastState=this.undoStack.pop();
            this.redoStack.push({imageId:this.displayImageWindow.mainView.id,blemishPoints:this.blemishPoints,satelliteTrails:this.satelliteTrails,freehandShapes:this.freehandShapes});
            let window=ImageWindow.windowById(lastState.imageId);
            if(window&&!window.isNull)
            {
                this.displayImage=window.mainView.image; this.displayImageValid=!!this.displayImage; this.displayImageWindow=window;
                this.blemishPoints=lastState.blemishPoints||[]; this.satelliteTrails=lastState.satelliteTrails||[]; this.freehandShapes=lastState.freehandShapes||[];
                this.unappliedChanges = !parameters.targetWindow ||
                    this.displayImageWindow.mainView.id !== parameters.targetWindow.mainView.id;
                this.doUpdateImage(this.displayImage); this.refreshPreview();
                console.writeln("Last blemish removal undone.");
            }
            else console.writeln("Image window not found: "+lastState.imageId);
        }
        else console.writeln("No blemish removals to undo.");
    }

    applyChangesToMainImage()
    {
        if(!parameters.targetWindow || !this.displayImageWindow)
        {
            console.writeln("No valid image is available to apply.");
            return;
        }

        // The preview STF is a display-only property. The correction image is
        // kept linear, so there is no STF to invert here. This is the same
        // architecture used by Mosaic Planner: copy the image data, attach the
        // desired STF to the temporary View, and render that View.
        let pm=new PixelMath;
        pm.expression=this.displayImageWindow.mainView.id;
        pm.useSingleExpression=true;
        configurePixelMath(pm);
        pm.executeOn(parameters.targetWindow.mainView);

        if(parameters.targetWindow)
        {
            let tmpImage=this.parent.createAndDisplayTemporaryImage(
                parameters.targetWindow.mainView.image );
            this.displayImage=tmpImage;
            this.displayImageValid=!!this.displayImage;
            this.displayImageWindow=parameters.targetWindow;
            this.initScrollBars();
            this.viewport.update();
        }

        this.unappliedChanges = false;
        console.noteln("Blemish Removal on Main Image Complete!\nReady to remove more blemishes!");
    }

    refreshPreview()
    {
        // Repaint overlays without destroying the rendered image bitmap.
        // Invalidating the bitmap here immediately after Execute was the
        // reason the preview turned black: doUpdateImage() had just built the
        // new bitmap and refreshPreview() immediately discarded it.
        if ( this.viewport ) this.viewport.update();
    }
};

// ============================================================================
// MiniViewport
// ============================================================================

class MiniViewport extends Control
{
    constructor( parent )
    {
        super( parent );
        this.feather=0.5; this.opacity=1.0;
        this.setFixedSize(100,100);
        this.onPaint = (x0,y0,x1,y1) =>
        {
            let g=new Graphics(this);
            g.fillRect(0,0,this.width,this.height,new Brush(0xff000000));
            let cx=this.width/2,cy=this.height/2,r=25;
            for(let y=0;y<this.height;y++) for(let x=0;x<this.width;x++)
            {
                let d=FMath.sqrt((x-cx)*(x-cx)+(y-cy)*(y-cy));
                if(d<=r)
                {
                    let ff=this.feather===0?1:FMath.min(1,(1/this.feather)*(r-d)/r);
                    let alpha=FMath.floor(this.opacity*255*ff);
                    let color=parseInt('0x'+alpha.toString(16).padStart(2,'0')+'ffffff',16);
                    g.pen=new Pen(color); g.drawPoint(x,y);
                }
            }
            g.end();
        };
    }
    updatePreview(feather,opacity){this.feather=feather===0?1:feather;this.opacity=opacity;this.update();}
};

// ============================================================================
// BlemishEraserDialog
// ============================================================================

class BlemishEraserDialog extends Dialog
{
    constructor()
    {
        super();
        let selectedImages=[];
        function isImageInSelectedList(id){for(let i=0;i<selectedImages.length;i++) if(selectedImages[i]===id) return true;return false;}

        this.title_Lbl=new Label(this);this.title_Lbl.frameStyle=FrameStyle.Box;this.title_Lbl.margin=6;this.title_Lbl.useRichText=true;this.title_Lbl.text="<b>"+TITLE+" "+VERSION+"</b>";this.title_Lbl.textAlignment=TextAlignment.Center;

        this.instructionBox=new Label(this);this.instructionBox.frameStyle=FrameStyle.Box;this.instructionBox.margin=6;this.instructionBox.useRichText=true;
        this.instructionBox.text="<b>Instructions:</b><br>Working image: the current PixInsight view. The preview uses that view's STF.<br>Shift-click and drag to draw a circle or freehand.<br>CTRL-click and drag to define Satellite Trail Removal Line.<br>Alt-click to auto find the Satellite Trail Removal Line.<br>Right-click to remove a point.<br>.....Multiple Areas Allowed!<br>Click Execute to apply blemish removal.<br>Click Apply to Main Image to save changes.";
        this.instructionBox.textAlignment=TextAlignment.Left;

        this.imageLabel=new Label(this);this.imageLabel.text="Working Image: (current view)";this.imageLabel.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;
        this.imageSelectionSizer=new HorizontalSizer;this.imageSelectionSizer.spacing=4;this.imageSelectionSizer.add(this.imageLabel,1);

        this.drawingModeSizer=new HorizontalSizer;this.drawingModeSizer.spacing=4;
        this.circleCheckbox=new CheckBox(this);this.circleCheckbox.text="Circle";this.circleCheckbox.checked=(parameters.drawingMode==="Circle");
        this.circleCheckbox.onCheck=checked=>{if(checked){parameters.drawingMode="Circle";parameters.correctStar=false;this.freehandCheckbox.checked=false;this.correctStarCheckbox.checked=false;}};
        this.drawingModeSizer.add(this.circleCheckbox);
        this.freehandCheckbox=new CheckBox(this);this.freehandCheckbox.text="Freehand";this.freehandCheckbox.checked=(parameters.drawingMode==="Freehand");
        this.freehandCheckbox.onCheck=checked=>{if(checked){parameters.drawingMode="Freehand";parameters.correctStar=false;this.circleCheckbox.checked=false;this.correctStarCheckbox.checked=false;}};
        this.drawingModeSizer.add(this.freehandCheckbox);
        this.correctStarCheckbox=new CheckBox(this);this.correctStarCheckbox.text="Correct Star (Experimental!)";this.correctStarCheckbox.checked=parameters.correctStar||false;
        this.correctStarCheckbox.onCheck=checked=>{parameters.correctStar=checked;if(checked){this.circleCheckbox.checked=false;this.freehandCheckbox.checked=false;}};
        this.drawingModeSizer.add(this.correctStarCheckbox);

        this.featherSlider=new NumericControl(this);
        this.featherSlider.label.text="Feather:";
        this.featherSlider.setRange(0.01,1);
        this.featherSlider.setPrecision(2);
        this.featherSlider.slider.setRange(0,100);
        this.featherSlider.setValue(parameters.feather);
        this.featherSlider.onValueUpdated=value=>
        {
            parameters.feather=value;
            parameters.save();
            this.miniViewport.updatePreview(value,this.opacitySlider.value);
        };

        this.opacitySlider=new NumericControl(this);
        this.opacitySlider.label.text="Opacity:";
        this.opacitySlider.setRange(0,1);
        this.opacitySlider.setPrecision(2);
        this.opacitySlider.slider.setRange(0,100);
        this.opacitySlider.setValue(parameters.opacity);
        this.opacitySlider.onValueUpdated=value=>
        {
            parameters.opacity=value;
            parameters.save();
            this.miniViewport.updatePreview(this.featherSlider.value,value);
        };

        this.channelDropdownLabel=new Label(this);this.channelDropdownLabel.text="Perform Blemish Blaster On:";this.channelDropdownLabel.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;
        this.channelDropdown=new ComboBox(this);["All Channels","Red","Green","Blue"].forEach(s=>this.channelDropdown.addItem(s));this.channelDropdown.currentItem=0;this.channelDropdown.onItemSelected=index=>{parameters.selectedChannel=index;};
        this.channelDropdownSizer=new HorizontalSizer;this.channelDropdownSizer.spacing=6;this.channelDropdownSizer.add(this.channelDropdownLabel);this.channelDropdownSizer.add(this.channelDropdown);this.channelDropdownSizer.addStretch();

        this.executeButton=new PushButton(this);this.executeButton.text="Execute";this.executeButton.toolTip="Apply blemish removal.";this.executeButton.icon=":/icons/ok.png";this.executeButton.onClick=()=>{this.previewControl.applyBlemishRemoval();};
        this.undoButton=new PushButton(this);this.undoButton.text="Undo";this.undoButton.toolTip="Undo the last blemish removal.";this.undoButton.icon=":/icons/undo.png";this.undoButton.onClick=()=>{this.previewControl.undoLastBlemishRemoval();};
        this.applyButton=new PushButton(this);this.applyButton.text="Apply to Main Image";this.applyButton.toolTip="Apply changes to main image.";this.applyButton.icon=":/icons/execute.png";this.applyButton.onClick=()=>{this.previewControl.applyChangesToMainImage();};

        this.authorshipLabel=new Label(this);this.authorshipLabel.text="<p style='text-align:center;'>Written by Franklin Marek 2026 and modified by Lamar McLouth 2026<br>www.setiastro.com</p>";this.authorshipLabel.textAlignment=TextAlignment.Center|TextAlignment.VertCenter;this.authorshipLabel.useRichText=true;
        this.blemishLabel=new Label(this);this.blemishLabel.text="<p style='text-align:center;'>Blemish Area Options</p>";this.blemishLabel.textAlignment=TextAlignment.Center|TextAlignment.VertCenter;this.blemishLabel.useRichText=true;
        this.satelliteLabel=new Label(this);this.satelliteLabel.text="<p style='text-align:center;'>Satellite Trail Options</p>";this.satelliteLabel.textAlignment=TextAlignment.Center|TextAlignment.VertCenter;this.satelliteLabel.useRichText=true;
        this.satelliteSizeSlider=new NumericControl(this);
        this.satelliteSizeSlider.label.text="Satellite Trail Width:";
        this.satelliteSizeSlider.setRange(1,20);
        this.satelliteSizeSlider.setPrecision(0);
        this.satelliteSizeSlider.slider.setScaledMinWidth(250);
        this.satelliteSizeSlider.setValue(parameters.satelliteTrailWidth);
        this.satelliteSizeSlider.onValueUpdated=value=>
        {
            parameters.satelliteTrailWidth=value;
            parameters.save();
        };

        this.newInstanceButton=new ToolButton(this);this.newInstanceButton.icon=this.scaledResource(":/process-interface/new-instance.png");this.newInstanceButton.setScaledFixedSize(24,24);this.newInstanceButton.toolTip="New Instance";this.newInstanceButton.onMousePress=()=>{this.newInstance();};

        this.exitButton=new PushButton(this);this.exitButton.text="Exit";this.exitButton.icon=":/toolbar/file-exit.png";this.exitButton.toolTip="Close the dialog and clean up.";
        this.exitButton.onClick=()=>
        {
            if ( this.previewControl.unappliedChanges )
            {
                const msg=new MessageBox(
                    "There are blemishes that have been removed but not applied to the main image. Do you want to Exit?",
                    "Confirm Exit",
                    StdIcon.Question,
                    StdButton.Yes,
                    StdButton.Cancel );
                if ( msg.execute() !== StdButton.Yes )
                    return;
            }

            this.cleanupAndClose();
        };

        this.miniViewport=new MiniViewport(this);
        let miniViewportSizer=new HorizontalSizer;miniViewportSizer.spacing=6;miniViewportSizer.addStretch();miniViewportSizer.add(this.miniViewport);miniViewportSizer.addStretch();

        this.previewControl=new ScrollControl(this);this.previewControl.setMinWidth(900);this.previewControl.setMinHeight(700);

        // Icon-only zoom controls, ordered like a typical PixInsight preview toolbar:
        // Full View, Zoom Out, Zoom In, 1:1. ToolButton avoids the push-button box.
        this.fullViewButton=new ToolButton(this);
        this.fullViewButton.icon=this.scaledResource(":/images/fit_window.png");
        this.fullViewButton.setScaledFixedSize(24,24);
        this.fullViewButton.toolTip="Full View";
        this.fullViewButton.onMousePress=()=>{this.previewControl.fullView();};

        this.zoomOutButton=new ToolButton(this);
        this.zoomOutButton.icon=this.scaledResource(":/icons/zoom-out.png");
        this.zoomOutButton.setScaledFixedSize(24,24);
        this.zoomOutButton.toolTip="Zoom Out";
        this.zoomOutButton.onMousePress=()=>{this.previewControl.zoomOut();};

        this.zoomInButton=new ToolButton(this);
        this.zoomInButton.icon=this.scaledResource(":/icons/zoom-in.png");
        this.zoomInButton.setScaledFixedSize(24,24);
        this.zoomInButton.toolTip="Zoom In";
        this.zoomInButton.onMousePress=()=>{this.previewControl.zoomIn();};

        this.zoom11Button=new ToolButton(this);
        this.zoom11Button.icon=this.scaledResource(":/icons/zoom-1-1.png");
        this.zoom11Button.setScaledFixedSize(24,24);
        this.zoom11Button.toolTip="Zoom 1:1";
        this.zoom11Button.onMousePress=()=>{this.previewControl.UpdateZoom(1);};

        this.zoomLabel=new Label(this);this.zoomLabel.text="Zoom with buttons or mouse wheel";

        this.wheelDirectionLabel=new Label(this);
        this.wheelDirectionLabel.text="Wheel:";
        this.wheelDirectionLabel.toolTip="Choose which physical wheel direction zooms in.";

        this.wheelDirectionCombo=new ComboBox(this);
        this.wheelDirectionCombo.addItem("Forward");
        this.wheelDirectionCombo.addItem("Backward");
        this.wheelDirectionCombo.currentItem=(parameters.wheelDirection==="Backward") ? 1 : 0;
        this.wheelDirectionCombo.toolTip =
            "Forward = wheel away from you zooms in; Backward = wheel toward you zooms in.";
        this.wheelDirectionCombo.onItemSelected=index=>
        {
            parameters.wheelDirection = index===1 ? "Backward" : "Forward";
            parameters.save();
        };

        this.zoomSizer=new HorizontalSizer;this.zoomSizer.spacing=6;
        this.zoomSizer.add(this.fullViewButton);
        this.zoomSizer.add(this.zoomOutButton);
        this.zoomSizer.add(this.zoomInButton);
        this.zoomSizer.add(this.zoom11Button);
        this.zoomSizer.add(this.zoomLabel);
        this.zoomSizer.add(this.wheelDirectionLabel);
        this.zoomSizer.add(this.wheelDirectionCombo);
        this.zoomSizer.addStretch();

        // Mosaic Planner-style status bar beneath the preview.
        this.zoomStatusLabel=new Label(this);this.zoomStatusLabel.text="Zoom:";
        this.zoomStatusValue=new Label(this);this.zoomStatusValue.text="1:1";
        this.xStatusLabel=new Label(this);this.xStatusLabel.text="X:";
        this.xStatusValue=new Label(this);this.xStatusValue.text="---";
        this.yStatusLabel=new Label(this);this.yStatusLabel.text="Y:";
        this.yStatusValue=new Label(this);this.yStatusValue.text="---";
        this.statusFrame=new Frame(this);
        this.statusFrame.styleSheet="QLabel { font-family: Hack; }";
        this.statusFrame.sizer=new HorizontalSizer;this.statusFrame.sizer.margin=4;this.statusFrame.sizer.spacing=5;
        this.statusFrame.sizer.add(this.zoomStatusLabel);this.statusFrame.sizer.add(this.zoomStatusValue);
        this.statusFrame.sizer.addSpacing(16);this.statusFrame.sizer.add(this.xStatusLabel);this.statusFrame.sizer.add(this.xStatusValue);
        this.statusFrame.sizer.addSpacing(16);this.statusFrame.sizer.add(this.yStatusLabel);this.statusFrame.sizer.add(this.yStatusValue);
        this.statusFrame.sizer.addStretch();

        this.previewControl.onStatusUpdate=(zoomText,x,y)=>
        {
            this.zoomStatusValue.text=zoomText;
            if ( x >= 0 && y >= 0 && this.previewControl.displayImage && x < this.previewControl.displayImage.width && y < this.previewControl.displayImage.height )
            {
                this.xStatusValue.text=format("%.2f",x);
                this.yStatusValue.text=format("%.2f",y);
            }
            else
            {
                this.xStatusValue.text="---";this.yStatusValue.text="---";
            }
        };

        let leftPanel=new VerticalSizer;leftPanel.spacing=6;leftPanel.margin=6;
        leftPanel.add(this.title_Lbl);leftPanel.add(this.instructionBox);leftPanel.add(this.imageSelectionSizer);
        leftPanel.addStretch();
        leftPanel.add(this.blemishLabel);leftPanel.add(this.drawingModeSizer);leftPanel.add(this.featherSlider);leftPanel.add(this.opacitySlider);leftPanel.add(this.channelDropdownSizer);
        let euSizer=new HorizontalSizer;euSizer.spacing=6;euSizer.add(this.executeButton);euSizer.add(this.undoButton);
        leftPanel.add(miniViewportSizer);leftPanel.addStretch();leftPanel.add(this.satelliteLabel);leftPanel.add(this.satelliteSizeSlider);leftPanel.addStretch();leftPanel.add(euSizer);leftPanel.add(this.applyButton);leftPanel.add(this.authorshipLabel);
        let ieSizer=new HorizontalSizer;ieSizer.spacing=6;ieSizer.add(this.newInstanceButton);ieSizer.add(this.exitButton);leftPanel.add(ieSizer);

        let rightPanel=new VerticalSizer;rightPanel.spacing=6;rightPanel.margin=6;rightPanel.add(this.zoomSizer);rightPanel.add(this.previewControl,1);rightPanel.add(this.statusFrame);

        let mainSizer=new HorizontalSizer;mainSizer.spacing=6;mainSizer.margin=6;mainSizer.add(leftPanel);mainSizer.add(rightPanel,1);
        this.sizer=mainSizer;this.adjustToContents();this.windowTitle=TITLE;

        this.onShow=()=>
        {
            const aw=ImageWindow.activeWindow;
            if(!aw || aw.isNull || !aw.mainView || aw.mainView.isNull)
            {
                console.criticalln("Blemish Blaster Pro: No current image view is available. Open or activate an image before running the script.");
                this.executeButton.enabled=false;
                this.applyButton.enabled=false;
                this.imageLabel.text="Working Image: No active view";
                return;
            }

            parameters.targetWindow=aw;
            selectedImages.length=0;
            selectedImages.push(aw.mainView.id);
            this.imageLabel.text="Working Image: " + aw.mainView.id;
            // PJSR exposes the View STF parameters, but the runtime does not
            // provide a dependable public "STF enabled" flag. In particular,
            // disabling STF in PixInsight does not necessarily reset the STF
            // parameters, so checking for an identity STF is not sufficient.
            //
            // For Blemish Blaster we therefore distinguish the two practical
            // data states by examining the image itself at startup. A typical
            // linear astronomical image has its background compressed into a
            // very small fraction of the [0,1] range, whereas a permanently
            // stretched nonlinear image has substantially larger channel
            // medians. Only nonlinear images are protected from applying the
            // captured STF.
            //
            // The threshold is deliberately conservative and is evaluated only
            // once at startup, so it has negligible impact on processing speed.
            const sourceSTF = aw.mainView.stf;
            let maxMedian = 0;
            try
            {
                const n = Math.min( 3, aw.mainView.image.numberOfNominalChannels );
                for ( let c = 0; c < n; ++c )
                {
                    const md = aw.mainView.image.median( new Rect(), c, c );
                    if ( md > maxMedian ) maxMedian = md;
                }
            }
            catch ( e )
            {
                // If statistics cannot be obtained, preserve the established
                // linear-image behavior and use the captured STF.
                maxMedian = 0;
            }

            const probablyNonlinear = maxMedian >= 0.05;
            const stfActive = !!sourceSTF && !probablyNonlinear;

            this.previewControl.displaySTFEnabled = stfActive;
            this.previewControl.displaySTF = stfActive ?
                JSON.parse(JSON.stringify(sourceSTF)) : null;

            console.writeln( "Blemish Blaster Pro: " +
                (probablyNonlinear ?
                    "Nonlinear image detected; using image as-is." :
                    "Linear image detected; using current View STF.") );

            this.createAndDisplayTemporaryImage(aw.mainView.image);
        };

        // Ctrl-Z: undo the most recent executed blemish removal.
        // Handle both key-down and key-press because focus can be on a button or
        // on the preview viewport.
        this._isCtrlZ = function( key, modifiers )
        {
            let controlMask = 0x04000000;
            try { if ( typeof KeyboardModifier !== "undefined" && KeyboardModifier.ControlModifier !== undefined ) controlMask = KeyboardModifier.ControlModifier; } catch ( e ) {}
            try { if ( typeof KeyModifier !== "undefined" && KeyModifier.Control !== undefined ) controlMask = KeyModifier.Control; } catch ( e ) {}
            return (key===90 || key===122 || (typeof KeyCode !== "undefined" && key===KeyCode.Z)) && ((modifiers & controlMask) !== 0);
        };
        this.onKeyPress=(key, modifiers)=>
        {
            if ( this._isCtrlZ(key,modifiers) ) { this.previewControl.undoLastBlemishRemoval(); return false; }
            return true;
        };
        this.onKeyDown=(key, modifiers)=>
        {
            if ( this._isCtrlZ(key,modifiers) ) { this.previewControl.undoLastBlemishRemoval(); return false; }
            return true;
        };

        this._cleanupDone=false;

        this.onClose=()=>
        {
            parameters.save();
            this.cleanupAndClose();
        };

        this.cleanupAndClose=(skipCancel)=>
        {
            if(this._cleanupDone) return;
            this._cleanupDone=true;

            parameters.save();

            this.previewControl.invalidateRenderCache();

            // Invalidate the paint-side Image reference before closing temporary
            // ImageWindows, preventing a queued onPaint from dereferencing a
            // destroyed native Image instance.
            this.previewControl.displayImageValid = false;
            this.previewControl.displayImage = null;
            this.previewControl.displayImageWindow = null;
            this.previewControl.displaySTF = null;
            this.previewControl.displaySTFEnabled = true;

            // Close each temporary/undo window at most once.
            const idsToClose=new Map;
            while(this.previewControl.undoStack.length>0)
            {
                const id=this.previewControl.undoStack.pop().imageId;
                if(typeof id==="string" && !isImageInSelectedList(id))
                    idsToClose.set(id,true);
            }

            while(this.previewControl.tempImageStack.length>0)
            {
                const id=this.previewControl.tempImageStack.pop();
                if(typeof id==="string" && !isImageInSelectedList(id))
                    idsToClose.set(id,true);
            }

            for(const id of idsToClose.keys())
            {
                try
                {
                    const w=ImageWindow.windowById(id);
                    if(w && !w.isNull) w.forceClose();
                }
                catch(e){}
            }

            console.writeln("Blemish Blaster: temporary-image cleanup complete.");

            if(!skipCancel)
                try { this.cancel(); } catch(e) {}
        };
    }

    createAndDisplayTemporaryImage( selectedImage )
    {
        // Keep the working image linear. The STF is attached to the temporary
        // View only, exactly like Mosaic Planner does before calling render().
        let window=new ImageWindow(
            selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels, selectedImage.bitsPerSample,
            selectedImage.isReal, selectedImage.isColor );

        // Register immediately so an exception during creation cannot leak this
        // temporary ImageWindow after the script is closed.
        this.previewControl.tempImageStack.push(window.mainView.id);

        try
        {
            window.mainView.beginProcess(UndoFlag.NoSwapFile);
            window.mainView.image.assign(selectedImage);
            window.mainView.endProcess();
        }
        catch(e)
        {
            try { window.forceClose(); } catch(err) {}
            throw e;
        }

        let resizedImage=new Image(window.mainView.image);
        this.previewControl.displayImage=resizedImage;
        this.previewControl.displayImageValid=!!resizedImage;
        this.previewControl.displayImageWindow=window;
        // Preserve the STF captured from the user's selected source view.
        this.previewControl.doUpdateImage(resizedImage);

        // Always start a new Blemish Blaster session in Full View.
        // The user can then zoom in with the same Mosaic Planner-style controls.
        this.previewControl.fullView();

        // Keep the owning temporary View alive because Image.render() uses its
        // View STF. The image itself remains the linear working data.
        return resizedImage;
    }

};

// ============================================================================
// Main
// ============================================================================

function main()
{
    const aw=ImageWindow.activeWindow;
    if(!aw || aw.isNull || !aw.mainView || aw.mainView.isNull)
    {
        console.show();
        console.criticalln("Blemish Blaster Pro: No current image view is available. Open or activate an image before running the script.");
        return;
    }
    // Keep the console available for genuine errors/messages, but the STF
    // renderer itself does not emit user-facing status messages from this script.
    console.show();
    console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    console.warningln( " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    let dialog=null;
    try
    {
        dialog=new BlemishEraserDialog();
        dialog.execute();
    }
    finally
    {
        // This also runs when an exception escapes from a UI callback or Execute,
        // ensuring TempImage windows are not left behind.
        if(dialog)
            dialog.cleanupAndClose(true);
    }
}

main();
