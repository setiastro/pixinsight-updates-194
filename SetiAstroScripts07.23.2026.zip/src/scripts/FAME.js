#engine v8

#feature-id FAME : SetiAstro > FAME
#feature-icon  fame.svg
#feature-info This script allows freehand, ellipse, and rectangular drawing of masks.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Freehand Adaptive Mask Editor
 * Version: V1.6
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script is designed for freehand drawing, creating ellipses,
 * and drawing rectangles that can then be used as masks.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license,
 *    and indicate if changes were made.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "Freehand Adaptive Mask Editor"
#define VERSION "V1.6"

let parameters = {
    targetWindow:    null,
    previewZoomLevel: "Fit to Preview",
    shapes:          [],
    shapeTypes:      [],
    save: function()
    {
        Parameters.set( "shapes",           JSON.stringify( this.shapes ) );
        Parameters.set( "shapeTypes",       JSON.stringify( this.shapeTypes ) );
        Parameters.set( "previewZoomLevel", this.previewZoomLevel );
        if ( this.targetWindow )
            Parameters.set( "targetWindow", this.targetWindow.mainView.id );
    },
    load: function()
    {
        if ( Parameters.has( "shapes" ) )           this.shapes           = JSON.parse( Parameters.getString( "shapes" ) );
        if ( Parameters.has( "shapeTypes" ) )       this.shapeTypes       = JSON.parse( Parameters.getString( "shapeTypes" ) );
        if ( Parameters.has( "previewZoomLevel" ) ) this.previewZoomLevel = Parameters.getString( "previewZoomLevel" );
        if ( Parameters.has( "targetWindow" ) )
        {
            let windowId = Parameters.getString( "targetWindow" );
            let win = ImageWindow.windowById( windowId );
            if ( win && !win.isNull ) this.targetWindow = win;
        }
    }
};

// ============================================================================
// Color range helper (used by mask generation)
// ============================================================================

function getColorRange( color )
{
    switch ( color )
    {
    case "Red":      return { min: 330, max: 40  };
    case "Yellow":   return { min: 40,  max: 85  };
    case "Green":    return { min: 85,  max: 160 };
    case "Cyan":     return { min: 160, max: 200 };
    case "Blue":     return { min: 200, max: 270 };
    case "Magenta":  return { min: 270, max: 330 };
    default:         return { min: 0,   max: 0   };
    }
}

// ============================================================================
// ScrollControl
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.autoScroll   = true;
        this.tracking     = true;

        this.displayImage         = null;
        this.dragging             = false;
        this.dragOrigin           = new Point( 0, 0 );
        this.isDrawing            = false;
        this.isTransforming       = false;
        this.isMoving             = false;
        this.currentShape         = [];
        this.shapes               = [];
        this.shapeTypes           = [];
        this.activeShapeIndex     = 0;
        this.scrollPosition       = new Point( 0, 0 );
        this.previousZoomLevel    = 1;
        this.shapeType            = "Freehand";
        this.maskType             = "Binary";
        this.transformCenter      = null;
        this.initialDistance      = null;
        this.initialAngle         = null;
        this.gradientStartPoint   = null;
        this.gradientEndPoint     = null;
        this.brushRadius          = 10;
        this.sprayDensity         = 0.5;
        this.startX               = 0;
        this.startY               = 0;
        this.originalShape        = [];

        // V8 render cache — avoids re-rendering displayImage to a new Bitmap
        // on every paint (which otherwise leaks, since V8's GC does not
        // promptly collect Bitmap/Image objects). Only invalidated when
        // displayImage itself changes via doUpdateImage().
        this._cachedBitmap = null;

        this.viewport.cursor = new Cursor( StdCursor.Cross );

        this.zoomFactor    = 1;
        this.minZoomFactor = 0.1;
        this.maxZoomFactor = 10;

        // ---- Viewport events ----

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            let zf         = this.zoomFactor;
            let adjustedX  = (x / zf) + this.scrollPosition.x;
            let adjustedY  = (y / zf) + this.scrollPosition.y;

            // Right click — set gradient points
            if ( button === 2 )
            {
                if ( !this.gradientStartPoint )
                {
                    this.gradientStartPoint = [adjustedX, adjustedY];
                    this.viewport.update();
                }
                else if ( !this.gradientEndPoint )
                {
                    this.gradientEndPoint = [adjustedX, adjustedY];
                    this.viewport.update();
                }
                return;
            }

            if ( modifiers === 1 ) // Shift — draw
            {
                this.startX = adjustedX; this.startY = adjustedY;
                this.isDrawing = true; this.dragging = false;
                if ( this.shapeType === "Ellipse" || this.shapeType === "Rectangle" )
                    this.currentShape = [[this.startX, this.startY], [this.startX, this.startY]];
                else
                    this.currentShape = [];
            }
            else if ( modifiers === 2 ) // Ctrl — move
            {
                this.startX = adjustedX; this.startY = adjustedY;
                this.isMoving = true; this.dragging = false;
                this.originalShape = this.shapes[this.activeShapeIndex].map( p => p.slice() );
            }
            else if ( modifiers === 4 ) // Alt — transform
            {
                this.startX = adjustedX; this.startY = adjustedY;
                this.isTransforming = true;
                this.transformCenter  = this._calcTransformCenter( this.shapes[this.activeShapeIndex] );
                this.initialAngle     = this._calcAngle( this.transformCenter[0], this.transformCenter[1], this.startX, this.startY );
                this.initialDistance  = this._calcDistance( this.startX, this.startY, this.transformCenter[0], this.transformCenter[1] );
                this.originalShape    = this.shapes[this.activeShapeIndex].map( p => p.slice() );
            }
            else
            {
                this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
                this.dragOrigin.x = x; this.dragOrigin.y = y;
                this.dragging = true;
            }
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            let zf        = this.zoomFactor;
            let adjustedX = (x / zf) + this.scrollPosition.x;
            let adjustedY = (y / zf) + this.scrollPosition.y;

            if ( this.isDrawing )
            {
                let endX = adjustedX, endY = adjustedY;

                if ( this.shapeType === "Freehand" )
                {
                    this.currentShape.push( [endX, endY] );
                }
                else if ( this.shapeType === "Ellipse" )
                {
                    let cx = (this.startX + endX) / 2, cy = (this.startY + endY) / 2;
                    let rx = Math.abs( endX - this.startX ) / 2;
                    let ry = Math.abs( endY - this.startY ) / 2;
                    this.currentShape = [];
                    for ( let a = 0; a < 2 * Math.PI; a += 0.01 )
                        this.currentShape.push( [cx + rx * Math.cos(a), cy + ry * Math.sin(a)] );
                    this.currentShape.push( this.currentShape[0] );
                }
                else if ( this.shapeType === "Rectangle" )
                {
                    this.currentShape = [
                        [this.startX, this.startY], [endX, this.startY],
                        [endX, endY], [this.startX, endY], [this.startX, this.startY]
                    ];
                }
                else if ( this.shapeType === "SprayCan" )
                {
                    let r = this.brushRadius, d = this.sprayDensity;
                    for ( let ix = endX - r; ix <= endX + r; ix++ )
                        for ( let iy = endY - r; iy <= endY + r; iy++ )
                        {
                            let dist = Math.sqrt( (ix-endX)**2 + (iy-endY)**2 );
                            if ( dist <= r && Math.random() < (1 - dist/r) * d )
                                this.currentShape.push( [ix, iy, 1] );
                        }
                }
                else if ( this.shapeType === "Brush" )
                {
                    let r = this.brushRadius;
                    let newPoints = [];
                    for ( let a = 0; a < 2 * Math.PI; a += Math.PI / 8 )
                        newPoints.push( [Math.round(endX + r * Math.cos(a)), Math.round(endY + r * Math.sin(a))] );
                    newPoints.push( [endX, endY] );

                    if ( this.currentShape.length > 0 )
                    {
                        let lastPoints = this.currentShape[this.currentShape.length - 1];
                        if ( lastPoints.length === newPoints.length )
                            for ( let i = 0; i < lastPoints.length; i++ )
                            {
                                let sx = lastPoints[i][0], sy = lastPoints[i][1];
                                let ex = newPoints[i][0],  ey = newPoints[i][1];
                                if ( !isNaN(sx) && !isNaN(sy) && !isNaN(ex) && !isNaN(ey) )
                                {
                                    this.currentShape.push( [sx, sy, ex, ey] );
                                    let q1x = sx + 0.25*(ex-sx), q1y = sy + 0.25*(ey-sy);
                                    let hx  = sx + 0.50*(ex-sx), hy  = sy + 0.50*(ey-sy);
                                    let q3x = sx + 0.75*(ex-sx), q3y = sy + 0.75*(ey-sy);
                                    this.currentShape.push( [sx, sy, q1x, q1y] );
                                    this.currentShape.push( [q1x, q1y, hx, hy] );
                                    this.currentShape.push( [hx, hy, q3x, q3y] );
                                    this.currentShape.push( [q3x, q3y, ex, ey] );
                                }
                            }
                    }
                    this.currentShape.push( newPoints );
                }

                this.viewport.update();
            }
            else if ( this.isMoving )
            {
                let dx = adjustedX - this.startX, dy = adjustedY - this.startY;
                this.shapes[this.activeShapeIndex] = this.originalShape.map( p => [p[0]+dx, p[1]+dy] );
                this.viewport.update();
            }
            else if ( this.isTransforming )
            {
                let curAngle  = this._calcAngle( this.transformCenter[0], this.transformCenter[1], adjustedX, adjustedY );
                let angleDiff = curAngle - this.initialAngle;
                let curDist   = this._calcDistance( adjustedX, adjustedY, this.transformCenter[0], this.transformCenter[1] );
                let scale     = curDist / this.initialDistance;
                this.shapes[this.activeShapeIndex] = this._transformShape(
                    this.originalShape, angleDiff, scale, scale,
                    this.transformCenter[0], this.transformCenter[1] );
                this.viewport.update();
            }
            else if ( this.dragging )
            {
                let dx = (this.dragOrigin.x - x) / this.zoomFactor;
                let dy = (this.dragOrigin.y - y) / this.zoomFactor;
                this.scrollPosition = new Point( this.scrollPosition.x + dx, this.scrollPosition.y + dy );
                this.dragOrigin.x = x; this.dragOrigin.y = y;
                this.viewport.update();
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            let zf        = this.zoomFactor;
            let adjustedX = (x / zf) + this.scrollPosition.x;
            let adjustedY = (y / zf) + this.scrollPosition.y;

            if ( this.isDrawing )
            {
                this.isDrawing = false;
                if ( this.shapeType === "Freehand" )
                {
                    this.currentShape.push( [adjustedX, adjustedY] );
                    this.currentShape.push( this.currentShape[0] );
                }
                this.shapes.push( this.currentShape.filter( p => !isNaN(p[0]) && !isNaN(p[1]) ) );
                this.shapeTypes.push( this.shapeType );
                this.currentShape = [];
                this.activeShapeIndex = this.shapes.length - 1;
                this.viewport.update();
            }
            else if ( this.isMoving )
            {
                this.isMoving = false;
                this.viewport.update();
            }
            else if ( this.isTransforming )
            {
                this.isTransforming = false;
                this.viewport.update();
            }
            else
            {
                this.viewport.cursor = new Cursor( StdCursor.Cross );
                this.dragging = false;
            }
        };

        this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
        {
            if ( !this.displayImage ) return;

            let oldZoom = this.zoomFactor;
            let maxH = (this.displayImage.width  * oldZoom) - this.viewport.width;
            let maxV = (this.displayImage.height * oldZoom) - this.viewport.height;
            let oldPctX = maxH > 0 ? this.scrollPosition.x / maxH : 0;
            let oldPctY = maxV > 0 ? this.scrollPosition.y / maxV : 0;

            if      ( delta > 0 ) this.zoomFactor = Math.min( this.zoomFactor * 1.25, this.maxZoomFactor );
            else if ( delta < 0 ) this.zoomFactor = Math.max( this.zoomFactor * 0.80, this.minZoomFactor );

            this.initScrollBars();

            maxH = (this.displayImage.width  * this.zoomFactor) - this.viewport.width;
            maxV = (this.displayImage.height * this.zoomFactor) - this.viewport.height;
            this.scrollPosition = new Point(
                Math.max( 0, Math.min( oldPctX * maxH, maxH ) ),
                Math.max( 0, Math.min( oldPctY * maxV, maxV ) ) );

            this.viewport.update();
        };

        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g  = new Graphics( this.viewport );
            let zf = this.zoomFactor;

            if ( this.displayImage == null )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
            }
            else
            {
                // Build the cached bitmap once; reused across every paint
                // until invalidated by doUpdateImage(). This is what keeps
                // .render() from being called dozens of times per second
                // during freehand drawing / shape moves, which is what was
                // causing the growing memory footprint on Linux.
                if ( !this._cachedBitmap )
                    this._cachedBitmap = this.displayImage.render();

                g.scaleTransformation( zf );
                g.translateTransformation( -this.scrollPosition.x, -this.scrollPosition.y );
                g.drawBitmap( 0, 0, this._cachedBitmap );

                // Draw stored shapes
                this.shapes.forEach( (shape, index) =>
                {
                    g.pen = new Pen( index === this.activeShapeIndex ? 0xff00ff00 : 0xffff0000 );
                    if ( this.shapeTypes[index] === "SprayCan" || this.shapeTypes[index] === "Brush" )
                    {
                        shape.forEach( p => { if ( Number.isFinite(p[0]) && Number.isFinite(p[1]) ) g.drawPoint( p[0], p[1] ); } );
                    }
                    else
                    {
                        for ( let i = 0; i < shape.length - 1; i++ )
                            if ( Number.isFinite(shape[i][0]) && Number.isFinite(shape[i][1]) &&
                                 Number.isFinite(shape[i+1][0]) && Number.isFinite(shape[i+1][1]) )
                                g.drawLine( shape[i][0], shape[i][1], shape[i+1][0], shape[i+1][1] );
                    }
                } );

                // Draw in-progress shape
                if ( this.currentShape.length > 0 )
                {
                    g.pen = new Pen( 0xff00ff00 );
                    if ( this.shapeType === "SprayCan" || this.shapeType === "Brush" )
                    {
                        this.currentShape.forEach( p => { if ( Number.isFinite(p[0]) && Number.isFinite(p[1]) ) g.drawPoint( p[0], p[1] ); } );
                    }
                    else
                    {
                        for ( let i = 0; i < this.currentShape.length - 1; i++ )
                            if ( Number.isFinite(this.currentShape[i][0])   && Number.isFinite(this.currentShape[i][1]) &&
                                 Number.isFinite(this.currentShape[i+1][0]) && Number.isFinite(this.currentShape[i+1][1]) )
                                g.drawLine( this.currentShape[i][0],   this.currentShape[i][1],
                                            this.currentShape[i+1][0], this.currentShape[i+1][1] );
                    }
                }

                // Draw gradient points
                if ( this.gradientStartPoint )
                {
                    g.pen   = new Pen(   0xff00ff00 );
                    g.brush = new Brush( 0xff00ff00 );
                    g.drawCircle( this.gradientStartPoint[0], this.gradientStartPoint[1], 5 );
                }
                if ( this.gradientEndPoint )
                {
                    g.pen   = new Pen(   0xffff0000 );
                    g.brush = new Brush( 0xffff0000 );
                    g.drawCircle( this.gradientEndPoint[0], this.gradientEndPoint[1], 5 );
                }
            }

            g.end();
        };

        this.viewport.onKeyPress = ( keyCode, modifiers ) =>
        {
            if ( keyCode === 0x20 && this.shapes.length > 0 )
            {
                this.activeShapeIndex = (this.activeShapeIndex + 1) % this.shapes.length;
                this.viewport.update();
            }
        };

        this.initScrollBars();
    }

    getImage() { return this.displayImage; }

    // Invalidate the cached render Bitmap. Must be called before
    // displayImage is replaced/forceClosed and before this control
    // is torn down, to ensure the cached Bitmap is released promptly.
    invalidateCache()
    {
        if ( this._cachedBitmap )
        {
            this._cachedBitmap.clear();
            this._cachedBitmap = null;
        }
    }

    doUpdateImage( image )
    {
        this.invalidateCache();
        this.displayImage = image;
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    initScrollBars( scrollPoint )
    {
        let image = this.getImage();
        if ( image == null || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange(   0, 0 );
            this.scrollPosition = new Point( 0, 0 );
        }
        else
        {
            let zf = this.zoomFactor;
            this.setHorizontalScrollRange( 0, Math.max( 0, image.width  * zf ) );
            this.setVerticalScrollRange(   0, Math.max( 0, image.height * zf ) );
            if ( scrollPoint )
                this.scrollPosition = scrollPoint;
            else
                this.scrollPosition = new Point(
                    Math.min( this.scrollPosition.x, image.width  * zf ),
                    Math.min( this.scrollPosition.y, image.height * zf ) );
        }
        if ( this.viewport ) this.viewport.update();
    }

    zoomIn()  { this.zoomFactor = Math.min( this.zoomFactor * 1.25, this.maxZoomFactor ); this.initScrollBars(); if ( this.viewport ) this.viewport.update(); }
    zoomOut() { this.zoomFactor = Math.max( this.zoomFactor * 0.80, this.minZoomFactor ); this.initScrollBars(); if ( this.viewport ) this.viewport.update(); }

    setFocus()
    {
        // Key events are already wired in the constructor via onKeyPress
    }

    // ---- Geometry helpers ----

    _calcTransformCenter( shape )
    {
        let sumX = 0, sumY = 0;
        shape.forEach( p => { sumX += p[0]; sumY += p[1]; } );
        return [sumX / shape.length, sumY / shape.length];
    }

    _calcDistance( x1, y1, x2, y2 )
    {
        return Math.sqrt( (x2-x1)**2 + (y2-y1)**2 );
    }

    _calcAngle( x1, y1, x2, y2 )
    {
        return Math.atan2( y2 - y1, x2 - x1 );
    }

    _transformShape( shape, angle, scaleX, scaleY, cx, cy )
    {
        return shape.map( p =>
        {
            let tx = p[0] - cx, ty = p[1] - cy;
            let rx = tx * Math.cos(angle) - ty * Math.sin(angle);
            let ry = tx * Math.sin(angle) + ty * Math.cos(angle);
            return [rx * scaleX + cx, ry * scaleY + cy];
        } );
    }

    // ---- Spray/brush point scaling (used by mask generation) ----

    scaleSprayCanPoints( points, scaleRatio )
    {
        let out = [];
        points.forEach( p =>
        {
            let x = Math.round( p[0] * scaleRatio );
            let y = Math.round( p[1] * scaleRatio );
            if ( !isNaN(x) && !isNaN(y) )
                for ( let dx = -Math.floor(scaleRatio/2); dx <= Math.floor(scaleRatio/2); dx++ )
                    for ( let dy = -Math.floor(scaleRatio/2); dy <= Math.floor(scaleRatio/2); dy++ )
                    {
                        let nx = x + dx, ny = y + dy;
                        if ( nx >= 0 && nx < this.displayImage.width && ny >= 0 && ny < this.displayImage.height )
                            out.push( [nx, ny] );
                    }
        } );
        return out;
    }

    scaleBrushPoints( points, scaleRatio )
    {
        let out = [];
        points.forEach( p =>
        {
            let x = Math.round( p[0] * scaleRatio );
            let y = Math.round( p[1] * scaleRatio );
            if ( !isNaN(x) && !isNaN(y) ) out.push( [x, y] );
        } );
        return out;
    }

    scaleShapes( newZoomLevel )
    {
        try
        {
            let ratio = this.previousZoomLevel / newZoomLevel;
            this.shapes = this.shapes.map( (shape, index) =>
            {
                if      ( this.shapeTypes[index] === "SprayCan" ) return this.scaleSprayCanPoints( shape, ratio );
                else if ( this.shapeTypes[index] === "Brush"    ) return this.scaleBrushPoints(    shape, ratio );
                else return shape.map( p => [Math.round(p[0]*ratio), Math.round(p[1]*ratio)] );
            } );
            this.previousZoomLevel = newZoomLevel;
            if ( this.viewport ) this.viewport.update();
        }
        catch ( e ) { console.warningln( "Error during shape scaling: " + e ); }
    }
};

// ============================================================================
// FAMEDialog
// ============================================================================

var FAMEDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.maskType        = "Binary";
        this.downsamplingFactor = 2;
        this.previousZoomLevel  = 1;

        // ---- Title ----
        this.title_Lbl = new Label( this );
        this.title_Lbl.frameStyle  = FrameStyle.Box;
        this.title_Lbl.margin      = 6;
        this.title_Lbl.useRichText = true;
        this.title_Lbl.text        = "<b>Freehand Adaptive Mask Editor (FAME) " + VERSION + "</b>";
        this.title_Lbl.textAlignment = TextAlignment.Center;

        // ---- Instructions ----
        this.instructions_Lbl = new TextBox( this );
        this.instructions_Lbl.readOnly   = true;
        this.instructions_Lbl.frameStyle = FrameStyle.Box;
        this.instructions_Lbl.text =
            "Instructions:\n\n" +
            "Shift + Click and drag to draw a shape.\n\n" +
            "Multiple Shapes can be drawn.\n\n" +
            "CTRL+Click and Drag to MOVE the drawn shape.\n" +
            "ALT+Click and Drag to ROTATE and RESIZE\n" +
            "Right Click to define start and end points for Gradient\n" +
            "SPACEBAR cycles through the active shapes\n\n" +
            "Grey undo button removes the active shape\n" +
            "Red Reset Button removes all shapes.";
        this.instructions_Lbl.setScaledMinWidth( 450 );

        // ---- Image selection ----
        let currentWindowName = ImageWindow.activeWindow.mainView.id;

        this.imageLabel = new Label( this );
        this.imageLabel.text = "Select Image:";
        this.imageLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.windowSelector_Cb = new ComboBox( this );
        this.windowSelector_Cb.toolTip = "Select the window you want to use.";
        for ( let i = 0; i < ImageWindow.windows.length; i++ )
        {
            this.windowSelector_Cb.addItem( ImageWindow.windows[i].mainView.id );
            if ( ImageWindow.windows[i].mainView.id == currentWindowName )
            {
                this.windowSelector_Cb.currentItem = i;
                let win = ImageWindow.windowById( currentWindowName );
                if ( win && !win.isNull ) parameters.targetWindow = win;
            }
        }

        this.windowSelector_Cb.onItemSelected = index =>
        {
            if ( index >= 0 )
            {
                let win = ImageWindow.windowById( this.windowSelector_Cb.itemText( index ) );
                if ( win && !win.isNull )
                {
                    parameters.targetWindow = win;
                    let selectedImage = win.mainView.image;
                    if ( selectedImage )
                    {
                        this.createAndDisplayTemporaryImage( selectedImage );
                        this.previousZoomLevel = this.downsamplingFactor;
                    }
                }
                else
                {
                    this.previewControl.visible = false;
                    this.zoomSizer.visible = false;
                    this.adjustToContents();
                }
            }
        };

        this.imageSelectionSizer = new HorizontalSizer;
        this.imageSelectionSizer.spacing = 4;
        this.imageSelectionSizer.add( this.imageLabel );
        this.imageSelectionSizer.add( this.windowSelector_Cb, 1 );

        // ---- Shape type radio buttons ----
        this.freehandShape_Rb = new RadioButton( this );
        this.freehandShape_Rb.text    = "Freehand Shape (Lasso Tool)";
        this.freehandShape_Rb.checked = true;
        this.freehandShape_Rb.onCheck = () =>
        {
            if ( this.freehandShape_Rb.checked )
            {
                this.previewControl.shapeType = "Freehand";
                this.brushRadiusSlider.hide();
                this.sprayDensitySlider.hide();
            }
        };

        this.brushRadiusSlider = new NumericControl( this );
        this.brushRadiusSlider.label.text = "Radius:";
        this.brushRadiusSlider.setRange( 1, 100 ); this.brushRadiusSlider.setPrecision( 1 );
        this.brushRadiusSlider.slider.setRange( 1, 100 ); this.brushRadiusSlider.setValue( 10 );
        this.brushRadiusSlider.hide();
        this.brushRadiusSlider.onValueUpdated = value => { this.previewControl.brushRadius = value; };

        this.sprayDensitySlider = new NumericControl( this );
        this.sprayDensitySlider.label.text = "Spray Density:";
        this.sprayDensitySlider.setRange( 0, 1 ); this.sprayDensitySlider.setPrecision( 2 );
        this.sprayDensitySlider.slider.setRange( 0, 100 ); this.sprayDensitySlider.setValue( 0.5 );
        this.sprayDensitySlider.hide();
        this.sprayDensitySlider.onValueUpdated = value => { this.previewControl.sprayDensity = value; };

        this.sprayCanTool_Rb = new RadioButton( this );
        this.sprayCanTool_Rb.text = "Spray Can";
        this.sprayCanTool_Rb.onCheck = () =>
        {
            if ( this.sprayCanTool_Rb.checked )
            {
                this.previewControl.shapeType = "SprayCan";
                this.brushRadiusSlider.show();
                this.sprayDensitySlider.show();
            }
        };

        this.brushTool_Rb = new RadioButton( this );
        this.brushTool_Rb.text = "Brush";
        this.brushTool_Rb.onCheck = () =>
        {
            if ( this.brushTool_Rb.checked )
            {
                this.previewControl.shapeType = "Brush";
                this.brushRadiusSlider.show();
                this.sprayDensitySlider.hide();
            }
        };

        this.ellipseShape_Rb = new RadioButton( this );
        this.ellipseShape_Rb.text = "Ellipse";
        this.ellipseShape_Rb.onCheck = () =>
        {
            if ( this.ellipseShape_Rb.checked )
            {
                this.previewControl.shapeType = "Ellipse";
                this.brushRadiusSlider.hide();
                this.sprayDensitySlider.hide();
            }
        };

        this.rectangleShape_Rb = new RadioButton( this );
        this.rectangleShape_Rb.text = "Rectangle";
        this.rectangleShape_Rb.onCheck = () =>
        {
            if ( this.rectangleShape_Rb.checked )
            {
                this.previewControl.shapeType = "Rectangle";
                this.brushRadiusSlider.hide();
                this.sprayDensitySlider.hide();
            }
        };

        this.shapeSizer = new VerticalSizer; this.shapeSizer.spacing = 4;
        this.shapeSizer.add( this.freehandShape_Rb );
        this.shapeSizer.add( this.brushTool_Rb );
        this.shapeSizer.add( this.brushRadiusSlider );
        this.shapeSizer.add( this.sprayCanTool_Rb );
        this.shapeSizer.add( this.sprayDensitySlider );
        this.shapeSizer.add( this.ellipseShape_Rb );
        this.shapeSizer.add( this.rectangleShape_Rb );

        // ---- Mask type checkboxes ----
        this.maskTypeLabel = new Label( this );
        this.maskTypeLabel.text = "Mask Type:";
        this.maskTypeLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.binaryMask_Cb = new CheckBox( this );
        this.binaryMask_Cb.text    = "Binary";
        this.binaryMask_Cb.toolTip = "Binary:\nBest for Linear Images.\nCreates a mask with binary values (0 or 1) inside the selected shapes.";
        this.binaryMask_Cb.checked = true;
        this.binaryMask_Cb.onCheck = () =>
        {
            if ( this.binaryMask_Cb.checked )
            {
                this.lightnessMask_Cb.checked = false; this.chrominanceMask_Cb.checked = false;
                this.colorMask_Cb.checked = false; this.gradientMask_Cb.checked = false;
                this.maskType = "Binary"; this.previewControl.maskType = "Binary";
            }
        };

        this.lightnessMask_Cb = new CheckBox( this );
        this.lightnessMask_Cb.text    = "Lightness";
        this.lightnessMask_Cb.toolTip = "Lightness:\nCreates a mask based on the brightness values of the original image inside the selected shapes.";
        this.lightnessMask_Cb.onCheck = () =>
        {
            if ( this.lightnessMask_Cb.checked )
            {
                this.binaryMask_Cb.checked = false; this.chrominanceMask_Cb.checked = false;
                this.colorMask_Cb.checked = false; this.gradientMask_Cb.checked = false;
                this.maskType = "Lightness"; this.previewControl.maskType = "Lightness";
            }
        };

        this.chrominanceMask_Cb = new CheckBox( this );
        this.chrominanceMask_Cb.text    = "Chrominance";
        this.chrominanceMask_Cb.toolTip = "Chrominance:\nCreates a mask based on the chrominance values of the original image inside the selected shapes.";
        this.chrominanceMask_Cb.onCheck = () =>
        {
            if ( this.chrominanceMask_Cb.checked )
            {
                this.binaryMask_Cb.checked = false; this.lightnessMask_Cb.checked = false;
                this.colorMask_Cb.checked = false; this.gradientMask_Cb.checked = false;
                this.maskType = "Chrominance"; this.previewControl.maskType = "Chrominance";
            }
        };

        this.colorMask_Cb = new CheckBox( this );
        this.colorMask_Cb.text    = "Color";
        this.colorMask_Cb.toolTip = "Color:\nCreates a mask based on the specified color saturation values inside the selected shapes.";
        this.colorMask_Cb.onCheck = () =>
        {
            if ( this.colorMask_Cb.checked )
            {
                this.binaryMask_Cb.checked = false; this.lightnessMask_Cb.checked = false;
                this.chrominanceMask_Cb.checked = false; this.gradientMask_Cb.checked = false;
                this.maskType = "Color"; this.previewControl.maskType = "Color";
            }
        };

        this.gradientMask_Cb = new CheckBox( this );
        this.gradientMask_Cb.text    = "Gradient Mask";
        this.gradientMask_Cb.toolTip = "Create a gradient mask between two points.";
        this.gradientMask_Cb.onCheck = () =>
        {
            if ( this.gradientMask_Cb.checked )
            {
                this.binaryMask_Cb.checked = false; this.lightnessMask_Cb.checked = false;
                this.chrominanceMask_Cb.checked = false; this.colorMask_Cb.checked = false;
                this.maskType = "Gradient"; this.previewControl.maskType = "Gradient";
            }
        };

        this.colorDropdown = new ComboBox( this );
        ["Red","Yellow","Green","Cyan","Blue","Magenta"].forEach( c => this.colorDropdown.addItem( c ) );
        this.colorDropdown.toolTip = "Select the color for the mask.";

        this.colorMaskSizer = new HorizontalSizer; this.colorMaskSizer.spacing = 4;
        this.colorMaskSizer.addStretch();
        this.colorMaskSizer.add( this.gradientMask_Cb );
        this.colorMaskSizer.addStretch();
        this.colorMaskSizer.add( this.colorMask_Cb );
        this.colorMaskSizer.add( this.colorDropdown );
        this.colorMaskSizer.addStretch();

        this.maskTypeSizer = new HorizontalSizer; this.maskTypeSizer.spacing = 4;
        this.maskTypeSizer.add( this.maskTypeLabel );
        this.maskTypeSizer.add( this.binaryMask_Cb );
        this.maskTypeSizer.add( this.lightnessMask_Cb );
        this.maskTypeSizer.add( this.chrominanceMask_Cb );

        // ---- Blur slider ----
        this.blurAmount_Slider = new NumericControl( this );
        this.blurAmount_Slider.label.text = "Blur Amount: ";
        this.blurAmount_Slider.setRange( 0, 200 ); this.blurAmount_Slider.slider.setRange( 0, 200 );
        this.blurAmount_Slider.setValue( 25 );

        // ---- AutoSTF ----
        this.autoSTF_Cb = new CheckBox( this );
        this.autoSTF_Cb.text    = "AutoSTF";
        this.autoSTF_Cb.checked = false;
        this.autoSTF_Cb.onCheck = () =>
        {
            if ( parameters.targetWindow )
            {
                let selectedImage = parameters.targetWindow.mainView.image;
                if ( selectedImage )
                    this.createAndDisplayTemporaryImage( selectedImage );
            }
        };

        // ---- Zoom level combo ----
        this.zoomLabel = new Label( this );
        this.zoomLabel.text = "Preview Zoom Level: ";
        this.zoomLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.zoomLevelComboBox = new ComboBox( this );
        ["1:1","1:2","1:4","1:8","Fit to Preview"].forEach( t => this.zoomLevelComboBox.addItem( t ) );
        this.zoomLevelComboBox.currentItem = 1;

        this.zoomLevelComboBox.onItemSelected = index =>
        {
            if ( parameters.targetWindow )
            {
                let selectedImage = parameters.targetWindow.mainView.image;
                if ( selectedImage )
                {
                    this.createAndDisplayTemporaryImage( selectedImage );
                    this._scaleShapes( this.downsamplingFactor );
                }
            }
        };

        // ---- Reset / Undo buttons ----
        this.resetButton = new ToolButton( this );
        this.resetButton.icon    = this.scaledResource( ":/icons/execute.png" );
        this.resetButton.toolTip = "Reset selections";
        this.resetButton.onMousePress = () =>
        {
            this.previewControl.shapes = [];
            this.previewControl.gradientStartPoint = null;
            this.previewControl.gradientEndPoint   = null;
            this.previewControl.viewport.update();
        };

        this.undoButton = new ToolButton( this );
        this.undoButton.icon    = this.scaledResource( ":/icons/reload.png" );
        this.undoButton.toolTip = "Undo last shape";
        this.undoButton.onMousePress = () =>
        {
            if ( this.previewControl.shapes.length > 0 )
            {
                this.previewControl.shapes.splice( this.previewControl.activeShapeIndex, 1 );
                this.previewControl.activeShapeIndex = this.previewControl.shapes.length > 0
                    ? this.previewControl.activeShapeIndex % this.previewControl.shapes.length : 0;
                this.previewControl.viewport.update();
            }
        };

        this.zoomSizer = new HorizontalSizer; this.zoomSizer.spacing = 4;
        this.zoomSizer.add( this.autoSTF_Cb );
        this.zoomSizer.add( this.zoomLabel );
        this.zoomSizer.add( this.zoomLevelComboBox );
        this.zoomSizer.add( this.undoButton );
        this.zoomSizer.add( this.resetButton );

        // ---- Authorship ----
        this.authorship_Lbl = new Label( this );
        this.authorship_Lbl.frameStyle  = FrameStyle.Box;
        this.authorship_Lbl.margin      = 6;
        this.authorship_Lbl.useRichText = true;
        this.authorship_Lbl.text        = "Written by Franklin Marek<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
        this.authorship_Lbl.textAlignment = TextAlignment.Center;

        // ---- New Instance / Execute buttons ----
        this.newInstance_Btn = new ToolButton( this );
        this.newInstance_Btn.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstance_Btn.setScaledFixedSize( 24, 24 );
        this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
        this.newInstance_Btn.onMousePress = () => { parameters.save(); this.newInstance(); };

        this.execute_Btn = new PushButton( this );
        this.execute_Btn.text    = "Execute";
        this.execute_Btn.toolTip = "Generate the mask based on the user-defined shapes.";
        this.execute_Btn.onClick = () =>
        {
            if ( parameters.targetWindow )
            {
                let selectedImage = parameters.targetWindow.mainView.image;
                if ( selectedImage ) this.generateMaskImage( selectedImage );
            }
        };

        this.buttonSizerHorizontal = new HorizontalSizer; this.buttonSizerHorizontal.spacing = 6;
        this.buttonSizerHorizontal.add( this.newInstance_Btn );
        this.buttonSizerHorizontal.addStretch();
        this.buttonSizerHorizontal.add( this.execute_Btn );

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth(  640 );
        this.previewControl.setMinHeight( 450 );

        // ---- Zoom in/out buttons ----
        this.zoomInButton = new PushButton( this );
        this.zoomInButton.text = ""; this.zoomInButton.icon = this.scaledResource( ":/icons/zoom-in.png" );
        this.zoomInButton.toolTip = "Zoom In";
        this.zoomInButton.onClick = () => { this.previewControl.zoomIn(); };

        this.zoomOutButton = new PushButton( this );
        this.zoomOutButton.text = ""; this.zoomOutButton.icon = this.scaledResource( ":/icons/zoom-out.png" );
        this.zoomOutButton.toolTip = "Zoom Out";
        this.zoomOutButton.onClick = () => { this.previewControl.zoomOut(); };

        this.zoomLabel2 = new Label( this );
        this.zoomLabel2.text = "Zoom In/Out (Mouse Wheel Supported)";

        this.zoomSizer2 = new HorizontalSizer; this.zoomSizer2.spacing = 6;
        this.zoomSizer2.add( this.zoomInButton );
        this.zoomSizer2.add( this.zoomOutButton );
        this.zoomSizer2.add( this.zoomLabel2 );
        this.zoomSizer2.addStretch();

        this.previewSizer = new VerticalSizer; this.previewSizer.spacing = 4;
        this.previewSizer.add( this.zoomSizer2 );
        this.previewSizer.add( this.previewControl, 1 );

        // ---- Left panel ----
        this.leftSizer = new VerticalSizer; this.leftSizer.spacing = 6;
        this.leftSizer.add( this.title_Lbl ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.instructions_Lbl ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.imageSelectionSizer ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.shapeSizer ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.blurAmount_Slider ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.maskTypeSizer );
        this.leftSizer.add( this.colorMaskSizer ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.zoomSizer ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.authorship_Lbl ); this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.buttonSizerHorizontal );

        this.leftPanel = new Control( this );
        this.leftPanel.sizer = this.leftSizer;
        this.leftPanel.setFixedWidth( 450 );

        this.leftSideSpacer = new Control( this );
        this.leftSideSpacer.setFixedWidth( 5 );

        this.mainSizer = new HorizontalSizer; this.mainSizer.spacing = 4;
        this.mainSizer.insert( 0, this.leftSideSpacer );
        this.mainSizer.addSpacing( 0 );
        this.mainSizer.add( this.leftPanel );
        this.mainSizer.add( this.previewSizer );

        this.sizer = this.mainSizer;
        this.windowTitle = "Freehand Adaptive Mask Editor (FAME)";
        this.adjustToContents();

        // ---- Key events (dialog level) ----
        this.onKeyDown = ( keyCode, modifiers ) =>
        {
            if ( keyCode === 0x20 && this.previewControl.shapes.length > 0 )
            {
                this.previewControl.activeShapeIndex =
                    (this.previewControl.activeShapeIndex + 1) % this.previewControl.shapes.length;
                this.previewControl.viewport.update();
            }
        };

        // ---- onShow ----
        this.onShow = () =>
        {
            if ( this.windowSelector_Cb.currentItem >= 0 )
            {
                let win = ImageWindow.windowById(
                    this.windowSelector_Cb.itemText( this.windowSelector_Cb.currentItem ) );
                if ( win && !win.isNull )
                {
                    let selectedImage = win.mainView.image;
                    if ( selectedImage )
                    {
                        this.createAndDisplayTemporaryImage( selectedImage );
                        this.previousZoomLevel = this.downsamplingFactor;
                    }
                }
            }
            else
            {
                this.previewControl.visible = false;
                this.zoomSizer.visible = false;
                this.adjustToContents();
            }
            this.previewControl.setFocus();
        };
    }

    // ---- Internal shape scaling helper (dialog-level) ----

    _scaleShapes( newZoomLevel )
    {
        try
        {
            let ratio = this.previousZoomLevel / newZoomLevel;
            this.previewControl.shapes = this.previewControl.shapes.map(
                shape => shape.map( p => [p[0]*ratio, p[1]*ratio] ) );
            this.previousZoomLevel = newZoomLevel;
            if ( this.previewControl.viewport ) this.previewControl.viewport.update();
        }
        catch ( e ) {}
    }

    updateZoomLevel( newZoomLevel )
    {
        if ( this.previewControl ) this.previewControl.scaleShapes( newZoomLevel );
    }

    // ---- Temporary image creation ----

    createAndDisplayTemporaryImage( selectedImage )
    {
        let win = new ImageWindow(
            selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        win.mainView.beginProcess();
        win.mainView.image.assign( selectedImage );
        win.mainView.endProcess();

        if ( this.autoSTF_Cb.checked )
        {
            let P = new PixelMath;
            P.expression =
                "C = -2.8  ;\n" +
                "B = 0.20  ;\n" +
                "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
                "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
            P.expression1 = P.expression2 = P.expression3 = "";
            P.useSingleExpression = true;
            P.symbols = "C,B,c";
            P.clearImageCacheAndExit = false;
            P.cacheGeneratedImages   = false;
            P.generateOutput         = true;
            P.singleThreaded         = false;
            P.optimization           = true;
            P.use64BitWorkingImage   = false;
            P.rescale      = false; P.rescaleLower = 0; P.rescaleUpper = 1;
            P.truncate     = true;  P.truncateLower = 0; P.truncateUpper = 1;
            P.createNewImage = false; P.showNewImage = true;
            P.newImageId = ""; P.newImageWidth = 0; P.newImageHeight = 0;
            P.newImageAlpha = false;
            P.newImageColorSpace   = PixelMath.SameAsTarget;
            P.newImageSampleFormat = PixelMath.SameAsTarget;
            P.executeOn( win.mainView );
        }

        let P2 = new IntegerResample;
        switch ( this.zoomLevelComboBox.currentItem )
        {
        case 0: P2.zoomFactor = -1; this.downsamplingFactor = 1; break;
        case 1: P2.zoomFactor = -2; this.downsamplingFactor = 2; break;
        case 2: P2.zoomFactor = -4; this.downsamplingFactor = 4; break;
        case 3: P2.zoomFactor = -8; this.downsamplingFactor = 8; break;
        case 4:
        {
            const pw = this.previewControl.width;
            const ws = Math.floor( selectedImage.width / pw );
            P2.zoomFactor = -Math.max( ws, 1 );
            this.downsamplingFactor = Math.max( ws, 1 );
            break;
        }
        default: P2.zoomFactor = -2; this.downsamplingFactor = 2; break;
        }
        P2.executeOn( win.mainView );

        let resizedImage = new Image( win.mainView.image );

        if ( resizedImage.width > 0 && resizedImage.height > 0 )
        {
            this.previewControl.doUpdateImage( resizedImage );
        }

        win.forceClose();
        return resizedImage;
    }

    // ---- Mask generation ----

    generateMaskImage( selectedImage )
    {
        console.noteln( "Mask Creation Started!" );
        console.flush();

        let gradientStartPoint = this.previewControl.gradientStartPoint;
        let gradientEndPoint   = this.previewControl.gradientEndPoint;

        if ( selectedImage.numberOfChannels < 3 && this.maskType === "Color" )
        {
            new MessageBox( "Cannot create a Color Mask from a mono image.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
            return;
        }

        let maskWindow = new ImageWindow(
            selectedImage.width, selectedImage.height,
            1, selectedImage.bitsPerSample, selectedImage.isReal, false );

        let maskImageView = maskWindow.mainView;
        maskImageView.beginProcess( UndoFlag.NoSwapFile );
        let maskImage = maskImageView.image;
        maskImage.fill( 0 );

        let scaleRatio = this.downsamplingFactor;
        let maskType   = this.maskType;
        let colorDropdown = this.colorDropdown;

        // ---- Polygon fill helpers (local to this call) ----

        function findMinMaxY( polygon )
        {
            let minY = polygon[0][1], maxY = polygon[0][1];
            for ( let i = 1; i < polygon.length; i++ )
            {
                if ( polygon[i][1] < minY ) minY = polygon[i][1];
                if ( polygon[i][1] > maxY ) maxY = polygon[i][1];
            }
            return { minY: minY, maxY: maxY };
        }

        function interpolateGradient( x, y, startX, startY, endX, endY )
        {
            let dx = endX - startX, dy = endY - startY;
            let length = Math.sqrt( dx*dx + dy*dy );
            if ( length === 0 ) return 0;
            let vx = x - startX, vy = y - startY;
            let t = (vx*dx + vy*dy) / (length * length);
            return Math.max( 0, Math.min( 1, t ) );
        }

        function fillPolygon( image, polygon )
        {
            let { minY, maxY } = findMinMaxY( polygon );
            for ( let y = minY; y <= maxY; y++ )
            {
                if ( y < 0 || y >= image.height ) continue;
                let intersections = [];
                for ( let i = 0; i < polygon.length; i++ )
                {
                    let j  = (i + 1) % polygon.length;
                    let x1 = polygon[i][0], y1 = polygon[i][1];
                    let x2 = polygon[j][0], y2 = polygon[j][1];
                    if ( (y1 <= y && y < y2) || (y2 <= y && y < y1) )
                        intersections.push( Math.round( x1 + (y - y1) * (x2 - x1) / (y2 - y1) ) );
                }
                intersections.sort( (a, b) => a - b );

                for ( let k = 0; k < intersections.length; k += 2 )
                {
                    let xStart = Math.max( intersections[k],   0 );
                    let xEnd   = Math.min( intersections[k+1], image.width - 1 );
                    for ( let x = xStart; x <= xEnd; x++ )
                    {
                        if ( maskType === "Binary" )
                        {
                            image.setSample( 1, x, y, 0 );
                        }
                        else if ( maskType === "Lightness" )
                        {
                            image.setSample( selectedImage.sample( x, y, 0 ), x, y, 0 );
                        }
                        else if ( maskType === "Chrominance" )
                        {
                            if ( selectedImage.numberOfChannels < 3 )
                            { console.warningln( "Cannot create Chrominance Mask from a greyscale image!" ); return; }
                            let r = selectedImage.sample(x,y,0), g = selectedImage.sample(x,y,1), b = selectedImage.sample(x,y,2);
                            let mx = Math.max(r,g,b), mn = Math.min(r,g,b);
                            let chrom = mx > 0 ? (mx - mn) / mx : 0;
                            image.setSample( isNaN(chrom) ? 0 : chrom, x, y, 0 );
                        }
                        else if ( maskType === "Color" )
                        {
                            let r = selectedImage.sample(x,y,0), g = selectedImage.sample(x,y,1), b = selectedImage.sample(x,y,2);
                            let hue = Math.atan2( Math.sqrt(3)*(g-b), 2*r-g-b ) * 180 / Math.PI;
                            if ( hue < 0 ) hue += 360;
                            let { min, max } = getColorRange( colorDropdown.itemText( colorDropdown.currentItem ) );
                            let colorValue = (min < max) ? (hue >= min && hue <= max ? 1 : 0) : ((hue >= min || hue <= max) ? 1 : 0);
                            let mx = Math.max(r,g,b);
                            let chrom = mx > 0 ? (mx - Math.min(r,g,b)) / mx : 0;
                            let sv = colorValue * chrom;
                            image.setSample( isNaN(sv) ? 0 : sv, x, y, 0 );
                        }
                        else if ( maskType === "Gradient" )
                        {
                            let sx = gradientStartPoint[0] * scaleRatio, sy = gradientStartPoint[1] * scaleRatio;
                            let ex = gradientEndPoint[0]   * scaleRatio, ey = gradientEndPoint[1]   * scaleRatio;
                            image.setSample( interpolateGradient( x, y, sx, sy, ex, ey ), x, y, 0 );
                        }
                    }
                }
            }
        }

        function drawBrushStrokes( image, strokes, thickness, ratio )
        {
            strokes = strokes.map( p => [p[0]*ratio, p[1]*ratio] );
            thickness *= ratio;
            for ( let i = 0; i < strokes.length - 1; i++ )
            {
                let p1 = strokes[i], p2 = strokes[i+1];
                let dx = p2[0]-p1[0], dy = p2[1]-p1[1];
                let len = Math.sqrt(dx*dx + dy*dy);
                if ( len === 0 ) continue;
                let ox = -dy/len * thickness/2, oy = dx/len * thickness/2;
                fillPolygon( image, [
                    [p1[0]+ox, p1[1]+oy], [p1[0]-ox, p1[1]-oy],
                    [p2[0]-ox, p2[1]-oy], [p2[0]+ox, p2[1]+oy]
                ] );
            }
        }

        function drawSprayCanPoints( image, strokes )
        {
            strokes.forEach( p =>
            {
                let x = Math.round(p[0]), y = Math.round(p[1]);
                if ( x >= 0 && x < image.width && y >= 0 && y < image.height )
                    image.setSample( 1, x, y, 0 );
            } );
        }

        function scaleSprayCanPointsMask( points, ratio )
        {
            let out = [];
            points.forEach( p =>
            {
                let x = Math.round( p[0] * ratio ), y = Math.round( p[1] * ratio );
                for ( let dx = 0; dx < ratio; dx++ )
                    for ( let dy = 0; dy < ratio; dy++ )
                        out.push( [x+dx, y+dy] );
            } );
            return out;
        }

        this.previewControl.shapes.forEach( (shape, index) =>
        {
            let scaledShape = shape.map( p => [p[0]*scaleRatio, p[1]*scaleRatio] );
            if ( this.previewControl.shapeTypes[index] === "Brush" )
                drawBrushStrokes( maskImage, shape, this.previewControl.brushRadius, scaleRatio );
            else if ( this.previewControl.shapeTypes[index] === "SprayCan" )
                drawSprayCanPoints( maskImage, scaleSprayCanPointsMask( shape, scaleRatio ) );
            else
                fillPolygon( maskImage, scaledShape );
        } );

        maskImageView.endProcess();

        let suffix =
            maskType === "Binary"     ? "_bin"      :
            maskType === "Lightness"  ? "_lght"     :
            maskType === "Chrominance"? "_chrm"     :
            maskType === "Color"      ? "_color"    :
            maskType === "Gradient"   ? "_gradient" : "";

        maskImageView.id = parameters.targetWindow.mainView.id + "_FAME_Mask" + suffix;
        maskWindow.show();

        let blurAmount = this.blurAmount_Slider.value;
        if ( blurAmount > 0 )
        {
            let P = new Convolution;
            P.mode  = Convolution.Parametric;
            P.sigma = blurAmount;
            P.executeOn( maskImageView );
        }
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );
    let dialog = new FAMEDialog();
    dialog.execute();
}

main();
