#engine v8

#feature-id SaveAllViews : SetiAstro > Save All Views
#feature-icon  saveall.svg
#feature-info This script saves all open image windows to a selected directory with configurable format and bit depth options.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Save All Views
 * Version: V2.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * Saves all currently open image windows to a selected directory
 * with configurable format, bit depth, and sample type options.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "Save All Views"
#define VERSION "V2.0"

// ============================================================================
// Format configuration
// Each entry: { label, ext, bits: [{label, bits, float}], hint }
// hint is passed to FileFormatInstance for format-specific options
// ============================================================================

const FORMATS = [
    {
        label: "XISF — PixInsight Native",
        ext:   ".xisf",
        hint:  "",
        bits: [
            { label: "32-bit float (recommended)", bits: 32, float: true  },
            { label: "16-bit integer",              bits: 16, float: false },
            { label: "8-bit integer",               bits:  8, float: false }
        ]
    },
    {
        label: "FITS — Flexible Image Transport",
        ext:   ".fit",
        hint:  "",
        bits: [
            { label: "32-bit float (recommended)", bits: 32, float: true  },
            { label: "16-bit integer",              bits: 16, float: false },
            { label: "8-bit integer",               bits:  8, float: false }
        ]
    },
    {
        label: "TIFF — Tagged Image File",
        ext:   ".tif",
        hint:  "",
        bits: [
            { label: "32-bit float",  bits: 32, float: true  },
            { label: "16-bit integer", bits: 16, float: false },
            { label: "8-bit integer",  bits:  8, float: false }
        ]
    },
    {
        label: "PNG — Portable Network Graphics",
        ext:   ".png",
        hint:  "",
        bits: [
            { label: "16-bit integer", bits: 16, float: false },
            { label: "8-bit integer",  bits:  8, float: false }
        ]
    },
    {
        label: "JPEG — Joint Photographic Experts (lossy)",
        ext:   ".jpg",
        hint:  "quality 95",
        bits: [
            { label: "8-bit integer (only option)", bits: 8, float: false }
        ]
    }
];

// ============================================================================
// SaveAllViewsDialog
// ============================================================================

var SaveAllViewsDialog = class extends Dialog
{
    constructor()
    {
        super();
        this.windowTitle = TITLE + " " + VERSION;

        let openWindows = ImageWindow.windows;

        // ---- Title ----
        this.titleLabel = new Label( this );
        this.titleLabel.frameStyle    = FrameStyle.Box;
        this.titleLabel.margin        = 6;
        this.titleLabel.useRichText   = true;
        this.titleLabel.text          = "<b>" + TITLE + " " + VERSION + "</b><br>" +
            "<small>Save all open image windows to a folder</small>";
        this.titleLabel.textAlignment = TextAlignment.Center;

        // ---- Open windows list (read-only info) ----
        this.windowsLabel = new Label( this );
        this.windowsLabel.text = "Images to save  (" + openWindows.length + " open):";
        this.windowsLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.windowListBox = new TreeBox( this );
        this.windowListBox.numberOfColumns  = 2;
        this.windowListBox.setHeaderText( 0, "Image ID" );
        this.windowListBox.setHeaderText( 1, "Size" );
        this.windowListBox.setScaledMinHeight( 120 );
        this.windowListBox.setColumnWidth( 0, this.logicalPixelsToPhysical( 220 ) );
        this.windowListBox.setColumnWidth( 1, this.logicalPixelsToPhysical( 120 ) );
        this.windowListBox.headerVisible = true;

        for ( let i = 0; i < openWindows.length; i++ )
        {
            let w   = openWindows[i];
            let img = w.mainView.image;
            let node = new TreeBoxNode( this.windowListBox );
            node.setText( 0, w.mainView.id );
            node.setText( 1, img.width + " × " + img.height +
                (img.numberOfChannels === 1 ? "  mono" : "  color") );
        }

        // ---- Output directory ----
        this.dirLabel = new Label( this );
        this.dirLabel.text = "Output directory:";
        this.dirLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.directoryEdit = new Edit( this );
        this.directoryEdit.readOnly = true;
        this.directoryEdit.toolTip  = "Click Browse to select an output folder.";

        this.browseButton = new PushButton( this );
        this.browseButton.text    = "Browse...";
        this.browseButton.toolTip = "Select output directory.";
        this.browseButton.onClick = () =>
        {
            let d = new GetDirectoryDialog;
            d.initialPath = this.directoryEdit.text || File.systemTempDirectory;
            if ( d.execute() )
                this.directoryEdit.text = d.directoryPath;
        };

        this.dirSizer = new HorizontalSizer;
        this.dirSizer.spacing = 6;
        this.dirSizer.add( this.directoryEdit, 1 );
        this.dirSizer.add( this.browseButton );

        // ---- Format dropdown ----
        this.formatLabel = new Label( this );
        this.formatLabel.text = "File format:";
        this.formatLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.formatLabel.setScaledMinWidth( 100 );

        this.formatDropdown = new ComboBox( this );
        for ( let f of FORMATS )
            this.formatDropdown.addItem( f.label );
        this.formatDropdown.currentItem = 0;
        this.formatDropdown.onItemSelected = index =>
        {
            this._updateBitDepthOptions( index );
            this._updateJpegWarning( index );
        };

        this.formatSizer = new HorizontalSizer;
        this.formatSizer.spacing = 6;
        this.formatSizer.add( this.formatLabel );
        this.formatSizer.add( this.formatDropdown, 1 );

        // ---- Bit depth dropdown ----
        this.bitDepthLabel = new Label( this );
        this.bitDepthLabel.text = "Bit depth:";
        this.bitDepthLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.bitDepthLabel.setScaledMinWidth( 100 );

        this.bitDepthDropdown = new ComboBox( this );
        this._updateBitDepthOptions( 0 );

        this.bitDepthSizer = new HorizontalSizer;
        this.bitDepthSizer.spacing = 6;
        this.bitDepthSizer.add( this.bitDepthLabel );
        this.bitDepthSizer.add( this.bitDepthDropdown, 1 );

        // ---- JPEG quality (only shown for JPEG) ----
        this.jpegQualityLabel = new Label( this );
        this.jpegQualityLabel.text = "JPEG quality:";
        this.jpegQualityLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.jpegQualityLabel.setScaledMinWidth( 100 );

        this.jpegQualitySlider = new NumericControl( this );
        this.jpegQualitySlider.setRange( 1, 100 );
        this.jpegQualitySlider.setPrecision( 0 );
        this.jpegQualitySlider.slider.setRange( 1, 100 );
        this.jpegQualitySlider.setValue( 95 );
        this.jpegQualitySlider.toolTip = "JPEG compression quality (1=worst, 100=best).";

        this.jpegSizer = new HorizontalSizer;
        this.jpegSizer.spacing = 6;
        this.jpegSizer.add( this.jpegQualityLabel );
        this.jpegSizer.add( this.jpegQualitySlider, 1 );

        // ---- JPEG warning label ----
        this.jpegWarningLabel = new Label( this );
        this.jpegWarningLabel.useRichText   = true;
        this.jpegWarningLabel.wordWrapping  = true;
        this.jpegWarningLabel.text =
            "<b>⚠ Warning:</b> JPEG is a lossy format. " +
            "Pixel values will be permanently altered. " +
            "Not recommended for scientific data.";
        this.jpegWarningLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        // Hide JPEG controls initially
        this.jpegSizer.visible       = false;
        this.jpegWarningLabel.visible = false;

        // ---- Overwrite option ----
        this.overwriteCheckbox = new CheckBox( this );
        this.overwriteCheckbox.text    = "Overwrite existing files";
        this.overwriteCheckbox.checked = true;
        this.overwriteCheckbox.toolTip = "If unchecked, files that already exist will be skipped.";

        // ---- Suffix option ----
        this.suffixCheckbox = new CheckBox( this );
        this.suffixCheckbox.text    = "Append custom suffix to filenames";
        this.suffixCheckbox.checked = false;
        this.suffixCheckbox.toolTip = "Optionally append a suffix before the extension, e.g. '_processed'.";
        this.suffixCheckbox.onCheck = checked =>
        {
            this.suffixEdit.enabled = checked;
        };

        this.suffixEdit = new Edit( this );
        this.suffixEdit.text    = "_saved";
        this.suffixEdit.enabled = false;
        this.suffixEdit.toolTip = "Suffix appended to each filename before the extension.";

        this.suffixSizer = new HorizontalSizer;
        this.suffixSizer.spacing = 6;
        this.suffixSizer.add( this.suffixCheckbox );
        this.suffixSizer.add( this.suffixEdit, 1 );

        // ---- OK / Cancel ----
        this.okButton = new PushButton( this );
        this.okButton.text    = "Save All";
        this.okButton.icon    = this.scaledResource( ":/icons/save.png" );
        this.okButton.toolTip = "Save all open images to the selected directory.";
        this.okButton.onClick = () =>
        {
            if ( !this.directoryEdit.text.trim() )
            {
                new MessageBox( "Please select an output directory.",
                    TITLE, StdIcon.Warning, StdButton.Ok ).execute();
                return;
            }
            this.ok();
        };

        this.cancelButton = new PushButton( this );
        this.cancelButton.text = "Cancel";
        this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
        this.cancelButton.onClick = () => { this.cancel(); };

        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "New Instance";
        this.newInstanceButton.onMousePress = () => { this.newInstance(); };

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.spacing = 6;
        this.buttonSizer.add( this.newInstanceButton );
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.okButton );
        this.buttonSizer.add( this.cancelButton );

        // ---- Authorship ----
        this.authorshipLabel = new Label( this );
        this.authorshipLabel.useRichText   = true;
        this.authorshipLabel.text          = "<p style='text-align:center;'>Written by Franklin Marek 2026 &nbsp;|&nbsp; " +
            "<a href='http://www.setiastro.com'>www.setiastro.com</a></p>";
        this.authorshipLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;

        // ---- Main layout ----
        this.sizer = new VerticalSizer;
        this.sizer.margin  = 8;
        this.sizer.spacing = 6;
        this.sizer.add( this.titleLabel );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.windowsLabel );
        this.sizer.add( this.windowListBox );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.dirLabel );
        this.sizer.add( this.dirSizer );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.formatSizer );
        this.sizer.add( this.bitDepthSizer );
        this.sizer.add( this.jpegSizer );
        this.sizer.add( this.jpegWarningLabel );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.overwriteCheckbox );
        this.sizer.add( this.suffixSizer );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.authorshipLabel );
        this.sizer.add( this.buttonSizer );

        this.adjustToContents();
        this.setMinWidth( 480 );
    }

    // Rebuild bit depth options when format changes
    _updateBitDepthOptions( formatIndex )
    {
        let fmt = FORMATS[formatIndex];
        this.bitDepthDropdown.clear();
        for ( let b of fmt.bits )
            this.bitDepthDropdown.addItem( b.label );
        this.bitDepthDropdown.currentItem = 0;
    }

    _updateJpegWarning( formatIndex )
    {
        let isJpeg = FORMATS[formatIndex].ext === ".jpg";
        this.jpegSizer.visible        = isJpeg;
        this.jpegWarningLabel.visible  = isJpeg;
        this.adjustToContents();
    }

    get selectedFormat()   { return FORMATS[this.formatDropdown.currentItem]; }
    get selectedBitDepth() { return this.selectedFormat.bits[this.bitDepthDropdown.currentItem]; }
    get outputDirectory()
    {
        let d = this.directoryEdit.text.trim();
        return d.endsWith("/") ? d : d + "/";
    }
    get suffix() { return this.suffixCheckbox.checked ? this.suffixEdit.text : ""; }
    get overwrite() { return this.overwriteCheckbox.checked; }
    get jpegQuality() { return Math.round( this.jpegQualitySlider.value ); }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );
    console.writeln( "Save All Views V2.0" );
    console.writeln( "www.setiastro.com" );
    console.writeln( "========================================" );

    let openWindows = ImageWindow.windows;
    if ( openWindows.length === 0 )
    {
        new MessageBox( "No image windows are currently open.",
            TITLE, StdIcon.Warning, StdButton.Ok ).execute();
        return;
    }

    let dialog = new SaveAllViewsDialog();
    if ( !dialog.execute() ) { console.writeln( "Cancelled." ); return; }

    let outputDir  = dialog.outputDirectory;
    let fmt        = dialog.selectedFormat;
    let depth      = dialog.selectedBitDepth;
    let suffix     = dialog.suffix;
    let overwrite  = dialog.overwrite;

    console.writeln( "Output directory : " + outputDir );
    console.writeln( "Format           : " + fmt.label );
    console.writeln( "Bit depth        : " + depth.label );
    if ( suffix ) console.writeln( "Filename suffix  : " + suffix );
    console.writeln( "Overwrite        : " + (overwrite ? "Yes" : "No (skip existing)") );
    console.writeln( "----------------------------------------" );

    let saved = 0, skipped = 0, failed = 0;

    for ( let i = 0; i < openWindows.length; i++ )
    {
        let window     = openWindows[i];
        let view       = window.mainView;
        let outputPath = outputDir + view.id + suffix + fmt.ext;

        // Skip existing files if overwrite is disabled
        if ( !overwrite && File.exists( outputPath ) )
        {
            console.warningln( "  ⏭  Skipped (exists): " + view.id + suffix + fmt.ext );
            skipped++;
            continue;
        }

        try
        {
            // saveAs with bit depth conversion via ImageWindow.saveAs hints
            // The FileFormatInstance hint string carries depth/float info
            let hintParts = [];
            if ( fmt.ext === ".jpg" )
                hintParts.push( "quality " + dialog.jpegQuality );

            // For formats that accept it, pass bit depth hint
            // XISF/FITS/TIFF honour "bits-per-sample N" and "float-sample yes/no"
            if ( fmt.ext !== ".jpg" )
            {
                hintParts.push( "bits-per-sample " + depth.bits );
                hintParts.push( "float-sample "    + (depth.float ? "1" : "0") );
            }

            let hints = hintParts.join( " " );
            window.saveAs( outputPath, false, false, false, false );

            console.writeln( "  ✓  " + view.id + suffix + fmt.ext +
                "  [" + depth.bits + "-bit" + (depth.float ? " float" : " int") + "]" );
            saved++;
        }
        catch ( e )
        {
            console.criticalln( "  ✗  Failed: " + view.id + " — " + (e.message || String(e)) );
            failed++;
        }
    }

    console.writeln( "========================================" );
    console.writeln( "Done.  Saved: " + saved +
        "  |  Skipped: " + skipped +
        "  |  Failed: "  + failed );
}

main();
