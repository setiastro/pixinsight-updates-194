#engine v8

#feature-id AstroDepth : SetiAstro > AstroDepth Image Enhancer
#feature-icon  astrodepth.svg
#feature-info This script allows users adjust a depth of field effect on their images

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * AstroDepth Image Enhancer
 * Version: V1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

// ============================================================================
// Depth effect processing function (standalone — no class needed)
// ============================================================================

function applyDepthEffect( window, effectStrength )
{
    if ( !window || window.isNull )
    { console.criticalln("No valid image window selected."); return; }

    let imageMedianValue = window.mainView.image.median();
    console.writeln( "Image median value: " + imageMedianValue );

    // ---- Dark areas mask + blur + darken curves ----
    let rangeSelection = new RangeSelection;
    rangeSelection.lowRange    = imageMedianValue;
    rangeSelection.highRange   = 1.0;
    rangeSelection.fuzziness   = 0.33 * effectStrength;
    rangeSelection.smoothness  = Math.min( 100, 100 * effectStrength );
    rangeSelection.screening   = false;
    rangeSelection.toLightness = true;
    rangeSelection.invert      = true;
    rangeSelection.createNewImage = true;
    rangeSelection.showNewImage   = false;
    rangeSelection.executeOn( window.mainView );

    let maskImage = ImageWindow.activeWindow;
    window.setMask( maskImage );
    window.maskVisible = true;

    let convolution = new Convolution;
    convolution.mode           = Convolution.Parametric;
    convolution.sigma          = 50 * effectStrength;
    convolution.shape          = 2.00;
    convolution.aspectRatio    = 1.00;
    convolution.rotationAngle  = 0.00;
    convolution.filterSource   = "";
    convolution.rescaleHighPass = false;
    convolution.viewId         = "";
    convolution.executeOn( window.mainView, true );

    let curves = new CurvesTransformation;
    curves.K = [
        [0.00000, 0.00000],
        [0.5 * imageMedianValue, 0.5 * imageMedianValue - 0.2 * imageMedianValue * effectStrength],
        [0.75000, 0.75000],
        [1.00000, 1.00000]
    ];
    curves.Kt = CurvesTransformation.AkimaSubsplines;
    curves.executeOn( window.mainView, true );

    window.removeMask();
    maskImage.forceClose();

    // ---- Bright areas mask + sharpen + brighten curves ----
    rangeSelection.invert         = false;
    rangeSelection.createNewImage = true;
    rangeSelection.showNewImage   = false;
    rangeSelection.executeOn( window.mainView );

    let brightMaskImage = ImageWindow.activeWindow;
    window.setMask( brightMaskImage );
    window.maskVisible = true;

    let unsharpMask = new UnsharpMask;
    unsharpMask.sigma                = 30.00 * effectStrength;
    unsharpMask.amount               = Math.max( 0.1, 0.2 * effectStrength );
    unsharpMask.useLuminance         = true;
    unsharpMask.linear               = false;
    unsharpMask.deringing            = false;
    unsharpMask.deringingDark        = 0.1000;
    unsharpMask.deringingBright      = 0.0000;
    unsharpMask.outputDeringingMaps  = false;
    unsharpMask.rangeLow             = 0.0;
    unsharpMask.rangeHigh            = 0.0;
    unsharpMask.executeOn( window.mainView, true );

    let brightenCurves = new CurvesTransformation;
    brightenCurves.K = [
        [0.00000, 0.00000],
        [0.25, 0.25],
        [0.5, 0.5 + 0.1 * effectStrength],
        [1.00000, 1.00000]
    ];
    brightenCurves.Kt = CurvesTransformation.AkimaSubsplines;
    brightenCurves.executeOn( window.mainView, true );

    window.removeMask();
    brightMaskImage.forceClose();

    console.writeln( "Effect applied successfully." );
}

// ============================================================================
// ScrollControl — V8 render cache added
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.mainImage     = null;
        this.zoomFactor    = 1.0;
        this.minZoomFactor = 0.1;
        this.maxZoomFactor = 10.0;
        this.dragging      = false;
        this.dragOrigin    = new Point( 0, 0 );

        // V8 render cache
        this._cachedBitmap = null;

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            this.dragging = true;
            this.dragOrigin.x = x;
            this.dragOrigin.y = y;
            this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            if ( this.dragging )
            {
                let dx = (x - this.dragOrigin.x) / this.zoomFactor;
                let dy = (y - this.dragOrigin.y) / this.zoomFactor;
                this.scrollPosition = new Point(
                    this.scrollPosition.x - dx,
                    this.scrollPosition.y - dy );
                this.dragOrigin.x = x;
                this.dragOrigin.y = y;
                if ( this.viewport ) this.viewport.update();
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.dragging = false;
            this.viewport.cursor = new Cursor( StdCursor.Arrow );
        };

        this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
        {
            if ( delta > 0 ) this.zoomFactor = Math.min( this.zoomFactor * 1.25, this.maxZoomFactor );
            else             this.zoomFactor = Math.max( this.zoomFactor * 0.8,  this.minZoomFactor );
            this.initScrollBars();
            if ( this.viewport ) this.viewport.update();
        };

        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this.viewport );
            let image = this.mainImage;

            if ( !image || image.isEmpty )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
                g.end();
                return;
            }

            // Rebuild cache only when invalidated
            if ( !this._cachedBitmap )
                this._cachedBitmap = image.render();

            g.scaleTransformation( this.zoomFactor );
            g.translateTransformation( -this.scrollPosition.x, -this.scrollPosition.y );
            g.drawBitmap( 0, 0, this._cachedBitmap );
            g.end();
        };

        this.initScrollBars();
    }

    invalidateCache()
    {
        if ( this._cachedBitmap )
        { this._cachedBitmap.clear(); this._cachedBitmap = null; }
    }

    getImage() { return this.mainImage; }

    updateImage( image )
    {
        this.invalidateCache();
        this.mainImage = image;
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    initScrollBars( scrollPoint )
    {
        let image = this.getImage();
        if ( !image || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange(   0, 0 );
            this.scrollPosition = new Point( 0, 0 );
        }
        else
        {
            let zf = this.zoomFactor;
            this.setHorizontalScrollRange( 0, Math.max(0, image.width  * zf) );
            this.setVerticalScrollRange(   0, Math.max(0, image.height * zf) );
            if ( scrollPoint )
                this.scrollPosition = scrollPoint;
            else
                this.scrollPosition = new Point(
                    Math.min(this.scrollPosition.x, image.width  * zf),
                    Math.min(this.scrollPosition.y, image.height * zf) );
        }
        if ( this.viewport ) this.viewport.update();
    }
};

// ============================================================================
// DepthEffectDialog
// ============================================================================

var DepthEffectDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.windowTitle   = "AstroDepth Image Enhancer";
        this.userResizable = true;
        this.okPressed     = false;

        this.tempImageWindows   = [];
        this.tempImageWindow    = null;
        this.applyTempImageWindow = null;
        this.baseImageWindow    = null;
        this.selectedWindow     = ImageWindow.activeWindow;

        // ---- Title ----
        this.titleLabel = new Label( this );
        this.titleLabel.frameStyle    = FrameStyle.Box;
        this.titleLabel.margin        = 6;
        this.titleLabel.useRichText   = true;
        this.titleLabel.text          = "<b>AstroDepth Image Enhancer</b>";
        this.titleLabel.textAlignment = TextAlignment.Center;

        // ---- Instructions ----
        this.instructionsLabel = new TextBox( this );
        this.instructionsLabel.readOnly   = true;
        this.instructionsLabel.frameStyle = FrameStyle.Box;
        this.instructionsLabel.text =
            "Instructions:\n\n" +
            "Adjust the Effect Strength using the slider.\n" +
            "Click 'Refresh Preview' to see the effect.\n" +
            "OK will apply the effect, Cancel will exit without changes.";
        this.instructionsLabel.setScaledMinWidth( 200 );

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth( 640 );
        this.previewControl.setMinHeight( 450 );

        // ---- Image window dropdown ----
        this.imageWindowDropdown = new ComboBox( this );
        this.imageWindowDropdown.editEnabled = false;

        this.populateImageWindowDropdown();

        this.imageWindowDropdown.onItemSelected = index =>
        {
            if ( index >= 0 )
            {
                let windowId = this.imageWindowDropdown.itemText( index );
                this.cleanupTemporaryImage();
                this.selectedWindow = ImageWindow.windowById( windowId );
                if ( this.selectedWindow && !this.selectedWindow.isNull )
                    this.setPreviewImage( this.selectedWindow );
            }
        };

        // ---- Strength slider ----
        this.strengthSliderLabel = new Label( this );
        this.strengthSliderLabel.text = "Effect Strength:";
        this.strengthSliderLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.strengthSlider = new NumericControl( this );
        this.strengthSlider.setRange( 0.1, 2.0 );
        this.strengthSlider.setPrecision( 2 );
        this.strengthSlider.slider.setRange( 1, 200 );
        this.strengthSlider.slider.setScaledMinWidth( 120 );
        this.strengthSlider.setValue( 1.0 );
        this.strengthSlider.updateControls();

        this.strengthSizer = new HorizontalSizer;
        this.strengthSizer.spacing = 6;
        this.strengthSizer.add( this.strengthSliderLabel );
        this.strengthSizer.add( this.strengthSlider, 1 );

        // ---- Blend checkbox + slider ----
        this.blendCheckbox = new CheckBox( this );
        this.blendCheckbox.text    = "Enable Blend";
        this.blendCheckbox.toolTip = "Blend the original image with the modified image.";
        this.blendCheckbox.onCheck = checked =>
        {
            this.blendSlider.visible = checked;
        };

        this.blendSlider = new NumericControl( this );
        this.blendSlider.setRange( 0, 1 ); this.blendSlider.setPrecision( 2 );
        this.blendSlider.slider.setRange( 0, 100 ); this.blendSlider.setValue( 0.5 );
        this.blendSlider.toolTip = "Blend amount between the original and modified image.";
        this.blendSlider.visible = false;

        // ---- Preview refresh button ----
        this.previewRefreshButton = new PushButton( this );
        this.previewRefreshButton.text = "Refresh Preview";
        this.previewRefreshButton.onClick = () =>
        {
            let selectedWindowIndex = this.imageWindowDropdown.currentItem;
            let windowId = this.imageWindowDropdown.itemText( selectedWindowIndex );
            let selectedWindow = ImageWindow.windowById( windowId );
            if ( selectedWindow && !selectedWindow.isNull )
                this.applyPreview( selectedWindow );
            else
                console.criticalln( "No valid image window selected for preview." );
        };

        // ---- OK button ----
        this.okButton = new PushButton( this );
        this.okButton.text = "OK";
        this.okButton.onClick = () =>
        {
            let selectedWindowIndex = this.imageWindowDropdown.currentItem;
            let windowId = this.imageWindowDropdown.itemText( selectedWindowIndex );
            let selectedWindow = ImageWindow.windowById( windowId );

            if ( selectedWindow && !selectedWindow.isNull )
            {
                let effectStrength = this.strengthSlider.value;

                this.baseImageWindow = new ImageWindow(
                    selectedWindow.mainView.image.width,
                    selectedWindow.mainView.image.height,
                    selectedWindow.mainView.image.numberOfChannels );
                this.baseImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
                this.baseImageWindow.mainView.image.assign( selectedWindow.mainView.image );
                this.baseImageWindow.mainView.endProcess();

                applyDepthEffect( selectedWindow, effectStrength );

                if ( this.blendCheckbox.checked )
                {
                    let baseImageId = this.baseImageWindow.mainView.id;
                    let finalImageId = selectedWindow.mainView.id;
                    this.applyBlendOperation( baseImageId, finalImageId );
                }

                this.okPressed = true;
            }
            else
            {
                console.criticalln( "No valid image window selected for depth effect." );
                this.okPressed = false;
            }

            this.cleanupTemporaryImage();
            this.cancel();
        };

        // ---- Cancel button ----
        this.cancelButton = new PushButton( this );
        this.cancelButton.text = "Cancel";
        this.cancelButton.onClick = () =>
        {
            this.okPressed = false;
            this.cleanupTemporaryImage();
            this.cancel();
        };

        this.onClose = () => { this.cleanupTemporaryImage(); };

        // ---- Authorship ----
        this.authorship_Lbl = new Label( this );
        this.authorship_Lbl.frameStyle    = FrameStyle.Box;
        this.authorship_Lbl.margin        = 6;
        this.authorship_Lbl.useRichText   = true;
        this.authorship_Lbl.text          = "Written by Franklin Marek 2026<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
        this.authorship_Lbl.textAlignment = TextAlignment.Center;
        this.authorship_Lbl.onMousePress  = () => { Dialog.openBrowser( "http://www.setiastro.com" ); };

        // ---- Zoom buttons ----
        this.zoomInButton = new PushButton( this );
        this.zoomInButton.text = "";
        this.zoomInButton.icon = this.scaledResource( ":/icons/zoom-in.png" );
        this.zoomInButton.onClick = () =>
        {
            this.previewControl.zoomFactor = Math.min( this.previewControl.zoomFactor * 1.25, this.previewControl.maxZoomFactor );
            this.previewControl.initScrollBars();
            this.previewControl.viewport.update();
        };

        this.zoomOutButton = new PushButton( this );
        this.zoomOutButton.text = "";
        this.zoomOutButton.icon = this.scaledResource( ":/icons/zoom-out.png" );
        this.zoomOutButton.onClick = () =>
        {
            this.previewControl.zoomFactor = Math.max( this.previewControl.zoomFactor * 0.8, this.previewControl.minZoomFactor );
            this.previewControl.initScrollBars();
            this.previewControl.viewport.update();
        };

        this.zoomButtonsSizer = new HorizontalSizer;
        this.zoomButtonsSizer.spacing = 6;
        this.zoomButtonsSizer.add( this.zoomInButton );
        this.zoomButtonsSizer.add( this.zoomOutButton );
        this.zoomButtonsSizer.addStretch();

        // ---- New Instance button ----
        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "Create a new instance with the current parameters.";
        this.newInstanceButton.onMousePress = () => { this.newInstance(); };

        // ---- Layout ----
        let leftSideSizer = new VerticalSizer;
        leftSideSizer.margin = 6;
        leftSideSizer.add( this.titleLabel );
        leftSideSizer.addSpacing( 10 );
        leftSideSizer.add( this.instructionsLabel );
        leftSideSizer.addSpacing( 10 );
        leftSideSizer.addStretch();
        leftSideSizer.add( this.imageWindowDropdown );
        leftSideSizer.addStretch();
        leftSideSizer.add( this.strengthSizer );
        leftSideSizer.addSpacing( 10 );
        leftSideSizer.add( this.blendCheckbox );
        leftSideSizer.add( this.blendSlider );
        leftSideSizer.addSpacing( 10 );
        leftSideSizer.add( this.previewRefreshButton );
        leftSideSizer.addSpacing( 10 );
        leftSideSizer.add( this.okButton );
        leftSideSizer.add( this.cancelButton );
        leftSideSizer.addStretch();
        leftSideSizer.add( this.authorship_Lbl );
        leftSideSizer.addStretch();

        let instanceButtonSizer = new HorizontalSizer;
        instanceButtonSizer.add( this.newInstanceButton );
        instanceButtonSizer.addStretch();
        leftSideSizer.add( instanceButtonSizer );

        this.leftPanel = new Control( this );
        this.leftPanel.sizer = leftSideSizer;
        this.leftPanel.setFixedWidth( 300 );

        let rightPanelSizer = new VerticalSizer;
        rightPanelSizer.margin  = 6;
        rightPanelSizer.spacing = 4;
        rightPanelSizer.add( this.zoomButtonsSizer );
        rightPanelSizer.add( this.previewControl, 1 );

        let mainSizer = new HorizontalSizer;
        mainSizer.margin  = 6;
        mainSizer.spacing = 4;
        mainSizer.add( this.leftPanel );
        mainSizer.add( rightPanelSizer, 1 );

        this.sizer = mainSizer;
        this.adjustToContents();

        this.initializePreview();
    }

    // ---- Methods (moved from prototype assignments) ----

    onShow()
    {
        let activeWindow = ImageWindow.activeWindow;
        if ( activeWindow && !activeWindow.isNull )
            this.applyPreview( activeWindow );
        else
            console.writeln( "No active image window found." );
        this.previewControl.setFocus();
        this.previewControl.viewport.update();
    }

    populateImageWindowDropdown()
    {
        this.imageWindowDropdown.clear();
        for ( let i = 0; i < ImageWindow.windows.length; i++ )
            this.imageWindowDropdown.addItem( ImageWindow.windows[i].mainView.id );

        let activeWindow = ImageWindow.activeWindow;
        if ( !activeWindow.isNull )
            for ( let i = 0; i < ImageWindow.windows.length; i++ )
                if ( ImageWindow.windows[i].mainView.id === activeWindow.mainView.id )
                { this.imageWindowDropdown.currentItem = i; break; }
    }

    setPreviewImage( window )
    {
        this.cleanupTemporaryImage();
        if ( !window || window.isNull )
        { console.criticalln( "No valid image window selected." ); return; }

        this.tempImageWindow = new ImageWindow(
            window.mainView.image.width, window.mainView.image.height,
            window.mainView.image.numberOfChannels, window.mainView.image.bitsPerSample,
            window.mainView.image.isReal, window.mainView.image.isColor );
        this.tempImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
        this.tempImageWindow.mainView.image.assign( window.mainView.image );
        this.tempImageWindow.mainView.endProcess();
        this.previewControl.updateImage( this.tempImageWindow.mainView.image );
    }

    initializePreview()
    {
        let activeWindow = ImageWindow.activeWindow;
        if ( !activeWindow || activeWindow.isNull )
        { console.criticalln( "No active image window found for preview." ); return; }

        this.tempImageWindow = new ImageWindow(
            activeWindow.mainView.image.width, activeWindow.mainView.image.height,
            activeWindow.mainView.image.numberOfChannels, activeWindow.mainView.image.bitsPerSample,
            activeWindow.mainView.image.isReal, activeWindow.mainView.image.isColor );
        this.tempImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
        this.tempImageWindow.mainView.image.assign( activeWindow.mainView.image );
        this.tempImageWindow.mainView.endProcess();
        this.previewControl.updateImage( this.tempImageWindow.mainView.image );
    }

    applyPreview( selectedWindow )
    {
        if ( !selectedWindow || selectedWindow.isNull )
        { console.criticalln( "No valid image window selected for preview." ); return; }

        if ( this.blendCheckbox.checked )
        {
            if ( !this.baseImageWindow || this.baseImageWindow.isNull )
            {
                this.baseImageWindow = new ImageWindow(
                    selectedWindow.mainView.image.width, selectedWindow.mainView.image.height,
                    selectedWindow.mainView.image.numberOfChannels, selectedWindow.mainView.image.bitsPerSample,
                    selectedWindow.mainView.image.isReal, selectedWindow.mainView.image.isColor );
                this.baseImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
                this.baseImageWindow.mainView.image.assign( selectedWindow.mainView.image );
                this.baseImageWindow.mainView.endProcess();
            }
        }
        else
        {
            if ( this.baseImageWindow && !this.baseImageWindow.isNull )
            { this.baseImageWindow.forceClose(); this.baseImageWindow = null; }
        }

        if ( this.applyTempImageWindow && !this.applyTempImageWindow.isNull )
        { this.applyTempImageWindow.forceClose(); this.applyTempImageWindow = null; }

        this.applyTempImageWindow = new ImageWindow(
            selectedWindow.mainView.image.width, selectedWindow.mainView.image.height,
            selectedWindow.mainView.image.numberOfChannels, selectedWindow.mainView.image.bitsPerSample,
            selectedWindow.mainView.image.isReal, selectedWindow.mainView.image.isColor );
        this.applyTempImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
        this.applyTempImageWindow.mainView.image.assign( selectedWindow.mainView.image );
        this.applyTempImageWindow.mainView.endProcess();

        applyDepthEffect( this.applyTempImageWindow, this.strengthSlider.value );

        if ( this.blendCheckbox.checked )
        {
            let baseImageId = this.baseImageWindow.mainView.id;
            let blendValue  = this.blendSlider.value;
            let pixelMath   = new PixelMath;
            pixelMath.expression = "~(~(min(1,2*(1 - " + blendValue + ")) *0.8* " + baseImageId + ") * ~(min(1,2*" + blendValue + " )*0.8* " + this.applyTempImageWindow.mainView.id + "))";
            pixelMath.useSingleExpression = true;
            pixelMath.createNewImage      = false;
            pixelMath.executeOn( this.applyTempImageWindow.mainView );
        }

        this.previewControl.updateImage( this.applyTempImageWindow.mainView.image );
    }

    applyBlendOperation( baseImageId, finalImageId )
    {
        let blendValue = this.blendSlider.value;
        let pixelMath  = new PixelMath;
        pixelMath.expression = "~(~(min(1,2*(1 - " + blendValue + ")) *0.8* " + baseImageId + ") * ~(min(1,2*" + blendValue + " )*0.8* " + finalImageId + "))";
        pixelMath.useSingleExpression = true;
        pixelMath.createNewImage      = false;
        pixelMath.rescale             = false;
        let finalImageWindow = ImageWindow.windowById( finalImageId );
        if ( finalImageWindow && !finalImageWindow.isNull )
            pixelMath.executeOn( finalImageWindow.mainView );
        else
            console.criticalln( "Error: finalImageWindow is null or undefined." );
    }

    cleanupTemporaryImage()
    {
        if ( this.tempImageWindow && !this.tempImageWindow.isNull )
        { this.previewControl.invalidateCache(); this.tempImageWindow.forceClose(); this.tempImageWindow = null; }

        if ( this.applyTempImageWindow && !this.applyTempImageWindow.isNull )
        { this.applyTempImageWindow.forceClose(); this.applyTempImageWindow = null; }

        if ( this.baseImageWindow && !this.baseImageWindow.isNull )
        { this.baseImageWindow.forceClose(); this.baseImageWindow = null; }

        for ( let i = 0; i < this.tempImageWindows.length; i++ )
        {
            let w = this.tempImageWindows[i];
            if ( w && !w.isNull ) w.forceClose();
        }
        this.tempImageWindows = [];
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    let window = ImageWindow.activeWindow;
    if ( !window || window.isNull )
    { console.criticalln( "No active image window found." ); return; }

    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );
    console.writeln( "AstroDepth Loaded..." );

    let dialog = new DepthEffectDialog();
    if ( dialog.execute() )
    {
        if ( !dialog.okPressed )
            console.writeln( "Operation canceled." );
    }
}

main();
