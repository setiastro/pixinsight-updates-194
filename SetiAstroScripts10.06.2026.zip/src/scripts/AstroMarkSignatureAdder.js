#engine v8

#feature-id AstroMark : SetiAstro > AstroMark Signature and Insert Adder
#feature-icon  astromark.svg
#feature-info This script allows users to overlay their signature image on top of another image.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * AstroMark
 * Version: V1.4.7
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 *
 * V1.4.7 changes:
 *  - Removed the Image.blend fast path entirely. It had two independent V8
 *    issues that kept producing the transparency-checkerboard-in-sig-region
 *    symptom: Image.render() defaults to withTransparency=false and
 *    flattens the sig's alpha channel before the bitmap even reaches blend,
 *    AND Image.blend writes the bitmap's alpha into the target's alpha
 *    where one exists. The per-pixel path, which was already handling all
 *    non-Normal blend modes and all RGBA targets, now handles Normal mode
 *    too. One code path for everything, correct in every target/sig
 *    channel-count combination, and still fast enough that you'd need a
 *    stopwatch to notice on a signature-sized overlay. The checkbox,
 *    skip-reason counters and signature probe all still work.
 *
 * V1.4.6 changes:
 *  - Fast-path (Image.blend) is now gated on the TARGET having no alpha
 *    channel of its own. Image.blend copies the signature bitmap's alpha
 *    channel into the target's alpha channel, which on an RGBA target
 *    punches holes wherever the signature background was transparent (PI
 *    renders those as the transparency checkerboard — the color data is
 *    still there underneath, just masked out by alpha=0). The per-pixel
 *    path, which was already used for non-Normal blend modes, is now also
 *    the path for any RGBA/mono+alpha target in Normal mode. It writes
 *    only to the color channels (R,G,B or mono) and leaves target alpha
 *    byte-for-byte intact.
 *  - Added a target-channel-layout line to the diagnostic log, so the
 *    chosen path is self-explanatory in the console.
 *
 * V1.4.5 changes:
 *  - New option: "Treat black pixels as transparent" checkbox (default off).
 *    When enabled, any signature pixel with RGB=(0,0,0) is treated as fully
 *    transparent regardless of what its alpha channel says. Useful for:
 *    (a) legacy signatures that encode transparency as pure black while
 *    technically carrying an alpha channel, and (b) signatures with no
 *    alpha channel at all. Modern RGBA sigs with real black content inside
 *    the artwork should leave it unchecked. The option is persisted via
 *    PI's Parameters so it survives New Instance / drag-to-workspace.
 *  - The option is honored by BOTH composite paths: the Normal fast path
 *    mutates its bitmap in place before tgt.blend(), and the per-pixel path
 *    extends its isBlack guard condition. The preview mirrors the setting
 *    (the preview's sig bitmap cache is invalidated on toggle and the
 *    rebuild applies the same black->transparent transform), so WYSIWYG
 *    holds across the toggle.
 *
 * V1.4.4 changes:
 *  - Normal blend mode now goes through the SAME path as the preview:
 *    render the finished signature Image to a Bitmap and call
 *    targetImage.blend(bitmap). This is PI's native alpha composite — no
 *    per-pixel JS loop, no interpretation of the alpha channel by us. If
 *    the preview is right, Execute now matches it. Opacity < 1 is applied
 *    by first drawing the raw signature bitmap onto a transparent scratch
 *    bitmap through a Graphics with g.opacity set, so the composite bitmap
 *    carries the scaled alpha when it reaches tgt.blend().
 *  - Fixed a logic bug in the per-pixel path (used by all non-Normal modes):
 *    the "skip pure-black pixel" guard was being applied even when the
 *    signature had a real alpha channel, which rejected every pixel of
 *    signatures encoded as pure-black-with-coverage-in-alpha. isBlack now
 *    only runs when hasAlpha is false, matching the only case it was ever
 *    meant for (legacy sigs with no alpha channel at all).
 *  - Per-pixel path now reports per-reason skip counts (zero-alpha,
 *    isBlack, out-of-bounds) so a silent 0-writes outcome is self-diagnosing.
 *
 * V1.4.3 changes:
 *  - V8 Image-lifetime fix. V1.4.2 lifted the finished signature out of its
 *    source window via `new Image(sigWindow.mainView.image)` and then called
 *    `sigWindow.forceClose()` before compositing. In V8, Image is a thin
 *    envelope over the view's native C++ pixel storage; the forceClose freed
 *    that storage, and every subsequent sample() returned 0 — so every pixel
 *    was classed as "black with zero alpha" and nothing was written. We now
 *    keep sigWindow alive through the compositing loop and only forceClose
 *    once we're done reading from it. (See Juan's porting article: "The
 *    associated JavaScript objects are lightweight envelopes requiring
 *    minimal memory allocation.")
 *  - Fixed a long-standing latent bug: picking a signature from the dropdown
 *    was NOT calling updateSignaturePosition(), so if the user Executed
 *    without also touching the Position dropdown or Offset field, the
 *    signature position stayed at (0,0) regardless of the "Position" setting.
 *    Hidden before V1.4.3 by other bugs that also produced blank/transparent
 *    output. Target-change handler got the same fix for completeness.
 *  - Added a signature-probe console line that samples the center pixel of
 *    the prepared signature image. If the probe is all zeros but the preview
 *    was visibly non-black, you'll know the backing store is detached before
 *    we even enter the composite loop.
 *
 * V1.4.2 changes:
 *  - applySignatureOverlay rewritten to composite DIRECTLY onto the target
 *    view inside a single beginProcess/endProcess pair, no temp window.
 *  - Fixed alpha-channel index: previously used numberOfChannels-1 which
 *    aliased the blue channel on RGB signatures. Now uses a real alpha
 *    channel when present, else derives alpha from max(R,G,B) luminance.
 *  - Added composited-pixel-count console note.
 ******************************************************************************/

#define TITLE   "AstroMark - Signature and Insert Adder"
#define VERSION "V1.4.7"

let parameters = {
    targetWindow:         null,
    signatureWindow:      null,
    signaturePosition:    new Point(0, 0),
    signatureScale:       1.0,
    signatureRotation:    0.0,
    signatureOpacity:     1.0,
    signaturePositioning: "Lower Right",
    signatureOffset:      10,
    previewZoomFactor:    1.0,
    blendMode:            "Normal",
    borderEnabled:        false,
    borderWidth:          3,
    borderColor:          0x00000000,
    treatBlackAsTransparent: false,

    save: function()
    {
        Parameters.set( "signatureScale",           this.signatureScale );
        Parameters.set( "signatureRotation",        this.signatureRotation );
        Parameters.set( "signatureOpacity",         this.signatureOpacity );
        Parameters.set( "signaturePositioning",     this.signaturePositioning );
        Parameters.set( "signatureOffset",          this.signatureOffset );
        Parameters.set( "blendMode",                this.blendMode );
        Parameters.set( "borderEnabled",            this.borderEnabled );
        Parameters.set( "borderWidth",              this.borderWidth );
        Parameters.set( "borderColor",              this.borderColor );
        Parameters.set( "treatBlackAsTransparent",  this.treatBlackAsTransparent );
    },

    load: function()
    {
        if ( Parameters.has( "signatureScale" ) )           this.signatureScale           = Parameters.getReal(    "signatureScale" );
        if ( Parameters.has( "signatureRotation" ) )        this.signatureRotation        = Parameters.getReal(    "signatureRotation" );
        if ( Parameters.has( "signatureOpacity" ) )         this.signatureOpacity         = Parameters.getReal(    "signatureOpacity" );
        if ( Parameters.has( "signaturePositioning" ) )     this.signaturePositioning     = Parameters.getString(  "signaturePositioning" );
        if ( Parameters.has( "signatureOffset" ) )          this.signatureOffset          = Parameters.getInteger( "signatureOffset" );
        if ( Parameters.has( "blendMode" ) )                this.blendMode                = Parameters.getString(  "blendMode" );
        if ( Parameters.has( "borderEnabled" ) )            this.borderEnabled            = Parameters.getBoolean( "borderEnabled" );
        if ( Parameters.has( "borderWidth" ) )              this.borderWidth              = Parameters.getInteger( "borderWidth" );
        if ( Parameters.has( "borderColor" ) )              this.borderColor              = Parameters.getInteger( "borderColor" );
        if ( Parameters.has( "treatBlackAsTransparent" ) )  this.treatBlackAsTransparent  = Parameters.getBoolean( "treatBlackAsTransparent" );
    }
};

// ============================================================================
// ScrollControl
// V8 notes:
//  - All viewport.onXxx handlers converted to arrow functions (no this.parent needed)
//  - _cachedMainBitmap / _cachedSigBitmap prevent render() being called every frame
//  - invalidateRenderCache() calls bitmap.clear() for explicit V8 deallocation
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.signaturePosition  = new Point(0, 0);
        this.signatureScale     = parameters.signatureScale;
        this.signatureRotation  = parameters.signatureRotation;
        this.signatureOpacity   = parameters.signatureOpacity;
        this.blendMode          = parameters.blendMode;

        this.autoScroll = true;
        this.tracking   = true;

        this.mainImage          = null;
        this.signatureImage     = null;
        this.dragging           = false;
        this.dragOrigin         = new Point(0, 0);
        this.isTransforming     = false;
        this.transformCenter    = null;
        this.initialDistance    = null;

        this.zoomFactor    = 1.0;
        this.minZoomFactor = 0.1;
        this.maxZoomFactor = 10.0;

        this.cachedSignatureImage = null;

        // V8 render caches
        this._cachedMainBitmap = null;
        this._cachedSigBitmap  = null;

        // ---- Viewport handlers (arrow functions — no this.parent needed) ----

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            let zf = this.zoomFactor;
            let ax = (x / zf) + this.scrollPosition.x;
            let ay = (y / zf) + this.scrollPosition.y;

            if ( modifiers === 1 ) // Shift — move signature
            {
                this.dragging = true;
                this.dragOrigin.x = ax;
                this.dragOrigin.y = ay;
            }
            else if ( modifiers === 2 ) // Ctrl — resize
            {
                this.isTransforming = true;
                this.transformCenter = new Point(
                    this.signaturePosition.x + (this.signatureImage.width  * this.signatureScale) / 2,
                    this.signaturePosition.y + (this.signatureImage.height * this.signatureScale) / 2 );
                this.initialDistance = this.calculateDistance( ax, ay, this.transformCenter.x, this.transformCenter.y );
            }
            else if ( modifiers === 4 ) // Alt — rotate
            {
                this.isTransforming = true;
                this.transformCenter = new Point(
                    this.signaturePosition.x + (this.signatureImage.width  * this.signatureScale) / 2,
                    this.signaturePosition.y + (this.signatureImage.height * this.signatureScale) / 2 );
                this.initialAngle    = this.calculateAngle( this.transformCenter.x, this.transformCenter.y, ax, ay );
                this.initialDistance = this.calculateDistance( ax, ay, this.transformCenter.x, this.transformCenter.y );
            }
            else // Default — scroll
            {
                this.dragging = true;
                this.dragOrigin.x = x;
                this.dragOrigin.y = y;
            }
            this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            let zf = this.zoomFactor;
            let ax = (x / zf) + this.scrollPosition.x;
            let ay = (y / zf) + this.scrollPosition.y;

            if ( this.dragging )
            {
                if ( modifiers === 1 ) // Shift — move signature
                {
                    let dx = ax - this.dragOrigin.x;
                    let dy = ay - this.dragOrigin.y;
                    this.signaturePosition.x += dx;
                    this.signaturePosition.y += dy;
                    this.dragOrigin.x = ax;
                    this.dragOrigin.y = ay;
                }
                else // Default — scroll
                {
                    let dx = (x - this.dragOrigin.x) / zf;
                    let dy = (y - this.dragOrigin.y) / zf;
                    this.scrollPosition = new Point(
                        this.scrollPosition.x - dx,
                        this.scrollPosition.y - dy );
                    this.dragOrigin.x = x;
                    this.dragOrigin.y = y;
                }
                if ( this.viewport ) this.viewport.update();
            }
            else if ( this.isTransforming ) // Ctrl — resize
            {
                let currentDistance = this.calculateDistance( ax, ay, this.transformCenter.x, this.transformCenter.y );
                this.signatureScale *= currentDistance / this.initialDistance;
                this.initialDistance = currentDistance;
                this.invalidateSigCache();
                this.cacheResampledSignature( "NearestNeighbor" );
                if ( this.viewport ) this.viewport.update();
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.dragging = false;
            if ( this.isTransforming )
            {
                this.isTransforming = false;
                this.invalidateSigCache();
                this.cacheResampledSignature( "Bilinear" );
                if ( this.viewport ) this.viewport.update();
            }
            this.viewport.cursor = new Cursor( StdCursor.Arrow );
        };

        this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
        {
            if ( delta > 0 ) this.zoomFactor = Math.min( this.zoomFactor * 1.25, this.maxZoomFactor );
            else             this.zoomFactor = Math.max( this.zoomFactor * 0.8,  this.minZoomFactor );
            this.initScrollBars();
            if ( this.viewport ) this.viewport.update();
        };

        // onPaint: uses cached bitmaps — render() only called when cache is null
        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this.viewport );

            if ( !this.mainImage )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
                g.end();
                return;
            }

            // Rebuild main bitmap cache only when invalidated
            if ( !this._cachedMainBitmap )
                this._cachedMainBitmap = this.mainImage.render();

            g.scaleTransformation( this.zoomFactor );
            g.translateTransformation( -this.scrollPosition.x, -this.scrollPosition.y );
            g.drawBitmap( 0, 0, this._cachedMainBitmap );

            let sigImage = this.cachedSignatureImage;
            if ( sigImage )
            {
                // Rebuild sig bitmap cache only when invalidated
                if ( !this._cachedSigBitmap )
                {
                    this._cachedSigBitmap = sigImage.render();
                    if ( parameters.treatBlackAsTransparent )
                        this._applyBlackToTransparent( this._cachedSigBitmap );
                }

                let posX = this.signaturePosition.x;
                let posY = this.signaturePosition.y;
                let w = sigImage.width, h = sigImage.height;
                let centerX = posX + w / 2, centerY = posY + h / 2;

                g.translateTransformation( centerX, centerY );
                g.rotateTransformation( this.signatureRotation * Math.PI / 180 );
                g.translateTransformation( -centerX, -centerY );

                g.opacity = this.signatureOpacity;
                g.drawBitmap( posX, posY, this._cachedSigBitmap );

                if ( parameters.borderEnabled )
                {
                    let borderColor = parameters.borderColor | 0xFF000000;
                    let borderWidth = parameters.borderWidth;
                    g.pen   = new Pen( borderColor, borderWidth );
                    g.brush = new Brush( 0x00000000 );
                    g.drawRect( posX - borderWidth/2, posY - borderWidth/2,
                                posX + w + borderWidth/2, posY + h + borderWidth/2 );
                }
                g.opacity = 1.0;
            }
            g.end();
        };

        this.initScrollBars();
    }

    // ---- Helpers ----

    // Mutate a rendered Bitmap in place: wherever RGB == (0,0,0), set the pixel
    // to fully transparent (ARGB = 0x00000000). Used by both the preview sig
    // cache and the Execute path so the preview and the output agree.
    _applyBlackToTransparent( bmp )
    {
        if ( !bmp ) return;
        let w = bmp.width, h = bmp.height;
        for ( let y = 0; y < h; ++y )
            for ( let x = 0; x < w; ++x )
            {
                let p = bmp.pixel( x, y );
                if ( (p & 0x00FFFFFF) === 0 )
                    bmp.setPixel( x, y, 0 );
            }
    }

    // ---- Cache management ----

    invalidateMainCache()
    {
        if ( this._cachedMainBitmap )
        { this._cachedMainBitmap.clear(); this._cachedMainBitmap = null; }
    }

    invalidateSigCache()
    {
        if ( this._cachedSigBitmap )
        { this._cachedSigBitmap.clear(); this._cachedSigBitmap = null; }
    }

    invalidateAllCaches()
    {
        this.invalidateMainCache();
        this.invalidateSigCache();
    }

    // ---- Core methods ----

    getImage() { return this.mainImage; }

    doUpdateImage( mainImage, signatureImage )
    {
        this.invalidateAllCaches();
        this.mainImage      = mainImage;
        this.signatureImage = signatureImage;
        this.cacheResampledSignature();
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    initScrollBars( scrollPoint )
    {
        let image = this.getImage();
        if ( !image || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange(   0, 0 );
            this.scrollPosition = new Point( 0, 0 );
        }
        else
        {
            let zf = this.zoomFactor;
            this.setHorizontalScrollRange( 0, Math.max(0, 4*image.width *zf) );
            this.setVerticalScrollRange(   0, Math.max(0, 4*image.height*zf) );
            if ( scrollPoint )
                this.scrollPosition = scrollPoint;
            else
                this.scrollPosition = new Point(
                    Math.min(this.scrollPosition.x, 4*image.width *zf),
                    Math.min(this.scrollPosition.y, 4*image.height*zf) );
        }
        if ( this.viewport ) this.viewport.update();
    }

    cacheResampledSignature( interpolationMethod )
    {
        if ( !this.signatureImage ) return;

        let tempWindow = new ImageWindow(
            this.signatureImage.width, this.signatureImage.height,
            this.signatureImage.numberOfChannels, this.signatureImage.bitsPerSample,
            this.signatureImage.isReal, this.signatureImage.isColor );

        // V8-safe order: beginProcess BEFORE touching mainView.image
        tempWindow.mainView.beginProcess();
        tempWindow.mainView.image.assign( this.signatureImage );
        tempWindow.mainView.endProcess();

        let P = new Resample;
        P.xSize = this.signatureScale; P.ySize = this.signatureScale;
        P.mode            = Resample.RelativeDimensions;
        P.absoluteMode    = Resample.ForceWidthAndHeight;
        P.xResolution     = 72; P.yResolution = 72;
        P.metric          = false; P.forceResolution = false;
        P.interpolation   = Resample.Auto;
        P.clampingThreshold = 0.30; P.smoothness = 1.50;
        P.gammaCorrection = false; P.noGUIMessages = true;
        P.executeOn( tempWindow.mainView );

        // V8 fix: copy then close immediately
        this.invalidateSigCache();
        this.cachedSignatureImage = new Image( tempWindow.mainView.image );
        tempWindow.forceClose();
    }

    calculateDistance( x1, y1, x2, y2 )
    { return Math.sqrt( Math.pow(x2-x1,2) + Math.pow(y2-y1,2) ); }

    calculateAngle( cx, cy, px, py )
    { return Math.atan2( py-cy, px-cx ); }

    zoomIn()
    {
        this.zoomFactor = Math.min( this.zoomFactor*1.25, this.maxZoomFactor );
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    zoomOut()
    {
        this.zoomFactor = Math.max( this.zoomFactor*0.8, this.minZoomFactor );
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }
};

// ============================================================================
// SignatureAdderDialog
// ============================================================================

var SignatureAdderDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.signaturePosition = new Point(0, 0);
        this.signatureScale    = parameters.signatureScale;
        this.signatureRotation = parameters.signatureRotation;
        this.signatureOpacity  = parameters.signatureOpacity;
        this.blendMode         = parameters.blendMode || "Normal";
        this.cachedSignatureImage = null;

        // ---- Title ----
        this.title_Lbl = new Label( this );
        this.title_Lbl.frameStyle    = FrameStyle.Box;
        this.title_Lbl.margin        = 6;
        this.title_Lbl.useRichText   = true;
        this.title_Lbl.text          = "<b>AstroMark - Signature and Insert Adder " + VERSION + "</b>";
        this.title_Lbl.textAlignment = TextAlignment.Center;

        // ---- Instructions ----
        this.instructions_Lbl = new TextBox( this );
        this.instructions_Lbl.readOnly   = true;
        this.instructions_Lbl.frameStyle = FrameStyle.Box;
        this.instructions_Lbl.text =
            "Instructions:\n\n" +
            "1. Select the target image.\n" +
            "2. Select the signature image.\n" +
            "3. Select a blend mode (Preview does not support blend modes but your executed image will)\n" +
            "4. Adjust the position (shift+click and drag) of the signature using mouse controls.\n" +
            "5. Click 'Execute' to overlay the signature onto the target image.";
        this.instructions_Lbl.setScaledMinWidth( 450 );

        // ---- Image selectors ----
        this.targetWindow_Label = new Label( this );
        this.targetWindow_Label.text = "Select Image:";
        this.targetWindow_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.signatureWindow_Label = new Label( this );
        this.signatureWindow_Label.text = "Select Signature:";
        this.signatureWindow_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.targetWindowSelector_Cb    = new ComboBox( this );
        this.signatureWindowSelector_Cb = new ComboBox( this );

        for ( let i = 0; i < ImageWindow.windows.length; i++ )
        {
            let windowId = ImageWindow.windows[i].mainView.id;
            this.targetWindowSelector_Cb.addItem( windowId );
            this.signatureWindowSelector_Cb.addItem( windowId );
        }
        this.signatureWindowSelector_Cb.insertItem( 0, "Select Image" );
        this.signatureWindowSelector_Cb.currentItem = 0;

        this.targetWindowSelector_Cb.onItemSelected = index =>
        {
            if ( index >= 0 )
            {
                let windowId = this.targetWindowSelector_Cb.itemText( index );
                parameters.targetWindow = ImageWindow.windowById( windowId );
                this.updatePreview();
                // New target → recompute position in case dimensions changed.
                this.updateSignaturePosition();
            }
        };

        this.signatureWindowSelector_Cb.onItemSelected = index =>
        {
            if ( index >= 1 )
            {
                let windowId = this.signatureWindowSelector_Cb.itemText( index );
                parameters.signatureWindow = ImageWindow.windowById( windowId );
                this.cacheResampledSignature();
                this.updatePreview();
                // Position wasn't computable until BOTH main and signature images
                // existed; now that the signature is in place, pin it to the
                // configured Position/Offset so Execute reads a real coordinate.
                this.updateSignaturePosition();
            }
            else
            {
                parameters.signatureWindow = null;
                this.cachedSignatureImage = null;
            }
        };

        let activeWindow = ImageWindow.activeWindow;
        if ( !activeWindow.isNull )
            this.targetWindowSelector_Cb.currentItem =
                this.targetWindowSelector_Cb.findItem( activeWindow.mainView.id );
        else
            this.targetWindowSelector_Cb.currentItem = 0;

        // ---- Blend mode ----
        this.blendMode_Label = new Label( this );
        this.blendMode_Label.text = "Blend Mode:";
        this.blendMode_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.blendMode_Cb = new ComboBox( this );
        ["Normal","Replacement","Lighten","Multiply","Screen","Overlay","Difference","Darken"]
            .forEach( m => this.blendMode_Cb.addItem(m) );
        this.blendMode_Cb.currentItem = this.blendMode_Cb.findItem( this.blendMode );
        this.blendMode_Cb.onItemSelected = index =>
        {
            this.blendMode = this.blendMode_Cb.itemText( index );
            parameters.blendMode = this.blendMode;
            this.previewControl.viewport.update();
        };

        this.blendModeHelp_Lbl = new Label( this );
        this.blendModeHelp_Lbl.useRichText = true;
        this.blendModeHelp_Lbl.text = "<a href=\"https://www.setiastro.com/blendmodes\">Help With Different Blend Modes</a>";
        this.blendModeHelp_Lbl.toolTip = "Click for help with different blend modes.";
        this.blendModeHelp_Lbl.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.blendModeHelp_Lbl.onMousePress = () =>
        { Dialog.openBrowser( "https://www.setiastro.com/blendmodes" ); };

        this.blendModeSizer = new HorizontalSizer;
        this.blendModeSizer.spacing = 4;
        this.blendModeSizer.add( this.blendMode_Label );
        this.blendModeSizer.add( this.blendMode_Cb );
        this.blendModeSizer.addSpacing( 20 );
        this.blendModeSizer.add( this.blendModeHelp_Lbl );
        this.blendModeSizer.addStretch();

        // ---- Sliders ----
        this.signatureSize_Slider = new NumericControl( this );
        this.signatureSize_Slider.label.text = "Signature Size:";
        this.signatureSize_Slider.setRange( 0.01, 5 );
        this.signatureSize_Slider.slider.setRange( 1, 500 );
        this.signatureSize_Slider.setPrecision( 2 );
        this.signatureSize_Slider.setValue( parameters.signatureScale );

        let signatureScaleUpdateTimer = new Timer;
        this.signatureSize_Slider.onValueUpdated = value =>
        {
            signatureScaleUpdateTimer.stop();
            signatureScaleUpdateTimer.interval   = 1.0;
            signatureScaleUpdateTimer.singleShot = true;
            signatureScaleUpdateTimer.onTimeout  = () =>
            {
                this.previewControl.signatureScale = value;
                this.previewControl.invalidateSigCache();
                this.previewControl.cacheResampledSignature( "Bilinear" );
                this.previewControl.viewport.update();
            };
            signatureScaleUpdateTimer.start();
            parameters.signatureScale = value;
        };

        this.signatureRotation_Slider = new NumericControl( this );
        this.signatureRotation_Slider.label.text = "Signature Rotation:";
        this.signatureRotation_Slider.setRange( 0.0, 360.0 );
        this.signatureRotation_Slider.slider.setRange( 0, 3600 );
        this.signatureRotation_Slider.setPrecision( 1 );
        this.signatureRotation_Slider.setValue( parameters.signatureRotation );
        this.signatureRotation_Slider.onValueUpdated = value =>
        {
            this.previewControl.signatureRotation = value;
            this.previewControl.viewport.update();
            parameters.signatureRotation = value;
        };

        this.signatureOpacity_Slider = new NumericControl( this );
        this.signatureOpacity_Slider.label.text = "Signature Opacity:";
        this.signatureOpacity_Slider.setRange( 0.01, 1.00 );
        this.signatureOpacity_Slider.slider.setRange( 1, 1000 );
        this.signatureOpacity_Slider.setPrecision( 2 );
        this.signatureOpacity_Slider.setValue( parameters.signatureOpacity );
        this.signatureOpacity_Slider.onValueUpdated = value =>
        {
            this.previewControl.signatureOpacity = value;
            this.previewControl.viewport.update();
            parameters.signatureOpacity = value;
        };

        // ---- Positioning ----
        this.positioningLabel = new Label( this );
        this.positioningLabel.text = "Position:";
        this.positioningLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.positioningComboBox = new ComboBox( this );
        ["Upper Left","Upper Center","Upper Right","Left","Center","Right","Lower Left","Lower Center","Lower Right"]
            .forEach( p => this.positioningComboBox.addItem(p) );
        this.positioningComboBox.currentItem =
            this.positioningComboBox.findItem( parameters.signaturePositioning );
        this.positioningComboBox.onItemSelected = index =>
        {
            parameters.signaturePositioning = this.positioningComboBox.itemText( index );
            this.updateSignaturePosition();
        };

        this.offsetLabel = new Label( this );
        this.offsetLabel.text = "Offset (px):";
        this.offsetLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.offsetInput = new Edit( this );
        this.offsetInput.text = parameters.signatureOffset.toString();
        this.offsetInput.onEditCompleted = () =>
        {
            let offsetValue = parseInt( this.offsetInput.text.trim() );
            if ( !isNaN(offsetValue) )
            {
                parameters.signatureOffset = offsetValue;
                this.updateSignaturePosition();
            }
        };

        this.positioningSizer = new HorizontalSizer;
        this.positioningSizer.spacing = 6;
        this.positioningSizer.add( this.positioningLabel );
        this.positioningSizer.add( this.positioningComboBox );
        this.positioningSizer.add( this.offsetLabel );
        this.positioningSizer.add( this.offsetInput );
        this.positioningSizer.addStretch();

        // ---- Transparency option ----
        this.treatBlack_Checkbox = new CheckBox( this );
        this.treatBlack_Checkbox.text    = "Treat black pixels as transparent";
        this.treatBlack_Checkbox.checked = parameters.treatBlackAsTransparent;
        this.treatBlack_Checkbox.toolTip =
            "<p>When checked, any pixel in the signature whose RGB is pure black " +
            "(0, 0, 0) will be treated as fully transparent, regardless of what " +
            "the alpha channel says there.</p>" +
            "<p>Leave unchecked for modern RGBA signatures where black is a real " +
            "color inside the signature artwork — the alpha channel alone decides " +
            "transparency.</p>" +
            "<p>Enable for legacy signatures that encode transparency as pure " +
            "black against black-free content, or for signatures without an alpha " +
            "channel at all (where it's the only transparency signal available).</p>";
        this.treatBlack_Checkbox.onCheck = checked =>
        {
            parameters.treatBlackAsTransparent = checked;
            // Invalidate the preview's sig bitmap cache so it rebuilds with the
            // new transparency rule next paint. Then force a repaint.
            this.previewControl.invalidateSigCache();
            if ( this.previewControl.viewport )
                this.previewControl.viewport.update();
        };

        // ---- Border controls ----
        this.borderCheckbox = new CheckBox( this );
        this.borderCheckbox.text    = "Add Border";
        this.borderCheckbox.checked = parameters.borderEnabled;
        this.borderCheckbox.toolTip = "Enable or disable border around the signature/image.";

        this.borderWidthSlider = new NumericControl( this );
        this.borderWidthSlider.label.text = "Border Width:";
        this.borderWidthSlider.setRange( 1, 20 );
        this.borderWidthSlider.slider.setRange( 1, 200 );
        this.borderWidthSlider.setPrecision( 0 );
        this.borderWidthSlider.setValue( parameters.borderWidth );
        this.borderWidthSlider.enabled = parameters.borderEnabled;

        const presetColors = {
            "Black":   0x000000, "White":   0xFFFFFF,
            "Red":     0xFF0000, "Orange":  0xFFA500,
            "Yellow":  0xFFFF00, "Green":   0x00FF00,
            "Blue":    0x0000FF, "Cyan":    0x00FFFF,
            "Magenta": 0xFF00FF
        };

        this.borderColor_Label = new Label( this );
        this.borderColor_Label.text = "Border Color:";
        this.borderColor_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.borderColorDropdown = new ComboBox( this );
        for ( let colorName in presetColors )
            this.borderColorDropdown.addItem( colorName );

        let currentColor = parameters.borderColor;
        let defaultColorIndex = 0, ci = 0;
        for ( let colorName in presetColors )
        {
            if ( presetColors[colorName] === currentColor ) { defaultColorIndex = ci; break; }
            ci++;
        }
        this.borderColorDropdown.currentItem = defaultColorIndex;
        this.borderColorDropdown.enabled     = parameters.borderEnabled;

        this.borderCheckbox.onCheck = checked =>
        {
            parameters.borderEnabled             = checked;
            this.borderWidthSlider.enabled       = checked;
            this.borderColorDropdown.enabled     = checked;
            this.previewControl.viewport.update();
        };

        this.borderWidthSlider.onValueUpdated = value =>
        {
            parameters.borderWidth = value;
            this.previewControl.viewport.update();
        };

        this.borderColorDropdown.onItemSelected = index =>
        {
            let colorName = this.borderColorDropdown.itemText( index );
            parameters.borderColor = presetColors[colorName] | 0xFF000000;
            this.previewControl.viewport.update();
        };

        this.borderSizer = new VerticalSizer;
        this.borderSizer.spacing = 4;
        this.borderSizer.add( this.borderCheckbox );
        this.borderSizer.add( this.borderWidthSlider );
        this.borderSizer.add( this.borderColor_Label );
        this.borderSizer.add( this.borderColorDropdown );

        // ---- Zoom buttons ----
        this.zoomInButton = new PushButton( this );
        this.zoomInButton.text    = "";
        this.zoomInButton.icon    = this.scaledResource( ":/icons/zoom-in.png" );
        this.zoomInButton.toolTip = "Zoom In";
        this.zoomInButton.onClick = () => { this.previewControl.zoomIn(); };

        this.zoomOutButton = new PushButton( this );
        this.zoomOutButton.text    = "";
        this.zoomOutButton.icon    = this.scaledResource( ":/icons/zoom-out.png" );
        this.zoomOutButton.toolTip = "Zoom Out";
        this.zoomOutButton.onClick = () => { this.previewControl.zoomOut(); };

        this.zoomLabel = new Label( this );
        this.zoomLabel.text = "Zoom In/Out (Mouse Wheel Supported)";

        this.zoomSizer = new HorizontalSizer;
        this.zoomSizer.spacing = 6;
        this.zoomSizer.add( this.zoomInButton );
        this.zoomSizer.add( this.zoomOutButton );
        this.zoomSizer.add( this.zoomLabel );
        this.zoomSizer.addStretch();

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth( 640 );
        this.previewControl.setMinHeight( 450 );

        // ---- Buttons ----
        this.execute_Btn = new PushButton( this );
        this.execute_Btn.text    = "Execute";
        this.execute_Btn.toolTip = "Apply the signature overlay to the target image.";
        this.execute_Btn.onClick = () =>
        {
            this.applySignatureOverlay();
            this.ok();
        };

        this.newInstance_Btn = new ToolButton( this );
        this.newInstance_Btn.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstance_Btn.setScaledFixedSize( 24, 24 );
        this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
        this.newInstance_Btn.onMousePress = () =>
        { parameters.save(); this.newInstance(); };

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.spacing = 6;
        this.buttonSizer.add( this.newInstance_Btn );
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.execute_Btn );

        // ---- Authorship ----
        this.authorship_Lbl = new Label( this );
        this.authorship_Lbl.frameStyle    = FrameStyle.Box;
        this.authorship_Lbl.margin        = 6;
        this.authorship_Lbl.useRichText   = true;
        this.authorship_Lbl.text          = "Written by Franklin Marek 2026<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
        this.authorship_Lbl.textAlignment = TextAlignment.Center;
        this.authorship_Lbl.onMousePress  = () => { Dialog.openBrowser( "http://www.setiastro.com" ); };

        // ---- Layout ----
        this.leftSizer = new VerticalSizer;
        this.leftSizer.spacing = 6;
        this.leftSizer.add( this.title_Lbl );
        this.leftSizer.addSpacing( 10 );
        this.leftSizer.add( this.instructions_Lbl );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.targetWindow_Label );
        this.leftSizer.add( this.targetWindowSelector_Cb );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.signatureWindow_Label );
        this.leftSizer.add( this.signatureWindowSelector_Cb );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.blendModeSizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.signatureSize_Slider );
        this.leftSizer.add( this.signatureRotation_Slider );
        this.leftSizer.add( this.signatureOpacity_Slider );
        this.leftSizer.add( this.positioningSizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.treatBlack_Checkbox );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.borderSizer );
        this.leftSizer.addStretch();
        this.leftSizer.add( this.authorship_Lbl );
        this.leftSizer.add( this.buttonSizer );

        this.leftPanel = new Control( this );
        this.leftPanel.sizer = this.leftSizer;
        this.leftPanel.setFixedWidth( 450 );

        this.rightSizer = new VerticalSizer;
        this.rightSizer.spacing = 6;
        this.rightSizer.add( this.zoomSizer );
        this.rightSizer.add( this.previewControl, 1 );

        this.mainSizer = new HorizontalSizer;
        this.mainSizer.spacing = 4;
        this.mainSizer.add( this.leftPanel );
        this.mainSizer.add( this.rightSizer, 1 );

        this.sizer = this.mainSizer;

        // Init
        parameters.targetWindow   = ImageWindow.windowById(
            this.targetWindowSelector_Cb.itemText( this.targetWindowSelector_Cb.currentItem ) );
        parameters.signatureWindow = null;
        this.updatePreview();
        this.updateSignaturePosition();

        this.windowTitle = TITLE;
        this.adjustToContents();
    }

    // ---- Preview helpers ----

    updatePreview()
    {
        if ( parameters.targetWindow && this.cachedSignatureImage )
        {
            this.previewControl.doUpdateImage(
                parameters.targetWindow.mainView.image,
                this.cachedSignatureImage );
        }
    }

    cacheResampledSignature()
    {
        if ( parameters.signatureWindow )
        {
            let signatureImage = new Image( parameters.signatureWindow.mainView.image );
            signatureImage.resample( this.signatureScale );
            this.cachedSignatureImage = signatureImage;
        }
    }

    updateSignaturePosition()
    {
        let offset        = parameters.signatureOffset;
        let mainImage     = this.previewControl.mainImage;
        let signatureImage = this.previewControl.cachedSignatureImage;
        if ( !mainImage || !signatureImage ) return;

        let x, y;
        switch ( parameters.signaturePositioning )
        {
        case "Upper Left":   x = offset; y = offset; break;
        case "Upper Center": x = (mainImage.width - signatureImage.width) / 2; y = offset; break;
        case "Upper Right":  x = mainImage.width - signatureImage.width - offset; y = offset; break;
        case "Left":         x = offset; y = (mainImage.height - signatureImage.height) / 2; break;
        case "Center":       x = (mainImage.width - signatureImage.width) / 2; y = (mainImage.height - signatureImage.height) / 2; break;
        case "Right":        x = mainImage.width - signatureImage.width - offset; y = (mainImage.height - signatureImage.height) / 2; break;
        case "Lower Left":   x = offset; y = mainImage.height - signatureImage.height - offset; break;
        case "Lower Center": x = (mainImage.width - signatureImage.width) / 2; y = mainImage.height - signatureImage.height - offset; break;
        case "Lower Right":  x = mainImage.width - signatureImage.width - offset; y = mainImage.height - signatureImage.height - offset; break;
        default:             x = 0; y = 0;
        }
        this.previewControl.signaturePosition = new Point( x, y );
        this.previewControl.viewport.update();
    }

    // ---- Apply overlay ----
    //
    // Design: build the final signature (resample + border + rotation) in a
    // throwaway ImageWindow, then composite it DIRECTLY onto the target view
    // inside a SINGLE beginProcess/endProcess pair. No temp result window, no
    // PixelMath copy-back, no cross-window image-reference handoffs — these
    // were the V8 failure sites.

    applySignatureOverlay()
    {
        if ( !parameters.targetWindow || !this.cachedSignatureImage )
        {
            new MessageBox( "Please select both main and signature images.", TITLE,
                StdIcon.Error, StdButton.Ok ).execute();
            return;
        }

        let targetView  = parameters.targetWindow.mainView;
        let targetImage = targetView.image;
        let cachedSignatureImage = this.cachedSignatureImage;

        // Convert main image to RGB if needed
        if ( !targetImage.isColor )
        {
            let conv = new ConvertToRGBColor;
            conv.executeOn( targetView );
            targetImage = targetView.image;
        }

        // Convert signature to RGB if needed
        if ( !cachedSignatureImage.isColor )
        {
            let tempWindow = new ImageWindow(
                cachedSignatureImage.width, cachedSignatureImage.height,
                cachedSignatureImage.numberOfChannels, cachedSignatureImage.bitsPerSample,
                cachedSignatureImage.isReal, cachedSignatureImage.isColor );
            tempWindow.mainView.beginProcess();
            tempWindow.mainView.image.assign( cachedSignatureImage );
            tempWindow.mainView.endProcess();
            let conv = new ConvertToRGBColor;
            conv.executeOn( tempWindow.mainView );
            cachedSignatureImage = new Image( tempWindow.mainView.image );
            tempWindow.forceClose();
        }

        function normalizeAngle( angle )
        {
            while ( angle >  Math.PI ) angle -= 2*Math.PI;
            while ( angle < -Math.PI ) angle += 2*Math.PI;
            return angle;
        }

        let signaturePosition = this.previewControl.signaturePosition;
        let signatureScale    = this.previewControl.signatureScale;
        let signatureRotation = normalizeAngle( this.previewControl.signatureRotation * Math.PI / 180 );
        let signatureOpacity  = this.previewControl.signatureOpacity;
        let blendMode         = parameters.blendMode || "Normal";

        // ========================================================================
        // STEP 1: Build the final signature (resample + border + rotation) in sigWindow
        // ========================================================================

        let sigWindow = new ImageWindow(
            cachedSignatureImage.width, cachedSignatureImage.height,
            cachedSignatureImage.numberOfChannels, cachedSignatureImage.bitsPerSample,
            cachedSignatureImage.isReal, cachedSignatureImage.isColor );
        sigWindow.mainView.beginProcess();
        sigWindow.mainView.image.assign( cachedSignatureImage );
        sigWindow.mainView.endProcess();

        // ---- Resample ----
        let R = new Resample;
        R.xSize = signatureScale; R.ySize = signatureScale;
        R.mode            = Resample.RelativeDimensions;
        R.absoluteMode    = Resample.ForceWidthAndHeight;
        R.xResolution = 72; R.yResolution = 72;
        R.metric = false; R.forceResolution = false;
        R.interpolation   = Resample.Auto;
        R.clampingThreshold = 0.30; R.smoothness = 2.00;
        R.gammaCorrection = true; R.noGUIMessages = true;
        R.executeOn( sigWindow.mainView );

        // ---- Border (optional) ----
        if ( parameters.borderEnabled )
        {
            let bw = parameters.borderWidth;
            let bc = parameters.borderColor;
            let rC = ((bc >> 16) & 0xFF) / 255.0;
            let gC = ((bc >>  8) & 0xFF) / 255.0;
            let bC = ( bc        & 0xFF) / 255.0;

            let sigImg = sigWindow.mainView.image;
            let newW   = sigImg.width  + 2*bw;
            let newH   = sigImg.height + 2*bw;

            let expWindow = new ImageWindow(
                newW, newH,
                sigImg.numberOfChannels, sigImg.bitsPerSample,
                sigImg.isReal, sigImg.isColor );

            expWindow.mainView.beginProcess();
            let expImg = expWindow.mainView.image;
            expImg.fill( 1 );

            let sigBitmap = sigImg.render();
            expImg.selectedPoint = new Point( bw, bw );
            expImg.blend( sigBitmap );
            sigBitmap.clear();

            for ( let bi = 0; bi < bw; bi++ )
            {
                for ( let x = bi; x < newW - bi; x++ )
                {
                    expImg.setSample(rC, x, bi, 0); expImg.setSample(gC, x, bi, 1); expImg.setSample(bC, x, bi, 2);
                    expImg.setSample(rC, x, newH-1-bi, 0); expImg.setSample(gC, x, newH-1-bi, 1); expImg.setSample(bC, x, newH-1-bi, 2);
                }
                for ( let y = bi; y < newH - bi; y++ )
                {
                    expImg.setSample(rC, bi, y, 0); expImg.setSample(gC, bi, y, 1); expImg.setSample(bC, bi, y, 2);
                    expImg.setSample(rC, newW-1-bi, y, 0); expImg.setSample(gC, newW-1-bi, y, 1); expImg.setSample(bC, newW-1-bi, y, 2);
                }
            }
            expWindow.mainView.endProcess();

            sigWindow.forceClose();
            sigWindow = expWindow;
        }

        // ---- Rotation ----
        let rot = new Rotation;
        rot.angle              = signatureRotation;
        rot.optimizeFast       = true;
        rot.interpolation      = Rotation.Auto;
        rot.clampingThreshold  = 0.30;
        rot.smoothness         = 1.50;
        rot.gammaCorrection    = false;
        rot.red = 0; rot.green = 0; rot.blue = 0; rot.alpha = 1;
        rot.noGUIMessages      = true;
        rot.executeOn( sigWindow.mainView );

        // ========================================================================
        // STEP 2: Composite directly onto target view
        //
        // V8 lifetime note: do NOT lift sigWindow.mainView.image into a local
        // Image via `new Image(...)` and then forceClose() the window — in V8,
        // Image is a thin envelope over the view's C++ pixel storage, and
        // forceClose() frees that storage out from under us (sample() then
        // returns 0 for every pixel). Instead: keep sigWindow alive, read
        // through sigWindow.mainView.image during the loop, and only
        // forceClose() AFTER the compositing is done.
        // ========================================================================

        let sigFinal = sigWindow.mainView.image;
        let sigW = sigFinal.width;
        let sigH = sigFinal.height;

        // Alpha channel detection: use real alpha if the signature has one
        // (RGBA = 4 chans on color, 2 chans on mono). Otherwise derive from
        // max(R,G,B) which treats pure black as transparent (same effective
        // behavior as the legacy script for black-bg signatures, but correct
        // for colored signatures too — the legacy code aliased the blue
        // channel as alpha, which silently broke yellow / red / green sigs).
        let sigChannels = sigFinal.numberOfChannels;
        let sigIsColor  = sigFinal.isColor;
        let hasAlpha    = (sigIsColor && sigChannels >= 4) || (!sigIsColor && sigChannels >= 2);
        let alphaIdx    = hasAlpha ? sigChannels - 1 : -1;
        let colorChans  = sigIsColor ? 3 : 1;

        // Sanity-check that the signature image is actually readable BEFORE
        // we touch the target view. If this reports all zeros but the preview
        // was non-black, the backing store has been detached.
        {
            let cx = Math.floor( sigW / 2 );
            let cy = Math.floor( sigH / 2 );
            let probe = [];
            for ( let c = 0; c < sigChannels; ++c )
                probe.push( sigFinal.sample( cx, cy, c ).toFixed(4) );
            console.writeln( format(
                "AstroMark: signature probe at (%d,%d) chans=%d isColor=%s hasAlpha=%s -> [%s]",
                cx, cy, sigChannels,
                String(sigIsColor), String(hasAlpha),
                probe.join(", ") ) );
            console.writeln( format(
                "AstroMark: target chans=%d isColor=%s",
                targetImage.numberOfChannels,
                String(targetImage.isColor) ) );
        }

        let centerX = signaturePosition.x + sigW / 2;
        let centerY = signaturePosition.y + sigH / 2;

        let posX = Math.round( signaturePosition.x );
        let posY = Math.round( signaturePosition.y );

        // ========================================================================
        // Per-pixel compositing path. Used for ALL blend modes.
        //
        // Earlier revisions had a Normal-mode fast path using Image.blend(),
        // on the theory that it would exactly match the preview's
        // Graphics.drawBitmap mechanism. That path had two independent V8
        // gotchas: (a) Image.render()'s default withTransparency=false
        // flattens the sig's alpha channel against an opaque background
        // before the bitmap even reaches blend(), and (b) Image.blend()
        // writes the bitmap's alpha channel into the target's alpha channel,
        // which punches holes in RGBA targets. Both are solvable in isolation
        // but combined they made the fast path less reliable than it was fast.
        // Dropped it; this per-pixel path handles everything correctly:
        //
        //   - Writes only to color channels (R,G,B for color targets, chan 0
        //     for mono), so any target alpha channel is preserved byte-for-byte.
        //   - Interprets the sig alpha channel ourselves, so what render()
        //     would have done to it is irrelevant.
        //   - All blend modes share one code path.
        //
        // The isBlack guard fires when either (a) the signature has no real
        // alpha channel at all, so RGB=0 is the only available transparency
        // signal, or (b) the user explicitly asked us to treat black as
        // transparent via the checkbox (legacy signatures).
        // ========================================================================

        let applyIsBlackGuard = !hasAlpha || parameters.treatBlackAsTransparent;

        targetView.beginProcess();
        let tgt = targetView.image;
        let tgtW = tgt.width;
        let tgtH = tgt.height;
        let tgtColorChans = tgt.isColor ? 3 : 1;

        let pixelsWritten    = 0;
        let skippedAlpha     = 0;
        let skippedIsBlack   = 0;
        let skippedBounds    = 0;

        for ( let y = 0; y < sigH; ++y )
        {
            for ( let x = 0; x < sigW; ++x )
            {
                // ---- Compute source alpha ----
                let srcAlpha;
                if ( hasAlpha )
                {
                    srcAlpha = sigFinal.sample( x, y, alphaIdx );
                }
                else
                {
                    let maxv = 0;
                    for ( let c = 0; c < colorChans; ++c )
                    {
                        let v = sigFinal.sample( x, y, c );
                        if ( v > maxv ) maxv = v;
                    }
                    srcAlpha = maxv;
                }
                let alpha = srcAlpha * signatureOpacity;
                if ( alpha <= 0 ) { ++skippedAlpha; continue; }

                // ---- Skip pure-black pixels when the guard is active ----
                if ( applyIsBlackGuard )
                {
                    let isBlack = true;
                    for ( let c = 0; c < colorChans; ++c )
                    {
                        if ( sigFinal.sample( x, y, c ) !== 0 ) { isBlack = false; break; }
                    }
                    if ( isBlack ) { ++skippedIsBlack; continue; }
                }

                // ---- Target coords ----
                let tx = Math.round( centerX + (x - sigW/2) );
                let ty = Math.round( centerY + (y - sigH/2) );
                if ( tx < 0 || tx >= tgtW || ty < 0 || ty >= tgtH ) { ++skippedBounds; continue; }

                // ---- Per-channel blend, write directly to target ----
                for ( let c = 0; c < tgtColorChans; ++c )
                {
                    let sp = sigIsColor ? sigFinal.sample(x, y, c) : sigFinal.sample(x, y, 0);
                    let cp = tgt.sample( tx, ty, c );
                    let bp;
                    switch ( blendMode )
                    {
                    case "Lighten":     bp = Math.max(sp*alpha, cp); break;
                    case "Multiply":    bp = sp*cp; break;
                    case "Screen":      bp = 1 - (1-sp*alpha)*(1-cp); break;
                    case "Overlay":     bp = cp < 0.5 ? 2*cp*sp*alpha : 1 - 2*(1-cp)*(1-sp*alpha); break;
                    case "Difference":  bp = Math.abs(cp - sp*alpha); break;
                    case "Darken":      bp = Math.min(sp*alpha, cp); break;
                    case "Replacement": bp = (sp*signatureOpacity) + (cp*(1 - signatureOpacity)); break;
                    default:            bp = (sp*alpha) + (cp*(1 - alpha));
                    }
                    tgt.setSample( bp, tx, ty, c );
                }
                ++pixelsWritten;
            }
        }

        targetView.endProcess();
        sigWindow.forceClose();

        console.noteln( format(
            "AstroMark: composited %d signature pixels (sig %dx%d at %d,%d, blend=%s). " +
            "Skipped: %d zero-alpha, %d isBlack, %d out-of-bounds.",
            pixelsWritten, sigW, sigH, posX, posY, blendMode,
            skippedAlpha, skippedIsBlack, skippedBounds ) );

        this.ok();
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );
    console.writeln( "AstroMark Loading..." );
    parameters.load();
    let dialog = new SignatureAdderDialog();
    dialog.execute();
}

main();
