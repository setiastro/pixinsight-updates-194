/*
 * NBExtractPI — Empirically Calibrated Dual-Band Narrowband Channel Extractor
 * ===========================================================================
 *
 * A native PixInsight (PJSR) implementation of the extraction *process*
 * pioneered by Franklin Marek's "NBExtract" tool in Seti Astro Suite Pro
 * (https://github.com/setiastro/setiastrosuitepro, GPL-3.0).
 * This is an original, independent implementation for PixInsight — no code
 * has been copied from SASpro. Full credit for the method goes to
 * Franklin Marek / Seti Astro.
 *
 * The process
 * -----------
 * Rather than relying on published sensor QE curves, the mixing of the two
 * emission lines (e.g. Ha and OIII behind a dual-band filter) into the R, G
 * and B channels of an OSC camera is fitted EMPIRICALLY from stars in the
 * actual image:
 *
 *   1. The image must be plate-solved (ImageSolver / SPCC astrometric
 *      solution). Stars with Gaia DR3 BP/RP mean spectra are fetched from
 *      the local Gaia DR3/SP XPSD database (the same database SPCC uses).
 *   2. Stars are re-detected in the image (StarDetector) and matched to the
 *      Gaia sources. For the brightest N matches, aperture photometry gives
 *      the measured R/G/B fluxes, and the star's Gaia XP spectrum is
 *      integrated over the two filter passband windows, giving the expected
 *      relative line-1 / line-2 signals S1 and S2.
 *   3. A 3x2 mixing matrix A is fitted by non-negative least squares with
 *      iterative sigma clipping:
 *
 *          R = a*S1 + b*S2
 *          G = c*S1 + d*S2
 *          B = e*S1 + f*S2
 *
 *   4. The per-pixel system is inverted (Moore-Penrose pseudo-inverse,
 *      clipped to >= 0) to produce the two pure emission-line images.
 *   5. Each output is blended with a "raw channel prior" (the dominant
 *      channel for that line) using a mixing strength Q derived
 *      automatically from the conditioning of A — this suppresses noise
 *      amplification when the channels are poorly separated.
 *
 * Requirements
 * ------------
 *   - PixInsight >= 1.9.4 (native ImageWindow astrometry API).
 *   - The Gaia process configured with "Gaia DR3/SP" XPSD database files
 *     (the *spectrum* variant used by SPCC).
 *   - A plate-solved LINEAR RGB image taken through a dual-band filter.
 *
 * Copyright (c) 2026. Released under GPL-3.0 in the spirit of the original.
 * Algorithm design credit: Franklin Marek / Seti Astro (NBExtract, SASpro).
 *
 * THIS SCRIPT IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

#feature-id    NBExtractPI : Lighthouse Suite > NBExtractPI

#feature-info  Empirically calibrated dual-band narrowband channel extraction. \
   Fits the Ha/OIII (or SII/OIII, SII/Hb) channel mixing matrix from Gaia DR3 \
   BP/RP spectra of stars measured in the plate-solved image, then separates \
   the two emission lines per pixel. A PixInsight implementation of the \
   process introduced by NBExtract (Seti Astro Suite Pro, Franklin Marek).

#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/StarDetector.jsh>

#define TITLE   "NBExtractPI"
#define VERSION "1.2.0"

// ─────────────────────────────────────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────────────────────────────────────

// Emission line rest wavelengths in nm (air)
var LINE_CENTERS_NM = {
   "Ha":   656.28,
   "OIII": 500.70,
   "SII":  671.64,
   "Hb":   486.13
};

// Default filter bandwidths (FWHM, nm) — user adjustable
var DEFAULT_BW_NM = {
   "Ha":   7.0,
   "OIII": 6.5,
   "SII":  7.0,
   "Hb":   6.5
};

// Preset name → [line1 key, line2 key]
var FILTER_PRESETS = [
   { name: "Ha / OIII",  l1: "Ha",    l2: "OIII"  },
   { name: "SII / OIII", l1: "SII",   l2: "OIII"  },
   { name: "SII / Hb",   l1: "SII",   l2: "Hb"    },
   { name: "Custom",     l1: "Line1", l2: "Line2" }
];
var PRESET_CUSTOM_INDEX = 3;

var CHANNEL_NAMES = [ "R", "G", "B" ];

// ─────────────────────────────────────────────────────────────────────────────
// Small numeric helpers
// ─────────────────────────────────────────────────────────────────────────────

function clamp( x, lo, hi )
{
   return (x < lo) ? lo : ((x > hi) ? hi : x);
}

function medianOfArray( a )
{
   if ( a.length == 0 )
      return 0;
   let s = a.slice().sort( function( u, v ) { return u - v; } );
   let n = s.length;
   return (n & 1) ? s[(n - 1) >> 1] : 0.5*(s[(n >> 1) - 1] + s[n >> 1]);
}

function madOfArray( a, med )
{
   let d = new Array( a.length );
   for ( let i = 0; i < a.length; ++i )
      d[i] = Math.abs( a[i] - med );
   return medianOfArray( d );
}

// Format a linear combination "c0*$T[0] + c1*$T[1] + c2*$T[2]" with safe signs
function linearCombination3( c, refs )
{
   let s = "";
   for ( let i = 0; i < 3; ++i )
   {
      let v = c[i];
      if ( i == 0 )
         s += (v < 0 ? "-" : "");
      else
         s += (v < 0 ? " - " : " + ");
      s += format( "%.10f", Math.abs( v ) ) + "*" + refs[i];
   }
   return s;
}

// ─────────────────────────────────────────────────────────────────────────────
// Core maths — mixing matrix machinery
// A is stored as a plain 3x2 array: A[row 0..2][col 0..1], rows = R,G,B
// ─────────────────────────────────────────────────────────────────────────────

/*
 * Exact non-negative least squares for TWO unknowns.
 * Minimizes ||X a - y||^2 subject to a >= 0, given the Gram matrix terms
 * G11 = x1·x1, G12 = x1·x2, G22 = x2·x2 and b1 = x1·y, b2 = x2·y.
 */
function nnls2( G11, G12, G22, b1, b2 )
{
   let det = G11*G22 - G12*G12;
   if ( det > 1e-300 )
   {
      let a1 = (b1*G22 - b2*G12)/det;
      let a2 = (b2*G11 - b1*G12)/det;
      if ( a1 >= 0 && a2 >= 0 )
         return [ a1, a2 ];
   }
   // Active-set boundary solutions
   let a1 = (G11 > 0) ? Math.max( 0, b1/G11 ) : 0;
   let a2 = (G22 > 0) ? Math.max( 0, b2/G22 ) : 0;
   // Compare residuals: r(a) = a'Ga - 2a'b (+ const)
   let r1 = a1*a1*G11 - 2*a1*b1;
   let r2 = a2*a2*G22 - 2*a2*b2;
   return (r1 <= r2) ? [ a1, 0 ] : [ 0, a2 ];
}

/*
 * Singular values of the 3x2 matrix A via the eigenvalues of A'A (2x2).
 * Returns [sv1, sv2] with sv1 >= sv2 >= 0.
 */
function singularValues32( A )
{
   let g11 = 0, g12 = 0, g22 = 0;
   for ( let r = 0; r < 3; ++r )
   {
      g11 += A[r][0]*A[r][0];
      g12 += A[r][0]*A[r][1];
      g22 += A[r][1]*A[r][1];
   }
   let tr = g11 + g22;
   let det = g11*g22 - g12*g12;
   let disc = Math.sqrt( Math.max( 0, tr*tr - 4*det ) );
   let l1 = Math.max( 0, 0.5*(tr + disc) );
   let l2 = Math.max( 0, 0.5*(tr - disc) );
   return [ Math.sqrt( l1 ), Math.sqrt( l2 ) ];
}

function conditionNumber32( A )
{
   let sv = singularValues32( A );
   return (sv[1] > 0) ? sv[0]/sv[1] : 1e12;
}

/*
 * Moore-Penrose pseudo-inverse of the 3x2 matrix A:
 *    P = (A'A)^-1 A'   →  2x3
 */
function pseudoInverse32( A )
{
   let g11 = 0, g12 = 0, g22 = 0;
   for ( let r = 0; r < 3; ++r )
   {
      g11 += A[r][0]*A[r][0];
      g12 += A[r][0]*A[r][1];
      g22 += A[r][1]*A[r][1];
   }
   let det = g11*g22 - g12*g12;
   if ( Math.abs( det ) < 1e-300 )
      throw new Error( "Mixing matrix is numerically singular — cannot invert." );
   let i11 =  g22/det, i12 = -g12/det, i22 = g11/det;
   let P = [ [ 0, 0, 0 ], [ 0, 0, 0 ] ];
   for ( let r = 0; r < 3; ++r )
   {
      P[0][r] = i11*A[r][0] + i12*A[r][1];
      P[1][r] = i12*A[r][0] + i22*A[r][1];
   }
   return P;
}

/*
 * Which RGB channel is the dominant receiver of each line (column maxima).
 */
function dominantChannelsFromMatrix( A )
{
   let ch = [ 0, 0 ];
   for ( let col = 0; col < 2; ++col )
   {
      let best = 0;
      for ( let r = 1; r < 3; ++r )
         if ( A[r][col] > A[best][col] )
            best = r;
      ch[col] = best;
   }
   return ch;
}

/*
 * Raw prior channel selection for one line: the dominant channel, or the
 * average of the two highest channels when they are within 5 percentage
 * points of each other (genuinely tied).
 * Returns { chans: [i] or [i,j], pct: [%R,%G,%B] }.
 */
function rawPriorChannels( A, col )
{
   let c = [ A[0][col], A[1][col], A[2][col] ];
   let total = c[0] + c[1] + c[2];
   if ( total <= 0 )
   {
      let best = 0;
      for ( let r = 1; r < 3; ++r )
         if ( c[r] > c[best] )
            best = r;
      return { chans: [ best ], pct: [ 0, 0, 0 ] };
   }
   let pct = [ 100*c[0]/total, 100*c[1]/total, 100*c[2]/total ];
   let order = [ 0, 1, 2 ].sort( function( u, v ) { return pct[v] - pct[u]; } );
   let best = order[0], second = order[1];
   if ( pct[best] - pct[second] <= 5.0 )
      return { chans: [ best, second ], pct: pct };
   return { chans: [ best ], pct: pct };
}

/*
 * Automatic per-line mixing strengths Q1, Q2 from the structure of A.
 *
 *  - Global baseline from the condition number: Q = 1/(1 + 0.1 k)
 *  - Q2 additionally penalized by (a) the singular value ratio and (b) the
 *    similarity of the two NON-dominant rows in the line-2 column — nearly
 *    identical rows mean the inversion extrapolates noise (the classic
 *    OIII over-subtraction failure mode with G ≈ B).
 */
function autoQPerChannel( A )
{
   let ch = dominantChannelsFromMatrix( A );
   let k = conditionNumber32( A );
   let qGlobal = clamp( 1/(1 + 0.1*k), 0.2, 0.9 );

   let sv = singularValues32( A );
   let svRatio = (sv[0] > 0) ? sv[1]/sv[0] : 0;

   let q1 = clamp( qGlobal, 0.2, 0.9 );
   let q2svd = clamp( qGlobal*svRatio, 0.2, 0.9 );

   // Non-dominant row degeneracy check for line 2
   let nonDom = [];
   for ( let r = 0; r < 3; ++r )
      if ( r != ch[1] )
         nonDom.push( r );
   let va = A[nonDom[0]][1], vb = A[nonDom[1]][1];
   let rowSum = Math.abs( va ) + Math.abs( vb );
   let similarity = (rowSum > 1e-10) ? 1 - Math.abs( va - vb )/rowSum : 1;

   // Squared penalty mirrors noise amplification physics (gain ∝ cond²)
   let q2 = clamp( q2svd*(1 - similarity*similarity*0.8), 0.2, 0.9 );

   return { q1: q1, q2: q2, k: k, svRatio: svRatio, similarity: similarity, ch: ch };
}

/*
 * Fit the 3x2 empirical mixing matrix from stellar photometry records.
 *
 * Model:  M_i ≈ F_i · A · s_i   for each star i, where
 *    M_i = (R,G,B) measured aperture fluxes,
 *    s_i = (S1,S2) integrals of the UNIT-normalized Gaia spectrum over the
 *          two filter windows (color information only),
 *    F_i = unknown per-star brightness scale.
 *
 * The per-star scale is eliminated by alternating least squares:
 *    1. Given F, fit each channel row of A by NNLS on (M_c/F) vs (S1,S2).
 *    2. Given A, update each star's optimal scale
 *           F_i = Σ_c M_ci·P_ci / Σ_c P_ci² ,   P_i = A·s_i.
 * A few alternations converge to a self-consistent solution in which every
 * star has equal weight regardless of brightness. Iterative MAD sigma
 * clipping rejects outliers (blends, mismatches, bad photometry).
 *
 * Note: naive alternatives are biased — regressing raw fluxes against the
 * color-only regressors is ill-posed (brightness is not in the model), and
 * regressing per-star flux FRACTIONS is a ratio of linear forms, which a
 * linear fit systematically mis-attributes. Both failure modes were observed
 * on real data before this formulation.
 *
 * records[i] = { S1, S2, R, G, B, x, y }
 * Returns { A, nUsed, nClipped } or { A:null, reason } on failure.
 */
function fitMixingMatrix( records, sigmaClip, maxClipIter, maxScaleIter )
{
   if ( sigmaClip === undefined ) sigmaClip = 3.0;
   if ( maxClipIter === undefined ) maxClipIter = 3;
   if ( maxScaleIter === undefined ) maxScaleIter = 300;

   let N = records.length;
   if ( N == 0 )
      return { A: null, reason: "no calibration stars" };

   let S1 = new Array( N ), S2 = new Array( N );
   let M = [ new Array( N ), new Array( N ), new Array( N ) ];
   let F = new Array( N );
   for ( let i = 0; i < N; ++i )
   {
      S1[i] = records[i].S1;
      S2[i] = records[i].S2;
      M[0][i] = records[i].R;
      M[1][i] = records[i].G;
      M[2][i] = records[i].B;
   }

   let keep = new Array( N );
   for ( let i = 0; i < N; ++i )
      keep[i] = true;

   let A = null;

   // One NNLS solve of all three rows of A for the current scales F
   let solveA = function()
   {
      let G11 = 0, G12 = 0, G22 = 0;
      for ( let i = 0; i < N; ++i )
         if ( keep[i] )
         {
            G11 += S1[i]*S1[i];
            G12 += S1[i]*S2[i];
            G22 += S2[i]*S2[i];
         }
      let Anew = [ [ 0, 0 ], [ 0, 0 ], [ 0, 0 ] ];
      for ( let c = 0; c < 3; ++c )
      {
         let b1 = 0, b2 = 0;
         for ( let i = 0; i < N; ++i )
            if ( keep[i] )
            {
               let y = M[c][i]/F[i];
               b1 += S1[i]*y;
               b2 += S2[i]*y;
            }
         Anew[c] = nnls2( G11, G12, G22, b1, b2 );
      }
      return Anew;
   };

   // Alternate A ↔ F to self-consistency on the current keep set.
   // Convergence along the scale/color manifold is slow, so run many cheap
   // iterations (O(N) each) with an early exit once A stabilizes.
   let alternate = function()
   {
      for ( let i = 0; i < N; ++i )
         F[i] = M[0][i] + M[1][i] + M[2][i]; // initial brightness proxy
      let Aprev = null;
      for ( let s = 0; s < maxScaleIter; ++s )
      {
         A = solveA();
         for ( let i = 0; i < N; ++i )
         {
            let num = 0, den = 0;
            for ( let c = 0; c < 3; ++c )
            {
               let p = A[c][0]*S1[i] + A[c][1]*S2[i];
               num += M[c][i]*p;
               den += p*p;
            }
            if ( den > 0 && num > 0 )
               F[i] = num/den;
            // else: keep the previous scale for this star
         }
         if ( Aprev != null )
         {
            let dmax = 0;
            for ( let c = 0; c < 3; ++c )
               for ( let j = 0; j < 2; ++j )
                  dmax = Math.max( dmax, Math.abs( A[c][j] - Aprev[c][j] )/
                                         Math.max( Math.abs( A[c][j] ), 1e-12 ) );
            if ( dmax < 1e-6 )
               break;
         }
         Aprev = [ A[0].slice(), A[1].slice(), A[2].slice() ];
      }
   };

   for ( let clipIter = 0; clipIter < maxClipIter; ++clipIter )
   {
      alternate();

      // Mean fractional residual per star (over the three channels)
      let res = new Array( N );
      for ( let i = 0; i < N; ++i )
      {
         let acc = 0;
         for ( let c = 0; c < 3; ++c )
         {
            let pred = F[i]*(A[c][0]*S1[i] + A[c][1]*S2[i]);
            acc += (pred > 0) ? Math.abs( M[c][i] - pred )/pred : 1;
         }
         res[i] = acc/3;
      }

      let kept = [];
      for ( let i = 0; i < N; ++i )
         if ( keep[i] )
            kept.push( res[i] );
      let med = medianOfArray( kept );
      let mad = 1.4826*madOfArray( kept, med );
      if ( mad <= 0 )
         break;

      let nClipped = 0, nRemain = 0;
      let newKeep = new Array( N );
      for ( let i = 0; i < N; ++i )
      {
         newKeep[i] = keep[i] && (res[i] < med + sigmaClip*mad);
         if ( keep[i] && !newKeep[i] )
            ++nClipped;
         if ( newKeep[i] )
            ++nRemain;
      }
      if ( nClipped == 0 )
         break;
      if ( nRemain < 6 )
      {
         console.writeln( "<end><cbr>Too few stars after clipping; keeping previous set." );
         break;
      }
      console.writeln( format( "<end><cbr>Sigma clip iteration %d: clipped %d stars, %d remaining.",
                               clipIter + 1, nClipped, nRemain ) );
      keep = newKeep;
   }

   // Final self-consistent fit on the surviving star set
   alternate();

   if ( A == null )
      return { A: null, reason: "fit did not run" };

   let nUsed = 0;
   for ( let i = 0; i < N; ++i )
      if ( keep[i] )
         ++nUsed;

   for ( let c = 0; c < 3; ++c )
      for ( let j = 0; j < 2; ++j )
         if ( !isFinite( A[c][j] ) )
            return { A: null, reason: "mixing matrix contains non-finite values" };

   // Each line must land in at least one channel
   if ( A[0][0] + A[1][0] + A[2][0] <= 0 || A[0][1] + A[1][1] + A[2][1] <= 0 )
      return { A: null, reason:
         "degenerate fit — one line column is entirely zero.\n" +
         "The star sample may lack spectral diversity; try more calibration\n" +
         "stars or a fainter magnitude limit." };

   let k = conditionNumber32( A );
   if ( k > 1e8 )
      return { A: null, reason:
         format( "mixing matrix is numerically singular (condition number %.2e).\n", k ) +
         "Likely cause: G and B channels are identical (e.g. a synthetic HOO image\n" +
         "where G = B = OIII). Extraction requires a real dual-band OSC image where\n" +
         "the green and blue Bayer pixels have genuinely different responses." };

   return { A: A, nUsed: nUsed, nClipped: N - nUsed };
}

/*
 * Severity assessment of the matrix conditioning:
 *   "ok"      k < 25  — clean separation
 *   "caution" k < 100 — moderate overlap, auto-Q compensates
 *   "severe"  k >= 100 — noise amplification too large
 */
function conditionNumberWarning( A )
{
   let k = conditionNumber32( A );
   if ( k >= 100 )
      return { text: format( "Condition number is %.1f — channel separation is too poor for " +
                             "reliable extraction (noise amplified ~%.0fx). Consider color-calibrating " +
                             "the image (SPCC) and using plain channel extraction instead.", k, k*k ),
               severity: "severe" };
   if ( k >= 25 )
      return { text: format( "Condition number is %.1f — moderate channel overlap. " +
                             "Auto-Q has been set conservatively. Check the extracted channels for " +
                             "dark halos and reduce Q further if needed.", k ),
               severity: "caution" };
   return { text: null, severity: "ok" };
}

// ─────────────────────────────────────────────────────────────────────────────
// Spectrum integration (uniform Gaia XP wavelength grid)
// ─────────────────────────────────────────────────────────────────────────────

function spectrumValueAt( fl, wl0, step, n, w )
{
   let t = (w - wl0)/step;
   if ( t <= 0 )
      return fl[0];
   if ( t >= n - 1 )
      return fl[n - 1];
   let i = Math.floor( t );
   let f = t - i;
   return fl[i]*(1 - f) + fl[i + 1]*f;
}

/*
 * Integral of the piecewise-linear spectrum over [lo, hi] (trapezoid rule
 * with interpolated end points) — the top-hat passband window integral.
 */
function integrateSpectrumWindow( fl, wl0, step, n, lo, hi )
{
   if ( hi <= lo )
      return 0;
   let wlMin = wl0, wlMax = wl0 + (n - 1)*step;
   if ( hi < wlMin || lo > wlMax )
      return 0;

   let xs = [ lo ], ys = [ spectrumValueAt( fl, wl0, step, n, lo ) ];
   let iLo = Math.max( 0, Math.ceil( (lo - wl0)/step ) );
   let iHi = Math.min( n - 1, Math.floor( (hi - wl0)/step ) );
   for ( let i = iLo; i <= iHi; ++i )
   {
      let w = wl0 + i*step;
      if ( w > lo && w < hi )
      {
         xs.push( w );
         ys.push( fl[i] );
      }
   }
   xs.push( hi );
   ys.push( spectrumValueAt( fl, wl0, step, n, hi ) );

   let s = 0;
   for ( let i = 1; i < xs.length; ++i )
      s += 0.5*(ys[i] + ys[i - 1])*(xs[i] - xs[i - 1]);
   return s;
}

// Total integral over the full grid (for unit-flux normalization)
function integrateSpectrumTotal( fl, step )
{
   let n = fl.length;
   if ( n < 2 )
      return 0;
   let s = 0;
   for ( let i = 0; i < n; ++i )
      s += fl[i];
   return step*(s - 0.5*(fl[0] + fl[n - 1]));
}

// ─────────────────────────────────────────────────────────────────────────────
// Astrometry helpers
// ─────────────────────────────────────────────────────────────────────────────

function imageToCelestialSafe( window, x, y )
{
   let q = null;
   try
   {
      q = window.imageToCelestial( x, y );
   }
   catch ( e )
   {
      try
      {
         q = window.imageToCelestial( new Point( x, y ) );
      }
      catch ( e2 )
      {
         q = null;
      }
   }
   if ( q && typeof q.x === "number" && isFinite( q.x ) && isFinite( q.y ) )
      return q; // q.x = RA (deg), q.y = Dec (deg)
   return null;
}

function celestialToImageSafe( window, ra, dec )
{
   let q = null;
   try
   {
      q = window.celestialToImage( ra, dec );
   }
   catch ( e )
   {
      try
      {
         q = window.celestialToImage( new Point( ra, dec ) );
      }
      catch ( e2 )
      {
         q = null;
      }
   }
   if ( q && typeof q.x === "number" && isFinite( q.x ) && isFinite( q.y ) )
      return q;
   return null;
}

function angularDistanceDeg( ra1, dec1, ra2, dec2 )
{
   let d2r = Math.PI/180;
   let sd = Math.sin( 0.5*(dec2 - dec1)*d2r );
   let sr = Math.sin( 0.5*(ra2 - ra1)*d2r );
   let h = sd*sd + Math.cos( dec1*d2r )*Math.cos( dec2*d2r )*sr*sr;
   return 2*Math.asin( Math.min( 1, Math.sqrt( h ) ) )/d2r;
}

/*
 * Center coordinates and search radius (deg) covering the whole image.
 * Returns null if the window has no valid astrometric solution.
 */
function fieldGeometry( window )
{
   let img = window.mainView.image;
   let W = img.width, H = img.height;
   let c = imageToCelestialSafe( window, 0.5*W, 0.5*H );
   if ( c == null )
      return null;
   let radius = 0;
   let corners = [ [ 0, 0 ], [ W, 0 ], [ 0, H ], [ W, H ] ];
   for ( let i = 0; i < 4; ++i )
   {
      let q = imageToCelestialSafe( window, corners[i][0], corners[i][1] );
      if ( q == null )
         return null;
      let d = angularDistanceDeg( c.x, c.y, q.x, q.y );
      if ( d > radius )
         radius = d;
   }
   return { ra: c.x, dec: c.y, radius: radius*1.02 + 0.01 };
}

/*
 * Observation epoch in Julian years from DATE-OBS/DATE-BEG, or null.
 */
function observationEpochYears( window )
{
   try
   {
      let kws = window.keywords;
      for ( let i = 0; i < kws.length; ++i )
      {
         let name = kws[i].name.toUpperCase();
         if ( name == "DATE-OBS" || name == "DATE-BEG" || name == "DATE-AVG" )
         {
            let v = kws[i].value.toString().replace( /'/g, "" ).trim();
            let m = /^(\d{4})-(\d{2})-(\d{2})/.exec( v );
            if ( m )
               return parseInt( m[1] ) + (parseInt( m[2] ) - 1)/12 + parseInt( m[3] )/365.25;
         }
      }
   }
   catch ( e )
   {
   }
   return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Gaia DR3/SP XPSD search
// ─────────────────────────────────────────────────────────────────────────────

/*
 * Search the local Gaia DR3/SP database for sources with BP/RP mean spectra.
 * Returns { sources, wl0, step, count } where each source row is
 * [ ra, dec, parx, pmra, pmdec, magG, magBP, magRP, flags, flux[] ].
 */
function gaiaXPSearch( ra, dec, radiusDeg, magHigh, sourceLimit )
{
   if ( (typeof Gaia) == 'undefined' )
      throw new Error( "The Gaia process is not installed in this PixInsight instance." );

   let S = new Gaia;
   if ( S.dataRelease === undefined || Gaia.prototype.DataRelease_3_SP === undefined )
      throw new Error( "This PixInsight version does not support Gaia DR3/SP (XPSD spectrum) databases.\n" +
                       "Please update to PixInsight 1.9.4 or newer." );

   S.command = "search";
   S.centerRA = ra;
   S.centerDec = dec;
   S.radius = radiusDeg;
   S.magnitudeLow = -1.5;
   S.magnitudeHigh = magHigh;
   S.sourceLimit = sourceLimit;
   S.requiredFlags = 0;
   S.inclusionFlags = 0;
   S.exclusionFlags = 0;
   S.dataRelease = Gaia.prototype.DataRelease_3_SP;
   S.normalizeSpectrum = false;   // we normalize to unit integrated flux ourselves
   S.photonFluxUnits = false;     // energy flux — same convention as SASpro NBExtract,
                                  // keeps the sensitivity tables directly comparable
   S.sortBy = Gaia.prototype.SortBy_G;
   S.generateTextOutput = false;
   S.verbosity = 1;

   let ok = false;
   try
   {
      ok = S.executeGlobal();
   }
   catch ( e )
   {
      throw new Error( "Gaia DR3/SP database search failed:\n" +
         ((e instanceof Error) ? e.message : e.toString()) + "\n\n" +
         "Make sure the Gaia process is configured with 'Gaia DR3/SP' XPSD database\n" +
         "files (the BP/RP spectrum variant used by SpectrophotometricColorCalibration).\n" +
         "Open PROCESS > Gaia, select data release 'Gaia DR3/SP', and add the\n" +
         "database files under 'XPSD server / Database files'." );
   }
   if ( !ok )
      throw new Error( "The Gaia XPSD search command failed. Check that Gaia DR3/SP\n" +
                       "database files are configured in the Gaia process preferences." );

   if ( !S.databaseHasMeanSpectrumData )
      throw new Error( "The configured Gaia database files do NOT include BP/RP mean spectrum\n" +
         "data. NBExtractPI requires the 'Gaia DR3/SP' XPSD variant — the same database\n" +
         "used by SpectrophotometricColorCalibration (SPCC)." );

   return {
      sources: S.sources,
      wl0:     S.databaseSpectrumStart,   // nm
      step:    S.databaseSpectrumStep,    // nm
      count:   S.databaseSpectrumCount
   };
}

// ─────────────────────────────────────────────────────────────────────────────
// Image measurement — detection and aperture photometry
// ─────────────────────────────────────────────────────────────────────────────

function uniqueViewId( baseId )
{
   let id = baseId.replace( /[^0-9A-Za-z_]/g, "_" );
   if ( /^\d/.test( id ) )
      id = "_" + id;
   if ( ImageWindow.windowById( id ).isNull )
      return id;
   for ( let i = 1; ; ++i )
      if ( ImageWindow.windowById( id + i ).isNull )
         return id + i;
}

/*
 * Run PixelMath on sourceView, creating a new (optionally hidden) grayscale
 * f32 image window. Returns the new ImageWindow.
 */
function pixelMathNewImage( sourceView, expression, newId, show )
{
   let P = new PixelMath;
   P.expression = expression;
   P.useSingleExpression = true;
   P.symbols = "";
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.truncate = false;
   P.createNewImage = true;
   P.showNewImage = (show === true);
   P.newImageId = newId;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.prototype.Gray;
   P.newImageSampleFormat = PixelMath.prototype.f32;
   if ( !P.executeOn( sourceView ) )
      throw new Error( "PixelMath execution failed: " + expression );
   let w = ImageWindow.windowById( newId );
   if ( w.isNull )
      throw new Error( "PixelMath did not create image '" + newId + "'." );
   return w;
}

function pixelMathInPlace( view, expression )
{
   let P = new PixelMath;
   P.expression = expression;
   P.useSingleExpression = true;
   P.symbols = "";
   P.rescale = false;
   P.truncate = false;
   P.createNewImage = false;
   if ( !P.executeOn( view ) )
      throw new Error( "PixelMath execution failed: " + expression );
}

/*
 * Detect stars on the mean-of-RGB luminance of the source view.
 * Returns the array of StarDetector Star objects.
 *
 * Handles both StarDetector generations shipped with PixInsight:
 *   V2 (>= 1.8.9-2): sensitivity normalized to [0,1], larger = more stars.
 *   V1 (older):      sensitivity is a threshold, SMALLER = more stars
 *                    (default 0.1). The UI value (0..1, larger = more stars)
 *                    is mapped accordingly.
 */
function detectStars( sourceView, sensitivity, structureLayers )
{
   let tmpId = uniqueViewId( "nbx_tmp_lum" );
   let w = pixelMathNewImage( sourceView, "mean($T[0], $T[1], $T[2])", tmpId, false );
   let stars = null;
   try
   {
      let D = new StarDetector;
      let isV2 = (D.brightThreshold !== undefined) || (D.minSNR !== undefined);
      D.structureLayers = structureLayers;
      D.hotPixelFilterRadius = 1;
      D.applyHotPixelFilterToDetectionImage = false;
      if ( isV2 )
         D.sensitivity = sensitivity;
      else
      {
         // Map UI 0..1 (0.5 = default) onto the V1 threshold scale:
         // 0.5 → 0.1 (V1 default), 1.0 → 0.01 (max), 0.0 → 1.0 (min)
         D.sensitivity = 0.1*Math.pow( 10, (0.5 - sensitivity)*2 );
      }
      D.upperLimit = 1.0;
      stars = D.stars( w.mainView.image );
   }
   finally
   {
      w.forceClose();
   }
   return stars;
}

/*
 * Photometric aperture radius for a detected star.
 *
 * Newer StarDetector versions provide the detection rectangle (star.rect);
 * older versions only provide the structure area in square pixels
 * (star.size). Returns -1 when the structure is too large to be a clean star.
 */
function apertureRadiusForStar( det )
{
   if ( det.rect !== undefined && det.rect !== null &&
        isFinite( det.rect.x0 ) && isFinite( det.rect.x1 ) )
   {
      let w = det.rect.x1 - det.rect.x0;
      let h = det.rect.y1 - det.rect.y0;
      let m = Math.max( w, h );
      if ( m > 40 )
         return -1; // not a clean star
      return clamp( 0.75*m, 3, 10 );
   }
   let size = (typeof det.size === "number" && det.size > 0) ? det.size : 25;
   let re = Math.sqrt( size/Math.PI ); // equivalent structure radius
   if ( re > 20 )
      return -1;
   return clamp( 2*re, 3, 10 );
}

/*
 * Circular aperture photometry with local annulus background subtraction.
 * img must be an RGB Image; (cx, cy) in image coordinates; r in pixels.
 * Returns { R, G, B, peak } (background-subtracted sums, normalized units)
 * or null when the measurement is invalid.
 */
function measureStarRGB( img, cx, cy, r, norm )
{
   let rIn = r + 2, rOut = r + 5;
   let W = img.width, H = img.height;
   let x0 = Math.floor( cx - rOut ), x1 = Math.ceil( cx + rOut );
   let y0 = Math.floor( cy - rOut ), y1 = Math.ceil( cy + rOut );
   if ( x0 < 0 || y0 < 0 || x1 >= W || y1 >= H )
      return null; // too close to the border for a clean annulus

   let ap = [ 0, 0, 0 ];
   let apArea = 0;
   let peak = 0;
   let ann = [ [], [], [] ];

   let rFull = r - 0.7072, rNone = r + 0.7072;

   for ( let iy = y0; iy <= y1; ++iy )
      for ( let ix = x0; ix <= x1; ++ix )
      {
         let dx = ix + 0.5 - cx;
         let dy = iy + 0.5 - cy;
         let d = Math.sqrt( dx*dx + dy*dy );

         if ( d <= rNone )
         {
            // Fractional pixel coverage of the aperture disk
            let wgt;
            if ( d <= rFull )
               wgt = 1;
            else
            {
               // 5x5 subpixel sampling of the boundary pixel
               let inCount = 0;
               for ( let sy = 0; sy < 5; ++sy )
                  for ( let sx = 0; sx < 5; ++sx )
                  {
                     let px = ix + (sx + 0.5)/5 - cx;
                     let py = iy + (sy + 0.5)/5 - cy;
                     if ( px*px + py*py <= r*r )
                        ++inCount;
                  }
               wgt = inCount/25;
               if ( wgt == 0 )
                  continue;
            }
            apArea += wgt;
            for ( let c = 0; c < 3; ++c )
            {
               let v = img.sample( ix, iy, c )*norm;
               ap[c] += wgt*v;
               if ( v > peak )
                  peak = v;
            }
         }
         else if ( d >= rIn && d <= rOut )
         {
            for ( let c = 0; c < 3; ++c )
               ann[c].push( img.sample( ix, iy, c )*norm );
         }
      }

   if ( apArea <= 0 || ann[0].length < 8 )
      return null;

   let out = [ 0, 0, 0 ];
   for ( let c = 0; c < 3; ++c )
   {
      let bkg = medianOfArray( ann[c] );
      out[c] = ap[c] - bkg*apArea;
      if ( !isFinite( out[c] ) || out[c] <= 0 )
         return null;
   }
   return { R: out[0], G: out[1], B: out[2], peak: peak };
}

// ─────────────────────────────────────────────────────────────────────────────
// Engine — parameters, calibration and extraction
// ─────────────────────────────────────────────────────────────────────────────

function NBXEngine()
{
   // User parameters (persisted)
   this.presetIndex = 0;
   this.line1Name = "Ha";
   this.line2Name = "OIII";
   this.center1 = LINE_CENTERS_NM["Ha"];
   this.center2 = LINE_CENTERS_NM["OIII"];
   this.bw1 = DEFAULT_BW_NM["Ha"];
   this.bw2 = DEFAULT_BW_NM["OIII"];
   this.maxCalStars = 300;
   this.matchTolerance = 3.0;
   this.magLimit = 16.5;
   this.sensitivity = 0.5;
   this.structureLayers = 5;
   this.saturationLimit = 0.95;
   this.medianMatch = true;
   this.autoQ = true;
   this.q1 = 1.0;
   this.q2 = 1.0;

   // Working state
   this.targetView = null;
   this.A = null;
   this.records = [];
   this.nUsed = 0;
   this.diag = "";           // last diagnostics report
   this.autoQInfo = null;
   this.nMatched = 0;

   this.effectiveLineNames = function()
   {
      if ( this.presetIndex == PRESET_CUSTOM_INDEX )
         return [ this.line1Name.trim() || "Line1", this.line2Name.trim() || "Line2" ];
      let p = FILTER_PRESETS[this.presetIndex];
      return [ p.l1, p.l2 ];
   };

   this.invalidateCalibration = function()
   {
      this.A = null;
      this.records = [];
      this.autoQInfo = null;
   };

   this.validateTarget = function()
   {
      let v = this.targetView;
      if ( v == null || v.isNull )
         throw new Error( "No target view selected." );
      if ( !v.isMainView )
         throw new Error( "Please select a main view (not a preview)." );
      if ( !v.image.isColor || v.image.numberOfChannels < 3 )
         throw new Error( "The target image must be an RGB color image (dual-band OSC integration)." );
   };

   // ── Step 1+2: fetch Gaia XP stars, measure, fit the matrix ───────────────
   this.calibrate = function()
   {
      this.validateTarget();
      this.invalidateCalibration();

      let view = this.targetView;
      let window = view.window;
      let img = view.image;
      let names = this.effectiveLineNames();

      console.show();
      console.abortEnabled = true;
      console.noteln( "<end><cbr><br>* " + TITLE + " — calibrating " + names[0] + "/" + names[1] +
                      " mixing matrix on '" + view.id + "'" );

      // 1. Astrometric solution / field geometry
      let geom = fieldGeometry( window );
      if ( geom == null )
         throw new Error( "The image has no valid astrometric solution.\n\n" +
            "Please plate-solve it first: SCRIPT > Image Analysis > ImageSolver,\n" +
            "or apply SPCC which also attaches a solution." );
      console.writeln( format( "Field center: RA = %.5f°, Dec = %+.5f°, search radius = %.3f°",
                               geom.ra, geom.dec, geom.radius ) );

      // 2. Gaia DR3/SP search
      console.writeln( "Searching local Gaia DR3/SP database (BP/RP spectra)..." );
      let gaia = gaiaXPSearch( geom.ra, geom.dec, geom.radius, this.magLimit, 100000 );
      if ( gaia.sources == null || gaia.sources.length == 0 )
         throw new Error( "The Gaia DR3/SP search returned no sources.\n" +
            "Try increasing the magnitude limit, or install additional XPSD database files." );
      console.writeln( format( "%d Gaia XP sources retrieved (spectrum grid: %.1f nm + n·%.1f nm, %d samples).",
                               gaia.sources.length, gaia.wl0, gaia.step, gaia.count ) );

      // 3. Project Gaia sources onto the image (with optional PM correction)
      let epoch = observationEpochYears( window );
      let dt = (epoch != null) ? epoch - 2016.0 : 0; // Gaia DR3 reference epoch
      if ( epoch != null )
         console.writeln( format( "Observation epoch %.2f — applying %.1f yr of proper motion.", epoch, dt ) );

      let W = img.width, H = img.height;
      let projected = [];
      let d2r = Math.PI/180;
      for ( let i = 0; i < gaia.sources.length; ++i )
      {
         if ( (i & 1023) == 0 )
         {
            processEvents();
            if ( console.abortRequested )
               throw new Error( "Aborted." );
         }
         let s = gaia.sources[i];
         // Row layout: ra, dec, parx, pmra, pmdec, magG, magBP, magRP, flags, flux
         let ra = s[0], dec = s[1];
         if ( dt != 0 )
         {
            let cd = Math.cos( dec*d2r );
            if ( Math.abs( cd ) > 1e-6 && isFinite( s[3] ) && isFinite( s[4] ) )
            {
               ra += s[3]*dt/3.6e6/cd;
               dec += s[4]*dt/3.6e6;
            }
         }
         let p = celestialToImageSafe( window, ra, dec );
         if ( p == null )
            continue;
         if ( p.x < 8 || p.y < 8 || p.x > W - 8 || p.y > H - 8 )
            continue;

         // Locate the sampled spectrum in the row
         let flux = null;
         if ( s.length > 9 && (s[9] instanceof Array || (s[9] != null && typeof s[9].length === "number")) )
            flux = s[9];
         else if ( s.length > 10 )
            flux = s.slice( 9 );
         if ( flux == null || flux.length < 2 )
            continue;

         projected.push( { x: p.x, y: p.y, magG: s[5], flux: flux } );
      }
      console.writeln( format( "%d Gaia XP sources fall inside the image.", projected.length ) );
      if ( projected.length == 0 )
         throw new Error( "No Gaia XP sources project inside the image. Check the plate solution." );

      // 4. Star detection
      console.writeln( "Detecting stars (StarDetector)..." );
      let dets = detectStars( view, this.sensitivity, this.structureLayers );
      console.writeln( format( "%d stars detected.", dets.length ) );
      if ( dets.length == 0 )
         throw new Error( "StarDetector found no stars. Increase the detection sensitivity." );

      // 5. Match Gaia sources to detections (nearest within tolerance)
      let tol = this.matchTolerance;
      let cell = Math.max( 4, 2*tol );
      let grid = {};
      for ( let j = 0; j < dets.length; ++j )
      {
         let key = Math.floor( dets[j].pos.x/cell ) + "_" + Math.floor( dets[j].pos.y/cell );
         if ( grid[key] === undefined )
            grid[key] = [];
         grid[key].push( j );
      }

      let bestForDet = {}; // detection index → { gi, dist2 } keep nearest Gaia source
      let tol2 = tol*tol;
      for ( let gi = 0; gi < projected.length; ++gi )
      {
         let g = projected[gi];
         let cx = Math.floor( g.x/cell ), cy = Math.floor( g.y/cell );
         let bestJ = -1, bestD2 = tol2;
         for ( let oy = -1; oy <= 1; ++oy )
            for ( let ox = -1; ox <= 1; ++ox )
            {
               let bucket = grid[(cx + ox) + "_" + (cy + oy)];
               if ( bucket === undefined )
                  continue;
               for ( let bi = 0; bi < bucket.length; ++bi )
               {
                  let j = bucket[bi];
                  let dx = dets[j].pos.x - g.x;
                  let dy = dets[j].pos.y - g.y;
                  let d2 = dx*dx + dy*dy;
                  if ( d2 < bestD2 )
                  {
                     bestD2 = d2;
                     bestJ = j;
                  }
               }
            }
         if ( bestJ >= 0 )
         {
            let prev = bestForDet[bestJ];
            if ( prev === undefined || projected[gi].magG < projected[prev.gi].magG )
               bestForDet[bestJ] = { gi: gi, dist2: bestD2 };
         }
      }

      let candidates = [];
      for ( let j in bestForDet )
      {
         let det = dets[parseInt( j )];
         candidates.push( { det: det, gaia: projected[bestForDet[j].gi] } );
      }
      this.nMatched = candidates.length;
      console.writeln( format( "%d Gaia XP stars re-detected within %.1f px.", candidates.length, tol ) );
      if ( candidates.length == 0 )
         throw new Error( "No Gaia XP stars matched the detected stars.\n" +
            "Check the plate solution, increase the match tolerance, or increase the\n" +
            "detection sensitivity." );

      // Brightest first, cap at maxCalStars
      candidates.sort( function( a, b ) { return b.det.flux - a.det.flux; } );
      if ( candidates.length > this.maxCalStars )
         candidates.length = this.maxCalStars;

      // 6. Photometry + spectrum window integration
      console.writeln( format( "Measuring %d brightest matches — integrating spectra over " +
                               "%s (%.2f ± %.2f nm) and %s (%.2f ± %.2f nm)...",
                               candidates.length,
                               names[0], this.center1, this.bw1/2,
                               names[1], this.center2, this.bw2/2 ) );

      let norm = img.isReal ? 1.0 : 1.0/((Math.pow( 2, img.bitsPerSample )) - 1);
      let records = [];
      let nSaturated = 0, nBadPhot = 0, nBadSpec = 0;

      for ( let i = 0; i < candidates.length; ++i )
      {
         if ( (i & 31) == 0 )
         {
            processEvents();
            if ( console.abortRequested )
               throw new Error( "Aborted." );
         }
         let det = candidates[i].det;
         let g = candidates[i].gaia;

         // Aperture radius from the detected structure size
         let r = apertureRadiusForStar( det );
         if ( r < 0 )
            continue; // not a clean star

         let phot = measureStarRGB( img, det.pos.x, det.pos.y, r, norm );
         if ( phot == null )
         {
            ++nBadPhot;
            continue;
         }
         if ( phot.peak > this.saturationLimit )
         {
            ++nSaturated;
            continue;
         }

         // Normalize the spectrum to unit total flux, then integrate windows
         let total = integrateSpectrumTotal( g.flux, gaia.step );
         if ( !(total > 0) )
         {
            ++nBadSpec;
            continue;
         }
         let S1 = integrateSpectrumWindow( g.flux, gaia.wl0, gaia.step, g.flux.length,
                                           this.center1 - 0.5*this.bw1, this.center1 + 0.5*this.bw1 )/total;
         let S2 = integrateSpectrumWindow( g.flux, gaia.wl0, gaia.step, g.flux.length,
                                           this.center2 - 0.5*this.bw2, this.center2 + 0.5*this.bw2 )/total;
         if ( !(S1 > 0) || !(S2 > 0) )
         {
            ++nBadSpec;
            continue;
         }

         records.push( { S1: S1, S2: S2, R: phot.R, G: phot.G, B: phot.B,
                         x: det.pos.x, y: det.pos.y } );
      }

      console.writeln( format( "%d calibration stars ready (%d saturated, %d bad photometry, %d bad spectra).",
                               records.length, nSaturated, nBadPhot, nBadSpec ) );

      if ( records.length < 6 )
         throw new Error( format( "Only %d usable calibration stars (need at least 6).\n\n", records.length ) +
            "Suggestions:\n" +
            "  - Increase the star detection sensitivity\n" +
            "  - Increase the Gaia magnitude limit\n" +
            "  - Install additional Gaia DR3/SP database volumes (fainter stars)\n" +
            "  - Verify the plate solution is accurate (re-solve with distortion correction)" );

      // 7. Fit the mixing matrix
      console.writeln( format( "Fitting %s/%s mixing matrix from %d stars...", names[0], names[1], records.length ) );
      let fit = fitMixingMatrix( records );
      if ( fit.A == null )
         throw new Error( "Could not fit the mixing matrix: " + fit.reason );

      this.A = fit.A;
      this.records = records;
      this.nUsed = fit.nUsed;

      // 8. Auto-Q and diagnostics
      let aq = autoQPerChannel( this.A );
      this.autoQInfo = aq;
      if ( this.autoQ )
      {
         this.q1 = aq.q1;
         this.q2 = aq.q2;
      }

      this.diag = this.makeReport( fit, aq, names );
      console.writeln( "" );
      console.noteln( this.diag );

      let warn = conditionNumberWarning( this.A );
      if ( warn.severity == "severe" )
         console.criticalln( warn.text );
      else if ( warn.severity == "caution" )
         console.warningln( warn.text );

      return { fit: fit, warning: warn };
   };

   this.makeReport = function( fit, aq, names )
   {
      let A = this.A;
      function pct( row, col )
      {
         let t = A[row][0] + A[row][1];
         return (t > 0) ? 100*A[row][col]/t : 0;
      }
      let lines = [];
      lines.push( format( "Calibrated from %d Gaia XP stars (%d matched, %d clipped as outliers)",
                          fit.nUsed, this.nMatched, fit.nClipped ) );
      lines.push( format( "Channel sensitivity  (%s %%  |  %s %%):", names[0], names[1] ) );
      for ( let r = 0; r < 3; ++r )
         lines.push( format( "  %s :  %5.1f%%  %s    %5.1f%%  %s",
                             CHANNEL_NAMES[r], pct( r, 0 ), names[0], pct( r, 1 ), names[1] ) );
      lines.push( format( "Mixing matrix A: [%.4g %.4g; %.4g %.4g; %.4g %.4g]",
                          A[0][0], A[0][1], A[1][0], A[1][1], A[2][0], A[2][1] ) );
      lines.push( format( "Condition number: %.2f   sv ratio: %.3f   G/B similarity: %.3f",
                          aq.k, aq.svRatio, aq.similarity ) );
      lines.push( format( "Auto Q1 = %.2f (%s)   Q2 = %.2f (%s)",
                          aq.q1, CHANNEL_NAMES[aq.ch[0]], aq.q2, CHANNEL_NAMES[aq.ch[1]] ) );
      let warn = conditionNumberWarning( A );
      if ( warn.text != null )
         lines.push( ((warn.severity == "severe") ? "(!) " : "/!\\ ") + warn.text );
      else
         lines.push( "Matrix looks well-conditioned — channels separate cleanly." );
      return lines.join( "\n" );
   };

   // Median of a single channel of the target view (normalized units)
   this.channelMedian = function( channel )
   {
      let tmpId = uniqueViewId( "nbx_tmp_med" );
      let w = pixelMathNewImage( this.targetView, format( "$T[%d]", channel ), tmpId, false );
      let m;
      try
      {
         m = w.mainView.image.median();
      }
      finally
      {
         w.forceClose();
      }
      return m;
   };

   /*
    * SetiAstro-style statistical (MTF) stretch matching the image median to
    * targetMedian, without black clipping. In-place.
    */
   this.mtfMatchMedian = function( window, targetMedian )
   {
      if ( !(targetMedian > 1e-6) )
         return;
      let img = window.mainView.image;
      let bp = img.minimum();
      let denom = 1 - bp;
      if ( !(denom > 1e-12) )
         return;
      let med = (img.median() - bp)/denom;
      if ( !(med > 0) || med >= 1 )
         return;
      let m = Math.mtf( targetMedian, med );
      pixelMathInPlace( window.mainView,
         format( "mtf(%.10f, min(1, max(0, $T - %.10f)/%.10f))", m, bp, denom ) );
   };

   // ── Step 3: per-pixel extraction ─────────────────────────────────────────
   this.extract = function()
   {
      if ( this.A == null )
         throw new Error( "Please calibrate the mixing matrix first." );
      this.validateTarget();

      let view = this.targetView;
      let window = view.window;
      let names = this.effectiveLineNames();

      console.show();
      console.noteln( "<end><cbr><br>* " + TITLE + " — extracting " + names[0] + " and " + names[1] +
                      " from '" + view.id + "'" );

      let P = pseudoInverse32( this.A );
      let ch = dominantChannelsFromMatrix( this.A );
      let q1 = clamp( this.q1, 0, 1 ), q2 = clamp( this.q2, 0, 1 );

      console.writeln( format( "Per-pixel unmixing weights (pseudo-inverse rows):" ) );
      console.writeln( format( "  %-6s = %+.4g*R %+.4g*G %+.4g*B", names[0], P[0][0], P[0][1], P[0][2] ) );
      console.writeln( format( "  %-6s = %+.4g*R %+.4g*G %+.4g*B", names[1], P[1][0], P[1][1], P[1][2] ) );
      console.writeln( format( "Blend: %s = %.2f*NNLS + %.2f*prior   |   %s = %.2f*NNLS + %.2f*prior",
                               names[0], q1, 1 - q1, names[1], q2, 1 - q2 ) );

      let refs = [ "$T[0]", "$T[1]", "$T[2]" ];
      let temp = [];
      try
      {
         // NNLS (pseudo-inverse) solutions, clipped to >= 0
         let nnls1 = pixelMathNewImage( view,
            "max(0, " + linearCombination3( P[0], refs ) + ")",
            uniqueViewId( "nbx_tmp_nnls1" ), false );
         temp.push( nnls1 );
         let nnls2w = pixelMathNewImage( view,
            "max(0, " + linearCombination3( P[1], refs ) + ")",
            uniqueViewId( "nbx_tmp_nnls2" ), false );
         temp.push( nnls2w );

         // Raw channel priors (dominant channel, or mean of two near-tied)
         let priorExpr = function( info )
         {
            if ( info.chans.length == 2 )
               return format( "0.5*($T[%d] + $T[%d])", info.chans[0], info.chans[1] );
            return format( "$T[%d]", info.chans[0] );
         };
         let pr1info = rawPriorChannels( this.A, 0 );
         let pr2info = rawPriorChannels( this.A, 1 );
         let prior1 = pixelMathNewImage( view, priorExpr( pr1info ), uniqueViewId( "nbx_tmp_prior1" ), false );
         temp.push( prior1 );
         let prior2 = pixelMathNewImage( view, priorExpr( pr2info ), uniqueViewId( "nbx_tmp_prior2" ), false );
         temp.push( prior2 );

         console.writeln( format( "%s prior: %s   |   %s prior: %s",
            names[0], pr1info.chans.map( function( c ) { return CHANNEL_NAMES[c]; } ).join( "+" ),
            names[1], pr2info.chans.map( function( c ) { return CHANNEL_NAMES[c]; } ).join( "+" ) ) );

         // Bring NNLS outputs and priors to the source intensity level BEFORE
         // blending, so Q operates on a consistent scale.
         if ( this.medianMatch )
         {
            let t1 = this.channelMedian( ch[0] );
            let t2 = this.channelMedian( ch[1] );
            console.writeln( format( "Median match targets: %s -> %.6f (%s), %s -> %.6f (%s)",
                                     names[0], t1, CHANNEL_NAMES[ch[0]],
                                     names[1], t2, CHANNEL_NAMES[ch[1]] ) );
            this.mtfMatchMedian( nnls1, t1 );
            this.mtfMatchMedian( prior1, t1 );
            this.mtfMatchMedian( nnls2w, t2 );
            this.mtfMatchMedian( prior2, t2 );
         }

         // Q-blend and finalize
         let out1 = this.blendAndFinalize( nnls1, prior1, q1, names[0], 0 );
         let out2 = this.blendAndFinalize( nnls2w, prior2, q2, names[1], 1 );

         console.noteln( format( "Extraction complete — '%s' and '%s' created from %d stars " +
                                 "(Q1 = %.2f, Q2 = %.2f).",
                                 out1.mainView.id, out2.mainView.id, this.nUsed, q1, q2 ) );
         console.writeln( "Tip: dark halos / over-subtraction -> reduce Q; residual bleed -> increase Q." );

         return [ out1, out2 ];
      }
      finally
      {
         for ( let i = 0; i < temp.length; ++i )
            try
            {
               temp[i].forceClose();
            }
            catch ( e )
            {
            }
      }
   };

   this.blendAndFinalize = function( nnlsWin, priorWin, q, lineName, lineIndex )
   {
      let view = this.targetView;
      let outId = uniqueViewId( lineName + "_NBX" );

      let expr = format( "%.8f*%s + %.8f*%s", q, nnlsWin.mainView.id, 1 - q, priorWin.mainView.id );
      let out = pixelMathNewImage( nnlsWin.mainView, expr, outId, true );

      // Rescale to [0,1] only if the blend exceeded unity
      let mx = out.mainView.image.maximum();
      if ( mx > 1 )
         pixelMathInPlace( out.mainView, format( "$T/%.10f", mx ) );

      // Inherit the astrometric solution (same pixel grid)
      try
      {
         out.copyAstrometricSolution( view.window );
      }
      catch ( e )
      {
      }

      // FITS keywords: copy source keywords, append extraction metadata
      try
      {
         let kws = [];
         let src = view.window.keywords;
         for ( let i = 0; i < src.length; ++i )
            kws.push( new FITSKeyword( src[i].name, src[i].value, src[i].comment ) );
         let A = this.A;
         let center = (lineIndex == 0) ? this.center1 : this.center2;
         let bw = (lineIndex == 0) ? this.bw1 : this.bw2;
         kws.push( new FITSKeyword( "HISTORY", "", TITLE + " " + VERSION +
                   " empirically calibrated dual-band extraction" ) );
         kws.push( new FITSKeyword( "NBXLINE", "'" + lineName + "'", "Extracted emission line" ) );
         kws.push( new FITSKeyword( "NBXCNTR", format( "%.2f", center ), "Line center [nm]" ) );
         kws.push( new FITSKeyword( "NBXBW", format( "%.2f", bw ), "Passband FWHM [nm]" ) );
         kws.push( new FITSKeyword( "NBXNSTAR", format( "%d", this.nUsed ), "Calibration stars used" ) );
         kws.push( new FITSKeyword( "NBXCOND", format( "%.3f", conditionNumber32( A ) ), "Mixing matrix condition number" ) );
         kws.push( new FITSKeyword( "NBXQ", format( "%.3f", q ), "NNLS/raw blend strength" ) );
         for ( let r = 0; r < 3; ++r )
            kws.push( new FITSKeyword( "NBXMTX" + r,
                      "'" + format( "%.6e %.6e", A[r][0], A[r][1] ) + "'",
                      "Mixing matrix row " + CHANNEL_NAMES[r] ) );
         out.keywords = kws;
      }
      catch ( e )
      {
      }

      out.show();
      return out;
   };
}

// ─────────────────────────────────────────────────────────────────────────────
// Settings persistence
// ─────────────────────────────────────────────────────────────────────────────

var SETTINGS_PREFIX = "NBExtractPI/";

function loadSettings( engine )
{
   function rd( key, type, def )
   {
      let v = Settings.read( SETTINGS_PREFIX + key, type );
      return Settings.lastReadOK ? v : def;
   }
   engine.presetIndex     = rd( "presetIndex", DataType_Int32, engine.presetIndex );
   engine.line1Name       = rd( "line1Name", DataType_String, engine.line1Name );
   engine.line2Name       = rd( "line2Name", DataType_String, engine.line2Name );
   engine.center1         = rd( "center1", DataType_Double, engine.center1 );
   engine.center2         = rd( "center2", DataType_Double, engine.center2 );
   engine.bw1             = rd( "bw1", DataType_Double, engine.bw1 );
   engine.bw2             = rd( "bw2", DataType_Double, engine.bw2 );
   engine.maxCalStars     = rd( "maxCalStars", DataType_Int32, engine.maxCalStars );
   engine.matchTolerance  = rd( "matchTolerance", DataType_Double, engine.matchTolerance );
   engine.magLimit        = rd( "magLimit", DataType_Double, engine.magLimit );
   engine.sensitivity     = rd( "sensitivity", DataType_Double, engine.sensitivity );
   engine.saturationLimit = rd( "saturationLimit", DataType_Double, engine.saturationLimit );
   engine.medianMatch     = rd( "medianMatch", DataType_Boolean, engine.medianMatch );
   engine.autoQ           = rd( "autoQ", DataType_Boolean, engine.autoQ );
   engine.presetIndex = clamp( engine.presetIndex, 0, FILTER_PRESETS.length - 1 );
}

function saveSettings( engine )
{
   Settings.write( SETTINGS_PREFIX + "presetIndex", DataType_Int32, engine.presetIndex );
   Settings.write( SETTINGS_PREFIX + "line1Name", DataType_String, engine.line1Name );
   Settings.write( SETTINGS_PREFIX + "line2Name", DataType_String, engine.line2Name );
   Settings.write( SETTINGS_PREFIX + "center1", DataType_Double, engine.center1 );
   Settings.write( SETTINGS_PREFIX + "center2", DataType_Double, engine.center2 );
   Settings.write( SETTINGS_PREFIX + "bw1", DataType_Double, engine.bw1 );
   Settings.write( SETTINGS_PREFIX + "bw2", DataType_Double, engine.bw2 );
   Settings.write( SETTINGS_PREFIX + "maxCalStars", DataType_Int32, engine.maxCalStars );
   Settings.write( SETTINGS_PREFIX + "matchTolerance", DataType_Double, engine.matchTolerance );
   Settings.write( SETTINGS_PREFIX + "magLimit", DataType_Double, engine.magLimit );
   Settings.write( SETTINGS_PREFIX + "sensitivity", DataType_Double, engine.sensitivity );
   Settings.write( SETTINGS_PREFIX + "saturationLimit", DataType_Double, engine.saturationLimit );
   Settings.write( SETTINGS_PREFIX + "medianMatch", DataType_Boolean, engine.medianMatch );
   Settings.write( SETTINGS_PREFIX + "autoQ", DataType_Boolean, engine.autoQ );
}

// ─────────────────────────────────────────────────────────────────────────────
// Dialog
// ─────────────────────────────────────────────────────────────────────────────

function NBXDialog( engine )
{
   this.__base__ = Dialog;
   this.__base__();

   let self = this;
   this.engine = engine;

   this.windowTitle = TITLE + " v" + VERSION;
   this.userResizable = true;

   let labelWidth = this.font.width( "Detection sensitivity:" ) + 8;

   // ── Header ───────────────────────────────────────────────────────────────
   this.helpLabel = new Label( this );
   this.helpLabel.frameStyle = FrameStyle_Box;
   this.helpLabel.margin = 6;
   this.helpLabel.wordWrapping = true;
   this.helpLabel.useRichText = true;
   this.helpLabel.text =
      "<p><b>" + TITLE + " v" + VERSION + "</b> — Empirically calibrated dual-band " +
      "narrowband channel extraction (Ha/OIII, SII/OIII, SII/Hb).</p>" +
      "<p>The line mixing matrix is fitted from stars in your <b>plate-solved, linear</b> " +
      "RGB image using their Gaia DR3 BP/RP spectra (local Gaia DR3/SP database, as used " +
      "by SPCC). Process concept: NBExtract, Seti Astro Suite Pro (Franklin Marek).</p>";

   // ── Target view ──────────────────────────────────────────────────────────
   this.viewLabel = new Label( this );
   this.viewLabel.text = "Target image:";
   this.viewLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.viewLabel.minWidth = labelWidth;

   this.viewList = new ViewList( this );
   this.viewList.getMainViews();
   this.viewList.toolTip = "<p>Plate-solved linear RGB image taken through a dual-band filter.</p>";
   this.viewList.onViewSelected = function( view )
   {
      self.engine.targetView = view;
      self.invalidate();
   };
   if ( !ImageWindow.activeWindow.isNull )
   {
      let v = ImageWindow.activeWindow.mainView;
      if ( !v.isNull && v.image.isColor )
      {
         this.viewList.currentView = v;
         this.engine.targetView = v;
      }
   }

   this.viewSizer = new HorizontalSizer;
   this.viewSizer.spacing = 4;
   this.viewSizer.add( this.viewLabel );
   this.viewSizer.add( this.viewList, 100 );

   // ── Filter configuration group ───────────────────────────────────────────
   this.presetLabel = new Label( this );
   this.presetLabel.text = "Filter type:";
   this.presetLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.presetLabel.minWidth = labelWidth;

   this.presetCombo = new ComboBox( this );
   for ( let i = 0; i < FILTER_PRESETS.length; ++i )
      this.presetCombo.addItem( FILTER_PRESETS[i].name );
   this.presetCombo.currentItem = engine.presetIndex;
   this.presetCombo.toolTip =
      "<p>Dual-band filter line pair. 'Custom' allows arbitrary line names and centers " +
      "(e.g. NII, HeI).</p>" +
      "<p><b>Note:</b> tri-band filters (Ha+OIII+SII) cannot be separated into three " +
      "channels from RGB data — only two lines are recoverable.</p>";
   this.presetCombo.onItemSelected = function( index )
   {
      self.engine.presetIndex = index;
      self.applyPreset( true/*resetValues*/ );
      self.invalidate();
   };

   this.presetSizer = new HorizontalSizer;
   this.presetSizer.spacing = 4;
   this.presetSizer.add( this.presetLabel );
   this.presetSizer.add( this.presetCombo );
   this.presetSizer.addStretch();

   // Line 1 row
   this.line1NameEdit = new Edit( this );
   this.line1NameEdit.text = engine.line1Name;
   this.line1NameEdit.setFixedWidth( this.font.width( "MMMMMM" ) );
   this.line1NameEdit.toolTip = "<p>Short label for line 1 (used in output image names).</p>";
   this.line1NameEdit.onTextUpdated = function( text )
   {
      self.engine.line1Name = text;
      self.invalidate();
   };

   this.center1Edit = new NumericEdit( this );
   this.center1Edit.label.text = "Center (nm):";
   this.center1Edit.setRange( 380, 1000 );
   this.center1Edit.setPrecision( 2 );
   this.center1Edit.setValue( engine.center1 );
   this.center1Edit.toolTip = "<p>Emission line center wavelength in nm.</p>";
   this.center1Edit.onValueUpdated = function( value )
   {
      self.engine.center1 = value;
      self.invalidate();
   };

   this.bw1Edit = new NumericEdit( this );
   this.bw1Edit.label.text = "Bandwidth (nm):";
   this.bw1Edit.setRange( 1, 30 );
   this.bw1Edit.setPrecision( 1 );
   this.bw1Edit.setValue( engine.bw1 );
   this.bw1Edit.toolTip = "<p>Filter passband FWHM at this line, in nm (e.g. 7 for a 7 nm dual-band filter).</p>";
   this.bw1Edit.onValueUpdated = function( value )
   {
      self.engine.bw1 = value;
      self.invalidate();
   };

   this.line1Sizer = new HorizontalSizer;
   this.line1Sizer.spacing = 6;
   this.line1Sizer.add( this.line1NameEdit );
   this.line1Sizer.add( this.center1Edit );
   this.line1Sizer.add( this.bw1Edit );
   this.line1Sizer.addStretch();

   // Line 2 row
   this.line2NameEdit = new Edit( this );
   this.line2NameEdit.text = engine.line2Name;
   this.line2NameEdit.setFixedWidth( this.font.width( "MMMMMM" ) );
   this.line2NameEdit.toolTip = "<p>Short label for line 2 (used in output image names).</p>";
   this.line2NameEdit.onTextUpdated = function( text )
   {
      self.engine.line2Name = text;
      self.invalidate();
   };

   this.center2Edit = new NumericEdit( this );
   this.center2Edit.label.text = "Center (nm):";
   this.center2Edit.setRange( 380, 1000 );
   this.center2Edit.setPrecision( 2 );
   this.center2Edit.setValue( engine.center2 );
   this.center2Edit.onValueUpdated = function( value )
   {
      self.engine.center2 = value;
      self.invalidate();
   };

   this.bw2Edit = new NumericEdit( this );
   this.bw2Edit.label.text = "Bandwidth (nm):";
   this.bw2Edit.setRange( 1, 30 );
   this.bw2Edit.setPrecision( 1 );
   this.bw2Edit.setValue( engine.bw2 );
   this.bw2Edit.onValueUpdated = function( value )
   {
      self.engine.bw2 = value;
      self.invalidate();
   };

   this.line2Sizer = new HorizontalSizer;
   this.line2Sizer.spacing = 6;
   this.line2Sizer.add( this.line2NameEdit );
   this.line2Sizer.add( this.center2Edit );
   this.line2Sizer.add( this.bw2Edit );
   this.line2Sizer.addStretch();

   this.filterGroup = new GroupBox( this );
   this.filterGroup.title = "Dual-Band Filter";
   this.filterGroup.sizer = new VerticalSizer;
   this.filterGroup.sizer.margin = 6;
   this.filterGroup.sizer.spacing = 4;
   this.filterGroup.sizer.add( this.presetSizer );
   this.filterGroup.sizer.add( this.line1Sizer );
   this.filterGroup.sizer.add( this.line2Sizer );

   // ── Calibration group ────────────────────────────────────────────────────
   this.maxStarsLabel = new Label( this );
   this.maxStarsLabel.text = "Max calibration stars:";
   this.maxStarsLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.maxStarsLabel.minWidth = labelWidth;

   this.maxStarsSpin = new SpinBox( this );
   this.maxStarsSpin.minValue = 6;
   this.maxStarsSpin.maxValue = 2000;
   this.maxStarsSpin.value = engine.maxCalStars;
   this.maxStarsSpin.toolTip =
      "<p>Maximum number of Gaia XP stars used to fit the mixing matrix. The brightest " +
      "N re-detected stars are selected. 300 is more than sufficient — increase only " +
      "for very sparse fields.</p>";
   this.maxStarsSpin.onValueUpdated = function( value )
   {
      self.engine.maxCalStars = value;
      self.invalidate();
   };

   this.magLimitEdit = new NumericEdit( this );
   this.magLimitEdit.label.text = "Mag limit (G):";
   this.magLimitEdit.setRange( 8, 20 );
   this.magLimitEdit.setPrecision( 1 );
   this.magLimitEdit.setValue( engine.magLimit );
   this.magLimitEdit.toolTip =
      "<p>Faint limit for the Gaia DR3/SP catalog search. The XP spectrum database " +
      "reaches G ≈ 17.6 if all volumes are installed.</p>";
   this.magLimitEdit.onValueUpdated = function( value )
   {
      self.engine.magLimit = value;
      self.invalidate();
   };

   this.maxStarsSizer = new HorizontalSizer;
   this.maxStarsSizer.spacing = 6;
   this.maxStarsSizer.add( this.maxStarsLabel );
   this.maxStarsSizer.add( this.maxStarsSpin );
   this.maxStarsSizer.addSpacing( 16 );
   this.maxStarsSizer.add( this.magLimitEdit );
   this.maxStarsSizer.addStretch();

   this.sensControl = new NumericControl( this );
   this.sensControl.label.text = "Detection sensitivity:";
   this.sensControl.label.minWidth = labelWidth;
   this.sensControl.setRange( 0, 1 );
   this.sensControl.slider.setRange( 0, 100 );
   this.sensControl.setPrecision( 2 );
   this.sensControl.setValue( engine.sensitivity );
   this.sensControl.toolTip =
      "<p>StarDetector sensitivity (0.5 default). Increase to detect more/fainter " +
      "stars if too few calibration stars are found.</p>";
   this.sensControl.onValueUpdated = function( value )
   {
      self.engine.sensitivity = value;
      self.invalidate();
   };

   this.tolEdit = new NumericEdit( this );
   this.tolEdit.label.text = "Match tolerance (px):";
   this.tolEdit.setRange( 1, 10 );
   this.tolEdit.setPrecision( 1 );
   this.tolEdit.setValue( engine.matchTolerance );
   this.tolEdit.toolTip =
      "<p>Maximum distance between a detected star and its predicted Gaia position.</p>";
   this.tolEdit.onValueUpdated = function( value )
   {
      self.engine.matchTolerance = value;
      self.invalidate();
   };

   this.satEdit = new NumericEdit( this );
   this.satEdit.label.text = "Saturation limit:";
   this.satEdit.setRange( 0.5, 1.0 );
   this.satEdit.setPrecision( 2 );
   this.satEdit.setValue( engine.saturationLimit );
   this.satEdit.toolTip =
      "<p>Stars whose peak sample exceeds this normalized level are rejected from " +
      "calibration (clipped photometry would bias the matrix).</p>";
   this.satEdit.onValueUpdated = function( value )
   {
      self.engine.saturationLimit = value;
      self.invalidate();
   };

   this.tolSizer = new HorizontalSizer;
   this.tolSizer.spacing = 6;
   this.tolSizer.add( this.tolEdit );
   this.tolSizer.addSpacing( 16 );
   this.tolSizer.add( this.satEdit );
   this.tolSizer.addStretch();

   this.calibGroup = new GroupBox( this );
   this.calibGroup.title = "Calibration";
   this.calibGroup.sizer = new VerticalSizer;
   this.calibGroup.sizer.margin = 6;
   this.calibGroup.sizer.spacing = 4;
   this.calibGroup.sizer.add( this.maxStarsSizer );
   this.calibGroup.sizer.add( this.sensControl );
   this.calibGroup.sizer.add( this.tolSizer );

   // ── Extraction group ─────────────────────────────────────────────────────
   this.medianMatchCheck = new CheckBox( this );
   this.medianMatchCheck.text = "Match output median to source (statistical stretch)";
   this.medianMatchCheck.checked = engine.medianMatch;
   this.medianMatchCheck.toolTip =
      "<p>Applies an MTF-based statistical stretch to each extracted channel so its " +
      "median matches the corresponding source channel median (NBExtract behavior). " +
      "The output then sits at the same intensity level as the input.</p>" +
      "<p><b>Note:</b> this is a mild non-linear operation. Disable it if you require " +
      "strictly linear pseudo-flux outputs.</p>";
   this.medianMatchCheck.onCheck = function( checked )
   {
      self.engine.medianMatch = checked;
   };

   this.autoQCheck = new CheckBox( this );
   this.autoQCheck.text = "Automatic Q (from matrix conditioning)";
   this.autoQCheck.checked = engine.autoQ;
   this.autoQCheck.toolTip =
      "<p>Q blends the full matrix inversion (1.0) with the raw dominant channel (0.0). " +
      "When automatic, Q is derived from the condition number and channel degeneracy " +
      "of the fitted matrix — poor separation gets a conservative Q.</p>" +
      "<p>Uncheck to set Q1/Q2 manually: reduce Q if you see dark halos or " +
      "over-subtraction; increase it if line bleed remains.</p>";
   this.autoQCheck.onCheck = function( checked )
   {
      self.engine.autoQ = checked;
      self.q1Control.enabled = !checked;
      self.q2Control.enabled = !checked;
      if ( checked && self.engine.autoQInfo != null )
      {
         self.engine.q1 = self.engine.autoQInfo.q1;
         self.engine.q2 = self.engine.autoQInfo.q2;
         self.q1Control.setValue( self.engine.q1 );
         self.q2Control.setValue( self.engine.q2 );
      }
   };

   this.q1Control = new NumericControl( this );
   this.q1Control.label.text = "Q1 (line 1):";
   this.q1Control.label.minWidth = labelWidth;
   this.q1Control.setRange( 0, 1 );
   this.q1Control.slider.setRange( 0, 100 );
   this.q1Control.setPrecision( 2 );
   this.q1Control.setValue( engine.q1 );
   this.q1Control.enabled = !engine.autoQ;
   this.q1Control.onValueUpdated = function( value )
   {
      self.engine.q1 = value;
   };

   this.q2Control = new NumericControl( this );
   this.q2Control.label.text = "Q2 (line 2):";
   this.q2Control.label.minWidth = labelWidth;
   this.q2Control.setRange( 0, 1 );
   this.q2Control.slider.setRange( 0, 100 );
   this.q2Control.setPrecision( 2 );
   this.q2Control.setValue( engine.q2 );
   this.q2Control.enabled = !engine.autoQ;
   this.q2Control.onValueUpdated = function( value )
   {
      self.engine.q2 = value;
   };

   this.extractGroup = new GroupBox( this );
   this.extractGroup.title = "Extraction";
   this.extractGroup.sizer = new VerticalSizer;
   this.extractGroup.sizer.margin = 6;
   this.extractGroup.sizer.spacing = 4;
   this.extractGroup.sizer.add( this.medianMatchCheck );
   this.extractGroup.sizer.add( this.autoQCheck );
   this.extractGroup.sizer.add( this.q1Control );
   this.extractGroup.sizer.add( this.q2Control );

   // ── Action buttons ───────────────────────────────────────────────────────
   this.calibrateButton = new PushButton( this );
   this.calibrateButton.text = "1 · Calibrate Mixing Matrix";
   this.calibrateButton.toolTip =
      "<p>Fetch Gaia XP stars, measure their R/G/B fluxes in the image and fit the " +
      "3x2 line mixing matrix.</p>";
   this.calibrateButton.onClick = function()
   {
      self.runGuarded( function()
      {
         self.engine.calibrate();
         self.diagBox.text = self.engine.diag;
         if ( self.engine.autoQ && self.engine.autoQInfo != null )
         {
            self.q1Control.setValue( self.engine.q1 );
            self.q2Control.setValue( self.engine.q2 );
         }
         self.extractButton.enabled = true;
      } );
   };

   this.extractButton = new PushButton( this );
   this.extractButton.text = "2 · Extract Channels";
   this.extractButton.enabled = false;
   this.extractButton.toolTip =
      "<p>Invert the calibrated mixing matrix per pixel and create the two " +
      "emission-line images.</p>";
   this.extractButton.onClick = function()
   {
      self.runGuarded( function()
      {
         self.engine.extract();
      } );
   };

   this.buttonSizer = new HorizontalSizer;
   this.buttonSizer.spacing = 8;
   this.buttonSizer.add( this.calibrateButton, 50 );
   this.buttonSizer.add( this.extractButton, 50 );

   // ── Diagnostics ──────────────────────────────────────────────────────────
   this.diagBox = new TextBox( this );
   this.diagBox.readOnly = true;
   this.diagBox.styleSheet = this.scaledStyleSheet(
      "QWidget { font-family: DejaVu Sans Mono, Consolas, monospace; font-size: 8pt; }" );
   this.diagBox.setMinHeight( this.font.height*10 );
   this.diagBox.text = "Mixing matrix: (not yet calibrated)\n\n" +
      "Workflow:\n" +
      "  1. Plate-solve the linear dual-band RGB image (ImageSolver / SPCC).\n" +
      "  2. Select it above, choose the filter type, click 'Calibrate'.\n" +
      "  3. Review the diagnostics, then click 'Extract'.";

   // ── Bottom row ───────────────────────────────────────────────────────────
   // Dialog.browseScriptDocumentation(id) only recognizes scripts that either
   // ship bundled with PixInsight core, or were installed through its own
   // repository/updater system (registered in etc/update/installed.xri) —
   // confirmed empirically on a real installation: it returns false for a
   // manually copied script + doc pair even when the id, the doc folder name,
   // the doc file name, and the #feature-id token all match exactly and the
   // file is genuinely present on disk. A plain manual "copy the folder in"
   // installation (as used here) will never satisfy it. So we try it first
   // in case that ever changes, then fall back to Dialog.openBrowser(url),
   // which opens an arbitrary URL with no such restriction, pointed at the
   // doc file resolved relative to CoreApplication.binDirPath (the running
   // PixInsight instance's own install directory, not a hardcoded path).
   this.docButton = new ToolButton( this );
   this.docButton.icon = this.scaledResource( ":/process-interface/browse-documentation.png" );
   this.docButton.setScaledFixedSize( 24, 24 );
   this.docButton.toolTip = "<p>Open the NBExtractPI documentation in the PixInsight " +
      "documentation browser.</p>";
   this.docButton.onClick = function()
   {
      if ( Dialog.browseScriptDocumentation( "NBExtractPI" ) )
         return;

      let rootDir = CoreApplication.binDirPath.replace( /[\/\\]bin[\/\\]?$/, "" );
      let docPath = rootDir + "/doc/scripts/NBExtractPI/NBExtractPI.html";

      if ( File.exists( docPath ) )
      {
         let url = "file:///" + docPath.replace( /\\/g, "/" );
         Dialog.openBrowser( url, "NBExtractPI Documentation" );
         return;
      }

      (new MessageBox(
         "<p>The NBExtractPI documentation has not been installed.</p>" +
         "<p>Copy the folder <b>doc/scripts/NBExtractPI</b> included with " +
         "this repository into your PixInsight installation's <b>doc/scripts/</b> " +
         "directory, then try again. See the README for details.</p>",
         TITLE, StdIcon_Information, StdButton_Ok )).execute();
   };

   this.versionLabel = new Label( this );
   this.versionLabel.text = "Lighthouse Suite  ·  Process concept: NBExtract / Seti Astro";
   this.versionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.closeButton = new PushButton( this );
   this.closeButton.text = "Close";
   this.closeButton.onClick = function()
   {
      self.ok();
   };

   this.bottomSizer = new HorizontalSizer;
   this.bottomSizer.spacing = 6;
   this.bottomSizer.add( this.docButton );
   this.bottomSizer.addSpacing( 8 );
   this.bottomSizer.add( this.versionLabel );
   this.bottomSizer.addStretch();
   this.bottomSizer.add( this.closeButton );

   // ── Layout ───────────────────────────────────────────────────────────────
   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 6;
   this.sizer.add( this.helpLabel );
   this.sizer.add( this.viewSizer );
   this.sizer.add( this.filterGroup );
   this.sizer.add( this.calibGroup );
   this.sizer.add( this.extractGroup );
   this.sizer.add( this.buttonSizer );
   this.sizer.add( this.diagBox, 100 );
   this.sizer.add( this.bottomSizer );

   this.adjustToContents();
   this.setMinWidth( 520 );

   // ── Behaviors ────────────────────────────────────────────────────────────
   /*
    * resetValues = true  → the user picked a preset: snap centers/bandwidths
    *                       to the preset defaults.
    * resetValues = false → dialog startup: keep the persisted values, only
    *                       synchronize labels and enabled states.
    */
   this.applyPreset = function( resetValues )
   {
      let idx = this.engine.presetIndex;
      let isCustom = (idx == PRESET_CUSTOM_INDEX);
      let p = FILTER_PRESETS[idx];

      this.line1NameEdit.enabled = isCustom;
      this.line2NameEdit.enabled = isCustom;

      if ( !isCustom )
      {
         this.engine.line1Name = p.l1;
         this.engine.line2Name = p.l2;
         this.line1NameEdit.text = p.l1;
         this.line2NameEdit.text = p.l2;
         if ( resetValues )
         {
            this.engine.center1 = LINE_CENTERS_NM[p.l1];
            this.engine.center2 = LINE_CENTERS_NM[p.l2];
            this.engine.bw1 = DEFAULT_BW_NM[p.l1];
            this.engine.bw2 = DEFAULT_BW_NM[p.l2];
            this.center1Edit.setValue( this.engine.center1 );
            this.center2Edit.setValue( this.engine.center2 );
            this.bw1Edit.setValue( this.engine.bw1 );
            this.bw2Edit.setValue( this.engine.bw2 );
         }
      }
   };

   this.invalidate = function()
   {
      this.engine.invalidateCalibration();
      this.extractButton.enabled = false;
   };

   this.runGuarded = function( fn )
   {
      this.enabled = false;
      try
      {
         fn();
      }
      catch ( e )
      {
         let msg = (e instanceof Error) ? e.message : e.toString();
         console.criticalln( "<end><cbr>*** " + TITLE + ": " + msg );
         (new MessageBox( msg, TITLE, StdIcon_Error, StdButton_Ok )).execute();
      }
      finally
      {
         this.enabled = true;
      }
   };

   this.applyPreset( false/*resetValues*/ );
}

NBXDialog.prototype = new Dialog;

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────

function main()
{
   console.hide();

   let engine = new NBXEngine();
   loadSettings( engine );

   let dialog = new NBXDialog( engine );
   dialog.execute();

   saveSettings( engine );
}

main();
