#engine v8

#feature-id ContinuumSubtractionUtility : SetiAstro > ContinuumSubtraction Utility
#feature-icon  continuumsubtraction.svg
#feature-info This script is designed for the automated continuum subtraction in astrophotography images. It includes functionalities for gradient descent optimization, color calibration, background neutralization, and non-linear stretching.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 * Continuum Subtraction Script
 * Version: 1.3.6
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "Continuum Subtraction Utility"
#define VERSION "1.3.5"

#ifeq __PI_PLATFORM__ MACOSX
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.3.mlpackage"
#endif
#ifeq __PI_PLATFORM__ MSWINDOWS
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.3.pb"
#endif
#ifeq __PI_PLATFORM__ LINUX
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.3.pb"
#endif

// ============================================================================
// Global parameters
// ============================================================================

var ContinuumSubtractionParameters = {
    targetView:           undefined,
    applyNoiseReduction:  false,
    noiseReductionMethod: "NoiseXterminator",
    starrySelected:       true,
    outputLinearImageOnly: false,
    aiModel:              "2.0.0",

    save: function()
    {
        Parameters.set( "targetView",            this.targetView ? this.targetView.id : "" );
        Parameters.set( "applyNoiseReduction",   this.applyNoiseReduction );
        Parameters.set( "noiseReductionMethod",  this.noiseReductionMethod );
        Parameters.set( "starrySelected",        this.starrySelected );
        Parameters.set( "outputLinearImageOnly", this.outputLinearImageOnly );
        Parameters.set( "aiModel",               this.aiModel );
    },

    load: function()
    {
        if ( Parameters.has( "targetView" ) )
        {
            let win = ImageWindow.windowById( Parameters.getString( "targetView" ) );
            if ( win && !win.isNull ) this.targetView = win.mainView;
        }
        if ( Parameters.has( "applyNoiseReduction" ) )   this.applyNoiseReduction   = Parameters.getBoolean( "applyNoiseReduction" );
        if ( Parameters.has( "noiseReductionMethod" ) )  this.noiseReductionMethod  = Parameters.getString( "noiseReductionMethod" );
        if ( Parameters.has( "starrySelected" ) )        this.starrySelected        = Parameters.getBoolean( "starrySelected" );
        if ( Parameters.has( "outputLinearImageOnly" ) ) this.outputLinearImageOnly = Parameters.getBoolean( "outputLinearImageOnly" );
        if ( Parameters.has( "aiModel" ) )               this.aiModel               = Parameters.getString( "aiModel" );
    }
};

ContinuumSubtractionParameters.load();

let qualityMultiplier = 1.0;
let targetMedian      = 0.25;
let createdWindows    = [];

// ============================================================================
// Utility helpers
// ============================================================================

function getAllImageIDs()
{
    let ids = [], windows = ImageWindow.windows;
    for ( let i = 0; i < windows.length; ++i ) ids.push( windows[i].mainView.id );
    return ids;
}

function findUniqueImageID( baseID )
{
    let ids = getAllImageIDs(), uniqueID = baseID, count = 1;
    while ( ids.indexOf( uniqueID ) !== -1 )
    {
        uniqueID = baseID + "_" + ("00" + count).slice(-2);
        count++;
    }
    return uniqueID;
}

function checkImageIsGreyscale( imageId )
{
    let win = ImageWindow.windowById( imageId );
    return win && !win.mainView.image.isColor;
}

// ============================================================================
// Image processing functions
// ============================================================================

function convertToGrayscale( imageWindow )
{
    let P = new ConvertToGrayscale;
    P.executeOn( imageWindow.mainView );
}

function applyNonLinearStretch( imageWindow )
{
    console.writeln( "Applying non-linear stretch to image: ", imageWindow.mainView.id );
    let P = new PixelMath;
    P.expression =
        "L=log((Med($T)*" + targetMedian + "-(" + targetMedian + "))/(Med($T)*(" + targetMedian + "-1)))/log(3);\n" +
        "S=(3^L*$T)/((3^L-1)*$T+1);";
    P.useSingleExpression = true; P.symbols = "L, S";
    P.clearImageCacheAndExit = false; P.cacheGeneratedImages = false;
    P.generateOutput = true; P.singleThreaded = false; P.optimization = true;
    P.use64BitWorkingImage = true; P.rescale = false;
    P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
    P.createNewImage = false; P.showNewImage = true;
    P.executeOn( imageWindow.mainView );
}

function calculate_window_size( image_height )
{
    return Math.min( Math.round( image_height * 0.05 ), 50 );
}

function calculate_spacing( window_size )
{
    return Math.ceil( window_size * 0.5 );
}

function get_average_pixel_brightness( var_image, x, y, channels )
{
    if ( channels == 1 ) return var_image.sample( x, y, 0 );
    return (var_image.sample(x,y,0) + var_image.sample(x,y,1) + var_image.sample(x,y,2)) / 3;
}

function get_window_stats( var_image, x, y, window_size, channels )
{
    let average_brightness = 0, sum_squares = 0;
    let num_pixels = window_size * window_size;
    for ( let ox = 0; ox < window_size; ox++ )
        for ( let oy = 0; oy < window_size; oy++ )
        {
            let b = get_average_pixel_brightness( var_image, x+ox, y+oy, channels );
            average_brightness += b;
            sum_squares += b * b;
        }
    average_brightness /= num_pixels;
    let variance = sum_squares / num_pixels - average_brightness * average_brightness;
    return { average_brightness: average_brightness, std_dev: Math.sqrt( variance ) };
}

function find_white_point( imageWindow )
{
    let var_image  = imageWindow.mainView.image;
    let channels   = var_image.numberOfChannels;
    let window_size = 200;
    let spacing    = calculate_spacing( window_size );

    let max_brightness = -Infinity, max_x = 0, max_y = 0;
    console.writeln( "Starting Gradient Ascent Path Algorithm" );

    let paths = 50, path_count = 0;
    let progress_checkpoints = [0, 0.25, 0.50, 0.75, 1.00], next_checkpoint = 0;

    while ( path_count < paths )
    {
        let x = Math.floor( Math.random() * (var_image.width  - window_size) );
        let y = Math.floor( Math.random() * (var_image.height - window_size) );
        for ( let iter = 0; iter < 200; iter++ )
        {
            CoreApplication.processEvents();
            let stats = get_window_stats( var_image, x, y, window_size, channels );
            if ( stats.average_brightness > max_brightness )
            {
                max_brightness = stats.average_brightness; max_x = x; max_y = y;
            }
            let dir = Math.floor( Math.random() * 4 );
            if      ( dir == 0 ) x = Math.max( 0,                               x - spacing );
            else if ( dir == 1 ) x = Math.min( var_image.width  - window_size,  x + spacing );
            else if ( dir == 2 ) y = Math.max( 0,                               y - spacing );
            else                 y = Math.min( var_image.height - window_size,   y + spacing );
        }
        path_count++;
        let pct = path_count / paths;
        if ( pct >= progress_checkpoints[next_checkpoint] )
        {
            console.writeln( "Progress: ", (pct*100).toFixed(2), "%" );
            next_checkpoint++;
        }
    }

    console.writeln( "Found white point at (", max_x, ",", max_y, ") with brightness ", max_brightness );
    imageWindow.createPreview( new Rect(max_x, max_y, max_x+window_size, max_y+window_size), "WhitePoint" );
    return { x0: max_x, y0: max_y, x1: max_x+window_size, y1: max_y+window_size };
}

function find_background( imageWindow )
{
    let var_image  = imageWindow.mainView.image;
    let channels   = var_image.numberOfChannels;
    let window_size = calculate_window_size( var_image.height );
    let spacing    = calculate_spacing( window_size );

    let min_brightness = Infinity, min_x = 0, min_y = 0;
    console.writeln( "Starting Gradient Descent Path Algorithm" );

    let paths = 50, path_count = 0;
    let progress_checkpoints = [0, 0.25, 0.50, 0.75, 1.00], next_checkpoint = 0;

    while ( path_count < paths )
    {
        let x = Math.floor( Math.random() * (var_image.width  - window_size) );
        let y = Math.floor( Math.random() * (var_image.height - window_size) );
        for ( let iter = 0; iter < 200; iter++ )
        {
            CoreApplication.processEvents();
            let stats = get_window_stats( var_image, x, y, window_size, channels );
            if ( stats.average_brightness < min_brightness )
            {
                min_brightness = stats.average_brightness; min_x = x; min_y = y;
            }
            let dir = Math.floor( Math.random() * 4 );
            if      ( dir == 0 ) x = Math.max( 0,                               x - spacing );
            else if ( dir == 1 ) x = Math.min( var_image.width  - window_size,  x + spacing );
            else if ( dir == 2 ) y = Math.max( 0,                               y - spacing );
            else                 y = Math.min( var_image.height - window_size,   y + spacing );
        }
        path_count++;
        let pct = path_count / paths;
        if ( pct >= progress_checkpoints[next_checkpoint] )
        {
            console.writeln( "Progress: ", (pct*100).toFixed(2), "%" );
            next_checkpoint++;
        }
    }

    console.writeln( "Found background at (", min_x, ",", min_y, ") with brightness ", min_brightness );
    imageWindow.createPreview( new Rect(min_x, min_y, min_x+window_size, min_y+window_size), "Background" );
    return { x0: min_x, y0: min_y, x1: min_x+window_size, y1: min_y+window_size };
}

function applyBackgroundNeutralization( imageWindow, bg )
{
    console.writeln( "Applying Background Neutralization to image: ", imageWindow.mainView.id );
    let P = new BackgroundNeutralization;
    P.backgroundReferenceViewId = "";
    P.backgroundLow  = 0.0;
    P.backgroundHigh = 0.1;
    P.useROI         = true;
    P.roiX0 = bg.x0; P.roiY0 = bg.y0; P.roiX1 = bg.x1; P.roiY1 = bg.y1;
    P.mode             = BackgroundNeutralization.RescaleAsNeeded;
    P.targetBackground = 0.001;
    P.executeOn( imageWindow.mainView );
}

function applyColorCalibrationStarry( imageWindow, bg )
{
    console.writeln( "Applying Color Calibration (Starry) to: ", imageWindow.mainView.id );
    let P = new ColorCalibration;
    P.whiteReferenceViewId  = ""; P.whiteLow = 0; P.whiteHigh = 0.9;
    P.whiteUseROI           = false;
    P.structureDetection    = true; P.structureLayers = 5; P.noiseLayers = 1;
    P.manualWhiteBalance    = false;
    P.manualRedFactor = 1; P.manualGreenFactor = 1; P.manualBlueFactor = 1;
    P.backgroundReferenceViewId = "";
    P.backgroundLow = 0; P.backgroundHigh = 0.3;
    P.backgroundUseROI = true;
    P.backgroundROIX0 = bg.x0; P.backgroundROIY0 = bg.y0;
    P.backgroundROIX1 = bg.x1; P.backgroundROIY1 = bg.y1;
    P.outputWhiteReferenceMask = false; P.outputBackgroundReferenceMask = false;
    P.executeOn( imageWindow.mainView );
}

function applyColorCalibrationStarless( imageWindow, bg, wp )
{
    console.writeln( "Applying Color Calibration (Starless) to: ", imageWindow.mainView.id );
    let P = new ColorCalibration;
    P.whiteReferenceViewId  = ""; P.whiteLow = 0; P.whiteHigh = 0.9;
    P.whiteUseROI = true;
    P.whiteROIX0 = wp.x0; P.whiteROIY0 = wp.y0; P.whiteROIX1 = wp.x1; P.whiteROIY1 = wp.y1;
    P.structureDetection = false; P.structureLayers = 5; P.noiseLayers = 1;
    P.manualWhiteBalance = false;
    P.manualRedFactor = 1; P.manualGreenFactor = 1; P.manualBlueFactor = 1;
    P.backgroundReferenceViewId = "";
    P.backgroundLow = 0; P.backgroundHigh = 0.3;
    P.backgroundUseROI = true;
    P.backgroundROIX0 = bg.x0; P.backgroundROIY0 = bg.y0;
    P.backgroundROIX1 = bg.x1; P.backgroundROIY1 = bg.y1;
    P.outputWhiteReferenceMask = false; P.outputBackgroundReferenceMask = false;
    P.executeOn( imageWindow.mainView );
}

function extractEmissionLineData( imageWindow )
{
    console.writeln( "Extracting emission line data from: ", imageWindow.mainView.id );
    let P = new PixelMath;
    P.expression  = "$T[0]-Q*($T[1]-med($T[1]))";
    P.expression1 = P.expression2 = P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "Q=" + qualityMultiplier.toString();
    P.clearImageCacheAndExit = false; P.cacheGeneratedImages = false;
    P.generateOutput = true; P.singleThreaded = false; P.optimization = true;
    P.use64BitWorkingImage = false; P.rescale = false;
    P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
    P.createNewImage = false; P.showNewImage = true;
    P.newImageId = ""; P.newImageWidth = 0; P.newImageHeight = 0; P.newImageAlpha = false;
    P.newImageColorSpace   = PixelMath.Gray;
    P.newImageSampleFormat = PixelMath.SameAsTarget;
    P.executeOn( imageWindow.mainView );
}

function extractPureSignal( imageWindow )
{
    console.writeln( "Extracting pure signal from: ", imageWindow.mainView.id );
    let P = new PixelMath;
    P.expression = "($T-med($T))/~med($T)";
    P.expression1 = P.expression2 = P.expression3 = "";
    P.useSingleExpression = true; P.symbols = "";
    P.clearImageCacheAndExit = false; P.cacheGeneratedImages = false;
    P.generateOutput = true; P.singleThreaded = false; P.optimization = true;
    P.use64BitWorkingImage = false; P.rescale = false;
    P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
    P.createNewImage = false; P.showNewImage = true;
    P.executeOn( imageWindow.mainView );
}

function applyNoiseXterminator( imageWindow )
{
    try
    {
        let P = new NoiseXTerminator;
        P.ai_file = NOISEXTERMINATOR_AI_FILE;
        P.denoise = 0.70; P.detail = 0.15;
        if ( !P.executeOn( imageWindow.mainView, false ) )
            throw new Error( "NoiseXterminator file not found." );
    }
    catch ( e )
    {
        new MessageBox(
            "NoiseXTerminator is not installed or the AI file is not found.\nPlease visit www.rc-astro.com/software/nxt/ to purchase and install it.",
            "Error", StdIcon.Error, StdButton.Ok ).execute();
    }
}

function applyGraXpertDenoise( imageWindow )
{
    try
    {
        let P = new GraXpert;
        P.backgroundExtraction = false; P.smoothing = 0; P.correction = "Subtraction";
        P.createBackground = false; P.backgroundExtractionAIModel = "1.0.1";
        P.denoising = true; P.strength = 0.7; P.batchSize = 4;
        P.denoiseAIModel = ContinuumSubtractionParameters.aiModel || "2.0.0";
        P.disableGPU = false; P.replaceImage = true; P.showLogs = false;
        P.executeOn( imageWindow.mainView, false );
    }
    catch ( e )
    {
        new MessageBox(
            "GraXpert is not installed.\nPlease visit www.deepskyforge.com/index.html to download and install it.",
            "Error", StdIcon.Error, StdButton.Ok ).execute();
    }
}

function applyCurvesBoost( imageWindow )
{
    let P = new CurvesTransformation;
    P.K  = [ [0.00000,0.00000],[0.37500,0.55000],[1.00000,1.00000] ];
    P.Kt = CurvesTransformation.AkimaSubsplines;
    P.executeOn( imageWindow.mainView );
}

function closeCreatedWindows()
{
    for ( let i = 0; i < createdWindows.length; i++ )
    {
        let win = ImageWindow.windowById( createdWindows[i] );
        if ( win ) win.forceClose();
    }
    createdWindows = [];
}

function closeExtractedChannels( extractedChannels )
{
    for ( let i = 0; i < extractedChannels.length; i++ )
    {
        let win = ImageWindow.windowById( extractedChannels[i] );
        if ( win ) win.forceClose();
    }
}

// ============================================================================
// Image creation and background finding
// ============================================================================

function createImagesAndFindBackground( ha, oiii, sii, redRgb, green )
{
    let createdImages    = [];
    let backgroundPreviews = {};
    let extractedChannels  = [];

    function checkImageDimensions( imageIds )
    {
        let first = ImageWindow.windowById( imageIds[0] );
        let w = first.mainView.image.width, h = first.mainView.image.height;
        for ( let i = 1; i < imageIds.length; i++ )
        {
            let img = ImageWindow.windowById( imageIds[i] );
            if ( img.mainView.image.width !== w || img.mainView.image.height !== h ) return false;
        }
        return true;
    }

    let selectedImages = [ha,oiii,sii,redRgb,green].filter( img => img !== "Select Image" );

    if ( !checkImageDimensions( selectedImages ) )
    {
        new MessageBox( "Image dimensions do not match. Please align and crop to the same dimensions.",
            "Dimension Mismatch", StdIcon.Error, StdButton.Ok ).execute();
        return null;
    }

    function makeColorImage( channels, baseID )
    {
        let uniqueID = findUniqueImageID( baseID );
        let P = new ChannelCombination;
        P.colorSpace = ChannelCombination.RGB;
        P.channels   = channels;
        P.inheritAstrometricSolution = true;
        P.executeGlobal();
        let newImage = ImageWindow.activeWindow;
        newImage.mainView.id = uniqueID;
        createdImages.push( uniqueID );
        backgroundPreviews[uniqueID] = find_background( newImage );
        return uniqueID;
    }

    function extractChannel( imageId, channelIndex, suffix )
    {
        let P = new ChannelExtraction;
        P.colorSpace = ChannelExtraction.RGB;
        P.channels   = [
            [channelIndex === 0, ""],
            [channelIndex === 1, ""],
            [channelIndex === 2, ""]
        ];
        P.sampleFormat = ChannelExtraction.SameAsSource;
        P.inheritAstrometricSolution = true;
        P.executeOn( ImageWindow.windowById( imageId ).mainView );
        let extracted = ImageWindow.activeWindow;
        extracted.mainView.id = imageId + suffix;
        extractedChannels.push( extracted.mainView.id );
        return extracted.mainView.id;
    }

    // Validate greyscale inputs
    for ( let [id, label] of [[ha,"Ha"],[oiii,"OIII"],[sii,"SII"],[green,"Green"]] )
    {
        if ( id !== "Select Image" && !checkImageIsGreyscale(id) )
        {
            new MessageBox( "The image " + id + " is the wrong color space, please select a greyscale image",
                TITLE, StdIcon.Error, StdButton.Ok ).execute();
            return null;
        }
    }

    if ( redRgb === "Select Image" || ImageWindow.windowById(redRgb).mainView.image.isGrayscale )
    {
        if ( ha    !== "Select Image" && redRgb !== "Select Image" )
            makeColorImage( [[true,ha],[true,redRgb],[true,redRgb]], "HaNB" );
        if ( sii   !== "Select Image" && redRgb !== "Select Image" )
            makeColorImage( [[true,sii],[true,redRgb],[true,redRgb]], "SIINB" );
        if ( oiii  !== "Select Image" && green  !== "Select Image" )
            makeColorImage( [[true,oiii],[true,green],[true,green]], "OIIINB" );
    }
    else if ( redRgb !== "Select Image" && ImageWindow.windowById(redRgb).mainView.image.isColor )
    {
        let redChannel   = extractChannel( redRgb, 0, "_R" );
        let greenChannel = extractChannel( redRgb, 1, "_G" );
        if ( ha   !== "Select Image" ) makeColorImage( [[true,ha],  [true,redChannel],  [true,redChannel]],  "HaNB"  );
        if ( sii  !== "Select Image" ) makeColorImage( [[true,sii], [true,redChannel],  [true,redChannel]],  "SIINB" );
        if ( oiii !== "Select Image" ) makeColorImage( [[true,oiii],[true,greenChannel],[true,greenChannel]], "OIIINB");
    }

    if ( createdImages.length === 0 )
    {
        new MessageBox( "Please Select Appropriate Emission and Continuum Images",
            TITLE, StdIcon.Error, StdButton.Ok ).execute();
        return null;
    }

    closeExtractedChannels( extractedChannels );
    return { createdImages: createdImages, backgroundPreviews: backgroundPreviews };
}

function applyBackgroundNeutralizationToImages( imagesAndPreviews )
{
    let { createdImages, backgroundPreviews } = imagesAndPreviews;
    for ( let i = 0; i < createdImages.length; i++ )
        applyBackgroundNeutralization( ImageWindow.windowById(createdImages[i]), backgroundPreviews[createdImages[i]] );
}

function applyColorCalibrationToImagesStarry( imagesAndPreviews )
{
    let { createdImages, backgroundPreviews } = imagesAndPreviews;
    for ( let i = 0; i < createdImages.length; i++ )
        applyColorCalibrationStarry( ImageWindow.windowById(createdImages[i]), backgroundPreviews[createdImages[i]] );
}

function applyColorCalibrationToImagesStarless( imagesAndPreviews )
{
    let { createdImages, backgroundPreviews } = imagesAndPreviews;
    for ( let i = 0; i < createdImages.length; i++ )
    {
        let imageWindow = ImageWindow.windowById( createdImages[i] );
        let wp = find_white_point( imageWindow );
        applyColorCalibrationStarless( imageWindow, backgroundPreviews[createdImages[i]], wp );
    }
}

// ============================================================================
// Dialog
// ============================================================================

var ContinuumSubtractionDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.title = TITLE + " Script";

        // ---- Title ----
        this.titleLabel = new Label( this );
        this.titleLabel.text = TITLE + " V" + VERSION;
        this.titleLabel.textAlignment = TextAlignment.Center;
        this.titleLabel.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0;";

        // ---- Instructions ----
        this.instructionLabel = new Label( this );
        this.instructionLabel.text =
            "Script to take Linear NB filter image(s) and RGB Channels (or OSC), perform a continuum subtraction, and automatically create pure signal non-linear images.\n\n" +
            "Select the relevant images for Ha, OIII, SII, and the continuum images Red (or RGB), Green. At least one image must be selected in both the emission line and continuum groups.\n\n" +
            "You will need a Red(or RGB) image for Ha and SII subtraction and a Green if you don't have an RGB image in the Red (or RGB) dropdown for OIII subtraction.\n\n" +
            "Be sure to select whether your images have had the stars removed or not with the Starry or Starless Buttons.  All images loaded need to either be all starless or all be full of stars.\n\n" +
            "Prior to Running the script ensure:\n -Gradients Removed\n -Stacking Artifacts cropped out\n -BlurXterminator ran (if you own it)";
        this.instructionLabel.wordWrapping  = true;
        this.instructionLabel.textAlignment = TextAlignment.Left;
        this.instructionLabel.frameStyle    = FrameStyle.Box;
        this.instructionLabel.styleSheet    = "font-size: 10pt; padding: 10px; background-color: #e6e6fa;";

        // ---- Starry / Starless radio buttons ----
        this.starryRadioButton = new RadioButton( this );
        this.starryRadioButton.text    = "Starry";
        this.starryRadioButton.checked = ContinuumSubtractionParameters.starrySelected;
        this.starryRadioButton.toolTip =
            "If processing galaxies I highly recommend you use Starry images\n\n" +
            "StarX and StarNet tend to remove portions of galaxies thinking they are stars.";
        this.starryRadioButton.onCheck = checked =>
        {
            if ( checked ) ContinuumSubtractionParameters.starrySelected = true;
        };

        this.starlessRadioButton = new RadioButton( this );
        this.starlessRadioButton.text    = "Starless";
        this.starlessRadioButton.checked = !ContinuumSubtractionParameters.starrySelected;
        this.starlessRadioButton.toolTip = this.starryRadioButton.toolTip;
        this.starlessRadioButton.onCheck = checked =>
        {
            if ( checked ) ContinuumSubtractionParameters.starrySelected = false;
        };

        this.radioButtonSizer = new HorizontalSizer; this.radioButtonSizer.spacing = 10;
        this.radioButtonSizer.add( this.starryRadioButton );
        this.radioButtonSizer.add( this.starlessRadioButton );

        // ---- Dropdown helper ----
        const makeDropdown = labelText =>
        {
            let sizer   = new HorizontalSizer;
            let label   = new Label( this );
            label.text  = labelText;
            label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
            let combo   = new ComboBox( this );
            combo.editEnabled = false;
            combo.addItem( "Select Image" );
            ImageWindow.windows.forEach( w => combo.addItem( w.mainView.id ) );
            combo.currentItem = 0;
            combo.maxWidth    = 400;
            sizer.add( label ); sizer.add( combo, 100 );
            return { sizer: sizer, comboBox: combo };
        };

        let ha      = makeDropdown( "Ha:" );
        let oiii    = makeDropdown( "OIII:" );
        let sii     = makeDropdown( "SII:" );
        let redRgb  = makeDropdown( "Red (or RGB):" );
        let green   = makeDropdown( "Green:" );

        this.haSizer       = ha.sizer;     this.haComboBox      = ha.comboBox;
        this.oiiiSizer     = oiii.sizer;   this.oiiiComboBox    = oiii.comboBox;
        this.siiSizer      = sii.sizer;    this.siiComboBox     = sii.comboBox;
        this.redRgbSizer   = redRgb.sizer; this.redRgbComboBox  = redRgb.comboBox;
        this.greenSizer    = green.sizer;  this.greenComboBox   = green.comboBox;

        // ---- New Instance button ----
        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = ":/process-interface/new-instance.png";
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "New Instance";
        this.newInstanceButton.onMousePress = () =>
        {
            ContinuumSubtractionParameters.save();
            this.newInstance();
        };

        // ---- Execute button ----
        this.executeButton = new PushButton( this );
        this.executeButton.text    = "Execute";
        this.executeButton.onClick = () => { this.executeScript(); };

        // ---- Authorship ----
        this.authorshipLabel = new Label( this );
        this.authorshipLabel.text = "Written by Franklin Marek\nCopyright 2026\nwww.setiastro.com";
        this.authorshipLabel.textAlignment = TextAlignment.Center;

        // ---- Noise reduction controls ----
        // Use ownerDialog as back-reference on checkbox handlers to avoid the read-only 'dialog' trap
        this.noiseReductionCheckBox = new CheckBox( this );
        this.noiseReductionCheckBox.text    = "Apply Noise Reduction within the Process";
        this.noiseReductionCheckBox.checked = ContinuumSubtractionParameters.applyNoiseReduction;
        this.noiseReductionCheckBox.ownerDialog = this;
        this.noiseReductionCheckBox.onCheck = function( checked )
        {
            this.ownerDialog.noiseReductionMethodGroup.visible = checked;
            this.ownerDialog.adjustToContents();
            ContinuumSubtractionParameters.applyNoiseReduction = checked;
        };

        this.noiseXterminatorCheckBox = new CheckBox( this );
        this.noiseXterminatorCheckBox.text    = "NoiseXterminator";
        this.noiseXterminatorCheckBox.checked = ContinuumSubtractionParameters.noiseReductionMethod === "NoiseXterminator";
        this.noiseXterminatorCheckBox.ownerDialog = this;
        this.noiseXterminatorCheckBox.onCheck = function( checked )
        {
            if ( checked )
            {
                ContinuumSubtractionParameters.noiseReductionMethod = "NoiseXterminator";
                this.ownerDialog.graXpertDenoiseCheckBox.checked = false;
                this.ownerDialog.aiModelLabel.visible   = false;
                this.ownerDialog.aiModelDropdown.visible = false;
                this.ownerDialog.adjustToContents();
            }
        };

        this.graXpertDenoiseCheckBox = new CheckBox( this );
        this.graXpertDenoiseCheckBox.text    = "GraXpertDenoise";
        this.graXpertDenoiseCheckBox.checked = ContinuumSubtractionParameters.noiseReductionMethod === "GraXpertDenoise";
        this.graXpertDenoiseCheckBox.ownerDialog = this;
        this.graXpertDenoiseCheckBox.onCheck = function( checked )
        {
            if ( checked )
            {
                ContinuumSubtractionParameters.noiseReductionMethod = "GraXpertDenoise";
                this.ownerDialog.noiseXterminatorCheckBox.checked = false;
                this.ownerDialog.aiModelLabel.visible   = true;
                this.ownerDialog.aiModelDropdown.visible = true;
                this.ownerDialog.adjustToContents();
            }
        };

        this.aiModelLabel = new Label( this );
        this.aiModelLabel.text = "Select AI Model: ";
        this.aiModelLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.aiModelLabel.visible = this.graXpertDenoiseCheckBox.checked;

        this.aiModelDropdown = new ComboBox( this );
        ["1.0.0","2.0.0","3.0.0","3.0.1","3.0.2"].forEach( v => this.aiModelDropdown.addItem(v) );
        this.aiModelDropdown.currentItem = 1;
        this.aiModelDropdown.visible     = this.graXpertDenoiseCheckBox.checked;
        this.aiModelDropdown.ownerDialog = this;
        this.aiModelDropdown.onItemSelected = function( index )
        {
            ContinuumSubtractionParameters.aiModel = this.ownerDialog.aiModelDropdown.itemText( index );
        };

        this.noiseReductionMethodGroup = new Control( this );
        this.noiseReductionMethodGroup.sizer = new VerticalSizer;
        this.noiseReductionMethodGroup.sizer.add( this.noiseXterminatorCheckBox );
        this.noiseReductionMethodGroup.sizer.add( this.graXpertDenoiseCheckBox );
        let aiModelSizer = new HorizontalSizer;
        aiModelSizer.add( this.aiModelLabel ); aiModelSizer.add( this.aiModelDropdown );
        this.noiseReductionMethodGroup.sizer.add( aiModelSizer );
        this.noiseReductionMethodGroup.visible = ContinuumSubtractionParameters.applyNoiseReduction;

        // ---- Output linear only ----
        this.outputLinearCheckBox = new CheckBox( this );
        this.outputLinearCheckBox.text    = "Output Linear Image Only";
        this.outputLinearCheckBox.checked = ContinuumSubtractionParameters.outputLinearImageOnly;
        this.outputLinearCheckBox.toolTip =
            "If checked, the script will output only the linear image and skip the non-linear stretch, pure signal extraction, and curves boost steps.";
        this.outputLinearCheckBox.onCheck = checked =>
        {
            ContinuumSubtractionParameters.outputLinearImageOnly = checked;
        };

        // ---- Layout ----
        this.sizer = new VerticalSizer; this.sizer.margin = 6; this.sizer.spacing = 6;
        this.sizer.add( this.titleLabel );
        this.sizer.add( this.instructionLabel );
        this.sizer.addSpacing( 10 );
        this.sizer.add( this.radioButtonSizer );
        this.sizer.addSpacing( 10 );

        this.groupLabelsSizer = new HorizontalSizer; this.groupLabelsSizer.spacing = 6;
        let emLbl = new Label( this ); emLbl.text = "Emission Line Group";
        emLbl.textAlignment = TextAlignment.Center; emLbl.styleSheet = "font-weight: bold;";
        let coLbl = new Label( this ); coLbl.text = "Continuum Group";
        coLbl.textAlignment = TextAlignment.Center; coLbl.styleSheet = "font-weight: bold;";
        this.groupLabelsSizer.add( emLbl, 100 ); this.groupLabelsSizer.addSpacing( 20 ); this.groupLabelsSizer.add( coLbl, 100 );
        this.sizer.add( this.groupLabelsSizer );

        this.dropdownGroupSizer = new HorizontalSizer; this.dropdownGroupSizer.spacing = 6;
        this.emissionSizer = new VerticalSizer; this.emissionSizer.spacing = 6;
        this.emissionSizer.add( this.haSizer ); this.emissionSizer.add( this.oiiiSizer ); this.emissionSizer.add( this.siiSizer );
        this.dropdownGroupSizer.add( this.emissionSizer );
        this.dropdownGroupSizer.addSpacing( 20 );
        this.continuumSizer = new VerticalSizer; this.continuumSizer.spacing = 6;
        this.continuumSizer.add( this.redRgbSizer ); this.continuumSizer.add( this.greenSizer );
        this.continuumSizer.add( new Label(this) );
        this.dropdownGroupSizer.add( this.continuumSizer );
        this.sizer.add( this.dropdownGroupSizer );

        let noiseAndOutputSizer = new HorizontalSizer; noiseAndOutputSizer.spacing = 8;
        noiseAndOutputSizer.add( this.noiseReductionCheckBox );
        noiseAndOutputSizer.add( this.outputLinearCheckBox );
        this.sizer.add( noiseAndOutputSizer );
        this.sizer.addSpacing( 8 );
        this.sizer.add( this.noiseReductionMethodGroup );

        let bottomRow = new HorizontalSizer; bottomRow.spacing = 6;
        bottomRow.add( this.newInstanceButton );
        bottomRow.addStretch();
        bottomRow.add( this.authorshipLabel );
        bottomRow.addStretch();
        bottomRow.add( this.executeButton );
        this.sizer.add( bottomRow );

        this.windowTitle = TITLE + " Script";
        this.adjustToContents();
        this.resizeable = true;
    }

    executeScript()
    {
        closeCreatedWindows();

        let ha     = this.haComboBox.itemText(     this.haComboBox.currentItem );
        let oiii   = this.oiiiComboBox.itemText(   this.oiiiComboBox.currentItem );
        let sii    = this.siiComboBox.itemText(    this.siiComboBox.currentItem );
        let redRgb = this.redRgbComboBox.itemText( this.redRgbComboBox.currentItem );
        let green  = this.greenComboBox.itemText(  this.greenComboBox.currentItem );

        qualityMultiplier = this.starryRadioButton.checked ? 0.9 : 1.0;

        let imagesAndPreviews = createImagesAndFindBackground( ha, oiii, sii, redRgb, green );
        if ( imagesAndPreviews === null ) return;

        applyBackgroundNeutralizationToImages( imagesAndPreviews );

        if ( this.starryRadioButton.checked )
            applyColorCalibrationToImagesStarry( imagesAndPreviews );
        else
            applyColorCalibrationToImagesStarless( imagesAndPreviews );

        for ( let i = 0; i < imagesAndPreviews.createdImages.length; i++ )
            extractEmissionLineData( ImageWindow.windowById( imagesAndPreviews.createdImages[i] ) );

        for ( let i = 0; i < imagesAndPreviews.createdImages.length; i++ )
            convertToGrayscale( ImageWindow.windowById( imagesAndPreviews.createdImages[i] ) );

        if ( ContinuumSubtractionParameters.applyNoiseReduction )
        {
            for ( let i = 0; i < imagesAndPreviews.createdImages.length; i++ )
            {
                let win = ImageWindow.windowById( imagesAndPreviews.createdImages[i] );
                if ( ContinuumSubtractionParameters.noiseReductionMethod === "NoiseXterminator" )
                    applyNoiseXterminator( win );
                else if ( ContinuumSubtractionParameters.noiseReductionMethod === "GraXpertDenoise" )
                    applyGraXpertDenoise( win );
            }
        }

        console.show();

        if ( !ContinuumSubtractionParameters.outputLinearImageOnly )
        {
            for ( let i = 0; i < imagesAndPreviews.createdImages.length; i++ )
                applyNonLinearStretch( ImageWindow.windowById( imagesAndPreviews.createdImages[i] ) );

            for ( let i = 0; i < imagesAndPreviews.createdImages.length; i++ )
                extractPureSignal( ImageWindow.windowById( imagesAndPreviews.createdImages[i] ) );

            for ( let i = 0; i < imagesAndPreviews.createdImages.length; i++ )
                applyCurvesBoost( ImageWindow.windowById( imagesAndPreviews.createdImages[i] ) );
        }

        console.noteln( "Continuum Subtraction complete! Created: ", imagesAndPreviews.createdImages.join(", ") );
        this.ok();
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );

    let dialog = new ContinuumSubtractionDialog();
    if ( dialog.execute() !== Dialog.Accepted )
        console.noteln( "Continuum Subtraction Script Dialog Closed." );
}

main();
