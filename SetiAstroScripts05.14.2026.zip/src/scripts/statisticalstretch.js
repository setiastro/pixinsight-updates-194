#engine v8

#feature-id StatisticalStretch : SetiAstro > Statistical Stretch
#feature-icon  statisticalstretch.svg
#feature-info This script performs a determines dynamically statistical properties of the image and logirthmically stretches accordingly.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Statistical Stretch Script
 * Version: 2.3
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script performs a determines dynamically statistical properties of the image and logirthmically stretches accordingly.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE "Statistical Astro Stretching"
#define VERSION "2.3"
#define DEBUGGING_MODE_ON false

// ============================================================================
// Helpers / Core Utilities
// ============================================================================

function calculate_image_median( var_image )
{
    return var_image.median();
}

function configurePixelMath( P, doTruncate )
{
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = true;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = (doTruncate === true);
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
}

function disableSTF( targetView )
{
    let stf = new ScreenTransferFunction;
    stf.STF = [
        [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
        [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
        [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
        [0.00000, 1.00000, 0.50000, 0.00000, 1.00000]
    ];
    stf.executeOn( targetView, false );
    console.writeln( "STF has been disabled." );
}

function lumaCoeffs()
{
    switch ( (SHOParameters.lumaMode || "rec709").toLowerCase() )
    {
    case "rec601":  return [0.2990, 0.5870, 0.1140];
    case "rec2020": return [0.2627, 0.6780, 0.0593];
    case "rec709":
    default:        return [0.2126, 0.7152, 0.0722];
    }
}

function _hdrCompressExprMono( amount, knee )
{
    return "" +
        "a = " + amount + ";\n" +
        "k = " + knee + ";\n" +
        "k = min(0.999999, max(0.1, k));\n" +
        "x = $T;\n" +
        "hi = x > k;\n" +
        "t = (x - k)/(1 - k);\n" +
        "t = min(1, max(0, t));\n" +
        "t2 = t*t;\n" +
        "t3 = t2*t;\n" +
        "h10 = (t3 - 2*t2 + t);\n" +
        "h01 = (-2*t3 + 3*t2);\n" +
        "h11 = (t3 - t2);\n" +
        "m1 = min(5, max(1, 1 + 4*a));\n" +
        "f = h10*1 + h01*1 + h11*m1;\n" +
        "y = k + (1 - k)*min(1, max(0, f));\n" +
        "iif(hi, y, x);";
}

function _hdrCompressExprColor( amount, knee )
{
    let C = lumaCoeffs();
    let cr = C[0], cg = C[1], cb = C[2];

    return "" +
        "a = " + amount + ";\n" +
        "k = " + knee + ";\n" +
        "k = min(0.999999, max(0.1, k));\n" +
        "R = $T[0]; G = $T[1]; B = $T[2];\n" +
        "cr = " + cr + "; cg = " + cg + "; cb = " + cb + ";\n" +
        "Y = cr*R + cg*G + cb*B;\n" +
        "hi = Y > k;\n" +
        "t = (Y - k)/(1 - k);\n" +
        "t = min(1, max(0, t));\n" +
        "t2 = t*t;\n" +
        "t3 = t2*t;\n" +
        "h10 = (t3 - 2*t2 + t);\n" +
        "h01 = (-2*t3 + 3*t2);\n" +
        "h11 = (t3 - t2);\n" +
        "m1 = min(5, max(1, 1 + 4*a));\n" +
        "f = h10*1 + h01*1 + h11*m1;\n" +
        "Yc = k + (1 - k)*min(1, max(0, f));\n" +
        "s = iif(hi, iif(Y <= 1.0e-10, 1, Yc/Y), 1);\n" +
        "$T * s;";
}

function _addHdrCompressProcess( container, isColor )
{
    let H = new PixelMath;
    H.useSingleExpression = true;

    H.symbols = isColor
        ? "a,k,x,hi,t,t2,t3,h10,h01,h11,m1,f,y,R,G,B,cr,cg,cb,Y,Yc,s"
        : "a,k,x,hi,t,t2,t3,h10,h01,h11,m1,f,y";

    H.expression = isColor
        ? _hdrCompressExprColor( SHOParameters.hdrAmount, SHOParameters.hdrKnee )
        : _hdrCompressExprMono( SHOParameters.hdrAmount, SHOParameters.hdrKnee );

    configurePixelMath( H );
    container.add( H );
}

// ============================================================================
// Final curve boost
// ============================================================================

function applyFinalCurve( targetView, targetMedian )
{
    let P = new CurvesTransformation;
    P.Bt = CurvesTransformation.AkimaSubsplines;

    P.K = [
        [0.00000, 0.00000],
        [0.5 * SHOParameters.targetMedian, 0.5 * SHOParameters.targetMedian],
        [SHOParameters.targetMedian, SHOParameters.targetMedian],
        [(1/4*(1-SHOParameters.targetMedian)+SHOParameters.targetMedian),
         Math.pow((1/4*(1-SHOParameters.targetMedian)+SHOParameters.targetMedian), (1-SHOParameters.curvesBoost))],
        [(3/4*(1-SHOParameters.targetMedian)+SHOParameters.targetMedian),
         Math.pow(Math.pow((3/4*(1-SHOParameters.targetMedian)+SHOParameters.targetMedian), (1-SHOParameters.curvesBoost)), (1-SHOParameters.curvesBoost))],
        [1.00000, 1.00000]
    ];

    P.St = CurvesTransformation.AkimaSubsplines;
    P.executeOn( targetView );
    console.noteln( "Final Sigma Curves applied successfully after all iterations." );
}

// ============================================================================
// Clip estimator
// ============================================================================

function _imgStats( imgLive )
{
    let img = new Image( imgLive );
    let nchan = img.isColor ? 3 : 1;
    let median = new Array( nchan );
    let mad    = new Array( nchan );
    let minv   = new Array( nchan );
    let oldSel = img.selectedChannel;

    try
    {
        for ( let c = 0; c < nchan; c++ )
        {
            img.selectedChannel = c;
            median[c] = img.median();
            mad[c]    = img.MAD();
            minv[c]   = img.minimum();
        }
    }
    finally
    {
        img.selectedChannel = oldSel;
    }

    return { median: median, mad: mad, minimum: minv, isColor: img.isColor, nchan: nchan };
}

function _computeBP_thresholds( img )
{
    let st = _imgStats( img );
    let sigma = 1.4826;
    let k = SHOParameters.blackpointSigma;
    let noClip = !!SHOParameters.noBlackClip;

    if ( !img.isColor )
    {
        let Med = st.median[0];
        let Sig = sigma * st.mad[0];
        let BPraw = Med - k * Sig;
        let MinC = st.minimum[0];
        let BP = noClip ? MinC : (BPraw < MinC ? MinC : BPraw);
        return { mode: "mono", bp: BP };
    }

    if ( SHOParameters.linkedStretch || SHOParameters.lumaOnly )
    {
        let C = lumaCoeffs();
        let cr = C[0], cg = C[1], cb = C[2];
        let Med = cr*st.median[0] + cg*st.median[1] + cb*st.median[2];
        let Sig = sigma * (cr*st.mad[0] + cg*st.mad[1] + cb*st.mad[2]);
        let MinC = Math.min( st.minimum[0], st.minimum[1], st.minimum[2] );
        let BPraw = Med - k * Sig;
        let BP = noClip ? MinC : (BPraw < MinC ? MinC : BPraw);
        return { mode: (SHOParameters.lumaOnly ? "lumaOnly" : "linked"), bp: BP };
    }

    let bp = [];
    for ( let c = 0; c < 3; c++ )
    {
        let Medc = st.median[c];
        let Sigc = sigma * st.mad[c];
        let BPrawc = Medc - k * Sigc;
        let Minc = st.minimum[c];
        let BPc = noClip ? Minc : (BPrawc < Minc ? Minc : BPrawc);
        bp.push( BPc );
    }
    return { mode: "unlinked", bp: bp };
}

function _estimateClippedPixels_Blackpoint( img, maxSamples )
{
    maxSamples = maxSamples || 1000000;

    let w = img.width, h = img.height;
    let total = w * h;
    let stride = 1;
    if ( total > maxSamples )
        stride = Math.max( 1, Math.floor( Math.sqrt( total / maxSamples ) ) );

    let bpInfo = _computeBP_thresholds( img );
    let clipped = 0;
    let sampled = 0;

    if ( !img.isColor )
    {
        let BP = bpInfo.bp;
        for ( let y = 0; y < h; y += stride )
            for ( let x = 0; x < w; x += stride )
            {
                if ( img.sample( x, y ) < BP ) clipped++;
                sampled++;
            }
    }
    else if ( bpInfo.mode === "unlinked" )
    {
        let bpr = bpInfo.bp[0], bpg = bpInfo.bp[1], bpb = bpInfo.bp[2];
        for ( let y = 0; y < h; y += stride )
            for ( let x = 0; x < w; x += stride )
            {
                let r = img.sample( x, y, 0 );
                let g = img.sample( x, y, 1 );
                let b = img.sample( x, y, 2 );
                if ( r < bpr || g < bpg || b < bpb ) clipped++;
                sampled++;
            }
    }
    else
    {
        let BPc = bpInfo.bp;
        for ( let y = 0; y < h; y += stride )
            for ( let x = 0; x < w; x += stride )
            {
                let r = img.sample( x, y, 0 );
                let g = img.sample( x, y, 1 );
                let b = img.sample( x, y, 2 );
                if ( Math.min( r, g, b ) < BPc ) clipped++;
                sampled++;
            }
    }

    let clippedEst = (stride === 1)
        ? clipped
        : Math.round( clipped * (total / sampled) );

    return { clippedEst: clippedEst, total: total, sampled: sampled, stride: stride, bpInfo: bpInfo };
}

function _fmtInt( n )
{
    return "" + Math.round( n );
}

// ============================================================================
// Stretch implementations
// ============================================================================

function processMonoImage( targetView, targetMedian, iteration )
{
    let P = new ProcessContainer;

    let P001 = new PixelMath;
    P001.expression =
        "Med = med($T);\n" +
        "Sig = 1.4826*MAD($T);\n" +
        "BPraw = Med - " + SHOParameters.blackpointSigma + "*Sig;\n" +
        "BP = iif(" + (SHOParameters.noBlackClip ? "1" : "0") + ", min($T), iif(BPraw < min($T), min($T), BPraw));\n" +
        "Rescaled = ($T - BP) / (1 - BP);\n" +
        "Rescaled;";
    P001.useSingleExpression = true;
    P001.symbols = "Med, Sig, BPraw, BP, Rescaled";
    configurePixelMath( P001, false );
    P.add( P001 );

    let P002 = new PixelMath;
    P002.expression =
        "((Med($T)-1)*" + targetMedian + "*$T)/(Med($T)*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
    P002.useSingleExpression = true;
    P002.symbols = "L, S";
    configurePixelMath( P002, false );
    P.add( P002 );

    let P003 = new PixelMath;
    P003.expression = SHOParameters.normalizeImageRange ? "$T/max($T)" : "$T;";
    P003.useSingleExpression = true;
    P003.symbols = "L, Mcolor, S";
    configurePixelMath( P003, true );
    P.add( P003 );

    if ( SHOParameters.hdrCompress && SHOParameters.hdrAmount > 0 )
        _addHdrCompressProcess( P, false );

    P.executeOn( targetView );
    console.noteln( "Mono Image Statistical Stretch completed successfully for iteration " + iteration + "." );
}

function processColorImage( targetView, targetMedian, iteration )
{
    if ( SHOParameters.lumaOnly )
    {
        let b = Math.max( 0, Math.min( 1, SHOParameters.lumaBlend ) );
        if ( b <= 0.000001 )
        {
            SHOParameters.lumaOnly = false;
            processColorImage( targetView, targetMedian, iteration );
            SHOParameters.lumaOnly = true;
        }
        else if ( b >= 0.999999 )
        {
            processColorImage_LumaOnly( targetView, targetMedian, iteration );
        }
        else
        {
            processColorImage_LumaBlend( targetView, targetMedian, iteration );
        }
        return;
    }

    let P = new ProcessContainer;

    let P001 = new PixelMath;
    P001.expression =
        "cr=0.2126; cg=0.7152; cb=0.0722;\n" +
        "Med = cr*med($T[0]) + cg*med($T[1]) + cb*med($T[2]);\n" +
        "Sig = 1.4826*(cr*MAD($T[0]) + cg*MAD($T[1]) + cb*MAD($T[2]));\n" +
        "MinC = min(min($T[0]),min($T[1]),min($T[2]));\n" +
        "BPraw = Med - " + SHOParameters.blackpointSigma + "*Sig;\n" +
        "BP = iif(" + (SHOParameters.noBlackClip ? "1" : "0") + ", MinC, iif(BPraw < MinC, MinC, BPraw));\n" +
        "Rescaled = ($T - BP) / (1 - BP);\n" +
        "Rescaled;";
    P001.useSingleExpression = true;
    P001.symbols = "cr,cg,cb,Med,Sig,MinC,BPraw,BP,Rescaled";
    configurePixelMath( P001, false );
    P.add( P001 );

    let P002 = new PixelMath;
    P002.expression =
        "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
        "((MedianColor-1)*" + targetMedian + "*$T)/(MedianColor*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
    P002.useSingleExpression = true;
    P002.symbols = "L, MedianColor, S";
    configurePixelMath( P002, false );
    P.add( P002 );

    let P003 = new PixelMath;
    P003.expression = SHOParameters.normalizeImageRange
        ? "Mcolor=max(max($T[0]),max($T[1]),max($T[2]));\n$T/Mcolor;"
        : "$T;";
    P003.useSingleExpression = true;
    P003.symbols = "L, Mcolor, S";
    configurePixelMath( P003, true );
    P.add( P003 );

    if ( SHOParameters.hdrCompress && SHOParameters.hdrAmount > 0 )
        _addHdrCompressProcess( P, true );

    P.executeOn( targetView );
    console.noteln( "Color Image Statistical Stretch completed successfully for iteration " + iteration + "." );
}

function processColorImage_LumaBlend( targetView, targetMedian, iteration )
{
    let P = new ProcessContainer;
    let C = lumaCoeffs();
    let cr = C[0], cg = C[1], cb = C[2];

    let P001 = new PixelMath;
    P001.expression =
        "cr=" + cr + "; cg=" + cg + "; cb=" + cb + ";\n" +
        "Med = cr*med($T[0]) + cg*med($T[1]) + cb*med($T[2]);\n" +
        "Sig = 1.4826*(cr*MAD($T[0]) + cg*MAD($T[1]) + cb*MAD($T[2]));\n" +
        "MinC = min(min($T[0]),min($T[1]),min($T[2]));\n" +
        "BPraw = Med - " + SHOParameters.blackpointSigma + "*Sig;\n" +
        "BP = iif(" + (SHOParameters.noBlackClip ? "1" : "0") + ", MinC, iif(BPraw < MinC, MinC, BPraw));\n" +
        "Rescaled = ($T - BP) / (1 - BP);\n" +
        "Rescaled;";
    P001.useSingleExpression = true;
    P001.symbols = "cr,cg,cb,Med,Sig,MinC,BPraw,BP,Rescaled";
    configurePixelMath( P001, false );
    P.add( P001 );

    let b = Math.max( 0, Math.min( 1, SHOParameters.lumaBlend ) );

    let P002 = new PixelMath;
    P002.expression =
        "cr=" + cr + "; cg=" + cg + "; cb=" + cb + ";\n" +
        "Y = cr*$T[0] + cg*$T[1] + cb*$T[2];\n" +
        "mr = med($T[0]); mg = med($T[1]); mb = med($T[2]);\n" +
        "MedianColor = avg(mr,mg,mb);\n" +
        "Linked = ((MedianColor-1)*" + targetMedian + "*$T)/(MedianColor*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T);\n" +
        "mY = cr*mr + cg*mg + cb*mb;\n" +
        "Yp = ((mY-1)*" + targetMedian + "*Y)/(mY*(" + targetMedian + "+Y-1)-" + targetMedian + "*Y);\n" +
        "f = iif(Y<=1.0e-10, 1, Yp/Y);\n" +
        "Luma = $T*f;\n" +
        "b=" + b + ";\n" +
        "((1-b)*Linked + b*Luma);";
    P002.useSingleExpression = true;
    P002.symbols = "cr,cg,cb,Y,mr,mg,mb,MedianColor,Linked,mY,Yp,f,Luma,b";
    configurePixelMath( P002, false );
    P.add( P002 );

    let P003 = new PixelMath;
    P003.expression = SHOParameters.normalizeImageRange
        ? "Mcolor=max(max($T[0]),max($T[1]),max($T[2]));\n$T/Mcolor;"
        : "$T;";
    P003.useSingleExpression = true;
    P003.symbols = "Mcolor";
    configurePixelMath( P003, true );
    P.add( P003 );

    if ( SHOParameters.hdrCompress && SHOParameters.hdrAmount > 0 )
        _addHdrCompressProcess( P, true );

    P.executeOn( targetView );
    console.noteln( "Color (Luma Blend) Statistical Stretch completed successfully for iteration " + iteration + "." );
}

function processColorImage_LumaOnly( targetView, targetMedian, iteration )
{
    let P = new ProcessContainer;
    let C = lumaCoeffs();
    let cr = C[0], cg = C[1], cb = C[2];

    let P001 = new PixelMath;
    P001.expression =
        "cr=" + cr + "; cg=" + cg + "; cb=" + cb + ";\n" +
        "Med = cr*med($T[0]) + cg*med($T[1]) + cb*med($T[2]);\n" +
        "Sig = 1.4826*(cr*MAD($T[0]) + cg*MAD($T[1]) + cb*MAD($T[2]));\n" +
        "MinC = min(min($T[0]),min($T[1]),min($T[2]));\n" +
        "BPraw = Med - " + SHOParameters.blackpointSigma + "*Sig;\n" +
        "BP = iif(" + (SHOParameters.noBlackClip ? "1" : "0") + ", MinC, iif(BPraw < MinC, MinC, BPraw));\n" +
        "Rescaled = ($T - BP) / (1 - BP);\n" +
        "Rescaled;";
    P001.useSingleExpression = true;
    P001.symbols = "cr,cg,cb,Med,Sig,MinC,BPraw,BP,Rescaled";
    configurePixelMath( P001, false );
    P.add( P001 );

    let P002 = new PixelMath;
    P002.expression =
        "cr=" + cr + "; cg=" + cg + "; cb=" + cb + ";\n" +
        "Y = cr*$T[0] + cg*$T[1] + cb*$T[2];\n" +
        "m = cr*med($T[0]) + cg*med($T[1]) + cb*med($T[2]);\n" +
        "Yp = ((m-1)*" + targetMedian + "*Y)/(m*(" + targetMedian + "+Y-1)-" + targetMedian + "*Y);\n" +
        "f = iif(Y<=1.0e-10, 1, Yp/Y);\n" +
        "$T*f;";
    P002.useSingleExpression = true;
    P002.symbols = "cr,cg,cb,Y,m,Yp,f";
    configurePixelMath( P002, false );
    P.add( P002 );

    let P003 = new PixelMath;
    P003.expression = SHOParameters.normalizeImageRange
        ? "Mcolor=max(max($T[0]),max($T[1]),max($T[2]));\n$T/Mcolor;"
        : "$T;";
    P003.useSingleExpression = true;
    P003.symbols = "Mcolor";
    configurePixelMath( P003, true );
    P.add( P003 );

    if ( SHOParameters.hdrCompress && SHOParameters.hdrAmount > 0 )
        _addHdrCompressProcess( P, true );

    P.executeOn( targetView );
    console.noteln( "Color (Luma Only) Statistical Stretch completed successfully for iteration " + iteration + "." );
}

function processUnlinkedColorImage( targetView, targetMedian, iteration )
{
    if ( SHOParameters.lumaOnly )
    {
        if ( SHOParameters.lumaBlend > 0.000001 )
        {
            processColorImage_LumaOnly( targetView, targetMedian, iteration );
            return;
        }
    }

    let P = new ProcessContainer;

    let P001 = new PixelMath;
    P001.useSingleExpression = false;

    let _bpExpr =
        "Med = med($T);\n" +
        "Sig = 1.4826*MAD($T);\n" +
        "BPraw = Med - " + SHOParameters.blackpointSigma + "*Sig;\n" +
        "BP = iif(" + (SHOParameters.noBlackClip ? "1" : "0") + ", min($T), iif(BPraw < min($T), min($T), BPraw));\n" +
        "Rescaled = ($T - BP) / (1 - BP);\n" +
        "Rescaled;";

    P001.expression  = _bpExpr;
    P001.expression1 = _bpExpr;
    P001.expression2 = _bpExpr;
    P001.symbols = "Med,Sig,BPraw,BP,Rescaled";
    configurePixelMath( P001, false );
    P.add( P001 );

    let b = Math.max( 0, Math.min( 1, SHOParameters.lumaBlend ) );
    let C = lumaCoeffs();
    let cr = C[0], cg = C[1], cb = C[2];

    let P002 = new PixelMath;
    P002.expression =
        "cr=" + cr + "; cg=" + cg + "; cb=" + cb + ";\n" +
        "Y = cr*$T[0] + cg*$T[1] + cb*$T[2];\n" +
        "mr = med($T[0]); mg = med($T[1]); mb = med($T[2]);\n" +
        "MedianColor = avg(mr,mg,mb);\n" +
        "Linked = ((MedianColor-1)*" + targetMedian + "*$T)/(MedianColor*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T);\n" +
        "mY = cr*mr + cg*mg + cb*mb;\n" +
        "Yp = ((mY-1)*" + targetMedian + "*Y)/(mY*(" + targetMedian + "+Y-1)-" + targetMedian + "*Y);\n" +
        "f = iif(Y<=1.0e-10, 1, Yp/Y);\n" +
        "Luma = $T*f;\n" +
        "b=" + b + ";\n" +
        "((1-b)*Linked + b*Luma);";
    P002.useSingleExpression = true;
    P002.symbols = "cr,cg,cb,Y,mr,mg,mb,MedianColor,Linked,mY,Yp,f,Luma,b";
    configurePixelMath( P002, false );
    P.add( P002 );

    let P003 = new PixelMath;
    P003.useSingleExpression = false;
    let _normExpr = SHOParameters.normalizeImageRange ? "$T/max($T)" : "$T;";
    P003.expression  = _normExpr;
    P003.expression1 = _normExpr;
    P003.expression2 = _normExpr;
    configurePixelMath( P003, true );
    P.add( P003 );

    if ( SHOParameters.hdrCompress && SHOParameters.hdrAmount > 0 )
        _addHdrCompressProcess( P, true );

    P.executeOn( targetView );
    console.noteln( "Unlinked Color Image Stretch completed successfully for iteration " + (iteration || 1) + "." );
}

// ============================================================================
// Global parameters object (persisted)
// ============================================================================

var SHOParameters = {
    targetViewId: undefined,
    targetMedian: 0.25,
    curvesBoost: 0.00,
    numIterations: 1,
    normalizeImageRange: false,
    linkedStretch: true,
    openDialogbox: true,
    autoConvergence: false,

    blackpointSigma: 5.0,
    noBlackClip: false,

    hdrCompress: false,
    hdrAmount: 0.25,
    hdrKnee: 0.35,

    lumaOnly: false,
    lumaMode: "rec709",
    lumaBlend: 0.60,

    targetView: undefined,

    save: function()
    {
        Parameters.set( "targetViewId",         this.targetViewId );
        Parameters.set( "targetMedian",         this.targetMedian );
        Parameters.set( "curvesBoost",          this.curvesBoost );
        Parameters.set( "numIterations",        this.numIterations );
        Parameters.set( "normalizeImageRange",  this.normalizeImageRange );
        Parameters.set( "linkedStretch",        this.linkedStretch );
        Parameters.set( "openDialogbox",        this.openDialogbox );
        Parameters.set( "autoConvergence",      this.autoConvergence );
        Parameters.set( "blackpointSigma",      this.blackpointSigma );
        Parameters.set( "noBlackClip",          this.noBlackClip );
        Parameters.set( "hdrCompress",          this.hdrCompress );
        Parameters.set( "hdrAmount",            this.hdrAmount );
        Parameters.set( "hdrKnee",              this.hdrKnee );
        Parameters.set( "lumaOnly",             this.lumaOnly );
        Parameters.set( "lumaMode",             this.lumaMode );
        Parameters.set( "lumaBlend",            this.lumaBlend );
    },

    load: function()
    {
        if ( Parameters.has( "targetViewId" ) )        this.targetViewId       = Parameters.getString( "targetViewId" );
        if ( Parameters.has( "targetMedian" ) )        this.targetMedian       = Parameters.getReal( "targetMedian" );
        if ( Parameters.has( "curvesBoost" ) )         this.curvesBoost        = Parameters.getReal( "curvesBoost" );
        if ( Parameters.has( "numIterations" ) )       this.numIterations      = Parameters.getInteger( "numIterations" );
        if ( Parameters.has( "normalizeImageRange" ) ) this.normalizeImageRange= Parameters.getBoolean( "normalizeImageRange" );
        if ( Parameters.has( "linkedStretch" ) )       this.linkedStretch      = Parameters.getBoolean( "linkedStretch" );
        if ( Parameters.has( "openDialogbox" ) )       this.openDialogbox      = Parameters.getBoolean( "openDialogbox" );
        if ( Parameters.has( "autoConvergence" ) )     this.autoConvergence    = Parameters.getBoolean( "autoConvergence" );
        if ( Parameters.has( "blackpointSigma" ) )     this.blackpointSigma    = Parameters.getReal( "blackpointSigma" );
        if ( Parameters.has( "noBlackClip" ) )         this.noBlackClip        = Parameters.getBoolean( "noBlackClip" );
        if ( Parameters.has( "hdrCompress" ) )         this.hdrCompress        = Parameters.getBoolean( "hdrCompress" );
        if ( Parameters.has( "hdrAmount" ) )           this.hdrAmount          = Parameters.getReal( "hdrAmount" );
        if ( Parameters.has( "hdrKnee" ) )             this.hdrKnee            = Parameters.getReal( "hdrKnee" );
        if ( Parameters.has( "lumaOnly" ) )            this.lumaOnly           = Parameters.getBoolean( "lumaOnly" );
        if ( Parameters.has( "lumaMode" ) )            this.lumaMode           = Parameters.getString( "lumaMode" );
        if ( Parameters.has( "lumaBlend" ) )           this.lumaBlend          = Parameters.getReal( "lumaBlend" );

        this.targetView = undefined;
        if ( this.targetViewId )
        {
            let w = ImageWindow.windowById( this.targetViewId );
            if ( w && !w.isNull )
                this.targetView = w.mainView;
        }

        if ( Parameters.isViewTarget && Parameters.targetView )
            this.targetView = Parameters.targetView;
    }
};

SHOParameters.load();

// ============================================================================
// ScrollControl (preview widget)
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.scrollPosition = new Point( 0, 0 );
        this.zoomFactor = 1.0;
        this.minZoomFactor = 0.1;
        this.maxZoomFactor = 10.0;
        this.autoScroll = true;
        this.tracking = true;
        this.displayImage = null;
        this.dragging = false;
        this.dragOrigin = new Point( 0, 0 );

        this.viewport.onResize = () =>
        {
            this.initScrollBars();
        };

        this.onHorizontalScrollPosUpdated = x =>
        {
            this.viewport.update();
        };

        this.onVerticalScrollPosUpdated = y =>
        {
            this.viewport.update();
        };

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
            this.dragging = true;
            this.dragOrigin = new Point( x, y );
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            const image = this.getImage();
            if ( !image ) return;

            if ( this.dragging )
            {
                this.scrollPosition = new Point( this.scrollPosition )
                    .translatedBy( this.dragOrigin.x - x, this.dragOrigin.y - y );
                this.dragOrigin.x = x;
                this.dragOrigin.y = y;
                this.viewport.update();
            }
            else
            {
                let imageX = Math.floor( x / this.zoomFactor + this.scrollPosition.x );
                let imageY = Math.floor( y / this.zoomFactor + this.scrollPosition.y );

                if ( imageX >= 0 && imageX < image.width && imageY >= 0 && imageY < image.height )
                {
                    if ( image.isColor )
                    {
                        let pixelValue = [
                            image.sample( imageX, imageY, 0 ),
                            image.sample( imageX, imageY, 1 ),
                            image.sample( imageX, imageY, 2 )
                        ];
                        if ( this.parent && this.parent.pixelValueLabel )
                            this.parent.pixelValueLabel.text =
                                "RGB: R=" + pixelValue[0].toFixed(3) +
                                ", G=" + pixelValue[1].toFixed(3) +
                                ", B=" + pixelValue[2].toFixed(3);
                    }
                    else
                    {
                        let v = image.sample( imageX, imageY );
                        if ( this.parent && this.parent.pixelValueLabel )
                            this.parent.pixelValueLabel.text = "K Value: " + v.toFixed(3);
                    }
                }
                else
                {
                    if ( this.parent && this.parent.pixelValueLabel )
                        this.parent.pixelValueLabel.text = "Pixel Value: Out of Bounds";
                }
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.Arrow );
            this.dragging = false;
        };

        this.viewport.onMouseWheel = ( x, y, delta ) =>
        {
            let oldZoom = this.zoomFactor;

            if ( delta > 0 )
                this.zoomFactor = Math.min( this.zoomFactor * 1.25, this.maxZoomFactor );
            else if ( delta < 0 )
                this.zoomFactor = Math.max( this.zoomFactor * 0.8, this.minZoomFactor );

            let zoomRatio = this.zoomFactor / oldZoom;
            this.scrollPosition = new Point(
                (this.scrollPosition.x + x) * zoomRatio - x,
                (this.scrollPosition.y + y) * zoomRatio - y
            );

            this.initScrollBars();
            this.viewport.update();
        };

        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this.viewport );
            let image = this.getImage();

            if ( !image )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
            }
            else
            {
                g.scaleTransformation( this.zoomFactor );
                g.translateTransformation( -this.scrollPosition.x, -this.scrollPosition.y );
                g.drawBitmap( 0, 0, image.render() );
            }
            g.end();
        };

        this.initScrollBars();
    }

    getImage()
    {
        return this.displayImage;
    }

    doUpdateImage( image )
    {
        if ( image )
            this.displayImage = image;
        this.scrollPosition = new Point( 0, 0 );
        this.initScrollBars();
        this.viewport.update();
    }

    initScrollBars()
    {
        const image = this.getImage();
        if ( !image || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange( 0, 0 );
            this.scrollPosition = new Point( 0, 0 );
        }
        else
        {
            const zoomedWidth  = image.width  * this.zoomFactor;
            const zoomedHeight = image.height * this.zoomFactor;

            this.setHorizontalScrollRange( 0, Math.max( 0, zoomedWidth  - this.viewport.width ) );
            this.setVerticalScrollRange(   0, Math.max( 0, zoomedHeight - this.viewport.height ) );

            this.scrollPosition = new Point(
                Math.min( this.scrollPosition.x, Math.max( 0, zoomedWidth  - this.viewport.width ) ),
                Math.min( this.scrollPosition.y, Math.max( 0, zoomedHeight - this.viewport.height ) )
            );
        }
        this.viewport.update();
    }
};

// ============================================================================
// Dialog
// ============================================================================

var MyDialog = class extends Dialog
{
    constructor()
    {
        super();

        this._instructionsText =
            "Select your image in the dropdown.\n\n" +
            "Target Median sets how bright the final stretch will be:\n" +
            "   0.10 is a good start for compact targets (galaxies / PN).\n" +
            "   0.25 is a good start for large nebula filling the frame.\n\n" +
            "Blackpoint Sigma controls how aggressively shadows are lifted:\n" +
            "   Higher values protect the background (darker result).\n" +
            "   Lower values lift more faint detail (brighter background).\n\n" +
            "No Black Clip prevents crushing true blacks:\n" +
            "   ON  = preserves the image minimum (safer for already-dark data).\n" +
            "   OFF = allows a computed blackpoint (more contrast, can clip if pushed).\n\n" +
            "HDR Compress tames bright cores/highlights after the stretch:\n" +
            "   HDR Amount controls strength (higher = more compression).\n" +
            "   HDR Knee sets where compression starts (lower = affects more of the image).\n\n" +
            "Luma Only (color images) stretches luminance and preserves chroma:\n" +
            "   Use Luma Mode to choose the luminance weighting (rec709 recommended).\n\n" +
            "   Luma Blend: 0 = normal linked stretch, 1 = pure luma-only.\n\n" +
            "Linked Stretch keeps RGB channels together (recommended for color balance).\n" +
            "Unlinked Stretch stretches each channel independently (can shift color).\n" +
            "Normalize scales the final result to fill the range [0,1].\n\n" +
            "Use Preview Refresh to update the preview.\n" +
            "MouseWheel or Zoom Buttons to zoom.";

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth( 600 );
        this.previewControl.setMinHeight( 450 );

        // ---- Title row ----
        this.titleBox = new Label( this );
        this.titleBox.text = "Statistical Stretch " + VERSION;
        this.titleBox.textAlignment = TextAlignment.Center;
        this.titleBox.frameStyle = FrameStyle.Box;
        this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0;";
        this.titleBox.setFixedHeight( 30 );

        this.titleRow = new HorizontalSizer;
        this.titleRow.spacing = 6;
        this.titleRow.add( this.titleBox, 100 );

        // ---- Instructions row ----
        this.instructionsLabel = new Label( this );
        this.instructionsLabel.text = "Instructions";
        this.instructionsLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.instructionsLabel.styleSheet = "font-size: 10pt; font-weight: bold;";

        this.helpButton = new ToolButton( this );
        this.helpButton.text = "?";
        this.helpButton.toolTip = "Show Instructions";
        this.helpButton.setFixedSize( 30, 22 );
        this.helpButton.onClick = () => { this._showInstructionsDialog(); };

        this.instructionsRow = new HorizontalSizer;
        this.instructionsRow.spacing = 6;
        this.instructionsRow.add( this.instructionsLabel );
        this.instructionsRow.add( this.helpButton );
        this.instructionsRow.addStretch();

        // ---- Image selection ----
        this.imageLabel = new Label( this );
        this.imageLabel.text = "Select Image to Stretch:";
        this.imageLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.imageList = new ComboBox( this );
        this.imageList.addItem( "Select an image" );
        this.imageList.maxWidth = 450;

        let activeWindow = ImageWindow.activeWindow;
        let activeWindowId = (activeWindow && !activeWindow.isNull) ? activeWindow.mainView.id : null;
        let foundActive = false;

        for ( let iw = 0; iw < ImageWindow.windows.length; ++iw )
        {
            let id = ImageWindow.windows[iw].mainView.id;
            this.imageList.addItem( id );
            if ( id === activeWindowId )
            {
                this.imageList.currentItem = iw + 1;
                foundActive = true;
            }
        }
        if ( !foundActive )
            this.imageList.currentItem = 0;

        this.imageSizer = new HorizontalSizer;
        this.imageSizer.spacing = 6;
        this.imageSizer.add( this.imageLabel );
        this.imageSizer.add( this.imageList, 1 );

        // ---- Target median ----
        this.targetMedianControl = new NumericControl( this );
        this.targetMedianControl.label.text = "Target Median:";
        this.targetMedianControl.setRange( 0, 1 );
        this.targetMedianControl.slider.setRange( 0, 100 );
        this.targetMedianControl.slider.scale = 0.01;
        this.targetMedianControl.setValue( SHOParameters.targetMedian );
        this.targetMedianControl.setPrecision( 2 );
        this.targetMedianControl.onValueUpdated = value =>
        {
            SHOParameters.targetMedian = value;
        };

        // ---- Blackpoint Sigma ----
        this.bpSigmaControl = new NumericControl( this );
        this.bpSigmaControl.label.text = "Blackpoint Sigma:";
        this.bpSigmaControl.setRange( 0.0, 10.0 );
        this.bpSigmaControl.slider.setRange( 0, 1000 );
        this.bpSigmaControl.slider.scale = 0.01;
        this.bpSigmaControl.setValue( SHOParameters.blackpointSigma );
        this.bpSigmaControl.setPrecision( 2 );
        this.bpSigmaControl.toolTip = "How many robust sigmas below median to set blackpoint.";
        this.bpSigmaControl.onValueUpdated = v =>
        {
            SHOParameters.blackpointSigma = v;
            this.clippedPixelsLabel.text = "Clipped pixels: (not calculated)";
        };

        // ---- Clipped pixels ----
        this.clippedPixelsLabel = new Label( this );
        this.clippedPixelsLabel.text = "Clipped pixels: (not calculated)";
        this.clippedPixelsLabel.textAlignment = TextAlignment.Left;
        this.clippedPixelsLabel.styleSheet = "font-size: 9pt; padding: 6px; background-color: #f7f7ff;";

        this.calcClippedButton = new PushButton( this );
        this.calcClippedButton.text = "Calculate Clipped Pixels";
        this.calcClippedButton.toolTip =
            "Estimates how many pixels fall below the Blackpoint Sigma threshold (Step 1).\n" +
            "Large images are sampled for speed; result is an estimate.";
        this.calcClippedButton.onClick = () =>
        {
            if ( this.imageList.currentItem <= 0 )
            {
                new MessageBox( "No image selected.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
                return;
            }

            let w = ImageWindow.windowById( this.imageList.itemText( this.imageList.currentItem ) );
            if ( !w || w.isNull )
            {
                new MessageBox( "Selected view is not available.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
                return;
            }

            SHOParameters.noBlackClip    = this.noBlackClipCheckbox.checked;
            SHOParameters.linkedStretch  = this.linkedStretchCheckbox.checked;
            SHOParameters.lumaOnly       = this.lumaOnlyCheckbox.checked;
            SHOParameters.lumaMode       = this.lumaModeCombo.itemText( this.lumaModeCombo.currentItem );
            SHOParameters.lumaBlend      = this.lumaBlendControl.value;

            let img = new Image( w.mainView.image );
            let r = _estimateClippedPixels_Blackpoint( img, 1000000 );
            let pct = (r.total > 0) ? (100.0 * r.clippedEst / r.total) : 0.0;
            let estTag = (r.stride === 1) ? "Exact" : "Estimated";

            let bpText = "";
            if ( r.bpInfo.mode === "unlinked" )
            {
                bpText = "BP(R,G,B)=(" +
                    r.bpInfo.bp[0].toFixed(6) + ", " +
                    r.bpInfo.bp[1].toFixed(6) + ", " +
                    r.bpInfo.bp[2].toFixed(6) + ")";
            }
            else
            {
                bpText = "BP=" + r.bpInfo.bp.toFixed(6);
            }

            this.clippedPixelsLabel.text =
                "Clipped pixels: " + _fmtInt( r.clippedEst ) + " / " + _fmtInt( r.total ) +
                "  (" + pct.toFixed(4) + "%) " + estTag + "  •  " + bpText;
        };

        // ---- No Black Clip ----
        this.noBlackClipCheckbox = new CheckBox( this );
        this.noBlackClipCheckbox.text = "No Black Clip";
        this.noBlackClipCheckbox.checked = SHOParameters.noBlackClip;
        this.noBlackClipCheckbox.toolTip = "If enabled, preserves true blacks by keeping BP at min().";
        this.noBlackClipCheckbox.onCheck = checked =>
        {
            SHOParameters.noBlackClip = checked;
            this.clippedPixelsLabel.text = "Clipped pixels: (not calculated)";
        };

        // ---- HDR controls ----
        this.hdrCompressCheckbox = new CheckBox( this );
        this.hdrCompressCheckbox.text = "HDR Compress (SASpro style)";
        this.hdrCompressCheckbox.checked = SHOParameters.hdrCompress;
        this.hdrCompressCheckbox.onCheck = checked =>
        {
            SHOParameters.hdrCompress = checked;
            this._updateHdrUiEnabled();
        };

        this.hdrAmountControl = new NumericControl( this );
        this.hdrAmountControl.label.text = "HDR Amount:";
        this.hdrAmountControl.setRange( 0.0, 1.0 );
        this.hdrAmountControl.slider.setRange( 0, 1000 );
        this.hdrAmountControl.slider.scale = 0.001;
        this.hdrAmountControl.setValue( SHOParameters.hdrAmount );
        this.hdrAmountControl.setPrecision( 2 );
        this.hdrAmountControl.onValueUpdated = v => { SHOParameters.hdrAmount = v; };

        this.hdrKneeControl = new NumericControl( this );
        this.hdrKneeControl.label.text = "HDR Knee:";
        this.hdrKneeControl.setRange( 0.10, 1.00 );
        this.hdrKneeControl.slider.setRange( 10, 1000 );
        this.hdrKneeControl.slider.scale = 0.001;
        this.hdrKneeControl.setValue( SHOParameters.hdrKnee );
        this.hdrKneeControl.setPrecision( 2 );
        this.hdrKneeControl.onValueUpdated = v => { SHOParameters.hdrKnee = v; };

        // ---- Luma-only controls ----
        this.lumaOnlyCheckbox = new CheckBox( this );
        this.lumaOnlyCheckbox.text = "Luma Only (preserve color)";
        this.lumaOnlyCheckbox.checked = SHOParameters.lumaOnly;
        this.lumaOnlyCheckbox.toolTip = "Stretches luminance only and rescales RGB to preserve chroma.";
        this.lumaOnlyCheckbox.onCheck = checked =>
        {
            SHOParameters.lumaOnly = checked;
            this.lumaModeCombo.enabled = checked;
            this.lumaBlendControl.enabled = checked;
            this._enforceLumaOnlyRules();
            this._updateLumaUiEnabled();
        };

        this.lumaModeLabel = new Label( this );
        this.lumaModeLabel.text = "Luma Mode:";
        this.lumaModeLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.lumaModeCombo = new ComboBox( this );
        this.lumaModeCombo.addItem( "rec709" );
        this.lumaModeCombo.addItem( "rec601" );
        this.lumaModeCombo.addItem( "rec2020" );
        this.lumaModeCombo.currentItem = Math.max( 0, ["rec709","rec601","rec2020"].indexOf( SHOParameters.lumaMode || "rec709" ) );
        this.lumaModeCombo.onItemSelected = idx =>
        {
            SHOParameters.lumaMode = this.lumaModeCombo.itemText( idx );
        };

        this.lumaModeSizer = new HorizontalSizer;
        this.lumaModeSizer.spacing = 6;
        this.lumaModeSizer.add( this.lumaModeLabel );
        this.lumaModeSizer.add( this.lumaModeCombo, 1 );

        this.lumaBlendControl = new NumericControl( this );
        this.lumaBlendControl.label.text = "Luma Blend:";
        this.lumaBlendControl.setRange( 0.0, 1.0 );
        this.lumaBlendControl.slider.setRange( 0, 1000 );
        this.lumaBlendControl.slider.scale = 0.001;
        this.lumaBlendControl.setValue( SHOParameters.lumaBlend );
        this.lumaBlendControl.setPrecision( 2 );
        this.lumaBlendControl.toolTip = "0 = normal linked stretch, 1 = pure luma-only stretch.";
        this.lumaBlendControl.onValueUpdated = v =>
        {
            SHOParameters.lumaBlend = v;
        };

        // ---- Normalize + Linked row ----
        this.normalizeImageRangeCheckbox = new CheckBox( this );
        this.normalizeImageRangeCheckbox.text = "Normalize Image Range to [0,1]";
        this.normalizeImageRangeCheckbox.checked = SHOParameters.normalizeImageRange;
        this.normalizeImageRangeCheckbox.onCheck = checked =>
        {
            SHOParameters.normalizeImageRange = checked;
        };

        this.linkedStretchCheckbox = new CheckBox( this );
        this.linkedStretchCheckbox.text = "Linked Stretch";
        this.linkedStretchCheckbox.checked = SHOParameters.linkedStretch;
        this.linkedStretchCheckbox.toolTip = "Uncheck to perform Unlinked Stretch.";
        this.linkedStretchCheckbox.onCheck = checked =>
        {
            SHOParameters.linkedStretch = checked;
        };

        this.checkboxSizer = new HorizontalSizer;
        this.checkboxSizer.spacing = 6;
        this.checkboxSizer.add( this.normalizeImageRangeCheckbox );
        this.checkboxSizer.addStretch();
        this.checkboxSizer.add( this.linkedStretchCheckbox );

        // ---- Curves boost ----
        this.curvesBoostSlider = new NumericControl( this );
        this.curvesBoostSlider.label.text = "Curves Boost:";
        this.curvesBoostSlider.setRange( 0.00, 0.50 );
        this.curvesBoostSlider.slider.setRange( 0, 500 );
        this.curvesBoostSlider.slider.scale = 0.001;
        this.curvesBoostSlider.setValue( SHOParameters.curvesBoost );
        this.curvesBoostSlider.setPrecision( 2 );
        this.curvesBoostSlider.onValueUpdated = value =>
        {
            SHOParameters.curvesBoost = value;
        };

        // ---- Pixel readout ----
        this.pixelValueLabel = new Label( this );
        this.pixelValueLabel.text = "Pixel Value: ";
        this.pixelValueLabel.styleSheet = "font-size: 10pt; padding: 5px; background-color: #e6e6fa;";
        this.pixelValueLabel.textAlignment = TextAlignment.Left;

        // ---- Buttons row ----
        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "New Instance";
        this.newInstanceButton.onMousePress = () =>
        {
            SHOParameters.save();
            this.newInstance();
        };

        this.zoomLabel = new Label( this );
        this.zoomLabel.text = "Preview Zoom Level: ";
        this.zoomLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.zoomLevelComboBox = new ComboBox( this );
        this.zoomLevelComboBox.addItem( "1:1" );
        this.zoomLevelComboBox.addItem( "1:2" );
        this.zoomLevelComboBox.addItem( "1:4" );
        this.zoomLevelComboBox.addItem( "1:8" );
        this.zoomLevelComboBox.addItem( "Fit to Preview" );
        this.zoomLevelComboBox.currentItem = 4;
        this.zoomLevelComboBox.onItemSelected = index =>
        {
            if ( this.imageList.currentItem > 0 )
            {
                let w = ImageWindow.windowById( this.imageList.itemText( this.imageList.currentItem ) );
                if ( w && !w.isNull && w.mainView.image )
                    this.processPreview( w.mainView.image );
            }
        };

        this.zoomSizer = new HorizontalSizer;
        this.zoomSizer.spacing = 4;
        this.zoomSizer.add( this.zoomLabel );
        this.zoomSizer.add( this.zoomLevelComboBox, 1 );

        this.executeButton = new PushButton( this );
        this.executeButton.text = "Execute";
        this.executeButton.onClick = () =>
        {
            this.executeAlgorithm( SHOParameters.numIterations );
        };

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.spacing = 6;
        this.buttonSizer.add( this.newInstanceButton );
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.zoomSizer );
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.executeButton );

        this.previewButton = new PushButton( this );
        this.previewButton.text = "Preview Refresh";
        this.previewButton.onClick = () =>
        {
            if ( this.imageList.currentItem > 0 )
            {
                let w = ImageWindow.windowById( this.imageList.itemText( this.imageList.currentItem ) );
                if ( w && !w.isNull && w.mainView.image )
                    this.processPreview( w.mainView.image );
            }
            else
            {
                console.writeln( "No image selected for preview!" );
            }
        };

        // ---- Right side: zoom buttons + preview ----
        this.zoomInButton = new PushButton( this );
        this.zoomInButton.text = "Zoom In";
        this.zoomInButton.onClick = () =>
        {
            this.previewControl.zoomFactor = Math.min( this.previewControl.zoomFactor * 1.25, this.previewControl.maxZoomFactor );
            this.previewControl.initScrollBars();
            this.previewControl.viewport.update();
        };

        this.zoomOutButton = new PushButton( this );
        this.zoomOutButton.text = "Zoom Out";
        this.zoomOutButton.onClick = () =>
        {
            this.previewControl.zoomFactor = Math.max( this.previewControl.zoomFactor * 0.8, this.previewControl.minZoomFactor );
            this.previewControl.initScrollBars();
            this.previewControl.viewport.update();
        };

        this.zoomButtonSizer = new HorizontalSizer;
        this.zoomButtonSizer.spacing = 6;
        this.zoomButtonSizer.add( this.zoomInButton );
        this.zoomButtonSizer.add( this.zoomOutButton );

        this.previewSizer = new VerticalSizer;
        this.previewSizer.spacing = 6;
        this.previewSizer.add( this.zoomButtonSizer );
        this.previewSizer.add( this.previewControl, 1 );

        // ---- Left sizer assembly ----
        this.leftSizer = new VerticalSizer;
        this.leftSizer.spacing = 6;
        this.leftSizer.add( this.titleRow );
        this.leftSizer.add( this.instructionsRow );
        this.leftSizer.add( this.imageSizer );
        this.leftSizer.add( this.targetMedianControl );
        this.leftSizer.add( this.bpSigmaControl );
        this.leftSizer.add( this.clippedPixelsLabel );
        this.leftSizer.add( this.calcClippedButton );
        this.leftSizer.add( this.noBlackClipCheckbox );
        this.leftSizer.add( this.hdrCompressCheckbox );
        this.leftSizer.add( this.hdrAmountControl );
        this.leftSizer.add( this.hdrKneeControl );
        this.leftSizer.add( this.lumaOnlyCheckbox );
        this.leftSizer.add( this.lumaModeSizer );
        this.leftSizer.add( this.lumaBlendControl );
        this.leftSizer.add( this.checkboxSizer );
        this.leftSizer.add( this.curvesBoostSlider );
        this.leftSizer.add( this.pixelValueLabel );
        this.leftSizer.add( this.buttonSizer );
        this.leftSizer.add( this.previewButton );

        // ---- Main sizer ----
        this.mainSizer = new HorizontalSizer;
        this.mainSizer.spacing = 6;
        this.mainSizer.margin = 10;
        this.mainSizer.add( this.leftSizer );
        this.mainSizer.add( this.previewSizer, 1 );

        this.sizer = this.mainSizer;
        this.windowTitle = TITLE;

        // ---- Wire up initial state ----
        this._updateHdrUiEnabled();
        this._enforceLumaOnlyRules();

        // ---- Image list handler ----
        this.imageList.onItemSelected = index =>
        {
            if ( index <= 0 ) return;

            let w = ImageWindow.windowById( this.imageList.itemText( index ) );
            if ( !w || w.isNull ) return;

            let selectedImage = w.mainView.image;
            if ( !selectedImage ) return;

            SHOParameters.targetViewId = w.mainView.id;
            SHOParameters.targetView   = w.mainView;
            SHOParameters.save();

            this._updateLumaUiEnabled();
            this._enforceLumaOnlyRules();

            let tmpImage = this.createTemporaryImage( selectedImage );
            this.previewControl.displayImage = tmpImage;
            this.previewControl.initScrollBars();
            this.previewControl.viewport.update();

            this.processPreview( selectedImage );
        };

        this.onShow = () =>
        {
            if ( this.imageList.currentItem > 0 )
            {
                let w = ImageWindow.windowById( this.imageList.itemText( this.imageList.currentItem ) );
                if ( w && !w.isNull && w.mainView.image )
                {
                    let tmpImage = this.createTemporaryImage( w.mainView.image );
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();

                    this._updateLumaUiEnabled();
                    this._enforceLumaOnlyRules();
                }
            }
        };

        this.adjustToContents();
    }

    // ---- Helper methods ----

    _showInstructionsDialog()
    {
        let dlg = new ( class extends Dialog
        {
            constructor( text )
            {
                super();
                this.windowTitle = TITLE + " - Instructions";

                this.sizer = new VerticalSizer;
                this.sizer.margin = 10;
                this.sizer.spacing = 6;

                let box = new TextBox( this );
                box.readOnly = true;
                box.wordWrapping = true;
                box.styleSheet = "font-size: 9pt; padding: 8px; background-color: #f7f7ff;";
                box.setMinSize( 520, 500 );
                box.text = text;
                try { box.cursorPosition = 0; } catch (e) {}
                try { box.setSelection( 0, 0 ); } catch (e) {}

                this.sizer.add( box, 100 );

                let btnRow = new HorizontalSizer;
                btnRow.addStretch();
                let closeBtn = new PushButton( this );
                closeBtn.text = "Close";
                closeBtn.onClick = () => { this.ok(); };
                btnRow.add( closeBtn );
                this.sizer.add( btnRow );
                this.adjustToContents();
            }
        } )( this._instructionsText );

        dlg.execute();
    }

    _updateHdrUiEnabled()
    {
        let en = !!SHOParameters.hdrCompress;
        this.hdrAmountControl.enabled = en;
        this.hdrKneeControl.enabled   = en;
    }

    _enforceLumaOnlyRules()
    {
        if ( SHOParameters.lumaOnly )
        {
            this.linkedStretchCheckbox.checked = true;
            SHOParameters.linkedStretch = true;
            this.linkedStretchCheckbox.enabled = false;
        }
        else
        {
            this.linkedStretchCheckbox.enabled = true;
        }
    }

    _updateLumaUiEnabled()
    {
        let isColor = false;
        if ( this.imageList.currentItem > 0 )
        {
            let w = ImageWindow.windowById( this.imageList.itemText( this.imageList.currentItem ) );
            if ( w && !w.isNull && w.mainView && w.mainView.image )
                isColor = !!w.mainView.image.isColor;
        }

        this.lumaOnlyCheckbox.enabled = isColor;

        if ( !isColor )
        {
            this.lumaOnlyCheckbox.checked = false;
            SHOParameters.lumaOnly = false;
        }

        let en = isColor && !!SHOParameters.lumaOnly;
        this.lumaModeCombo.enabled    = en;
        this.lumaBlendControl.enabled = en;
    }

    createTemporaryImage( selectedImage )
    {
        let window = new ImageWindow(
            selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        window.mainView.beginProcess();
        window.mainView.image.assign( selectedImage );
        window.mainView.endProcess();

        let P = new IntegerResample;

        switch ( this.zoomLevelComboBox.currentItem )
        {
        case 0: P.zoomFactor = -1; break;
        case 1: P.zoomFactor = -2; break;
        case 2: P.zoomFactor = -4; break;
        case 3: P.zoomFactor = -8; break;
        case 4:
            {
                let previewWidth = this.previewControl.width;
                let widthScale = Math.floor( selectedImage.width / previewWidth );
                P.zoomFactor = -Math.max( widthScale, 1 );
            }
            break;
        default:
            P.zoomFactor = -2;
            break;
        }

        P.executeOn( window.mainView );

        let resizedImage = new Image( window.mainView.image );

        if ( resizedImage.width > 0 && resizedImage.height > 0 )
        {
            this.previewControl.displayImage = resizedImage;
            this.previewControl.doUpdateImage( resizedImage );
            this.previewControl.initScrollBars();
        }
        else
        {
            console.error( "Resized image has invalid dimensions." );
        }

        window.forceClose();
        return resizedImage;
    }

    processPreview( selectedImage )
    {
        let processingWindow = new ImageWindow(
            selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        if ( !processingWindow || processingWindow.isNull )
        {
            console.writeln( "Failed to create processing window." );
            return;
        }

        processingWindow.hide();
        processingWindow.mainView.beginProcess();
        processingWindow.mainView.image.assign( selectedImage );
        processingWindow.mainView.endProcess();

        let iterations = SHOParameters.autoConvergence ? 5 : SHOParameters.numIterations;
        iterations = Math.min( iterations, 5 );

        for ( let i = 0; i < iterations; i++ )
        {
            if ( processingWindow.mainView.image.isColor )
            {
                if ( this.linkedStretchCheckbox.checked )
                    processColorImage( processingWindow.mainView, SHOParameters.targetMedian, i + 1 );
                else
                    processUnlinkedColorImage( processingWindow.mainView, SHOParameters.targetMedian, i + 1 );
            }
            else
            {
                processMonoImage( processingWindow.mainView, SHOParameters.targetMedian, i + 1 );
            }

            if ( SHOParameters.autoConvergence )
            {
                let currentMedian = calculate_image_median( processingWindow.mainView.image );
                if ( Math.abs( currentMedian - SHOParameters.targetMedian ) < 0.001 )
                    break;
            }
        }

        if ( SHOParameters.curvesBoost > 0 )
            applyFinalCurve( processingWindow.mainView, SHOParameters.targetMedian );

        let tempImage = this.createTemporaryImage( processingWindow.mainView.image );
        if ( tempImage )
            this.previewControl.doUpdateImage( tempImage );

        processingWindow.forceClose();
    }

    executeAlgorithm( numIterations )
    {
        if ( this.imageList.currentItem <= 0 )
        {
            new MessageBox( "No image selected for processing.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
            return;
        }

        let window = ImageWindow.windowById( this.imageList.itemText( this.imageList.currentItem ) );
        if ( !window || window.isNull )
        {
            new MessageBox( "Selected view is not available.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
            return;
        }

        let targetView = window.mainView;

        SHOParameters.linkedStretch        = this.linkedStretchCheckbox.checked;
        SHOParameters.normalizeImageRange  = this.normalizeImageRangeCheckbox.checked;
        SHOParameters.lumaOnly             = this.lumaOnlyCheckbox.checked;
        SHOParameters.lumaMode             = this.lumaModeCombo.itemText( this.lumaModeCombo.currentItem );
        SHOParameters.lumaBlend            = this.lumaBlendControl.value;
        SHOParameters.save();

        let iterations = SHOParameters.autoConvergence
            ? 5
            : (numIterations !== undefined ? numIterations : SHOParameters.numIterations);
        iterations = Math.min( iterations, 5 );

        let converged = false;

        for ( let i = 0; i < iterations; i++ )
        {
            if ( targetView.image.isColor )
            {
                if ( SHOParameters.linkedStretch )
                    processColorImage( targetView, SHOParameters.targetMedian, i + 1 );
                else
                    processUnlinkedColorImage( targetView, SHOParameters.targetMedian, i + 1 );
            }
            else
            {
                processMonoImage( targetView, SHOParameters.targetMedian, i + 1 );
            }

            let currentMedian = calculate_image_median( targetView.image );
            if ( Math.abs( currentMedian - SHOParameters.targetMedian ) < 0.001 )
            {
                converged = true;
                break;
            }
        }

        if ( !converged )
            console.noteln( "Convergence not achieved within " + iterations + " iterations." );

        if ( SHOParameters.curvesBoost > 0 )
            applyFinalCurve( targetView, SHOParameters.targetMedian );
        else
            console.writeln( "Curves boost is set to zero, skipping final curve application." );

        disableSTF( targetView );
    }
};

// ============================================================================
// Main entry
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln( " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );

    SHOParameters.load();

    if ( Parameters.isGlobalTarget )
    {
        console.criticalln( "This script cannot run in a global context." );
        return;
    }

    if ( Parameters.isViewTarget && Parameters.targetView )
    {
        SHOParameters.targetView   = Parameters.targetView;
        SHOParameters.targetViewId = Parameters.targetView.id;
        SHOParameters.save();

        if ( SHOParameters.openDialogbox )
        {
            let dlg = new MyDialog();

            for ( let i = 1; i < dlg.imageList.numberOfItems; ++i )
            {
                if ( dlg.imageList.itemText( i ) === SHOParameters.targetViewId )
                {
                    dlg.imageList.currentItem = i;
                    break;
                }
            }

            dlg.execute();
            return;
        }

        let iterations = SHOParameters.autoConvergence ? 5 : SHOParameters.numIterations;
        iterations = Math.min( iterations, 5 );

        for ( let i = 0; i < iterations; i++ )
        {
            if ( SHOParameters.targetView.image.isColor )
            {
                if ( SHOParameters.linkedStretch )
                    processColorImage( SHOParameters.targetView, SHOParameters.targetMedian, i + 1 );
                else
                    processUnlinkedColorImage( SHOParameters.targetView, SHOParameters.targetMedian, i + 1 );
            }
            else
            {
                processMonoImage( SHOParameters.targetView, SHOParameters.targetMedian, i + 1 );
            }

            let currentMedian = calculate_image_median( SHOParameters.targetView.image );
            if ( Math.abs( currentMedian - SHOParameters.targetMedian ) < 0.001 )
                break;
        }

        if ( SHOParameters.curvesBoost > 0 )
            applyFinalCurve( SHOParameters.targetView, SHOParameters.targetMedian );

        disableSTF( SHOParameters.targetView );
        return;
    }

    let dlg = new MyDialog();
    if ( dlg.execute() )
        dlg.executeAlgorithm( SHOParameters.numIterations );
    else
        console.noteln( "Statistical Stretch Dialog Closed." );
}

main();
