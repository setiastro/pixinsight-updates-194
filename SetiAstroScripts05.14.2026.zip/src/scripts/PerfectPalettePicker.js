#engine v8

#feature-id PerfectPalettePicker : SetiAstro > Perfect Palette Picker
#feature-icon  palettepicker.svg
#feature-info Script to combine images into various palettes.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 * Perfect Palette Picker
 * Version: 1.2
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define VERSION "1.2"

// ============================================================================
// PixelMath stretch helper
// ============================================================================

function processMonoImage( targetView, targetMedian, iteration )
{
    console.writeln( "processMonoImage(", targetView.id,
                     ") iteration #", iteration,
                     " => targetMedian=", targetMedian );

    let P = new ProcessContainer;

    let P001 = new PixelMath;
    P001.expression =
        "BlackPoint = iif((med($T) - 2.7*sdev($T))<min($T), min($T), med($T) - 2.7*sdev($T));\n" +
        "Rescaled   = ($T - BlackPoint) / (1 - BlackPoint);";
    P001.useSingleExpression  = true;
    P001.symbols              = "BlackPoint, Rescaled, CurrentMedian, DesiredMedian, Alpha";
    P001.clearImageCacheAndExit = false; P001.cacheGeneratedImages = false;
    P001.generateOutput = true; P001.singleThreaded = false; P001.optimization = true;
    P001.use64BitWorkingImage = true; P001.rescale = false;
    P001.truncate = true; P001.truncateLower = 0; P001.truncateUpper = 1;
    P001.createNewImage = false; P001.showNewImage = true;
    P.add( P001 );

    let P002 = new PixelMath;
    P002.expression =
        "((Med($T)-1)*" + targetMedian + "*$T)/" +
        "(Med($T)*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
    P002.useSingleExpression  = true; P002.symbols = "L, S";
    P002.clearImageCacheAndExit = false; P002.cacheGeneratedImages = false;
    P002.generateOutput = true; P002.singleThreaded = false; P002.optimization = true;
    P002.use64BitWorkingImage = true; P002.rescale = false;
    P002.truncate = true; P002.truncateLower = 0; P002.truncateUpper = 1;
    P002.createNewImage = false; P002.showNewImage = true;
    P.add( P002 );

    P.executeOn( targetView );
}

// ============================================================================
// Downsample 4× helper
// ============================================================================

function downsample4x( view )
{
    console.writeln( "Downsampling: ", view.id, " by 4× ..." );
    let P = new IntegerResample;
    P.zoomFactor        = -4;
    P.downsamplingMode  = IntegerResample.Average;
    P.xResolution       = 72.000;
    P.yResolution       = 72.000;
    P.metric            = false;
    P.forceResolution   = false;
    P.gammaCorrection   = false;
    P.noGUIMessages     = true;
    P.executeOn( view );
}

// ============================================================================
// OSC channel extraction
// ============================================================================

function extractOSCchannels( mainView )
{
    if ( mainView.image.numberOfChannels < 3 )
    {
        console.warningln( "[!] The image has fewer than 3 channels—skipping extraction." );
        return [];
    }

    let P = new ChannelExtraction;
    P.colorSpace  = ChannelExtraction.RGB;
    P.channels    = [
        [ true, "" + mainView.id + "_pppR" ],
        [ true, "" + mainView.id + "_pppG" ],
        [ true, "" + mainView.id + "_pppB" ]
    ];
    P.sampleFormat                = ChannelExtraction.SameAsSource;
    P.inheritAstrometricSolution  = true;
    P.executeOn( mainView );

    let baseId = mainView.id;
    let Rwin = ImageWindow.windowById( baseId + "_pppR" );
    let Gwin = ImageWindow.windowById( baseId + "_pppG" );
    let Bwin = ImageWindow.windowById( baseId + "_pppB" );

    if ( !Rwin || !Gwin || !Bwin )
    {
        console.warningln( "[!] ChannelExtraction: some channel windows not found for base ID:", baseId );
        return [];
    }

    Rwin.hide(); Gwin.hide(); Bwin.hide();
    return [ Rwin.mainView, Gwin.mainView, Bwin.mainView ];
}

// ============================================================================
// Combine 3 mono views → single colour ImageWindow via PixelMath
// ============================================================================

function combineChannelsToColor( chViews, outputId )
{
    let referenceView = chViews[0] || chViews[1] || chViews[2];
    if ( !referenceView ) { console.warningln( "No valid channels to combine—aborting." ); return null; }

    let width  = referenceView.image.width;
    let height = referenceView.image.height;
    let bits   = referenceView.image.bitsPerSample;
    let real   = referenceView.image.isReal;

    let targetWin = new ImageWindow( width, height, 3, bits, real, true, outputId );
    targetWin.mainView.beginProcess();
    targetWin.mainView.image.fill( 0 );
    targetWin.mainView.endProcess();

    let exprR = chViews[0] ? chViews[0].id : "0";
    let exprG = chViews[1] ? chViews[1].id : "0";
    let exprB = chViews[2] ? chViews[2].id : "0";

    let PM = new PixelMath;
    PM.useSingleExpression = false;
    PM.expression  = exprR;
    PM.expression1 = exprG;
    PM.expression2 = exprB;
    PM.expression3 = "";
    PM.createNewImage = false; PM.showNewImage = false;
    PM.clearImageCacheAndExit = false; PM.cacheGeneratedImages = false;
    PM.generateOutput = true; PM.singleThreaded = false; PM.optimization = true;
    PM.use64BitWorkingImage = false; PM.rescale = false;
    PM.truncate = true; PM.truncateLower = 0; PM.truncateUpper = 1;
    PM.executeOn( targetWin.mainView );

    return targetWin.mainView;
}

// ============================================================================
// Palette channel mapping
// ============================================================================

function mapChannels( paletteName, Ha, OIII, SII )
{
    let usedHa  = (Ha  !== null && Ha  !== undefined) ? Ha  : SII;
    let usedSII = (SII !== null && SII !== undefined) ? SII : Ha;
    if ( (Ha === null || Ha === undefined) && (SII === null || SII === undefined) )
        usedHa = usedSII = null;

    switch ( paletteName )
    {
    case "SHO": return [usedSII, usedHa,  OIII];
    case "HOO": return [usedHa,  OIII,    OIII];
    case "HSO": return [usedHa,  usedSII, OIII];
    case "HOS": return [usedHa,  OIII,    usedSII];
    case "OSS": return [OIII,    usedSII, usedSII];
    case "OHH": return [OIII,    usedHa,  usedHa];
    case "OSH": return [OIII,    usedSII, usedHa];
    case "OHS": return [OIII,    usedHa,  usedSII];
    case "HSS": return [usedHa,  usedSII, usedSII];
    default:
        return [
            usedSII ? usedSII.id : "0",
            usedHa  ? usedHa.id  : "0",
            OIII    ? OIII.id    : "0"
        ];
    }
}

// ============================================================================
// PerfectPalettePickerDialog
// ============================================================================

var PerfectPalettePickerDialog = class extends Dialog
{
    constructor()
    {
        super();

        // ---- State ----
        this.previewScale = 1.0;
        this.previewHa    = null;
        this.previewOIII  = null;
        this.previewSII   = null;
        this.previewR     = null;
        this.previewG     = null;
        this.previewB     = null;
        this.finalHa      = null;
        this.finalOIII    = null;
        this.finalSII     = null;

        // ---- Left panel ----
        this.leftPanel = new Control( this );
        this.leftPanel.sizer = new VerticalSizer;
        this.leftPanel.sizer.margin  = 4;
        this.leftPanel.sizer.spacing = 4;
        this.leftPanel.setFixedWidth( 300 );

        this.titleLabel = new Label( this.leftPanel );
        this.titleLabel.text = "Perfect Palette Picker v" + VERSION;
        this.titleLabel.textAlignment = TextAlignment.Center;
        this.titleLabel.styleSheet = "font-size:14pt; font-weight:bold;";

        this.instructionLabel = new Label( this.leftPanel );
        this.instructionLabel.text =
            "Instructions:\n" +
            "1. Add narrowband images or OSC camera\n images.You can use both OSC dropdowns\n if you have 2 dual filters\n" +
            "2. Check the 'Linear Data' checkbox if the\n images are linear.\n" +
            "3. Click 'Create Palettes' to generate the\n palettes.\n" +
            "4. Use the Zoom buttons to zoom in and out.\n" +
            "5. Resize the UI by dragging the lower right\n corner.\n" +
            "6. Click on a palette from the preview\n selection to generate that palette. \n\nMultiple palettes can be generated.";
        this.instructionLabel.textAlignment = TextAlignment.Left;
        this.instructionLabel.styleSheet = "font-size: 8pt; padding: 10px; background-color: #e6e6fa;";
        this.instructionLabel.setFixedHeight( 230 );

        this.linearCheckbox = new CheckBox( this.leftPanel );
        this.linearCheckbox.text    = "Linear Input Data";
        this.linearCheckbox.checked = true;
        this.linearCheckbox.toolTip = "<p>When checked, we apply the 0.25 stretch for previews/final images.</p>";

        // ---- Channel dropdowns ----
        this.labelHa   = new Label( this.leftPanel ); this.labelHa.text   = "Ha:";
        this.comboHa   = new ComboBox( this.leftPanel ); this.comboHa.addItem( " — None — " );

        this.labelOIII = new Label( this.leftPanel ); this.labelOIII.text = "OIII:";
        this.comboOIII = new ComboBox( this.leftPanel ); this.comboOIII.addItem( " — None — " );

        this.labelSII  = new Label( this.leftPanel ); this.labelSII.text  = "SII:";
        this.comboSII  = new ComboBox( this.leftPanel ); this.comboSII.addItem( " — None — " );

        this.labelOSC  = new Label( this.leftPanel ); this.labelOSC.text  = "OSC HaO3 Dual:";
        this.comboOSC  = new ComboBox( this.leftPanel ); this.comboOSC.addItem( " — None — " );

        this.labelOSC2 = new Label( this.leftPanel ); this.labelOSC2.text = "OSC S2O3 Dual:";
        this.comboOSC2 = new ComboBox( this.leftPanel ); this.comboOSC2.addItem( " — None — " );

        let wList = ImageWindow.windows;
        for ( let i = 0; i < wList.length; i++ )
        {
            let wId = wList[i].mainView.id;
            this.comboHa.addItem( wId );
            this.comboOIII.addItem( wId );
            this.comboSII.addItem( wId );
            this.comboOSC.addItem( wId );
            this.comboOSC2.addItem( wId );
        }

        let rowHa  = new HorizontalSizer; rowHa.add( this.labelHa );   rowHa.add( this.comboHa,   1 );
        let rowO3  = new HorizontalSizer; rowO3.add( this.labelOIII );  rowO3.add( this.comboOIII, 1 );
        let rowS2  = new HorizontalSizer; rowS2.add( this.labelSII );   rowS2.add( this.comboSII,  1 );
        let rowOSC = new HorizontalSizer; rowOSC.add( this.labelOSC );  rowOSC.add( this.comboOSC, 1 );
        let rowOSC2= new HorizontalSizer; rowOSC2.add( this.labelOSC2);rowOSC2.add( this.comboOSC2,1 );

        this.comboSizer = new VerticalSizer; this.comboSizer.margin = 0; this.comboSizer.spacing = 4;
        this.comboSizer.add( rowHa ); this.comboSizer.add( rowO3 ); this.comboSizer.add( rowS2 );
        this.comboSizer.add( rowOSC ); this.comboSizer.add( rowOSC2 );

        this.leftPanel.sizer.add( this.titleLabel );
        this.leftPanel.sizer.addSpacing( 6 );
        this.leftPanel.sizer.add( this.instructionLabel );
        this.leftPanel.sizer.addStretch();
        this.leftPanel.sizer.add( this.comboSizer );
        this.leftPanel.sizer.addSpacing( 6 );
        this.leftPanel.sizer.add( this.linearCheckbox );
        this.leftPanel.sizer.addSpacing( 6 );

        // ---- Create Palettes button ----
        this.btnCreatePalettes = new PushButton( this.leftPanel );
        this.btnCreatePalettes.text    = "Create Palettes";
        this.btnCreatePalettes.onClick = () => { this.preparePreviewPalettes(); };
        this.leftPanel.sizer.add( this.btnCreatePalettes );
        this.leftPanel.sizer.addStretch();
        this.leftPanel.sizer.addSpacing( 6 );

        // ---- Authorship ----
        this.authorship_Lbl = new Label( this.leftPanel );
        this.authorship_Lbl.frameStyle  = FrameStyle.Box;
        this.authorship_Lbl.margin      = 6;
        this.authorship_Lbl.useRichText = true;
        this.authorship_Lbl.text        =
            "Written by Franklin Marek<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
        this.authorship_Lbl.textAlignment = TextAlignment.Center;
        this.authorship_Lbl.onMousePress  = () => { Dialog.openBrowser( "http://www.setiastro.com" ); };
        this.leftPanel.sizer.add( this.authorship_Lbl );

        // ---- Buttons row ----
        this.buttonsSizer = new HorizontalSizer; this.buttonsSizer.spacing = 6;

        this.newInstanceButton = new ToolButton( this.leftPanel );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip    = "New Instance";
        this.newInstanceButton.onMousePress = () => { this.newInstance(); };
        this.buttonsSizer.add( this.newInstanceButton );
        this.buttonsSizer.addSpacing( 12 );
        this.buttonsSizer.addStretch();

        this.cancelButton = new PushButton( this.leftPanel );
        this.cancelButton.text    = "Exit";
        this.cancelButton.onClick = () => { this.cancel(); };
        this.buttonsSizer.add( this.cancelButton );

        this.leftPanel.sizer.add( this.buttonsSizer );
        this.leftPanel.sizer.addSpacing( 6 );

        // ---- Zoom buttons ----
        this.zoomButtonsSizer = new HorizontalSizer; this.zoomButtonsSizer.spacing = 6;

        this.zoomInButton = new PushButton( this );
        this.zoomInButton.text    = "Zoom In";
        this.zoomInButton.toolTip = "Scale up the preview images by +25%";
        this.zoomInButton.onClick = () =>
        {
            this.previewScale += 0.25;
            this.updateAllTilePreviews();
        };

        this.zoomOutButton = new PushButton( this );
        this.zoomOutButton.text    = "Zoom Out";
        this.zoomOutButton.toolTip = "Scale down the preview images by 25%";
        this.zoomOutButton.onClick = () =>
        {
            this.previewScale = Math.max( 0.25, this.previewScale - 0.25 );
            this.updateAllTilePreviews();
        };

        this.zoomButtonsSizer.add( this.zoomInButton );
        this.zoomButtonsSizer.addSpacing( 8 );
        this.zoomButtonsSizer.add( this.zoomOutButton );
        this.zoomButtonsSizer.addStretch();

        // ---- Right sizer ----
        this.rightSizer = new VerticalSizer; this.rightSizer.margin = 0; this.rightSizer.spacing = 8;
        this.rightSizer.add( this.zoomButtonsSizer );

        // ---- 3×4 palette grid ----
        this.paletteNames = [
            "SHO","HOO","HSO","HOS",
            "OSS","OHH","OSH","OHS",
            "HSS","Realistic1","Realistic2","Foraxx"
        ];

        this.thumbsBox = new VerticalSizer; this.thumbsBox.margin = 0; this.thumbsBox.spacing = 6;
        this.thumbnailArray = [];

        let index = 0;
        for ( let row = 0; row < 3; row++ )
        {
            let rowSizer = new HorizontalSizer; rowSizer.spacing = 6;

            for ( let col = 0; col < 4; col++ )
            {
                let pName = this.paletteNames[index++];

                let ctrl = new Control( this );
                ctrl.setMinSize( 200, 130 );
                ctrl.paletteName   = pName;
                ctrl.selected      = false;
                ctrl.previewBitmap = null;
                ctrl.ownerDialog   = this;   // safe back-reference (not 'dialog' which is read-only)

                ctrl.refreshMe = function() { this.update(); };

                ctrl.onPaint = function()
                {
                    let g = new Graphics( this );
                    g.fillRect( 0, 0, this.width, this.height, new Brush( 0xFF202020 ) );

                    if ( this.previewBitmap )
                    {
                        let scale   = this.ownerDialog.previewScale;
                        g.scaleTransformation( scale );

                        let bmpW    = this.previewBitmap.width;
                        let bmpH    = this.previewBitmap.height;
                        let scaledW = bmpW * scale;
                        let scaledH = bmpH * scale;
                        let drawX   = (this.width  - scaledW) / 2 / scale;
                        let drawY   = (this.height - scaledH) / 2 / scale;

                        g.drawBitmap( drawX, drawY, this.previewBitmap );
                        g.resetTransformation();
                    }

                    g.font = new Font( "Helvetica", 12 );
                    let textColor = this.selected ? 0xFF00FF00 : 0xFFFFFFFF;
                    g.pen = new Pen( textColor );
                    g.drawText( 5, this.height - 5, this.paletteName );
                    g.end();
                };

                ctrl.onMousePress = function()
                {
                    for ( let t = 0; t < this.ownerDialog.thumbnailArray.length; t++ )
                    {
                        this.ownerDialog.thumbnailArray[t].selected = false;
                        this.ownerDialog.thumbnailArray[t].refreshMe();
                    }
                    this.selected = true;
                    this.refreshMe();
                    this.ownerDialog.generateFinalPaletteImage( this.paletteName );
                };

                rowSizer.add( ctrl, 1 );
                this.thumbnailArray.push( ctrl );
            }
            this.thumbsBox.add( rowSizer );
        }

        this.rightSizer.add( this.thumbsBox, 1 );

        // ---- Main sizer ----
        this.mainSizer = new HorizontalSizer; this.mainSizer.margin = 6; this.mainSizer.spacing = 8;
        this.mainSizer.add( this.leftPanel );
        this.adjustToContents();
        this.mainSizer.addSpacing( 8 );
        this.mainSizer.add( this.rightSizer, 1 );
        this.sizer = this.mainSizer;

        this.windowTitle = "Perfect Palette Picker v" + VERSION;
    }

    // ---- Tile refresh ----

    updateAllTilePreviews()
    {
        for ( let i = 0; i < this.thumbnailArray.length; i++ )
            this.thumbnailArray[i].refreshMe();
    }

    // ---- Image copy helpers ----

    makeFinalCopy( inView, newId )
    {
        let w = new ImageWindow(
            inView.image.width, inView.image.height,
            inView.image.numberOfChannels, inView.image.bitsPerSample,
            inView.image.isReal, inView.image.isColor, newId );
        w.mainView.beginProcess();
        w.mainView.image.assign( inView.image );
        w.mainView.endProcess();
        return w.mainView;
    }

    makePreviewCopy( inView, newId )
    {
        let w = new ImageWindow(
            inView.image.width, inView.image.height,
            inView.image.numberOfChannels, inView.image.bitsPerSample,
            inView.image.isReal, inView.image.isColor, newId );
        w.mainView.beginProcess();
        w.mainView.image.assign( inView.image );
        w.mainView.endProcess();
        return w.mainView;
    }

    averageChannels( view1, view2, outName )
    {
        let targetWin = new ImageWindow(
            view1.image.width, view1.image.height,
            1, view1.image.bitsPerSample, view1.image.isReal, false, outName );
        targetWin.mainView.beginProcess();
        targetWin.mainView.image.fill( 0 );
        targetWin.mainView.endProcess();

        let P = new PixelMath;
        P.useSingleExpression = true;
        P.expression = "(" + view1.id + " + " + view2.id + ") / 2";
        P.clearImageCacheAndExit = false; P.cacheGeneratedImages = false;
        P.generateOutput = true; P.singleThreaded = false; P.optimization = true;
        P.use64BitWorkingImage = true; P.rescale = false;
        P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
        P.createNewImage = false; P.showNewImage = false;
        P.executeOn( targetWin.mainView );
        return targetWin.mainView;
    }

    // ---- PixelMath colour combine helpers ----

    _makePMColorWindow( refView, outId )
    {
        let w = refView.image.width, h = refView.image.height;
        let bits = refView.image.bitsPerSample, real = refView.image.isReal;
        let targetWin = new ImageWindow( w, h, 3, bits, real, true, outId );
        targetWin.mainView.beginProcess();
        targetWin.mainView.image.fill( 0 );
        targetWin.mainView.endProcess();
        return targetWin;
    }

    _runPM( targetWin, exprR, exprG, exprB )
    {
        let PM = new PixelMath;
        PM.useSingleExpression = false;
        PM.expression  = exprR; PM.expression1 = exprG;
        PM.expression2 = exprB; PM.expression3 = "";
        PM.createNewImage = false; PM.showNewImage = false;
        PM.clearImageCacheAndExit = false; PM.cacheGeneratedImages = false;
        PM.generateOutput = true; PM.singleThreaded = false; PM.optimization = true;
        PM.use64BitWorkingImage = false; PM.rescale = false;
        PM.truncate = true; PM.truncateLower = 0; PM.truncateUpper = 1;
        PM.executeOn( targetWin.mainView );
        return targetWin.mainView;
    }

    combineChannelsToColorExpressions( outId, exprR, exprG, exprB )
    {
        let refView = this.finalHa || this.finalOIII || this.finalSII || this.previewR;
        if ( !refView )
        {
            console.warningln( "No reference final channel available. Cannot build partial merges." );
            return null;
        }
        return this._runPM( this._makePMColorWindow( refView, outId ), exprR, exprG, exprB );
    }

    combineChannelsToColorExpressionsMini( outId, exprR, exprG, exprB )
    {
        let refId = "";
        if      ( this.previewHa   ) refId = this.previewHa.id;
        else if ( this.previewOIII ) refId = this.previewOIII.id;
        else if ( this.previewSII  ) refId = this.previewSII.id;
        else if ( this.previewR    ) refId = this.previewR.id;

        if ( refId === "" )
        {
            console.warningln( "No reference preview for dimension—cannot build partial merges." );
            return null;
        }
        let refWin = ImageWindow.windowById( refId );
        if ( !refWin || refWin.isNull )
        {
            console.warningln( "Ref window not found for ID=", refId );
            return null;
        }
        return this._runPM( this._makePMColorWindow( refWin.mainView, outId ), exprR, exprG, exprB );
    }

    // ---- Preview palette creation ----

    createMiniPalettePreview( paletteName )
    {
        console.writeln( "createMiniPalettePreview(", paletteName, ")" );

        let outName  = "Preview_" + paletteName;
        let usedHa   = this.previewHa   || this.previewSII;
        let usedSII  = this.previewSII  || this.previewHa;

        if ( !usedHa && !this.previewOIII )
        {
            console.warningln( "[!] Missing both Ha/SII and OIII channels for palette:", paletteName );
            return null;
        }

        let HaView   = usedHa;
        let OIIIView = this.previewOIII;
        let SIIView  = usedSII;

        switch ( paletteName )
        {
        case "SHO": case "HOO": case "HSO": case "HOS":
        case "OSS": case "OHH": case "OSH": case "OHS":
        case "HSS":
        {
            let mapped = mapChannels( paletteName, HaView, OIIIView, SIIView );
            return combineChannelsToColor( [mapped[0], mapped[1], mapped[2]], outName );
        }

        case "Realistic1":
        {
            let exprR = (HaView && SIIView)
                ? "(" + HaView.id + " + " + SIIView.id + ") / 2"
                : (HaView ? HaView.id : "0");
            let exprG = (HaView ? "0.3*" + HaView.id : "0") + (OIIIView ? " + 0.7*" + OIIIView.id : "");
            let exprB = (OIIIView ? "0.9*" + OIIIView.id : "0") + (HaView ? " + 0.1*" + HaView.id : "");
            return this.combineChannelsToColorExpressionsMini( outName, exprR, exprG, exprB );
        }

        case "Realistic2":
        {
            let exprR = (HaView && SIIView) ? "0.7*" + HaView.id + " + 0.3*" + SIIView.id
                      : (HaView ? HaView.id : "0");
            let exprG = (SIIView && OIIIView) ? "0.3*" + SIIView.id + " + 0.7*" + OIIIView.id
                      : (OIIIView ? OIIIView.id : "0");
            let exprB = OIIIView ? OIIIView.id : "0";
            return this.combineChannelsToColorExpressionsMini( outName, exprR, exprG, exprB );
        }

        case "Foraxx":
        {
            if ( HaView && OIIIView && !SIIView )
            {
                let ho   = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprR = HaView.id;
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;
                let exprB = OIIIView.id;
                return this.combineChannelsToColorExpressionsMini( outName, exprR, exprG, exprB );
            }
            else if ( HaView && OIIIView && SIIView )
            {
                let o    = OIIIView.id;
                let ho   = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprR = "(" + o + " ^ ~" + o + ") * " + SIIView.id + " + ~(" + o + " ^ ~" + o + ") * " + HaView.id;
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;
                let exprB = OIIIView.id;
                return this.combineChannelsToColorExpressionsMini( outName, exprR, exprG, exprB );
            }
            else
            {
                console.warningln( "Foraxx: not enough channels—falling back to SHO." );
                let mapped = mapChannels( "SHO", HaView, OIIIView, SIIView );
                return combineChannelsToColor( [mapped[0], mapped[1], mapped[2]], outName );
            }
        }

        default:
        {
            let mapped = mapChannels( "SHO", HaView, OIIIView, SIIView );
            return combineChannelsToColor( [mapped[0], mapped[1], mapped[2]], outName );
        }
        }
    }

    // ---- Main palette preparation ----

    preparePreviewPalettes()
    {
        let selHa   = this.comboHa.currentItem;
        let selOIII = this.comboOIII.currentItem;
        let selSII  = this.comboSII.currentItem;
        let selOSC1 = this.comboOSC.currentItem;
        let selOSC2 = this.comboOSC2.currentItem;

        let haId   = selHa   > 0 ? this.comboHa.itemText(selHa)     : "";
        let oiiiId = selOIII > 0 ? this.comboOIII.itemText(selOIII) : "";
        let siiId  = selSII  > 0 ? this.comboSII.itemText(selSII)   : "";
        let osc1Id = selOSC1 > 0 ? this.comboOSC.itemText(selOSC1)  : "";
        let osc2Id = selOSC2 > 0 ? this.comboOSC2.itemText(selOSC2) : "";

        let haveHa   = haId.length   > 0;
        let haveOIII = oiiiId.length > 0;
        let haveSII  = siiId.length  > 0;
        let haveOSC1 = osc1Id.length > 0;
        let haveOSC2 = osc2Id.length > 0;

        console.writeln( "preparePreviewPalettes() => Ha:", haId,
            "  OIII:", oiiiId, "  SII:", siiId,
            "  OSC1:", osc1Id, "  OSC2:", osc2Id );

        this.cleanupPreviewWindows();
        this.finalHa = this.finalOIII = this.finalSII = null;
        this.previewHa = this.previewOIII = this.previewSII = null;

        // ---- OSC1 → Ha + OIII ----
        if ( haveOSC1 )
        {
            let W1 = ImageWindow.windowById( osc1Id );
            if ( !W1 ) { console.warningln( "[!] OSC1 window not found: ", osc1Id ); }
            else
            {
                let ch1 = extractOSCchannels( W1.mainView );
                if ( ch1.length < 3 ) { console.warningln( "[!] OSC1 could not extract 3 channels!" ); }
                else
                {
                    this.finalHa = this.makeFinalCopy( ch1[0], "Ha_OSC1_final" );
                    if ( this.linearCheckbox.checked ) processMonoImage( this.finalHa, 0.25, 1 );

                    this.finalOIII = this.averageChannels( ch1[1], ch1[2], "OIII_OSC1_final" );
                    if ( this.linearCheckbox.checked ) processMonoImage( this.finalOIII, 0.25, 1 );

                    let pvHa = this.makePreviewCopy( this.finalHa, "Ha_OSC1_preview" );
                    downsample4x( pvHa ); this.previewHa = pvHa;

                    let pvO  = this.makePreviewCopy( this.finalOIII, "OIII_OSC1_preview" );
                    downsample4x( pvO ); this.previewOIII = pvO;
                }
            }
        }

        // ---- OSC2 → SII + OIII (averaged with OSC1 OIII if present) ----
        if ( haveOSC2 )
        {
            let W2 = ImageWindow.windowById( osc2Id );
            if ( !W2 ) { console.warningln( "[!] OSC2 window not found: ", osc2Id ); }
            else
            {
                let ch2 = extractOSCchannels( W2.mainView );
                if ( ch2.length < 3 ) { console.warningln( "[!] OSC2 could not extract 3 channels!" ); }
                else
                {
                    this.finalSII = this.makeFinalCopy( ch2[0], "SII_OSC2_final" );
                    if ( this.linearCheckbox.checked ) processMonoImage( this.finalSII, 0.25, 1 );

                    let oiiiOSC2 = this.averageChannels( ch2[1], ch2[2], "OIII_OSC2_final" );
                    if ( this.linearCheckbox.checked ) processMonoImage( oiiiOSC2, 0.25, 1 );

                    if ( this.finalOIII )
                    {
                        this.finalOIII = this.averageChannels( this.finalOIII, oiiiOSC2, "OIII_combined_final" );
                        if ( this.linearCheckbox.checked ) processMonoImage( this.finalOIII, 0.25, 2 );
                        let pvO2 = this.makePreviewCopy( this.finalOIII, "OIII_combined_preview" );
                        downsample4x( pvO2 ); this.previewOIII = pvO2;
                    }
                    else
                    {
                        this.finalOIII = oiiiOSC2;
                        let pvO2 = this.makePreviewCopy( this.finalOIII, "OIII_OSC2_preview" );
                        downsample4x( pvO2 ); this.previewOIII = pvO2;
                    }

                    let pvS = this.makePreviewCopy( this.finalSII, "SII_OSC2_preview" );
                    downsample4x( pvS ); this.previewSII = pvS;
                }
            }
        }

        // ---- Individual Ha/OIII/SII ----
        if ( haveHa )
        {
            let W = ImageWindow.windowById( haId );
            if ( !W ) { console.warningln( "[!] Ha window not found: ", haId ); }
            else
            {
                if ( this.linearCheckbox.checked )
                {
                    this.finalHa = this.makeFinalCopy( W.mainView, "Ha_final" );
                    processMonoImage( this.finalHa, 0.25, 1 );
                }
                else this.finalHa = W.mainView;

                let pv = this.makePreviewCopy( this.finalHa, "Ha_preview" );
                downsample4x( pv ); this.previewHa = pv;
            }
        }

        if ( haveOIII )
        {
            let W = ImageWindow.windowById( oiiiId );
            if ( !W ) { console.warningln( "[!] OIII window not found: ", oiiiId ); }
            else
            {
                if ( this.linearCheckbox.checked )
                {
                    this.finalOIII = this.makeFinalCopy( W.mainView, "OIII_final" );
                    processMonoImage( this.finalOIII, 0.25, 1 );
                }
                else this.finalOIII = W.mainView;

                let pv = this.makePreviewCopy( this.finalOIII, "OIII_preview" );
                downsample4x( pv ); this.previewOIII = pv;
            }
        }

        if ( haveSII )
        {
            let W = ImageWindow.windowById( siiId );
            if ( !W ) { console.warningln( "[!] SII window not found: ", siiId ); }
            else
            {
                if ( this.linearCheckbox.checked )
                {
                    this.finalSII = this.makeFinalCopy( W.mainView, "SII_final" );
                    processMonoImage( this.finalSII, 0.25, 1 );
                }
                else this.finalSII = W.mainView;

                let pv = this.makePreviewCopy( this.finalSII, "SII_preview" );
                downsample4x( pv ); this.previewSII = pv;
            }
        }

        // ---- Build each palette mini-preview ----
        console.writeln( "[*] Now building each palette's mini-preview..." );
        for ( let i = 0; i < this.thumbnailArray.length; i++ )
        {
            let pName    = this.thumbnailArray[i].paletteName;
            let miniView = this.createMiniPalettePreview( pName );

            if ( miniView )
            {
                this.thumbnailArray[i].previewBitmap = miniView.image.render();
                this.thumbnailArray[i].refreshMe();
                miniView.window.forceClose();
            }
            else
            {
                this.thumbnailArray[i].previewBitmap = null;
                console.warningln( "[Palette: " + pName + "] Failed to create mini-preview." );
            }
        }
        console.writeln( "[*] Palette mini-previews done." );
    }

    // ---- Final palette image generation ----

    generateFinalPaletteImage( paletteName )
    {
        console.writeln( "generateFinalPaletteImage(", paletteName, ")" );

        let HaView   = this.finalHa;
        let OIIIView = this.finalOIII;
        let SIIView  = this.finalSII;
        let outName  = "Final_" + paletteName;

        if ( !HaView && !OIIIView )
        {
            console.warningln( "[!] Missing both Ha and OIII channels for palette:", paletteName );
            return;
        }

        let showView = v => { if (v) { v.window.show(); v.window.bringToFront(); } };

        switch ( paletteName )
        {
        case "SHO": case "HOO": case "HSO": case "HOS":
        case "OSS": case "OHH": case "OSH": case "OHS":
        case "HSS":
        {
            let mapped = mapChannels( paletteName, HaView, OIIIView, SIIView );
            let cv = combineChannelsToColor( [mapped[0], mapped[1], mapped[2]], outName );
            showView( cv );
            break;
        }

        case "Realistic1":
        {
            let exprR = (HaView && SIIView) ? "(" + HaView.id + " + " + SIIView.id + ") / 2"
                      : (HaView ? HaView.id : "0");
            let exprG = (HaView ? "0.3*" + HaView.id : "0") + (OIIIView ? " + 0.7*" + OIIIView.id : "");
            let exprB = (OIIIView ? "0.9*" + OIIIView.id : "0") + (HaView ? " + 0.1*" + HaView.id : "");
            showView( this.combineChannelsToColorExpressions( outName, exprR, exprG, exprB ) );
            break;
        }

        case "Realistic2":
        {
            let exprR = (HaView && SIIView) ? "0.7*" + HaView.id + " + 0.3*" + SIIView.id
                      : (HaView ? HaView.id : "0");
            let exprG = (SIIView && OIIIView) ? "0.3*" + SIIView.id + " + 0.7*" + OIIIView.id
                      : (OIIIView ? OIIIView.id : "0");
            let exprB = OIIIView ? OIIIView.id : "0";
            showView( this.combineChannelsToColorExpressions( outName, exprR, exprG, exprB ) );
            break;
        }

        case "Foraxx":
        {
            if ( HaView && OIIIView && !SIIView )
            {
                let ho   = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprR = HaView.id;
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;
                let exprB = OIIIView.id;
                showView( this.combineChannelsToColorExpressions( outName, exprR, exprG, exprB ) );
            }
            else if ( HaView && OIIIView && SIIView )
            {
                let o    = OIIIView.id;
                let ho   = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprR = "(" + o + " ^ ~" + o + ") * " + SIIView.id + " + ~(" + o + " ^ ~" + o + ") * " + HaView.id;
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;
                let exprB = OIIIView.id;
                showView( this.combineChannelsToColorExpressions( outName, exprR, exprG, exprB ) );
            }
            else
            {
                console.warningln( "Foraxx: not enough channels—falling back to SHO." );
                let mapped = mapChannels( "SHO", HaView, OIIIView, SIIView );
                showView( combineChannelsToColor( [mapped[0], mapped[1], mapped[2]], outName ) );
            }
            break;
        }

        default:
        {
            let mapped = mapChannels( "SHO", HaView, OIIIView, SIIView );
            showView( combineChannelsToColor( [mapped[0], mapped[1], mapped[2]], outName ) );
            break;
        }
        }
    }

    // ---- Cleanup ----

    cleanupPreviewWindows()
    {
        const suffixes = ["_preview","_final","_pppR","_pppG","_pppB"];
        let allW = ImageWindow.windows;
        for ( let i = allW.length - 1; i >= 0; i-- )
        {
            let id = allW[i].mainView.id;
            if ( suffixes.some( s => id.endsWith(s) ) )
            {
                allW[i].forceClose();
                console.writeln( "Closed temporary window: " + id );
            }
        }
        this.previewHa = this.previewOIII = this.previewSII = null;
        this.previewR  = this.previewG    = this.previewB   = null;
        this.finalHa   = this.finalOIII   = this.finalSII   = null;
    }

    onHide()
    {
        this.cleanupPreviewWindows();
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );
    console.writeln( " Perfect Palette Picker by Franklin Marek" );

    let D = new PerfectPalettePickerDialog();
    D.execute();
    D.cleanupPreviewWindows();
}

main();
