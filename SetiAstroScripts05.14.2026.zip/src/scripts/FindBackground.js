#engine v8

#feature-id   FindBackground : SetiAstro > Find Background
#feature-icon  findbackground.svg
#feature-info This script utilizes gradient descent and various filters to quickly determine algorithmically an optimal background region of interest.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*!
 * FindBackground (consolidated V8 port)
 * Files merged: FindBackgroundUI.js + FindBackground_1.1.js + FindBackground_UserDefined.js
 *
 * Copyright (c) 2024, Gerrit Erdt
 * Copyright (c) 2024, Franklin Marek
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 */

#define TITLE   "Find Background"
#define VERSION "1.2.2"

// ============================================================================
// Parameters
// ============================================================================

let parameters =
{
    targetWindow:      null,
    filterAvg:         true,
    filterSdev:        true,
    filterPoisonIndex: false,
    filterMAAD:        false,
    filterObjects:     false,
    printInformation:  true,
    generatePreview:   true,
    previewName:       "Background",
    slowSearch:        false,
    fastSearch:        true,
    size:              50,
    spacingRate:       2,
    searchGridSize:    100,
    startingPoints:    40,

    save: function()
    {
        Parameters.set( "filterAvg",         this.filterAvg );
        Parameters.set( "filterSdev",        this.filterSdev );
        Parameters.set( "filterPoisonIndex", this.filterPoisonIndex );
        Parameters.set( "filterMAAD",        this.filterMAAD );
        Parameters.set( "filterObjects",     this.filterObjects );
        Parameters.set( "printInformation",  this.printInformation );
        Parameters.set( "generatePreview",   this.generatePreview );
        Parameters.set( "previewName",       this.previewName );
        Parameters.set( "slowSearch",        this.slowSearch );
        Parameters.set( "fastSearch",        this.fastSearch );
        Parameters.set( "size",              this.size );
        Parameters.set( "spacingRate",       this.spacingRate );
        Parameters.set( "searchGridSize",    this.searchGridSize );
        Parameters.set( "startingPoints",    this.startingPoints );
    },

    load: function()
    {
        if ( Parameters.has( "filterAvg" ) )         this.filterAvg         = Parameters.getBoolean( "filterAvg" );
        if ( Parameters.has( "filterSdev" ) )        this.filterSdev        = Parameters.getBoolean( "filterSdev" );
        if ( Parameters.has( "filterPoisonIndex" ) ) this.filterPoisonIndex = Parameters.getBoolean( "filterPoisonIndex" );
        if ( Parameters.has( "filterMAAD" ) )        this.filterMAAD        = Parameters.getBoolean( "filterMAAD" );
        if ( Parameters.has( "filterObjects" ) )     this.filterObjects     = Parameters.getBoolean( "filterObjects" );
        if ( Parameters.has( "printInformation" ) )  this.printInformation  = Parameters.getBoolean( "printInformation" );
        if ( Parameters.has( "generatePreview" ) )   this.generatePreview   = Parameters.getBoolean( "generatePreview" );
        if ( Parameters.has( "previewName" ) )       this.previewName       = Parameters.getString(  "previewName" );
        if ( Parameters.has( "slowSearch" ) )        this.slowSearch        = Parameters.getBoolean( "slowSearch" );
        if ( Parameters.has( "fastSearch" ) )        this.fastSearch        = Parameters.getBoolean( "fastSearch" );
        if ( Parameters.has( "size" ) )              this.size              = Parameters.getInteger( "size" );
        if ( Parameters.has( "spacingRate" ) )       this.spacingRate       = Parameters.getInteger( "spacingRate" );
        if ( Parameters.has( "searchGridSize" ) )    this.searchGridSize    = Parameters.getInteger( "searchGridSize" );
        if ( Parameters.has( "startingPoints" ) )    this.startingPoints    = Parameters.getInteger( "startingPoints" );
    }
};

let constants = { indent: 20, minLabelSize: 170 };

// ============================================================================
// Region helpers
// ============================================================================

function mergeOverlappingRegions( regions )
{
    let merged = [];
    for ( let i = 0; i < regions.length; i++ )
    {
        let region = regions[i];
        let isMerged = false;
        for ( let j = 0; j < merged.length; j++ )
        {
            if ( isOverlapping( region, merged[j] ) )
            {
                merged[j] = mergeRegions( region, merged[j] );
                isMerged = true;
                break;
            }
        }
        if ( !isMerged ) merged.push( region );
    }
    return merged;
}

function isOverlapping( r1, r2 )
{
    return !( r1.right < r2.left || r1.left > r2.right || r1.bottom < r2.top || r1.top > r2.bottom );
}

function mergeRegions( r1, r2 )
{
    return new Rect(
        Math.min( r1.left, r2.left ), Math.min( r1.top,    r2.top ),
        Math.max( r1.right, r2.right ), Math.max( r1.bottom, r2.bottom ) );
}

function normalizeRect( rect )
{
    return new Rect(
        Math.min( rect.left, rect.right ), Math.min( rect.top,    rect.bottom ),
        Math.max( rect.left, rect.right ), Math.max( rect.top,    rect.bottom ) );
}

function clampRectToBounds( rect, w, h )
{
    return new Rect(
        Math.max( 0, Math.min( rect.left,   w ) ),
        Math.max( 0, Math.min( rect.top,    h ) ),
        Math.max( 0, Math.min( rect.right,  w ) ),
        Math.max( 0, Math.min( rect.bottom, h ) ) );
}

// ============================================================================
// FindBackground — full-image search engine
// ============================================================================

function FindBackground( windowSize, spacingPortion )
{
    this.window        = null;
    this.image         = null;
    this.windowSize    = windowSize;
    this.spacing       = Math.round( windowSize / spacingPortion );
    this.brightnessArray = new Array( windowSize * windowSize );
    this.verbosity     = 1;
    this.generatePreview = true;
    this.exclusionAreas  = [];

    this.filterAverage                      = true;
    this.filterStandardDeviation            = true;
    this.filterMedianAverageAbsoluteDifference = true;
    this.filterPoissonIndex                 = false;
    this.filterForObjects                   = true;

    let filterAverageValue                         = 1.0;
    let filterStandardDeviationValue               = 1.0;
    let filterMedianAverageAbsoluteDifferenceValue = 1.0;
    let filterPoissonIndexValue                    = 1.0;

    let filterStandardDeviationCap                         = 0.3333333;
    let filterMedianAverageAbsoluteDifferenceCap           = 0.1;
    let filterPoissonIndexCap                              = 0.2;
    let filterStandardDeviationNormalization               = 1.0;
    let filterMedianAverageAbsoluteDifferenceNormalization = 1.0;
    let filterPoissonIndexNormalization                    = 1.0;

    this.setTarget = function( win )
    {
        if ( win.isNull ) throw new Error( "The selected image is invalid. Please select a valid image." );
        this.window = win;
        this.image  = win.mainView.image;
    };

    this.setWindowSize     = function( ws ) { this.windowSize = ws; this.spacing = -1; };
    this.setSpacingPortion = function( sp ) { this.spacing = Number( (this.windowSize / sp).toFixed(0) ); };

    this.isPointInExclusionArea    = function( pt, area ) {
        if ( !area ) return false;
        return pt.x >= area.left && pt.x <= area.right && pt.y >= area.top && pt.y <= area.bottom;
    };
    this.isPointInAnyExclusionArea = function( pt, areas ) {
        return areas.some( a => this.isPointInExclusionArea( pt, a ) );
    };

    this.searchBackground = function( printInfo, previewName )
    {
        if ( this.spacing == -1 ) throw new Error( "Spacing not set." );

        setupFilterNormalization();

        let lowestX = 0, lowestY = 0, lowestScore = Infinity;

        let total = 0;
        for ( let x = this.windowSize; x < this.image.width  - this.windowSize; x += this.spacing )
            for ( let y = this.windowSize; y < this.image.height - this.windowSize; y += this.spacing )
                if ( !this.isPointInAnyExclusionArea( {x,y}, this.exclusionAreas ) ) total++;

        let divisor = Math.max( 1, Math.floor( total / 100 ) );
        let iter    = 0;

        console.abortEnabled = true;
        if ( this.verbosity == 1 )
        {
            console.show();
            console.writeln( "Processing started..." );
            console.writeln( "Exclusion areas: " + JSON.stringify( this.exclusionAreas ) );
            console.writeln( "|.....................................................................................................|" );
            console.write( "|" );
        }

        for ( let x = this.windowSize; x < this.image.width - this.windowSize; x += this.spacing )
        {
            for ( let y = this.windowSize; y < this.image.height - this.windowSize; y += this.spacing )
            {
                if ( this.isPointInAnyExclusionArea( {x,y}, this.exclusionAreas ) ) continue;
                calculateFilterValues( x, y );
                let score = getScore();
                if ( score < lowestScore ) { lowestScore = score; lowestX = x; lowestY = y; }
                if ( ++iter % divisor == 0 ) console.write( "." );
            }
            CoreApplication.processEvents();
            if ( console.abortRequested ) { console.writeln( "|" ); console.writeln( "Processing aborted by user." ); return; }
        }

        log( "|" );
        log( "Refining solution using gradient descent..." );
        let refined = gradientDescent( lowestX, lowestY );
        lowestX = refined[0]; lowestY = refined[1];
        log( "Gradient descent finished, found final solution." );

        if ( this.generatePreview )
            this.window.createPreview( lowestX, lowestY, lowestX + this.windowSize, lowestY + this.windowSize, previewName || "Background" );
        if ( printInfo ) printInformation( lowestX, lowestY );
    };

    this.fastSearchBackground = function( initialSize, targetCount, printInfo, previewName )
    {
        if ( this.spacing == -1 ) throw new Error( "Spacing not set." );

        console.show(); console.abortEnabled = true;
        log( "Fast search started..." );
        setupFilterNormalization();

        let oldSpacing  = this.spacing;
        this.spacing    = initialSize;
        let averages    = [];

        console.writeln( "Looking for starting points..." );
        console.writeln( "Exclusion areas: " + JSON.stringify( this.exclusionAreas ) );

        for ( let x = this.spacing; x < this.image.width  - this.spacing; x += this.spacing )
        {
            for ( let y = this.spacing; y < this.image.height - this.spacing; y += this.spacing )
            {
                if ( this.isPointInAnyExclusionArea( {x,y}, this.exclusionAreas ) ) continue;
                calculateFilterValues( x, y );
                averages.push( [x, y, getScore()] );
            }
            CoreApplication.processEvents();
            if ( console.abortRequested ) throw new Error( "Processing aborted by user." );
        }

        console.writeln( "Finished looking for starting points." );
        this.spacing = oldSpacing;

        averages = averages.sort( (a,b) => a[2] - b[2] ).slice( 0, targetCount );
        log( "Selected the " + targetCount + " best starting points." );

        let results = [];
        for ( let i = 0; i < averages.length; i++ )
        {
            log( "Optimizing window " + (i+1) + " of " + targetCount + "..." );
            results.push( gradientDescent( averages[i][0], averages[i][1] ) );
            CoreApplication.processEvents();
            if ( console.abortRequested ) throw new Error( "Processing aborted by user." );
        }

        results = results.sort( (a,b) => a[2] - b[2] );
        log( "Selected the best result." );

        if ( this.generatePreview )
            this.window.createPreview( results[0][0], results[0][1], results[0][0] + this.windowSize, results[0][1] + this.windowSize, previewName || "Background" );
        if ( printInfo ) printInformation( results[0][0], results[0][1] );
    };

    // ---- Internal closures ----

    let gradientDescent = ( x, y ) =>
    {
        this.spacing = parseFloat( this.spacing );
        x = parseFloat( x ); y = parseFloat( y );

        let lowestScore = Infinity, moveRate = 1.0;
        let lowestX = x, lowestY = y;

        while ( moveRate * this.spacing >= 1.0 )
        {
            let improved = false;
            for ( let dx = -1.0; dx <= 1.0; dx += 1.0 )
                for ( let dy = -1.0; dy <= 1.0; dy += 1.0 )
                {
                    let nx = Math.round( x + dx * this.spacing * moveRate );
                    let ny = Math.round( y + dy * this.spacing * moveRate );
                    if ( nx - this.windowSize < 0 || nx + this.windowSize >= this.image.width ||
                         ny - this.windowSize < 0 || ny + this.windowSize >= this.image.height ) continue;
                    if ( this.isPointInAnyExclusionArea( {x:nx,y:ny}, this.exclusionAreas ) ) continue;
                    calculateFilterValues( nx, ny );
                    let score = getScore();
                    if ( score < lowestScore ) { lowestScore = score; lowestX = nx; lowestY = ny; improved = true; }
                }
            if ( !improved ) moveRate *= 0.5;
            x = lowestX; y = lowestY;
            CoreApplication.processEvents();
            if ( console.abortRequested ) throw new Error( "Processing aborted by user." );
        }
        return [lowestX, lowestY, lowestScore];
    };

    let calculateFilterValues = ( x, y ) =>
    {
        if ( this.filterAverage ) calculateAverage( x, y );
        if ( this.filterStandardDeviation )
        {
            if ( !this.filterAverage ) calculateAverage( x, y );
            calculateStandardDeviation( x, y, filterAverageValue );
        }
        if ( this.filterMedianAverageAbsoluteDifference )
        {
            if ( !this.filterAverage && !this.filterStandardDeviation ) calculateAverage( x, y );
            if ( !this.filterStandardDeviation ) calculateStandardDeviation( x, y, filterAverageValue );
            calculateMedianAverageAbsoluteDifference( x, y, filterAverageValue, filterStandardDeviationValue );
        }
        if ( this.filterPoissonIndex ) calculatePoissonIndex( x, y );
    };

    let getScore = () =>
    {
        let score = 0;
        if ( this.filterAverage ) score += 1 / filterAverageValue;
        if ( this.filterStandardDeviation )
        {
            let s = 1 / filterStandardDeviationValue;
            score += this.filterAverage
                ? Math.min( (1/filterAverageValue) * filterStandardDeviationCap, filterStandardDeviationNormalization * s )
                : s * filterStandardDeviationNormalization;
        }
        if ( this.filterMedianAverageAbsoluteDifference )
        {
            let m = 1 / filterMedianAverageAbsoluteDifferenceValue;
            score += this.filterAverage
                ? Math.min( (1/filterAverageValue) * filterMedianAverageAbsoluteDifferenceCap, filterMedianAverageAbsoluteDifferenceNormalization * m )
                : m * filterMedianAverageAbsoluteDifferenceNormalization;
        }
        if ( this.filterPoissonIndex )
        {
            let p = 1 / filterPoissonIndexValue;
            score += this.filterAverage
                ? Math.min( (1/filterAverageValue) * filterPoissonIndexCap, filterPoissonIndexNormalization * p )
                : p * filterPoissonIndexNormalization;
        }
        return 1 / score;
    };

    let log = msg => { if ( this.verbosity == 1 ) console.writeln( msg ); CoreApplication.processEvents(); };

    let setupFilterNormalization = () =>
    {
        let tileSize = 500, targetMedian = 0.5;
        let avgs = [], sdevs = [], maads = [], poissons = [];
        for ( let x = 0; x < this.image.width  - tileSize; x += tileSize )
            for ( let y = 0; y < this.image.height - tileSize; y += tileSize )
            {
                calculateFilterValues( x, y );
                avgs.push( filterAverageValue ); sdevs.push( filterStandardDeviationValue );
                maads.push( filterMedianAverageAbsoluteDifferenceValue ); poissons.push( filterPoissonIndexValue );
            }
        let indices = avgs.map( (_,i) => i ).sort( (a,b) => avgs[a] - avgs[b] );
        let n = indices.length;
        let reorder = (arr) => indices.map( i => arr[i] ).slice( 0, Math.floor( n/4 ) );
        avgs = reorder(avgs); sdevs = reorder(sdevs); maads = reorder(maads); poissons = reorder(poissons);
        let mid = a => a[Math.floor(a.length/2)];
        let mAvg = 1/mid(avgs), mSdev = 1/mid(sdevs), mMaad = 1/mid(maads), mPois = 1/mid(poissons);
        filterStandardDeviationNormalization               = (targetMedian * filterStandardDeviationCap                  * mAvg) / mSdev;
        filterMedianAverageAbsoluteDifferenceNormalization = (targetMedian * filterMedianAverageAbsoluteDifferenceCap    * mAvg) / mMaad;
        filterPoissonIndexNormalization                    = (targetMedian * filterPoissonIndexCap                       * mAvg) / mPois;
    };

    let printInformation = ( lx, ly ) =>
    {
        calculateFilterValues( lx, ly );
        let score = getScore();
        console.noteln( "\n\nProcessing finished!\n\n" );
        let bright = new Array( this.image.numberOfChannels ).fill( 0 );
        for ( let x = lx; x < lx + this.windowSize; x++ )
            for ( let y = ly; y < ly + this.windowSize; y++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    bright[c] += this.image.sample( x, y, c );
        for ( let c = 0; c < this.image.numberOfChannels; c++ ) bright[c] /= this.windowSize * this.windowSize;
        let maxBright = Math.max( ...bright );
        console.writeln( "Average channel brightness:" );
        for ( let c = 0; c < this.image.numberOfChannels; c++ ) console.writeln( "\t[" + c + "]: " + bright[c] );
        if ( this.image.numberOfChannels > 1 )
        {
            console.writeln( "\nAdditive color correction constants:" );
            for ( let c = 0; c < this.image.numberOfChannels; c++ ) console.writeln( "\t[" + c + "]: " + (maxBright - bright[c]) );
        }
        console.writeln( "\nROI coordinates:\n\tX: " + lx + "\n\tY: " + ly + "\n\tWidth: " + this.windowSize + "\n\tHeight: " + this.windowSize );
        console.writeln( "\nQuality assessment: " );
        if ( this.filterAverage )                           console.writeln( "\tAverage brightness                 : " + filterAverageValue );
        if ( this.filterStandardDeviation )                 console.writeln( "\tStandard deviation                 : " + filterStandardDeviationValue );
        if ( this.filterPoissonIndex )                      console.writeln( "\tPoisson index                      : " + filterPoissonIndexValue );
        if ( this.filterMedianAverageAbsoluteDifference )   console.writeln( "\tMedian average absolute difference : " + filterMedianAverageAbsoluteDifferenceValue );
        console.writeln( "\tScore                              : " + score );
        console.noteln( "Background Found! Preview Created!" );
    };

    let calculateAverage = ( x, y ) =>
    {
        let avg = 0;
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    avg += this.image.sample( x+dx, y+dy, c );
        filterAverageValue = avg / (this.windowSize * this.windowSize * this.image.numberOfChannels);
    };

    let calculateStandardDeviation = ( x, y, avg ) =>
    {
        let sd = 0;
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
            {
                let px = 0;
                for ( let c = 0; c < this.image.numberOfChannels; c++ ) px += this.image.sample( x+dx, y+dy, c );
                sd += Math.pow( px - avg, 2 );
            }
        filterStandardDeviationValue = Math.sqrt( sd / (this.windowSize * this.windowSize * this.image.numberOfChannels) );
    };

    let calculateMedianAverageAbsoluteDifference = ( x, y, avg, stDev ) =>
    {
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
            {
                let px = 0;
                for ( let c = 0; c < this.image.numberOfChannels; c++ ) px += this.image.sample( x+dx, y+dy, c );
                this.brightnessArray[dx * this.windowSize + dy] = px;
            }
        this.brightnessArray = this.brightnessArray.sort( (a,b) => a-b );
        let idx = Math.floor( this.brightnessArray.length / 2 );
        let med = this.brightnessArray.length % 2
            ? this.brightnessArray[idx]
            : (this.brightnessArray[idx-1] + this.brightnessArray[idx]) / 2;
        filterMedianAverageAbsoluteDifferenceValue = Math.abs( med - avg ) / stDev;
    };

    let calculatePoissonIndex = ( x, y ) =>
    {
        let avgs = new Array( this.image.numberOfChannels ).fill( 0 );
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    avgs[c] += this.image.sample( x+dx, y+dy, c );
        for ( let c = 0; c < avgs.length; c++ ) avgs[c] /= this.windowSize * this.windowSize;
        let variances = new Array( this.image.numberOfChannels ).fill( 0 );
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    variances[c] += Math.pow( this.image.sample( x+dx, y+dy, c ) - avgs[c], 2 );
        for ( let c = 0; c < variances.length; c++ ) variances[c] /= this.windowSize * this.windowSize;
        let pi = 0;
        for ( let c = 0; c < this.image.numberOfChannels; c++ )
            pi += Math.abs( avgs[c] - variances[c] ) / avgs[c];
        filterPoissonIndexValue = Math.abs( pi / this.image.numberOfChannels - 1 );
    };
}

// ============================================================================
// FindBackgroundUserDefined — region-constrained search engine
// ============================================================================

function FindBackgroundUserDefined( windowSize, spacingPortion, userDefinedRegions )
{
    this.window             = null;
    this.image              = null;
    this.windowSize         = windowSize;
    this.spacing            = Math.round( windowSize / spacingPortion );
    this.brightnessArray    = new Array( windowSize * windowSize );
    this.verbosity          = 1;
    this.generatePreview    = true;
    this.userDefinedRegions = userDefinedRegions;

    this.filterAverage                         = true;
    this.filterStandardDeviation               = true;
    this.filterMedianAverageAbsoluteDifference = true;
    this.filterPoissonIndex                    = false;
    this.filterForObjects                      = true;

    let filterAverageValue                         = 1.0;
    let filterStandardDeviationValue               = 1.0;
    let filterMedianAverageAbsoluteDifferenceValue = 1.0;
    let filterPoissonIndexValue                    = 1.0;

    let filterStandardDeviationCap                         = 0.3333333;
    let filterMedianAverageAbsoluteDifferenceCap           = 0.1;
    let filterPoissonIndexCap                              = 0.2;
    let filterStandardDeviationNormalization               = 1.0;
    let filterMedianAverageAbsoluteDifferenceNormalization = 1.0;
    let filterPoissonIndexNormalization                    = 1.0;

    this.setTarget = function( win )
    {
        if ( win.isNull ) throw new Error( "The selected image is invalid." );
        this.window = win;
        this.image  = win.mainView.image;
    };

    this.setWindowSize     = function( ws ) { this.windowSize = ws; this.spacing = -1; };
    this.setSpacingPortion = function( sp ) { this.spacing = Number( (this.windowSize / sp).toFixed(0) ); };

    this.searchBackgroundUserDefined = function( printInfo, previewName )
    {
        if ( this.spacing == -1 ) throw new Error( "Spacing not set." );
        setupFilterNormalization();

        let lowestX = 0, lowestY = 0, lowestScore = Infinity;
        console.abortEnabled = true;
        if ( this.verbosity == 1 )
        {
            console.show();
            console.writeln( "Processing started..." );
            console.writeln( "|.....................................................................................................|" );
            console.write( "|" );
        }

        for ( let region of this.userDefinedRegions )
        {
            let startX = Math.max( this.windowSize, region.left );
            let endX   = Math.min( this.image.width  - this.windowSize, region.right );
            let startY = Math.max( this.windowSize, region.top );
            let endY   = Math.min( this.image.height - this.windowSize, region.bottom );

            let totalIter = Math.ceil((endX-startX)/this.spacing) * Math.ceil((endY-startY)/this.spacing);
            let divisor   = Math.max( 1, Math.floor( totalIter / 100 ) );
            let iter      = 0;

            for ( let x = startX; x < endX; x += this.spacing )
            {
                for ( let y = startY; y < endY; y += this.spacing )
                {
                    calculateFilterValues( x, y );
                    let score = getScore();
                    if ( score < lowestScore ) { lowestScore = score; lowestX = x; lowestY = y; }
                    if ( ++iter % divisor == 0 ) console.write( "." );
                }
                CoreApplication.processEvents();
                if ( console.abortRequested ) { console.writeln( "|" ); console.writeln( "Processing aborted by user." ); return; }
            }
        }

        log( "|" );
        log( "Refining solution using gradient descent..." );
        let refined = gradientDescent( lowestX, lowestY );
        lowestX = refined[0]; lowestY = refined[1];
        log( "Gradient descent finished." );

        if ( this.generatePreview )
            this.window.createPreview( lowestX, lowestY, lowestX + this.windowSize, lowestY + this.windowSize, previewName || "Background" );
        if ( printInfo ) printInformation( lowestX, lowestY );
    };

    this.fastSearchBackgroundUserDefined = function( initialSize, targetCount, printInfo, previewName )
    {
        if ( this.spacing == -1 ) throw new Error( "Spacing not set." );
        console.show(); console.abortEnabled = true;
        log( "Fast search started..." );
        setupFilterNormalization();

        let oldSpacing = this.spacing;
        this.spacing   = initialSize;
        let averages   = [];

        log( "Looking for starting points..." );
        for ( let region of this.userDefinedRegions )
        {
            let startX = Math.max( this.windowSize, region.left );
            let endX   = Math.min( this.image.width  - this.windowSize, region.right );
            let startY = Math.max( this.windowSize, region.top );
            let endY   = Math.min( this.image.height - this.windowSize, region.bottom );
            for ( let x = startX; x < endX; x += this.spacing )
            {
                for ( let y = startY; y < endY; y += this.spacing )
                {
                    calculateFilterValues( x, y );
                    averages.push( [x, y, getScore()] );
                }
                CoreApplication.processEvents();
                if ( console.abortRequested ) throw new Error( "Processing aborted by user." );
            }
        }

        this.spacing = oldSpacing;
        averages = averages.sort( (a,b) => a[2]-b[2] ).slice( 0, targetCount );
        log( "Selected the " + targetCount + " best starting points." );

        let results = [];
        for ( let i = 0; i < averages.length; i++ )
        {
            log( "Optimizing window " + (i+1) + " of " + targetCount + "..." );
            results.push( gradientDescent( averages[i][0], averages[i][1] ) );
            CoreApplication.processEvents();
            if ( console.abortRequested ) throw new Error( "Processing aborted by user." );
        }
        results = results.sort( (a,b) => a[2]-b[2] );
        log( "Selected the best result." );

        if ( this.generatePreview )
            this.window.createPreview( results[0][0], results[0][1], results[0][0] + this.windowSize, results[0][1] + this.windowSize, previewName || "Background" );
        if ( printInfo ) printInformation( results[0][0], results[0][1] );
    };

    // ---- Internal closures (identical logic to FindBackground) ----

    let gradientDescent = ( x, y ) =>
    {
        this.spacing = parseFloat( this.spacing );
        x = parseFloat(x); y = parseFloat(y);
        let lowestScore = Infinity, moveRate = 1.0, lowestX = x, lowestY = y;
        while ( moveRate * this.spacing >= 1.0 )
        {
            let improved = false;
            for ( let dx = -1.0; dx <= 1.0; dx += 1.0 )
                for ( let dy = -1.0; dy <= 1.0; dy += 1.0 )
                {
                    let nx = Math.round( x + dx * this.spacing * moveRate );
                    let ny = Math.round( y + dy * this.spacing * moveRate );
                    if ( nx - this.windowSize < 0 || nx + this.windowSize >= this.image.width ||
                         ny - this.windowSize < 0 || ny + this.windowSize >= this.image.height ) continue;
                    calculateFilterValues( nx, ny );
                    let score = getScore();
                    if ( score < lowestScore ) { lowestScore = score; lowestX = nx; lowestY = ny; improved = true; }
                }
            if ( !improved ) moveRate *= 0.5;
            x = lowestX; y = lowestY;
            CoreApplication.processEvents();
            if ( console.abortRequested ) throw new Error( "Processing aborted by user." );
        }
        return [lowestX, lowestY, lowestScore];
    };

    let calculateFilterValues = ( x, y ) =>
    {
        if ( this.filterAverage ) calculateAverage( x, y );
        if ( this.filterStandardDeviation )
        {
            if ( !this.filterAverage ) calculateAverage( x, y );
            calculateStandardDeviation( x, y, filterAverageValue );
        }
        if ( this.filterMedianAverageAbsoluteDifference )
        {
            if ( !this.filterAverage && !this.filterStandardDeviation ) calculateAverage( x, y );
            if ( !this.filterStandardDeviation ) calculateStandardDeviation( x, y, filterAverageValue );
            calculateMedianAverageAbsoluteDifference( x, y, filterAverageValue, filterStandardDeviationValue );
        }
        if ( this.filterPoissonIndex ) calculatePoissonIndex( x, y );
    };

    let getScore = () =>
    {
        let score = 0;
        if ( this.filterAverage ) score += 1 / filterAverageValue;
        if ( this.filterStandardDeviation )
        {
            let s = 1 / filterStandardDeviationValue;
            score += this.filterAverage
                ? Math.min( (1/filterAverageValue)*filterStandardDeviationCap, filterStandardDeviationNormalization*s )
                : s * filterStandardDeviationNormalization;
        }
        if ( this.filterMedianAverageAbsoluteDifference )
        {
            let m = 1 / filterMedianAverageAbsoluteDifferenceValue;
            score += this.filterAverage
                ? Math.min( (1/filterAverageValue)*filterMedianAverageAbsoluteDifferenceCap, filterMedianAverageAbsoluteDifferenceNormalization*m )
                : m * filterMedianAverageAbsoluteDifferenceNormalization;
        }
        if ( this.filterPoissonIndex )
        {
            let p = 1 / filterPoissonIndexValue;
            score += this.filterAverage
                ? Math.min( (1/filterAverageValue)*filterPoissonIndexCap, filterPoissonIndexNormalization*p )
                : p * filterPoissonIndexNormalization;
        }
        return 1 / score;
    };

    let log = msg => { if ( this.verbosity == 1 ) console.writeln( msg ); CoreApplication.processEvents(); };

    let setupFilterNormalization = () =>
    {
        let tileSize = 500, targetMedian = 0.5;
        let avgs = [], sdevs = [], maads = [], poissons = [];
        let startX = this.windowSize, endX = this.image.width  - this.windowSize;
        let startY = this.windowSize, endY = this.image.height - this.windowSize;
        for ( let x = startX; x <= endX - tileSize; x += tileSize )
            for ( let y = startY; y <= endY - tileSize; y += tileSize )
            {
                calculateFilterValues( x, y );
                avgs.push(filterAverageValue); sdevs.push(filterStandardDeviationValue);
                maads.push(filterMedianAverageAbsoluteDifferenceValue); poissons.push(filterPoissonIndexValue);
            }
        let indices = avgs.map((_,i)=>i).sort((a,b)=>avgs[a]-avgs[b]);
        let n = indices.length;
        let reorder = arr => indices.map(i=>arr[i]).slice(0,Math.floor(n/4));
        avgs=reorder(avgs); sdevs=reorder(sdevs); maads=reorder(maads); poissons=reorder(poissons);
        let mid = a => a[Math.floor(a.length/2)];
        let mAvg=1/mid(avgs), mSdev=1/mid(sdevs), mMaad=1/mid(maads), mPois=1/mid(poissons);
        filterStandardDeviationNormalization               = (targetMedian*filterStandardDeviationCap*mAvg)/mSdev;
        filterMedianAverageAbsoluteDifferenceNormalization = (targetMedian*filterMedianAverageAbsoluteDifferenceCap*mAvg)/mMaad;
        filterPoissonIndexNormalization                    = (targetMedian*filterPoissonIndexCap*mAvg)/mPois;
    };

    let printInformation = ( lx, ly ) =>
    {
        calculateFilterValues( lx, ly );
        let score = getScore();
        console.noteln( "\n\nProcessing finished!\n\n" );
        let bright = new Array( this.image.numberOfChannels ).fill(0);
        for ( let x = lx; x < lx+this.windowSize; x++ )
            for ( let y = ly; y < ly+this.windowSize; y++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    bright[c] += this.image.sample(x,y,c);
        for ( let c = 0; c < this.image.numberOfChannels; c++ ) bright[c] /= this.windowSize*this.windowSize;
        let maxBright = Math.max(...bright);
        console.writeln("Average channel brightness:");
        for ( let c = 0; c < this.image.numberOfChannels; c++ ) console.writeln("\t["+c+"]: "+bright[c]);
        if ( this.image.numberOfChannels > 1 )
        {
            console.writeln("\nAdditive color correction constants:");
            for ( let c = 0; c < this.image.numberOfChannels; c++ ) console.writeln("\t["+c+"]: "+(maxBright-bright[c]));
        }
        console.writeln("\nROI coordinates:\n\tX: "+lx+"\n\tY: "+ly+"\n\tWidth: "+this.windowSize+"\n\tHeight: "+this.windowSize);
        console.writeln("\nQuality assessment:");
        if (this.filterAverage)                           console.writeln("\tAverage brightness                 : "+filterAverageValue);
        if (this.filterStandardDeviation)                 console.writeln("\tStandard deviation                 : "+filterStandardDeviationValue);
        if (this.filterPoissonIndex)                      console.writeln("\tPoisson index                      : "+filterPoissonIndexValue);
        if (this.filterMedianAverageAbsoluteDifference)   console.writeln("\tMedian average absolute difference : "+filterMedianAverageAbsoluteDifferenceValue);
        console.writeln("\tScore                              : "+score);
        console.noteln("Background Found! Preview Created!");
    };

    let calculateAverage = ( x, y ) =>
    {
        let avg = 0;
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    avg += this.image.sample(x+dx,y+dy,c);
        filterAverageValue = avg / (this.windowSize*this.windowSize*this.image.numberOfChannels);
    };

    let calculateStandardDeviation = ( x, y, avg ) =>
    {
        let sd = 0;
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
            {
                let px = 0;
                for ( let c = 0; c < this.image.numberOfChannels; c++ ) px += this.image.sample(x+dx,y+dy,c);
                sd += Math.pow(px-avg,2);
            }
        filterStandardDeviationValue = Math.sqrt( sd / (this.windowSize*this.windowSize*this.image.numberOfChannels) );
    };

    let calculateMedianAverageAbsoluteDifference = ( x, y, avg, stDev ) =>
    {
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
            {
                let px = 0;
                for ( let c = 0; c < this.image.numberOfChannels; c++ ) px += this.image.sample(x+dx,y+dy,c);
                this.brightnessArray[dx*this.windowSize+dy] = px;
            }
        this.brightnessArray = this.brightnessArray.sort((a,b)=>a-b);
        let idx = Math.floor(this.brightnessArray.length/2);
        let med = this.brightnessArray.length%2
            ? this.brightnessArray[idx]
            : (this.brightnessArray[idx-1]+this.brightnessArray[idx])/2;
        filterMedianAverageAbsoluteDifferenceValue = Math.abs(med-avg)/stDev;
    };

    let calculatePoissonIndex = ( x, y ) =>
    {
        let avgs = new Array(this.image.numberOfChannels).fill(0);
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    avgs[c] += this.image.sample(x+dx,y+dy,c);
        for ( let c = 0; c < avgs.length; c++ ) avgs[c] /= this.windowSize*this.windowSize;
        let variances = new Array(this.image.numberOfChannels).fill(0);
        for ( let dx = 0; dx < this.windowSize; dx++ )
            for ( let dy = 0; dy < this.windowSize; dy++ )
                for ( let c = 0; c < this.image.numberOfChannels; c++ )
                    variances[c] += Math.pow(this.image.sample(x+dx,y+dy,c)-avgs[c],2);
        for ( let c = 0; c < variances.length; c++ ) variances[c] /= this.windowSize*this.windowSize;
        let pi = 0;
        for ( let c = 0; c < this.image.numberOfChannels; c++ )
            pi += Math.abs(avgs[c]-variances[c])/avgs[c];
        filterPoissonIndexValue = Math.abs(pi/this.image.numberOfChannels-1);
    };
}

// ============================================================================
// PixelMath helpers (preview stretch)
// ============================================================================

function _fb_configurePixelMath( P )
{
    P.clearImageCacheAndExit = false; P.cacheGeneratedImages = false;
    P.generateOutput = true; P.singleThreaded = false; P.optimization = true;
    P.use64BitWorkingImage = false; P.rescale = false; P.rescaleLower = 0; P.rescaleUpper = 1;
    P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
    P.createNewImage = false; P.showNewImage = true;
}

function processMonoImage( targetView, targetMedian )
{
    let P = new ProcessContainer;
    let P001 = new PixelMath;
    P001.expression =
        "BlackPoint = iif((med($T) - 2.7*sdev($T))<min($T),min($T),med($T) - 2.7*sdev($T));\n" +
        "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
    P001.useSingleExpression = true;
    P001.symbols = "BlackPoint, Rescaled, CurrentMedian, DesiredMedian, Alpha";
    _fb_configurePixelMath( P001 );
    P.add( P001 );

    let P002 = new PixelMath;
    P002.expression = "((Med($T)-1)*" + targetMedian + "*$T)/(Med($T)*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
    P002.useSingleExpression = true;
    P002.symbols = "L, S";
    _fb_configurePixelMath( P002 );
    P.add( P002 );

    P.executeOn( targetView );
}

function processUnlinkedColorImage( targetView, targetMedian )
{
    let P = new ProcessContainer;
    let P001 = new PixelMath;
    P001.useSingleExpression = false;
    P001.expression  = "BlackPoint = iif((med($T[0]) - 2.7*sdev($T[0]))<min($T[0]),min($T[0]),med($T[0]) - 2.7*sdev($T[0]));\nRescaled = ($T[0] - BlackPoint) / (1 - BlackPoint);";
    P001.expression1 = "BlackPoint = iif((med($T[1]) - 2.7*sdev($T[1]))<min($T[1]),min($T[1]),med($T[1]) - 2.7*sdev($T[1]));\nRescaled = ($T[1] - BlackPoint) / (1 - BlackPoint);";
    P001.expression2 = "BlackPoint = iif((med($T[2]) - 2.7*sdev($T[2]))<min($T[2]),min($T[2]),med($T[2]) - 2.7*sdev($T[2]));\nRescaled = ($T[2] - BlackPoint) / (1 - BlackPoint);";
    P001.symbols = "BlackPoint, Rescaled";
    _fb_configurePixelMath( P001 );
    P.add( P001 );

    let P002 = new PixelMath;
    P002.useSingleExpression = false;
    P002.expression  = "((Med($T[0])-1)*"+targetMedian+"*$T[0])/(Med($T[0])*("+targetMedian+"+$T[0]-1)-"+targetMedian+"*$T[0])";
    P002.expression1 = "((Med($T[1])-1)*"+targetMedian+"*$T[1])/(Med($T[1])*("+targetMedian+"+$T[1]-1)-"+targetMedian+"*$T[1])";
    P002.expression2 = "((Med($T[2])-1)*"+targetMedian+"*$T[2])/(Med($T[2])*("+targetMedian+"+$T[2]-1)-"+targetMedian+"*$T[2])";
    P002.symbols = "L, S";
    _fb_configurePixelMath( P002 );
    P.add( P002 );

    P.executeOn( targetView );
}

// ============================================================================
// ScrollControl — preview pane with region drawing
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.autoScroll        = true;
        this.tracking          = true;
        this.displayImage      = null;
        this.dragging          = false;
        this.dragOrigin        = new Point( 0, 0 );
        this.isDragging        = false;
        this.userDefinedRegions = [];
        this.exclusionAreas    = [];
        this.currentRegion     = null;
        this.startX            = 0;
        this.startY            = 0;
        this.scrollPosition    = new Point( 0, 0 );

        this.viewport.cursor = new Cursor( StdCursor.Cross );

        this.viewport.onResize = () => { this.initScrollBars(); };
        this.onHorizontalScrollPosUpdated = () => { if ( this.viewport ) this.viewport.update(); };
        this.onVerticalScrollPosUpdated   = () => { if ( this.viewport ) this.viewport.update(); };

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            if ( modifiers === 1 ) // Shift — draw region
            {
                this.startX    = x + this.scrollPosition.x;
                this.startY    = y + this.scrollPosition.y;
                this.isDragging = true;
                this.dragging   = false;
            }
            else
            {
                this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
                this.dragOrigin.x = x; this.dragOrigin.y = y;
                this.dragging = true;
            }
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            if ( this.isDragging )
            {
                this.currentRegion = clampRectToBounds(
                    normalizeRect( new Rect( this.startX, this.startY,
                        x + this.scrollPosition.x, y + this.scrollPosition.y ) ),
                    this.displayImage.width, this.displayImage.height );
                if ( this.viewport ) this.viewport.update();
            }
            else if ( this.dragging )
            {
                this.scrollPosition = new Point(
                    this.scrollPosition.x + this.dragOrigin.x - x,
                    this.scrollPosition.y + this.dragOrigin.y - y );
                this.dragOrigin.x = x; this.dragOrigin.y = y;
                this.viewport.update();
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            if ( this.isDragging )
            {
                this.isDragging = false;
                let finalRegion = clampRectToBounds(
                    normalizeRect( new Rect( this.startX, this.startY,
                        x + this.scrollPosition.x, y + this.scrollPosition.y ) ),
                    this.displayImage.width, this.displayImage.height );
                this.userDefinedRegions.push( finalRegion );
                this.currentRegion = null;
                if ( this.viewport ) this.viewport.update();
                this.onRectangleSelectionComplete();
            }
            else
            {
                this.viewport.cursor = new Cursor( StdCursor.Cross );
                this.dragging = false;
            }
        };

        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g      = new Graphics( this.viewport );
            let result = this.displayImage;

            if ( result == null )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
            }
            else
            {
                result.selectedRect = new Rect( x0, y0, x1, y1 ).translated( this.scrollPosition );
                g.drawBitmap( x0, y0, result.render() );
                result.resetRectSelection();

                // Draw user-defined regions
                this.userDefinedRegions.forEach( region =>
                {
                    let color = this.ownerDialog && this.ownerDialog.userDefinedExclusionChk.checked ? 0xffff0000 : 0xff00ff00;
                    g.pen = new Pen( color );
                    g.drawRect( region.translatedBy( -this.scrollPosition.x, -this.scrollPosition.y ) );
                } );

                // Draw in-progress region
                if ( this.currentRegion )
                {
                    let color = this.ownerDialog && this.ownerDialog.userDefinedExclusionChk.checked ? 0xffff0000 : 0xff00ff00;
                    g.pen = new Pen( color );
                    g.drawRect( this.currentRegion.translatedBy( -this.scrollPosition.x, -this.scrollPosition.y ) );
                }

                // Draw exclusion areas in blue
                this.exclusionAreas.forEach( area =>
                {
                    g.pen = new Pen( 0xff0000ff );
                    g.drawRect( area.translatedBy( -this.scrollPosition.x, -this.scrollPosition.y ) );
                } );
            }

            g.end();
        };

        this.initScrollBars();
    }

    getImage() { return this.displayImage; }

    doUpdateImage( image )
    {
        this.displayImage = image;
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    initScrollBars()
    {
        let image = this.displayImage;
        if ( image == null || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange(   0, 0 );
        }
        else
        {
            this.setHorizontalScrollRange( 0, Math.max( 0, image.width  - this.viewport.width ) );
            this.setVerticalScrollRange(   0, Math.max( 0, image.height - this.viewport.height ) );
        }
        if ( this.viewport ) this.viewport.update();
    }

    onRectangleSelectionComplete()
    {
        if ( this.userDefinedRegions.length > 0 && this.parent )
        {
            let f = this.parent.downsamplingFactor || 1;
            this.userDefinedRegions.forEach( (region, index) =>
            {
                let sr = new Rect( region.left*f, region.top*f, region.right*f, region.bottom*f );
                console.writeln( "Region " + (index+1) + " (scaled): TL=(" + sr.left + "," + sr.top + ") BR=(" + sr.right + "," + sr.bottom + ")" );
            } );
        }
    }
};

// ============================================================================
// FindBackgroundDialog
// ============================================================================

var FindBackgroundDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.downsamplingFactor = 1;

        // ---- Title ----
        this.title_Lbl = new Label( this );
        this.title_Lbl.frameStyle  = FrameStyle.Box;
        this.title_Lbl.margin      = 6;
        this.title_Lbl.useRichText = true;
        this.title_Lbl.text =
            "<b>FindBackground " + VERSION + "</b> - A script to find a region covering only true background in astronomical images.<br>" +
            "Copyright (C) 2024, Gerrit Erdt<br>Copyright (C) 2024, Franklin Marek<br>";

        // ---- Conditions ----
        this.conditions_Lbl = new Label( this );
        this.conditions_Lbl.frameStyle   = FrameStyle.Box;
        this.conditions_Lbl.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.conditions_Lbl.useRichText  = true;
        this.conditions_Lbl.text =
            "<b>Preconditions:</b><ul>" +
            "<li>The image has been corrected for background gradients.</li>" +
            "<li>Stacking artifacts at the edges have been removed/cropped.</li>" +
            "</ul><b>Results:</b><ul>" +
            "<li>A preview named 'Background' that covers the found background region.</li>" +
            "<li>Optionally: a console output of the background parameters and quality estimators.</li>" +
            "</ul>For a complete documentation of all functionalities, see the tooltips of the respective elements.";

        // ---- Instructions ----
        this.instructions_Lbl = new Label( this );
        this.instructions_Lbl.frameStyle  = FrameStyle.Box;
        this.instructions_Lbl.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.instructions_Lbl.useRichText = true;
        this.instructions_Lbl.text =
            "<b>Instructions:</b> Shift + Click and drag to define User Defined Areas (Multiple Areas allowed)<br>" +
            "Reset Button to Clear Selected Regions";

        // ---- Search area checkboxes ----
        this.fullImageChk = new CheckBox( this );
        this.fullImageChk.text    = "Full Image";
        this.fullImageChk.checked = true;
        this.fullImageChk.toolTip = "Select this option to search the entire image for the background region.";
        this.fullImageChk.onCheck = checked =>
        {
            if ( checked )
            {
                this.userDefinedChk.checked = false;
                this.userDefinedExclusionChk.checked = false;
                this.previewControl.visible = false;
                this.zoomSizer.visible = false;
                this.adjustToContents();
            }
        };

        this.userDefinedChk = new CheckBox( this );
        this.userDefinedChk.text    = "User Defined Search Area";
        this.userDefinedChk.checked = false;
        this.userDefinedChk.toolTip = "Select this option to search a user-defined area for the background region.";
        this.userDefinedChk.onCheck = checked =>
        {
            if ( checked )
            {
                this.fullImageChk.checked = false;
                this.userDefinedExclusionChk.checked = false;
                this.previewControl.userDefinedRegions = [];
                this.previewControl.exclusionAreas     = [];
                this.previewControl.viewport.update();
                this.previewControl.visible = true;
                this.zoomSizer.visible = true;
                if ( parameters.targetWindow )
                {
                    let img = parameters.targetWindow.mainView.image;
                    if ( img )
                    {
                        this.previewControl.displayImage = this.createAndDisplayTemporaryImage( img );
                        this.previewControl.viewport.update();
                    }
                }
                this.adjustToContents();
            }
        };

        this.userDefinedExclusionChk = new CheckBox( this );
        this.userDefinedExclusionChk.text    = "User Defined Exclusion Area";
        this.userDefinedExclusionChk.checked = false;
        this.userDefinedExclusionChk.toolTip = "Select this option to exclude a user-defined area from the background region search.";
        this.userDefinedExclusionChk.onCheck = checked =>
        {
            if ( checked )
            {
                this.fullImageChk.checked = false;
                this.userDefinedChk.checked = false;
                this.previewControl.userDefinedRegions = [];
                this.previewControl.exclusionAreas     = [];
                this.previewControl.viewport.update();
                this.previewControl.visible = true;
                this.zoomSizer.visible = true;
                if ( parameters.targetWindow )
                {
                    let img = parameters.targetWindow.mainView.image;
                    if ( img )
                    {
                        this.previewControl.displayImage = this.createAndDisplayTemporaryImage( img );
                        this.previewControl.viewport.update();
                    }
                }
                this.adjustToContents();
            }
        };

        this.resetButton = new ToolButton( this );
        this.resetButton.icon    = this.scaledResource( ":/icons/reload.png" );
        this.resetButton.toolTip = "User Area Reset";
        this.resetButton.onMousePress = () =>
        {
            this.previewControl.userDefinedRegions = [];
            this.previewControl.viewport.update();
        };

        this.searchAreaSizer = new HorizontalSizer; this.searchAreaSizer.spacing = 6;
        this.searchAreaSizer.add( this.fullImageChk );
        this.searchAreaSizer.add( this.userDefinedChk );
        this.searchAreaSizer.add( this.userDefinedExclusionChk );
        this.searchAreaSizer.add( this.resetButton );

        // ---- Window selector ----
        let currentWindowName = ImageWindow.activeWindow.mainView.id;
        this.windowSelector_Cb = new ComboBox( this );
        this.windowSelector_Cb.toolTip = "Select the window you want to use for the background search.";
        for ( let i = 0; i < ImageWindow.windows.length; i++ )
        {
            this.windowSelector_Cb.addItem( ImageWindow.windows[i].mainView.id );
            if ( ImageWindow.windows[i].mainView.id == currentWindowName )
            {
                this.windowSelector_Cb.currentItem = i;
                let win = ImageWindow.windowById( currentWindowName );
                if ( win && !win.isNull ) parameters.targetWindow = win;
            }
        }
        this.windowSelector_Cb.onItemSelected = index =>
        {
            let win = ImageWindow.windowById( this.windowSelector_Cb.itemText( index ) );
            if ( win && !win.isNull )
            {
                parameters.targetWindow = win;
                let img = win.mainView.image;
                if ( img ) this.createAndDisplayTemporaryImage( img );
            }
        };

        // ---- Filter checkboxes ----
        this.filterInformation_Lbl = new Label( this );
        this.filterInformation_Lbl.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.filterInformation_Lbl.useRichText   = true;
        this.filterInformation_Lbl.text          = "Filters: ";

        this.filterSdev_Chk = new CheckBox( this );
        this.filterSdev_Chk.text    = "Standard deviation";
        this.filterSdev_Chk.checked = parameters.filterSdev;
        this.filterSdev_Chk.onCheck = checked => { parameters.filterSdev = checked; };

        this.filterPoisonIndex_Chk = new CheckBox( this );
        this.filterPoisonIndex_Chk.text    = "Poisson distribution fit";
        this.filterPoisonIndex_Chk.checked = parameters.filterPoisonIndex;
        this.filterPoisonIndex_Chk.onCheck = checked => { parameters.filterPoisonIndex = checked; };

        this.filterMAAD_Chk = new CheckBox( this );
        this.filterMAAD_Chk.text    = "Absolute median average deviation";
        this.filterMAAD_Chk.checked = parameters.filterMAAD;
        this.filterMAAD_Chk.onCheck = checked => { parameters.filterMAAD = checked; };

        this.filterObjects_Chk = new CheckBox( this );
        this.filterObjects_Chk.text    = "Filters out objects";
        this.filterObjects_Chk.checked = parameters.filterObjects;
        this.filterObjects_Chk.onCheck = checked => { parameters.filterObjects = checked; };

        this.filterSizerVertical = new VerticalSizer; this.filterSizerVertical.spacing = 6;
        this.filterSizerVertical.add( this.filterSdev_Chk );
        this.filterSizerVertical.add( this.filterPoisonIndex_Chk );
        this.filterSizerVertical.add( this.filterMAAD_Chk );
        this.filterSizerVertical.add( this.filterObjects_Chk );

        this.filterSizerHorizontal = new HorizontalSizer;
        this.filterSizerHorizontal.addUnscaledSpacing( constants.indent );
        this.filterSizerHorizontal.add( this.filterSizerVertical );

        // ---- Search routine radio buttons ----
        this.searchRoutine_Lbl = new Label( this );
        this.searchRoutine_Lbl.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.searchRoutine_Lbl.useRichText   = true;
        this.searchRoutine_Lbl.text          = "Search routine: ";

        this.slowSearch_Rdb = new RadioButton( this );
        this.slowSearch_Rdb.text    = "Slow search";
        this.slowSearch_Rdb.checked = parameters.slowSearch;
        this.slowSearch_Rdb.onCheck = checked =>
        {
            parameters.slowSearch = checked; parameters.fastSearch = !checked;
            this.backgroundParameterSearchGridSize_NC.enabled = false;
            this.backgroundParameterStartingPoints_NC.enabled = false;
        };

        this.fastSearch_Rdb = new RadioButton( this );
        this.fastSearch_Rdb.text    = "Fast search";
        this.fastSearch_Rdb.checked = parameters.fastSearch;
        this.fastSearch_Rdb.onCheck = checked =>
        {
            parameters.fastSearch = checked; parameters.slowSearch = !checked;
            this.backgroundParameterSearchGridSize_NC.enabled = true;
            this.backgroundParameterStartingPoints_NC.enabled = true;
        };

        this.searchOptionsSizerVertical = new VerticalSizer; this.searchOptionsSizerVertical.spacing = 6;
        this.searchOptionsSizerVertical.add( this.slowSearch_Rdb );
        this.searchOptionsSizerVertical.add( this.fastSearch_Rdb );
        this.searchOptionsSizerHorizontal = new HorizontalSizer;
        this.searchOptionsSizerHorizontal.addUnscaledSpacing( constants.indent );
        this.searchOptionsSizerHorizontal.add( this.searchOptionsSizerVertical );

        // ---- Search parameters ----
        this.backgroundRegionParameters_Lbl = new Label( this );
        this.backgroundRegionParameters_Lbl.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.backgroundRegionParameters_Lbl.useRichText   = true;
        this.backgroundRegionParameters_Lbl.text          = "Search parameters: ";

        let makeNC = ( labelText, range, precision, value, onUpdate ) =>
        {
            let nc = new NumericControl( this );
            nc.real = true;
            nc.label.text = labelText;
            nc.label.minWidth = constants.minLabelSize;
            nc.label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
            nc.setRange( range[0], range[1] ); nc.setPrecision( precision ); nc.setValue( value );
            nc.slider.minWidth = 200; nc.edit.minWidth = 50;
            nc.onValueUpdated = onUpdate;
            return nc;
        };

        this.backgroundParameterSize_NC = makeNC(
            "Size: ", [2,500], 0, parameters.size, v => { parameters.size = Math.round(v); } );
        this.backgroundParameterSpacingRate_NC = makeNC(
            "Spacing rate: ", [1,10], 0, parameters.spacingRate, v => { parameters.spacingRate = Math.round(v); } );
        this.backgroundParameterSearchGridSize_NC = makeNC(
            "Search grid width: ", [10,500], 0, parameters.searchGridSize, v => { parameters.searchGridSize = Math.round(v); } );
        this.backgroundParameterStartingPoints_NC = makeNC(
            "Number of starting points: ", [1,1000], 0, parameters.startingPoints, v => { parameters.startingPoints = Math.round(v); } );

        this.backgroundParameterSizerVertical = new VerticalSizer; this.backgroundParameterSizerVertical.spacing = 0;
        this.backgroundParameterSizerVertical.add( this.backgroundParameterSize_NC );
        this.backgroundParameterSizerVertical.add( this.backgroundParameterSpacingRate_NC );
        this.backgroundParameterSizerVertical.add( this.backgroundParameterSearchGridSize_NC );
        this.backgroundParameterSizerVertical.add( this.backgroundParameterStartingPoints_NC );
        this.backgroundParametersSizerHorizontal = new HorizontalSizer;
        this.backgroundParametersSizerHorizontal.addUnscaledSpacing( constants.indent );
        this.backgroundParametersSizerHorizontal.add( this.backgroundParameterSizerVertical );

        // ---- Output options ----
        this.printInformation_Chk = new CheckBox( this );
        this.printInformation_Chk.text    = "Print information to the console";
        this.printInformation_Chk.checked = parameters.printInformation;
        this.printInformation_Chk.onCheck = checked => { parameters.printInformation = checked; };

        this.generatePreview_Chk = new CheckBox( this );
        this.generatePreview_Chk.text    = "Generate background preview";
        this.generatePreview_Chk.checked = parameters.generatePreview;
        this.generatePreview_Chk.onCheck = checked =>
        {
            parameters.generatePreview = checked;
            parameters.previewName = checked ? parameters.previewName : "";
            this.previewName.enabled = checked;
        };

        this.previewName = new Edit( this );
        this.previewName.text = parameters.previewName;
        this.previewName.onTextUpdated = text => { parameters.previewName = text; };

        this.previewSizerHorizontal = new HorizontalSizer; this.previewSizerHorizontal.spacing = 6;
        this.previewSizerHorizontal.add( this.generatePreview_Chk );
        this.previewSizerHorizontal.add( this.previewName );

        this.removePreview_Btn = new PushButton( this );
        this.removePreview_Btn.text    = "Remove previous preview";
        this.removePreview_Btn.onClick = () =>
        {
            let win = parameters.targetWindow;
            if ( !win ) return;
            let previews = win.previews;
            for ( let i = 0; i < previews.length; i++ )
                if ( previews[i].id == parameters.previewName ) { win.deletePreview( previews[i] ); break; }
        };

        this.removePreview_Sizer = new HorizontalSizer;
        this.removePreview_Sizer.add( this.removePreview_Btn );
        this.removePreview_Sizer.addStretch();

        // ---- New Instance / Execute ----
        this.newInstance_Btn = new ToolButton( this );
        this.newInstance_Btn.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstance_Btn.setScaledFixedSize( 24, 24 );
        this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
        this.newInstance_Btn.onMousePress = () => { parameters.save(); this.newInstance(); };

        this.execute_Btn = new PushButton( this );
        this.execute_Btn.text    = "Search!";
        this.execute_Btn.toolTip = "Start the search for the background region with the selected parameters.";
        this.execute_Btn.onClick = () => { parameters.save(); this.ok(); };

        this.buttonSizerHorizontal = new HorizontalSizer; this.buttonSizerHorizontal.spacing = 0;
        this.buttonSizerHorizontal.add( this.newInstance_Btn );
        this.buttonSizerHorizontal.addStretch();
        this.buttonSizerHorizontal.add( this.execute_Btn );

        // ---- Zoom / preview control ----
        this.zoomSizer = new HorizontalSizer; this.zoomSizer.spacing = 0;

        this.zoomLabel = new Label( this );
        this.zoomLabel.text = "Preview Zoom Level: ";
        this.zoomLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.zoomSizer.add( this.zoomLabel );

        this.zoomLevelComboBox = new ComboBox( this );
        ["1:1","1:2","1:4","1:8","Fit to Preview"].forEach( t => this.zoomLevelComboBox.addItem(t) );
        this.zoomLevelComboBox.currentItem = 4;
        this.zoomSizer.add( this.zoomLevelComboBox, 1 );

        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth(  640 );
        this.previewControl.setMinHeight( 450 );
        // Give the scroll control a back-reference so onPaint can check the exclusion checkbox state
        this.previewControl.ownerDialog = this;

        // ---- Main layout ----
        this.mainSizer = new HorizontalSizer; this.mainSizer.spacing = 0; this.mainSizer.margin = 0;

        this.leftSizer = new VerticalSizer; this.leftSizer.spacing = 0;
        this.leftSizer.add( this.title_Lbl ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.conditions_Lbl ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.instructions_Lbl );
        this.leftSizer.add( this.searchAreaSizer ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.windowSelector_Cb ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.filterInformation_Lbl );
        this.leftSizer.add( this.filterSizerHorizontal ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.searchRoutine_Lbl );
        this.leftSizer.add( this.searchOptionsSizerHorizontal ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.backgroundRegionParameters_Lbl );
        this.leftSizer.add( this.backgroundParametersSizerHorizontal ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.printInformation_Chk );
        this.leftSizer.add( this.previewSizerHorizontal );
        this.leftSizer.add( this.removePreview_Sizer ); this.leftSizer.addSpacing(10);
        this.leftSizer.add( this.buttonSizerHorizontal );
        this.leftSizer.add( this.zoomSizer );

        this.mainSizer.add( this.leftSizer );
        this.mainSizer.add( this.previewControl, 1 );

        this.sizer = this.mainSizer;
        this.windowTitle = "FindBackground";
        this.adjustToContents();

        // ---- Zoom level change handler ----
        this.zoomLevelComboBox.onItemSelected = index =>
        {
            if ( parameters.targetWindow )
            {
                let img = parameters.targetWindow.mainView.image;
                if ( img )
                {
                    let tmp = this.createAndDisplayTemporaryImage( img );
                    this.previewControl.displayImage = tmp;
                    this.previewControl.viewport.update();
                }
            }
        };

        // ---- onShow ----
        this.onShow = () =>
        {
            if ( this.windowSelector_Cb.currentItem >= 0 && this.userDefinedChk.checked )
            {
                let win = ImageWindow.windowById( this.windowSelector_Cb.itemText( this.windowSelector_Cb.currentItem ) );
                if ( win && !win.isNull )
                {
                    let img = win.mainView.image;
                    if ( img )
                    {
                        let tmp = this.createAndDisplayTemporaryImage( img );
                        this.previewControl.displayImage = tmp;
                        this.previewControl.initScrollBars();
                        this.previewControl.viewport.update();
                    }
                }
            }
            else
            {
                this.previewControl.visible = false;
                this.zoomSizer.visible      = false;
                this.adjustToContents();
            }
        };

        // Initially hidden
        this.previewControl.visible = false;
        this.zoomSizer.visible      = false;
    }

    createAndDisplayTemporaryImage( selectedImage )
    {
        let win = new ImageWindow(
            selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor );

        win.mainView.beginProcess();
        win.mainView.image.assign( selectedImage );
        win.mainView.endProcess();

        if ( selectedImage.numberOfChannels == 1 )
            processMonoImage( win.mainView, 0.25 );
        else
            processUnlinkedColorImage( win.mainView, 0.25 );

        let P = new IntegerResample;
        switch ( this.zoomLevelComboBox.currentItem )
        {
        case 0: P.zoomFactor = -1; this.downsamplingFactor = 1; break;
        case 1: P.zoomFactor = -2; this.downsamplingFactor = 2; break;
        case 2: P.zoomFactor = -4; this.downsamplingFactor = 4; break;
        case 3: P.zoomFactor = -8; this.downsamplingFactor = 8; break;
        case 4:
        {
            let ws = Math.floor( selectedImage.width / this.previewControl.width );
            P.zoomFactor = -Math.max( ws, 1 );
            this.downsamplingFactor = Math.max( ws, 1 );
            break;
        }
        default: P.zoomFactor = -2; this.downsamplingFactor = 2; break;
        }
        P.executeOn( win.mainView );

        let resizedImage = new Image( win.mainView.image );
        if ( resizedImage.width > 0 && resizedImage.height > 0 )
        {
            this.previewControl.displayImage = resizedImage;
            this.previewControl.doUpdateImage( resizedImage );
            this.previewControl.initScrollBars();
        }
        win.forceClose();
        return resizedImage;
    }
};

// ============================================================================
// Finder factory
// ============================================================================

function getFinderInstance( userDefinedRegions )
{
    let win = parameters.targetWindow;
    if ( !win || win.isNull )
    {
        console.show();
        console.criticalln( "No target window selected or the selected window is invalid." );
        return null;
    }

    let finder;
    if ( userDefinedRegions && userDefinedRegions.length > 0 )
        finder = new FindBackgroundUserDefined( parameters.size, parameters.spacingRate, userDefinedRegions );
    else
        finder = new FindBackground( parameters.size, parameters.spacingRate );

    finder.filterAverage                         = parameters.filterAvg;
    finder.filterStandardDeviation               = parameters.filterSdev;
    finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
    finder.filterPoissonIndex                    = parameters.filterPoisonIndex;
    finder.filterForObjects                      = parameters.filterObjects;
    finder.setTarget( win );
    return finder;
}

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );

    if ( Parameters.isGlobalTarget )
    {
        console.show();
        console.criticalln( "FindBackground can only be executed on a single image, not in global context." );
        return false;
    }

    if ( Parameters.isViewTarget )
    {
        parameters.load();
        parameters.targetWindow = ImageWindow.activeWindow;

        let finder = getFinderInstance();
        if ( !finder ) return false;

        let previewName = parameters.generatePreview ? parameters.previewName : "";

        if ( parameters.slowSearch )
            finder.searchBackground( parameters.printInformation, previewName );
        else
            finder.fastSearchBackground( parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, previewName );

        console.noteln( "Background Found! Preview Created!" );
        return false;
    }

    let dialog = new FindBackgroundDialog();
    if ( !dialog.execute() )
    {
        console.noteln( "FindBackground dialog closed." );
        return false;
    }

    parameters.save();

    let win = ImageWindow.windowById( dialog.windowSelector_Cb.itemText( dialog.windowSelector_Cb.currentItem ) );
    if ( !win || win.isNull ) { console.criticalln( "No valid target window selected." ); return false; }
    parameters.targetWindow = win;
    win.bringToFront();

    let view            = win.mainView;
    let prevMaskEnabled = view.maskEnabled;
    view.maskEnabled    = false;
    let wrapped         = false;

    try
    {
        view.beginProcess( UndoFlag.NoSwapFile );
        wrapped = true;

        let f = dialog.downsamplingFactor || 1;
        let userDefinedRegions = [];
        if ( dialog.userDefinedChk.checked || dialog.userDefinedExclusionChk.checked )
        {
            userDefinedRegions = dialog.previewControl.userDefinedRegions.map(
                r => new Rect( r.left*f, r.top*f, r.right*f, r.bottom*f ) );
            userDefinedRegions = mergeOverlappingRegions( userDefinedRegions );
        }

        let exclusionAreas = [];
        if ( dialog.userDefinedExclusionChk.checked )
            exclusionAreas = userDefinedRegions.slice();

        let previewName = parameters.generatePreview ? parameters.previewName : "";

        let finder;
        if ( dialog.fastSearch_Rdb.checked )
        {
            if ( userDefinedRegions.length > 0 && !dialog.userDefinedExclusionChk.checked )
            {
                finder = new FindBackgroundUserDefined( parameters.size, parameters.spacingRate, userDefinedRegions );
                finder.filterAverage = parameters.filterAvg; finder.filterStandardDeviation = parameters.filterSdev;
                finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
                finder.filterPoissonIndex = parameters.filterPoisonIndex; finder.filterForObjects = parameters.filterObjects;
                finder.setTarget( parameters.targetWindow );
                finder.fastSearchBackgroundUserDefined( parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, previewName );
            }
            else
            {
                finder = new FindBackground( parameters.size, parameters.spacingRate );
                finder.filterAverage = parameters.filterAvg; finder.filterStandardDeviation = parameters.filterSdev;
                finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
                finder.filterPoissonIndex = parameters.filterPoisonIndex; finder.filterForObjects = parameters.filterObjects;
                finder.exclusionAreas = exclusionAreas;
                finder.setTarget( parameters.targetWindow );
                finder.fastSearchBackground( parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, previewName );
            }
        }
        else
        {
            if ( userDefinedRegions.length > 0 && !dialog.userDefinedExclusionChk.checked )
            {
                finder = new FindBackgroundUserDefined( parameters.size, parameters.spacingRate, userDefinedRegions );
                finder.filterAverage = parameters.filterAvg; finder.filterStandardDeviation = parameters.filterSdev;
                finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
                finder.filterPoissonIndex = parameters.filterPoisonIndex; finder.filterForObjects = parameters.filterObjects;
                finder.setTarget( parameters.targetWindow );
                finder.searchBackgroundUserDefined( parameters.printInformation, previewName );
            }
            else
            {
                finder = new FindBackground( parameters.size, parameters.spacingRate );
                finder.filterAverage = parameters.filterAvg; finder.filterStandardDeviation = parameters.filterSdev;
                finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
                finder.filterPoissonIndex = parameters.filterPoisonIndex; finder.filterForObjects = parameters.filterObjects;
                finder.exclusionAreas = exclusionAreas;
                finder.setTarget( parameters.targetWindow );
                finder.searchBackground( parameters.printInformation, previewName );
            }
        }
    }
    finally
    {
        view.maskEnabled = prevMaskEnabled;
        if ( wrapped ) view.endProcess();
    }

    console.noteln( "Background Found! Preview Created!" );
    return true;
}

while ( main() );
