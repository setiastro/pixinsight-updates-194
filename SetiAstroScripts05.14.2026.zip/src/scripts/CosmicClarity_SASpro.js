#engine v8

#feature-id CosmicClarity : SetiAstro > Cosmic Clarity - SASpro
#feature-icon  astrosuite.svg
#feature-info This script works with Seti Astro Suite Pro Cosmic Clarity program

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Cosmic Clarity - SASpro
 * Version: V1.4
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script integrates with Seti Astro Suite Pro Cosmic Clarity CLI
 * to sharpen images directly from PixInsight.
 *
 * Aberration Remover model and weights © Riccardo Alberghi.
 * More information: https://github.com/riccardoalberghi
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define VERSION "v1.4"

var IS_WIN = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
var IS_MAC = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
var IS_LIN = (CoreApplication.platform == "Linux");

var pathSeparator = IS_WIN ? "\\" : "/";

var _sysTemp = _cc_normalizePathForExternal( File.systemTempDirectory );
var scriptTempDir = _cc_normalizePathForExternal(
    _sysTemp + pathSeparator + "SetiAstroCosmicClarity_SASpro" );

if ( !File.directoryExists( scriptTempDir ) )
    File.createDirectory( scriptTempDir );

// ============================================================================
// Config parsing helpers
// ============================================================================

function _cc_toBool( s, defv )
{
    var v = String( s ).toLowerCase().trim();
    if ( v == "1" || v == "true"  || v == "yes" || v == "on"  ) return true;
    if ( v == "0" || v == "false" || v == "no"  || v == "off" ) return false;
    return defv;
}

function _cc_toFloat( s, defv )
{
    var x = parseFloat( String( s ) );
    return isNaN( x ) ? defv : x;
}

function _cc_toInt( s, defv )
{
    var x = parseInt( String( s ), 10 );
    return isNaN( x ) ? defv : x;
}

// ============================================================================
// Parameters / config
// ============================================================================

var SetiAstroSharpParameters = {
    targetView: undefined,

    sharpeningMode:            "Both",
    stellarAmount:             0.90,
    nonStellarStrength:        3.00,
    nonStellarAmount:          0.50,
    sharpenChannelsSeparately: false,
    useGPU:                    true,
    removeAberrationFirst:     false,
    tempStretch:               false,
    tempStretchTargetMedian:   0.25,

    inputReadyTimeoutSec:      30,
    outputReadyTimeoutSec:     300,

    processMode:   "sharpen",
    autoPSF:       false,

    denoiseLuma:              0.50,
    denoiseColor:             0.50,
    denoiseMode:              "full",
    separateDenoiseChannels:  false,
    denoiseModel:             "Standard",

    superResScale: 2,

    darkStarMode:              "unscreen",
    darkStarProcessingPath:    "hybrid_luma_color",
    darkStarShowStarsOnly:     true,
    darkStarOverlapFrac:       0.125,
    darkStarEdgePadding:       64,
    darkStarCompatibilityMode: false,

    satelliteMode:        "full",
    satelliteClipTrail:   true,
    satelliteSensitivity: 0.10,

    chunkSize: 256,
    overlap:   64,

    cliLauncherMode:   "Auto Detect",
    cliLauncherPath:   "",
    pythonScriptPath:  "",

    configFilePath: scriptTempDir + pathSeparator + "saspro_cc_cli_config.txt",

    save: function()
    {
        Parameters.set( "processMode",              this.processMode );
        Parameters.set( "useGPU",                   this.useGPU );
        Parameters.set( "removeAberrationFirst",    this.removeAberrationFirst );
        Parameters.set( "tempStretch",              this.tempStretch );
        Parameters.set( "tempStretchTargetMedian",  this.tempStretchTargetMedian );
        Parameters.set( "inputReadyTimeoutSec",     this.inputReadyTimeoutSec );
        Parameters.set( "outputReadyTimeoutSec",    this.outputReadyTimeoutSec );
        Parameters.set( "darkStarMode",             this.darkStarMode );
        Parameters.set( "darkStarProcessingPath",   this.darkStarProcessingPath );
        Parameters.set( "darkStarShowStarsOnly",    this.darkStarShowStarsOnly );
        Parameters.set( "darkStarOverlapFrac",      this.darkStarOverlapFrac );
        Parameters.set( "darkStarEdgePadding",      this.darkStarEdgePadding );
        Parameters.set( "darkStarCompatibilityMode",this.darkStarCompatibilityMode );
        Parameters.set( "chunkSize",                this.chunkSize );
        Parameters.set( "overlap",                  this.overlap );
        Parameters.set( "sharpeningMode",           this.sharpeningMode );
        Parameters.set( "stellarAmount",            this.stellarAmount );
        Parameters.set( "nonStellarStrength",       this.nonStellarStrength );
        Parameters.set( "nonStellarAmount",         this.nonStellarAmount );
        Parameters.set( "sharpenChannelsSeparately",this.sharpenChannelsSeparately );
        Parameters.set( "autoPSF",                  this.autoPSF );
        Parameters.set( "denoiseLuma",              this.denoiseLuma );
        Parameters.set( "denoiseColor",             this.denoiseColor );
        Parameters.set( "denoiseMode",              this.denoiseMode );
        Parameters.set( "separateDenoiseChannels",  this.separateDenoiseChannels );
        Parameters.set( "denoiseModel",             this.denoiseModel );
        Parameters.set( "superResScale",            this.superResScale );
        Parameters.set( "satelliteMode",            this.satelliteMode );
        Parameters.set( "satelliteClipTrail",       this.satelliteClipTrail );
        Parameters.set( "satelliteSensitivity",     this.satelliteSensitivity );
        Parameters.set( "cliLauncherMode",          this.cliLauncherMode );
        Parameters.set( "cliLauncherPath",          this.cliLauncherPath );
        Parameters.set( "pythonScriptPath",         this.pythonScriptPath );
        this.saveConfigFile();
    },

    load: function()
    {
        if ( Parameters.has( "processMode" ) )             this.processMode              = Parameters.getString( "processMode" );
        if ( Parameters.has( "useGPU" ) )                  this.useGPU                   = Parameters.getBoolean( "useGPU" );
        if ( Parameters.has( "tempStretch" ) )             this.tempStretch              = Parameters.getBoolean( "tempStretch" );
        if ( Parameters.has( "tempStretchTargetMedian" ) ) this.tempStretchTargetMedian  = Parameters.getReal( "tempStretchTargetMedian" );
        if ( Parameters.has( "inputReadyTimeoutSec" ) )    this.inputReadyTimeoutSec     = Parameters.getInteger( "inputReadyTimeoutSec" );
        if ( Parameters.has( "outputReadyTimeoutSec" ) )   this.outputReadyTimeoutSec    = Parameters.getInteger( "outputReadyTimeoutSec" );
        if ( Parameters.has( "removeAberrationFirst" ) )   this.removeAberrationFirst    = Parameters.getBoolean( "removeAberrationFirst" );
        if ( Parameters.has( "darkStarMode" ) )            this.darkStarMode             = Parameters.getString( "darkStarMode" );
        if ( Parameters.has( "darkStarProcessingPath" ) )  this.darkStarProcessingPath   = Parameters.getString( "darkStarProcessingPath" );
        if ( Parameters.has( "darkStarShowStarsOnly" ) )   this.darkStarShowStarsOnly    = Parameters.getBoolean( "darkStarShowStarsOnly" );
        if ( Parameters.has( "darkStarOverlapFrac" ) )     this.darkStarOverlapFrac      = Parameters.getReal( "darkStarOverlapFrac" );
        if ( Parameters.has( "darkStarEdgePadding" ) )     this.darkStarEdgePadding      = Parameters.getInteger( "darkStarEdgePadding" );
        if ( Parameters.has( "darkStarCompatibilityMode" ) ) this.darkStarCompatibilityMode = Parameters.getBoolean( "darkStarCompatibilityMode" );
        if ( Parameters.has( "chunkSize" ) )               this.chunkSize                = Parameters.getInteger( "chunkSize" );
        if ( Parameters.has( "overlap" ) )                 this.overlap                  = Parameters.getInteger( "overlap" );
        if ( Parameters.has( "sharpeningMode" ) )          this.sharpeningMode           = Parameters.getString( "sharpeningMode" );
        if ( Parameters.has( "stellarAmount" ) )           this.stellarAmount            = Parameters.getReal( "stellarAmount" );
        if ( Parameters.has( "nonStellarStrength" ) )      this.nonStellarStrength       = Parameters.getReal( "nonStellarStrength" );
        if ( Parameters.has( "nonStellarAmount" ) )        this.nonStellarAmount         = Parameters.getReal( "nonStellarAmount" );
        if ( Parameters.has( "sharpenChannelsSeparately" ) ) this.sharpenChannelsSeparately = Parameters.getBoolean( "sharpenChannelsSeparately" );
        if ( Parameters.has( "autoPSF" ) )                 this.autoPSF                  = Parameters.getBoolean( "autoPSF" );
        if ( Parameters.has( "denoiseLuma" ) )             this.denoiseLuma              = Parameters.getReal( "denoiseLuma" );
        if ( Parameters.has( "denoiseColor" ) )            this.denoiseColor             = Parameters.getReal( "denoiseColor" );
        if ( Parameters.has( "denoiseMode" ) )             this.denoiseMode              = Parameters.getString( "denoiseMode" );
        if ( Parameters.has( "separateDenoiseChannels" ) ) this.separateDenoiseChannels  = Parameters.getBoolean( "separateDenoiseChannels" );
        if ( Parameters.has( "denoiseModel" ) )            this.denoiseModel             = Parameters.getString( "denoiseModel" );
        if ( Parameters.has( "superResScale" ) )           this.superResScale            = Parameters.getInteger( "superResScale" );
        if ( Parameters.has( "satelliteMode" ) )           this.satelliteMode            = Parameters.getString( "satelliteMode" );
        if ( Parameters.has( "satelliteClipTrail" ) )      this.satelliteClipTrail       = Parameters.getBoolean( "satelliteClipTrail" );
        if ( Parameters.has( "satelliteSensitivity" ) )    this.satelliteSensitivity     = Parameters.getReal( "satelliteSensitivity" );
        if ( Parameters.has( "cliLauncherMode" ) )         this.cliLauncherMode          = Parameters.getString( "cliLauncherMode" );
        if ( Parameters.has( "cliLauncherPath" ) )         this.cliLauncherPath          = Parameters.getString( "cliLauncherPath" );
        if ( Parameters.has( "pythonScriptPath" ) )        this.pythonScriptPath         = Parameters.getString( "pythonScriptPath" );

        this.loadConfigFile();

        // Safety clamps
        if ( this.superResScale != 2 && this.superResScale != 3 && this.superResScale != 4 )
            this.superResScale = 2;
        if ( this.sharpeningMode != "Both" && this.sharpeningMode != "Stellar Only" && this.sharpeningMode != "Non-Stellar Only" )
            this.sharpeningMode = "Both";
        if ( this.denoiseMode != "full" && this.denoiseMode != "luminance" )
            this.denoiseMode = "full";
        if ( this.denoiseModel != "Standard" && this.denoiseModel != "Walking Noise" && this.denoiseModel != "Lite (faster)" )
            this.denoiseModel = "Standard";
        if ( this.satelliteMode != "full" && this.satelliteMode != "luminance" )
            this.satelliteMode = "full";
        if ( ["sharpen","denoise","both","superres","satellite","darkstar"].indexOf( this.processMode ) < 0 )
            this.processMode = "sharpen";

        this.tempStretchTargetMedian = _cc_toFloat( this.tempStretchTargetMedian, 0.25 );
        if ( this.tempStretchTargetMedian < 0.01 ) this.tempStretchTargetMedian = 0.01;
        if ( this.tempStretchTargetMedian > 0.50 ) this.tempStretchTargetMedian = 0.50;

        this.inputReadyTimeoutSec  = _cc_toInt( this.inputReadyTimeoutSec, 30 );
        this.outputReadyTimeoutSec = _cc_toInt( this.outputReadyTimeoutSec, 300 );
        if ( this.inputReadyTimeoutSec  < 5    ) this.inputReadyTimeoutSec  = 5;
        if ( this.inputReadyTimeoutSec  > 3600 ) this.inputReadyTimeoutSec  = 3600;
        if ( this.outputReadyTimeoutSec < 10   ) this.outputReadyTimeoutSec = 10;
        if ( this.outputReadyTimeoutSec > 14400) this.outputReadyTimeoutSec = 14400;

        this.chunkSize = _cc_toInt( this.chunkSize, 256 );
        this.overlap   = _cc_toInt( this.overlap,   64  );
        if ( this.chunkSize < 64   ) this.chunkSize = 64;
        if ( this.chunkSize > 2048 ) this.chunkSize = 2048;
        if ( this.overlap   < 0    ) this.overlap   = 0;
        if ( this.overlap   >= this.chunkSize ) this.overlap = Math.max( 0, this.chunkSize - 1 );
    },

    saveConfigFile: function()
    {
        try
        {
            var lines = [];
            lines.push( "cliLauncherMode="  + (this.cliLauncherMode  || "") );
            lines.push( "cliLauncherPath="  + (this.cliLauncherPath  || "") );
            lines.push( "pythonScriptPath=" + (this.pythonScriptPath || "") );
            lines.push( "processMode="      + (this.processMode      || "sharpen") );
            lines.push( "useGPU="           + (this.useGPU ? "1" : "0") );
            lines.push( "removeAberrationFirst=" + (this.removeAberrationFirst ? "1" : "0") );
            lines.push( "chunkSize="        + format( "%d",   this.chunkSize || 256 ) );
            lines.push( "overlap="          + format( "%d",   this.overlap   || 64  ) );
            lines.push( "sharpeningMode="   + (this.sharpeningMode || "Both") );
            lines.push( "stellarAmount="    + format( "%.6f", this.stellarAmount ) );
            lines.push( "nonStellarStrength=" + format( "%.6f", this.nonStellarStrength ) );
            lines.push( "nonStellarAmount=" + format( "%.6f", this.nonStellarAmount ) );
            lines.push( "sharpenChannelsSeparately=" + (this.sharpenChannelsSeparately ? "1" : "0") );
            lines.push( "autoPSF="          + (this.autoPSF ? "1" : "0") );
            lines.push( "tempStretch="      + (this.tempStretch ? "1" : "0") );
            lines.push( "tempStretchTargetMedian=" + format( "%.6f", this.tempStretchTargetMedian ) );
            lines.push( "inputReadyTimeoutSec="    + format( "%d",   this.inputReadyTimeoutSec ) );
            lines.push( "outputReadyTimeoutSec="   + format( "%d",   this.outputReadyTimeoutSec ) );
            lines.push( "darkStarMode="            + (this.darkStarMode || "unscreen") );
            lines.push( "darkStarProcessingPath="  + (this.darkStarProcessingPath || "hybrid_luma_color") );
            lines.push( "darkStarShowStarsOnly="   + (this.darkStarShowStarsOnly ? "1" : "0") );
            lines.push( "darkStarOverlapFrac="     + format( "%.6f", this.darkStarOverlapFrac ) );
            lines.push( "darkStarEdgePadding="     + format( "%d",   this.darkStarEdgePadding ) );
            lines.push( "darkStarCompatibilityMode=" + (this.darkStarCompatibilityMode ? "1" : "0") );
            lines.push( "denoiseLuma="             + format( "%.6f", this.denoiseLuma ) );
            lines.push( "denoiseColor="            + format( "%.6f", this.denoiseColor ) );
            lines.push( "denoiseMode="             + (this.denoiseMode || "full") );
            lines.push( "separateDenoiseChannels=" + (this.separateDenoiseChannels ? "1" : "0") );
            lines.push( "denoiseModel="            + (this.denoiseModel || "Standard") );
            lines.push( "superResScale="           + format( "%d",   this.superResScale || 2 ) );
            lines.push( "satelliteMode="           + (this.satelliteMode || "full") );
            lines.push( "satelliteClipTrail="      + (this.satelliteClipTrail ? "1" : "0") );
            lines.push( "satelliteSensitivity="    + format( "%.6f", this.satelliteSensitivity ) );
            File.writeTextFile( this.configFilePath, lines.join( "\n" ) );
        }
        catch ( e ) { console.warningln( "Failed to save CLI config: " + e.message ); }
    },

    loadConfigFile: function()
    {
        try
        {
            if ( !File.exists( this.configFilePath ) ) return;
            var lines = File.readLines( this.configFilePath );
            if ( !lines || lines.length === 0 ) return;

            var looksLikeOldFormat = true;
            for ( var i = 0; i < Math.min( lines.length, 3 ); i++ )
                if ( String( lines[i] ).indexOf( "=" ) >= 0 ) { looksLikeOldFormat = false; break; }

            if ( looksLikeOldFormat )
            {
                if ( lines.length > 0 && lines[0].trim().length > 0 ) this.cliLauncherMode = lines[0].trim();
                if ( lines.length > 1 ) this.cliLauncherPath  = lines[1].trim();
                if ( lines.length > 2 ) this.pythonScriptPath = lines[2].trim();
                return;
            }

            for ( var j = 0; j < lines.length; j++ )
            {
                var line = String( lines[j] );
                var eq = line.indexOf( "=" );
                if ( eq <= 0 ) continue;
                var k = line.substring( 0, eq ).trim();
                var v = line.substring( eq + 1 );

                switch ( k )
                {
                case "cliLauncherMode":           this.cliLauncherMode           = v.trim(); break;
                case "cliLauncherPath":            this.cliLauncherPath            = v.trim(); break;
                case "pythonScriptPath":           this.pythonScriptPath           = v.trim(); break;
                case "processMode":                this.processMode                = v.trim(); break;
                case "useGPU":                     this.useGPU                     = _cc_toBool( v, this.useGPU ); break;
                case "removeAberrationFirst":      this.removeAberrationFirst      = _cc_toBool( v, this.removeAberrationFirst ); break;
                case "sharpeningMode":             this.sharpeningMode             = v.trim(); break;
                case "stellarAmount":              this.stellarAmount              = _cc_toFloat( v, this.stellarAmount ); break;
                case "nonStellarStrength":         this.nonStellarStrength         = _cc_toFloat( v, this.nonStellarStrength ); break;
                case "nonStellarAmount":           this.nonStellarAmount           = _cc_toFloat( v, this.nonStellarAmount ); break;
                case "sharpenChannelsSeparately":  this.sharpenChannelsSeparately  = _cc_toBool( v, this.sharpenChannelsSeparately ); break;
                case "autoPSF":                    this.autoPSF                    = _cc_toBool( v, this.autoPSF ); break;
                case "chunkSize":                  this.chunkSize                  = _cc_toInt( v, this.chunkSize ); break;
                case "overlap":                    this.overlap                    = _cc_toInt( v, this.overlap ); break;
                case "tempStretch":                this.tempStretch                = _cc_toBool( v, this.tempStretch ); break;
                case "tempStretchTargetMedian":    this.tempStretchTargetMedian    = _cc_toFloat( v, this.tempStretchTargetMedian ); break;
                case "inputReadyTimeoutSec":       this.inputReadyTimeoutSec       = _cc_toInt( v, this.inputReadyTimeoutSec ); break;
                case "outputReadyTimeoutSec":      this.outputReadyTimeoutSec      = _cc_toInt( v, this.outputReadyTimeoutSec ); break;
                case "darkStarMode":               this.darkStarMode               = v.trim(); break;
                case "darkStarProcessingPath":     this.darkStarProcessingPath     = v.trim(); break;
                case "darkStarShowStarsOnly":      this.darkStarShowStarsOnly      = _cc_toBool( v, this.darkStarShowStarsOnly ); break;
                case "darkStarOverlapFrac":        this.darkStarOverlapFrac        = _cc_toFloat( v, this.darkStarOverlapFrac ); break;
                case "darkStarEdgePadding":        this.darkStarEdgePadding        = _cc_toInt( v, this.darkStarEdgePadding ); break;
                case "darkStarCompatibilityMode":  this.darkStarCompatibilityMode  = _cc_toBool( v, this.darkStarCompatibilityMode ); break;
                case "denoiseLuma":                this.denoiseLuma                = _cc_toFloat( v, this.denoiseLuma ); break;
                case "denoiseColor":               this.denoiseColor               = _cc_toFloat( v, this.denoiseColor ); break;
                case "denoiseMode":                this.denoiseMode                = v.trim(); break;
                case "separateDenoiseChannels":    this.separateDenoiseChannels    = _cc_toBool( v, this.separateDenoiseChannels ); break;
                case "denoiseModel":               this.denoiseModel               = v.trim(); break;
                case "superResScale":              this.superResScale              = _cc_toInt( v, this.superResScale ); break;
                case "satelliteMode":              this.satelliteMode              = v.trim(); break;
                case "satelliteClipTrail":         this.satelliteClipTrail         = _cc_toBool( v, this.satelliteClipTrail ); break;
                case "satelliteSensitivity":       this.satelliteSensitivity       = _cc_toFloat( v, this.satelliteSensitivity ); break;
                }
            }
        }
        catch ( e ) { console.warningln( "Failed to load CLI config: " + e.message ); }
    }
};

// ============================================================================
// Utility
// ============================================================================

function _cc_setExclusive( group, checkedBox )
{
    for ( var i = 0; i < group.length; i++ )
        if ( group[i] !== checkedBox )
            group[i].checked = false;
    checkedBox.checked = true;
}

function _cc_ensureDir( dirPath )
{
    if ( !File.directoryExists( dirPath ) )
        File.createDirectory( dirPath );
}

function _cc_uniqueTempBase( viewId )
{
    var t = new Date().getTime().toString();
    var safeId = String( viewId ).replace( /[^\w\-\.]/g, "_" );
    return _cc_normalizePathForExternal( scriptTempDir + pathSeparator + safeId + "_" + t );
}

function _cc_fileExistsSafe( p )
{
    try { return p && p.length > 0 && File.exists( p ); }
    catch ( e ) { return false; }
}

function _cc_waitForFileReady( filePath, timeoutMs, stableMs )
{
    var t0 = new Date().getTime();
    var pollMs = 200;
    var seenOnce = false;
    var stableSince = -1;

    while ( true )
    {
        var now = new Date().getTime();
        if ( (now - t0) > timeoutMs ) return false;

        if ( File.exists( filePath ) )
        {
            var canRead = false;
            try
            {
                var f = new File;
                f.openForReading( filePath );
                f.close();
                canRead = true;
            }
            catch ( e ) { canRead = false; }

            if ( canRead )
            {
                if ( !seenOnce ) { seenOnce = true; stableSince = now; }
                else if ( (now - stableSince) >= stableMs ) return true;
            }
            else { seenOnce = false; stableSince = -1; }
        }

        _cc_msleep( pollMs );
    }
}

function _cc_msleep( milliseconds )
{
    var start = new Date().getTime();
    while ( new Date().getTime() - start < milliseconds )
        CoreApplication.processEvents();
}

function _cc_waitForFile( filePath, timeoutMs, settleMs )
{
    var t0 = new Date().getTime();
    var pollMs = 250;
    while ( !File.exists( filePath ) )
    {
        if ( (new Date().getTime() - t0) > timeoutMs ) return false;
        _cc_msleep( pollMs );
    }
    if ( settleMs > 0 ) _cc_msleep( settleMs );
    return true;
}

function _cc_deleteFileQuiet( path )
{
    try { if ( File.exists( path ) ) File.remove( path ); }
    catch ( e ) {}
}

function getDefaultFrozenSasproPath()
{
    if ( IS_WIN ) return "C:\\Program Files\\SetiAstroSuitePro\\SetiAstroSuitePro.exe";
    if ( IS_MAC ) return "/Applications/SetiAstroSuitePro.app/Contents/MacOS/SetiAstroSuitePro";
    return "";
}

function looksLikeLinuxSasproFrozenName( p )
{
    if ( !p ) return false;
    var s = String( p ).toLowerCase();
    return s.indexOf( "setiastrosuitepro_linux_ubuntu24.04" ) >= 0 ||
           s.indexOf( "setiastrosuitepro" ) >= 0;
}

function promptForFrozenSasproExecutableLinux( ownerDialog )
{
    var ofd = new OpenFileDialog;
    ofd.caption = "Select SetiAstroSuitePro Linux Executable";
    ofd.multipleSelections = false;
    if ( SetiAstroSharpParameters.cliLauncherPath && SetiAstroSharpParameters.cliLauncherPath.length > 0 )
        ofd.initialPath = SetiAstroSharpParameters.cliLauncherPath;

    if ( !ofd.execute() || !ofd.fileNames || ofd.fileNames.length < 1 ) return "";

    var p = ofd.fileNames[0];
    SetiAstroSharpParameters.cliLauncherPath = p;
    SetiAstroSharpParameters.save();

    if ( !looksLikeLinuxSasproFrozenName( p ) )
        new MessageBox(
            "Selected file does not look like the usual SASpro Linux executable name.\n\n" +
            "Expected something like:\nSetiAstroSuitePro_linux_ubuntu24.04\n\n" +
            "If this is intentional, you can continue.",
            "SASpro Frozen Executable", StdIcon.Warning, StdButton.Ok ).execute();

    return p;
}

// ============================================================================
// Temp file I/O
// ============================================================================

function saveViewForSasproCLI( view )
{
    var imgWindow = view.isMainView ? view.window : view.mainView.window;
    if ( !imgWindow )
        throw new Error( "Image window is undefined for the specified view." );

    _cc_ensureDir( scriptTempDir );

    var base           = _cc_uniqueTempBase( imgWindow.mainView.id );
    var inputFilePath  = base + "_in.fits";
    var outputFilePath = base + "_out.fits";

    var srcImg     = imgWindow.mainView.image;
    var floatSample = srcImg.isReal;
    var isColor     = (srcImg.colorSpace != ColorSpace.Gray);

    var tmp = new ImageWindow(
        srcImg.width, srcImg.height,
        srcImg.numberOfChannels,
        srcImg.bitsPerSample,
        floatSample,
        isColor,
        "SASpro_CC_Temp"
    );

    tmp.mainView.beginProcess( UndoFlag.NoSwapFile );
    tmp.mainView.image.assign( srcImg );
    tmp.mainView.endProcess();

    if ( !tmp.saveAs( inputFilePath, false, false, false, false ) )
    {
        tmp.forceClose();
        throw new Error( "Failed to save temporary FITS: " + inputFilePath );
    }

    tmp.forceClose();
    console.writeln( "Saved temp input (clone): " + inputFilePath );

    return { inputFilePath: inputFilePath, outputFilePath: outputFilePath };
}

function createDarkStarStarsOnlyImage( originalWindow, starlessWindow, starMode )
{
    let originalId = originalWindow.mainView.id;
    let starlessId = starlessWindow.mainView.id;

    let P = new PixelMath;
    P.expression = starMode == "additive"
        ? "(" + originalId + "-" + starlessId + ")"
        : "(" + originalId + "-" + starlessId + ")/(1-" + starlessId + ")";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression  = true;
    P.symbols              = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput       = true;
    P.singleThreaded       = false;
    P.optimization         = true;
    P.use64BitWorkingImage = false;
    P.rescale              = false;
    P.truncate             = true;
    P.truncateLower        = 0;
    P.truncateUpper        = 1;
    P.createNewImage       = true;
    P.showNewImage         = true;
    P.newImageId           = originalId + "_DarkStar_StarsOnly";
    P.newImageColorSpace   = PixelMath.SameAsTarget;
    P.newImageSampleFormat = PixelMath.SameAsTarget;
    P.executeOn( originalWindow.mainView );
}

function processDarkStarOutput( outputFilePath, targetView )
{
    if ( !File.exists( outputFilePath ) )
        throw new Error( "DarkStar output file not found: " + outputFilePath );

    _cc_msleep( 3000 );

    var opened = null, attempts = 4, retryDelayMs = 3000, lastError = "";

    for ( var attempt = 1; attempt <= attempts; ++attempt )
    {
        try
        {
            console.noteln( format( "Opening DarkStar output (attempt %d/%d): %s", attempt, attempts, outputFilePath ) );
            opened = ImageWindow.open( outputFilePath );
            if ( opened && opened.length > 0 ) break;
            lastError = "ImageWindow.open() returned no windows.";
        }
        catch ( e ) { lastError = e.message; }

        if ( attempt < attempts )
        {
            console.warningln( format( "DarkStar output not ready yet, waiting %d ms before retry... (%s)", retryDelayMs, lastError ) );
            _cc_msleep( retryDelayMs );
        }
    }

    if ( !opened || opened.length < 1 )
        throw new Error( "Failed to open DarkStar output image after multiple attempts: " + outputFilePath + "\nLast error: " + lastError );

    var outWindow = opened[0];
    outWindow.show();

    if ( SetiAstroSharpParameters.darkStarShowStarsOnly )
        createDarkStarStarsOnlyImage( targetView, outWindow, SetiAstroSharpParameters.darkStarMode || "unscreen" );

    var pixelMath = new PixelMath;
    pixelMath.expression       = outWindow.mainView.id;
    pixelMath.useSingleExpression = true;
    pixelMath.createNewImage   = false;
    pixelMath.rescale          = false;
    pixelMath.truncate         = false;
    pixelMath.executeOn( targetView.mainView );

    outWindow.forceClose();

    try { File.remove( outputFilePath ); console.writeln( "Deleted temp output: " + outputFilePath ); }
    catch ( e ) { console.warningln( "Could not delete temp output: " + e.message ); }
}

function processOutputImage( outputFilePath, targetView )
{
    if ( !File.exists( outputFilePath ) )
        throw new Error( "Cosmic Clarity output file not found: " + outputFilePath );

    _cc_msleep( 3000 );

    var opened = null, attempts = 4, retryDelayMs = 3000, lastError = "";

    for ( var attempt = 1; attempt <= attempts; ++attempt )
    {
        try
        {
            console.noteln( format( "Opening Cosmic Clarity output (attempt %d/%d): %s", attempt, attempts, outputFilePath ) );
            opened = ImageWindow.open( outputFilePath );
            if ( opened && opened.length > 0 ) break;
            lastError = "ImageWindow.open() returned no windows.";
        }
        catch ( e ) { lastError = e.message; }

        if ( attempt < attempts )
        {
            console.warningln( format( "Output file not ready yet, waiting %d ms before retry... (%s)", retryDelayMs, lastError ) );
            _cc_msleep( retryDelayMs );
        }
    }

    if ( !opened || opened.length < 1 )
        throw new Error( "Failed to open Cosmic Clarity output image after multiple attempts: " + outputFilePath + "\nLast error: " + lastError );

    var outWindow = opened[0];
    outWindow.show();

    var pixelMath = new PixelMath;
    pixelMath.expression          = "iif(" + outWindow.mainView.id + " == 0, $T, " + outWindow.mainView.id + ")";
    pixelMath.useSingleExpression = true;
    pixelMath.createNewImage      = false;
    pixelMath.executeOn( targetView.mainView );

    outWindow.forceClose();

    try { File.remove( outputFilePath ); console.writeln( "Deleted temp output: " + outputFilePath ); }
    catch ( e ) { console.warningln( "Could not delete temp output: " + e.message ); }
}

// ============================================================================
// CLI command building
// ============================================================================

function buildCosmicClarityArgs( inputFilePath, outputFilePath )
{
    var args = [];
    inputFilePath  = _cc_normalizePathForExternal( inputFilePath );
    outputFilePath = _cc_normalizePathForExternal( outputFilePath );

    var mode = SetiAstroSharpParameters.processMode || "sharpen";
    args.push( mode );
    args.push( "-i" ); args.push( inputFilePath );
    args.push( "-o" ); args.push( outputFilePath );

    if ( SetiAstroSharpParameters.useGPU ) args.push( "--gpu" );
    else                                   args.push( "--no-gpu" );

    if ( SetiAstroSharpParameters.removeAberrationFirst )
        args.push( "--aberration-first" );

    if ( mode == "sharpen" || mode == "denoise" || mode == "both" )
    {
        if ( SetiAstroSharpParameters.tempStretch ) args.push( "--temp-stretch" );
        else                                        args.push( "--no-temp-stretch" );

        var tm = _cc_toFloat( SetiAstroSharpParameters.tempStretchTargetMedian, 0.25 );
        if ( tm < 0.01 ) tm = 0.01;
        if ( tm > 0.50 ) tm = 0.50;
        args.push( "--target-median" ); args.push( format( "%.3f", tm ) );
    }

    var cs = _cc_toInt( SetiAstroSharpParameters.chunkSize, 256 );
    var ov = _cc_toInt( SetiAstroSharpParameters.overlap,   64  );
    if ( cs < 64 ) cs = 64; if ( cs > 2048 ) cs = 2048;
    if ( ov < 0  ) ov = 0;  if ( ov >= cs   ) ov = Math.max( 0, cs - 1 );

    if ( mode != "darkstar" )
    {
        args.push( "--chunk-size" ); args.push( format( "%d", cs ) );
        args.push( "--overlap"    ); args.push( format( "%d", ov ) );
    }

    if ( mode == "sharpen" || mode == "both" )
    {
        args.push( "--sharpening-mode" ); args.push( SetiAstroSharpParameters.sharpeningMode || "Both" );
        args.push( "--stellar-amount"  ); args.push( format( "%.2f", SetiAstroSharpParameters.stellarAmount ) );
        args.push( "--nonstellar-amount" ); args.push( format( "%.2f", SetiAstroSharpParameters.nonStellarAmount ) );

        if ( SetiAstroSharpParameters.autoPSF )
        {
            args.push( "--auto-psf" );
        }
        else
        {
            args.push( "--no-auto-psf" );
            args.push( "--nonstellar-psf" ); args.push( format( "%.2f", SetiAstroSharpParameters.nonStellarStrength ) );
        }

        if ( SetiAstroSharpParameters.sharpenChannelsSeparately )
            args.push( "--sharpen-channels-separately" );
    }

    if ( mode == "denoise" || mode == "both" )
    {
        args.push( "--denoise-luma"  ); args.push( format( "%.2f", SetiAstroSharpParameters.denoiseLuma ) );
        args.push( "--denoise-color" ); args.push( format( "%.2f", SetiAstroSharpParameters.denoiseColor ) );
        args.push( "--denoise-mode"  ); args.push( SetiAstroSharpParameters.denoiseMode || "full" );

        if ( SetiAstroSharpParameters.separateDenoiseChannels )
            args.push( "--separate-channels" );

        if      ( SetiAstroSharpParameters.denoiseModel == "Walking Noise" ) args.push( "--denoise-walking" );
        else if ( SetiAstroSharpParameters.denoiseModel == "Lite (faster)"  ) args.push( "--denoise-lite" );
    }

    if ( mode == "superres" )
    {
        args.push( "--scale" ); args.push( format( "%d", SetiAstroSharpParameters.superResScale || 2 ) );
    }

    if ( mode == "darkstar" )
    {
        args.push( "--star-removal-mode" ); args.push( SetiAstroSharpParameters.darkStarMode || "unscreen" );
        args.push( "--processing-path"   ); args.push( SetiAstroSharpParameters.darkStarProcessingPath || "hybrid_luma_color" );

        if ( SetiAstroSharpParameters.darkStarShowStarsOnly ) args.push( "--show-extracted-stars" );
        else                                                   args.push( "--no-show-extracted-stars" );

        args.push( "--chunk-size"    ); args.push( format( "%d",   _cc_toInt(   SetiAstroSharpParameters.chunkSize, 512 ) ) );
        args.push( "--overlap-frac"  ); args.push( format( "%.3f", _cc_toFloat( SetiAstroSharpParameters.darkStarOverlapFrac, 0.125 ) ) );
        args.push( "--edge-padding"  ); args.push( format( "%d",   _cc_toInt(   SetiAstroSharpParameters.darkStarEdgePadding, 64 ) ) );

        if ( SetiAstroSharpParameters.darkStarCompatibilityMode ) args.push( "--compatibility-mode" );
        else                                                        args.push( "--no-compatibility-mode" );
    }

    if ( mode == "satellite" )
    {
        args.push( "--mode" ); args.push( SetiAstroSharpParameters.satelliteMode || "full" );
        if ( SetiAstroSharpParameters.satelliteClipTrail ) args.push( "--clip-trail" );
        else                                                args.push( "--no-clip-trail" );
        args.push( "--sensitivity" ); args.push( format( "%.2f", SetiAstroSharpParameters.satelliteSensitivity ) );
    }

    return args;
}

function makeLauncher( program, prefixArgs, label )
{
    return { program: program, prefixArgs: prefixArgs || [], label: label || String( program ) };
}

function getDefaultPythonCmd()
{
    return IS_WIN ? "python" : "python3";
}

function resolveSasproCliLauncher()
{
    var mode         = SetiAstroSharpParameters.cliLauncherMode;
    var launcherPath = (SetiAstroSharpParameters.cliLauncherPath  || "").trim();
    var scriptPath   = (SetiAstroSharpParameters.pythonScriptPath || "").trim();

    if ( mode == "setiastrosuitepro cc (installed command)" )
        return makeLauncher( "setiastrosuitepro", ["cc"], "setiastrosuitepro cc (installed command)" );

    if ( mode == "Frozen setiastrosuitepro executable" )
    {
        if ( launcherPath.length == 0 )
        {
            var def = getDefaultFrozenSasproPath();
            if ( def.length > 0 && _cc_fileExistsSafe( def ) )
            {
                launcherPath = def;
                SetiAstroSharpParameters.cliLauncherPath = launcherPath;
                SetiAstroSharpParameters.save();
            }
            else if ( IS_LIN )
                throw new Error( "Frozen executable mode selected, but no executable path is configured.\nOn Linux, please browse to your SetiAstroSuitePro executable." );
            else
                throw new Error( "Frozen executable mode selected, but no executable path is configured.\nExpected default path:\n" + def );
        }
        return makeLauncher( launcherPath, ["cc"], "Frozen setiastrosuitepro executable" );
    }

    if ( mode == "python -m setiastro.saspro cc" )
    {
        var py = launcherPath.length > 0 ? launcherPath : getDefaultPythonCmd();
        return makeLauncher( py, ["-m", "setiastro.saspro", "cc"], "python -m setiastro.saspro cc" );
    }

    if ( mode == "python setiastrosuitepro.py cc" )
    {
        var py2 = launcherPath.length > 0 ? launcherPath : getDefaultPythonCmd();
        if ( scriptPath.length == 0 )
            throw new Error( "python setiastrosuitepro.py mode selected, but no script path is configured." );
        return makeLauncher( py2, [scriptPath, "cc"], "python setiastrosuitepro.py cc" );
    }

    // Auto-detect
    var candidates = [];
    candidates.push( makeLauncher( "setiastrosuitepro", ["cc"], "Auto: setiastrosuitepro cc" ) );

    var defaultFrozen = getDefaultFrozenSasproPath();
    if ( defaultFrozen.length > 0 && _cc_fileExistsSafe( defaultFrozen ) )
        candidates.push( makeLauncher( defaultFrozen, ["cc"], "Auto: frozen default path" ) );

    if ( launcherPath.length > 0 )
        candidates.push( makeLauncher( launcherPath, ["cc"], "Auto: frozen executable path" ) );

    if ( IS_WIN )
    {
        candidates.push( makeLauncher( "py",     ["-3", "-m", "setiastro.saspro", "cc"], "Auto: py -3 -m setiastro.saspro cc" ) );
        candidates.push( makeLauncher( "python", ["-m", "setiastro.saspro", "cc"],       "Auto: python -m setiastro.saspro cc" ) );
    }
    else
    {
        candidates.push( makeLauncher( "python3", ["-m", "setiastro.saspro", "cc"], "Auto: python3 -m setiastro.saspro cc" ) );
        candidates.push( makeLauncher( "python",  ["-m", "setiastro.saspro", "cc"], "Auto: python -m setiastro.saspro cc"  ) );
    }

    if ( scriptPath.length > 0 )
    {
        var py3 = launcherPath.length > 0 ? launcherPath : getDefaultPythonCmd();
        candidates.push( makeLauncher( py3, [scriptPath, "cc"], "Auto: python setiastrosuitepro.py cc" ) );
    }

    return { isAuto: true, autoCandidates: candidates };
}

// ============================================================================
// External process execution
// ============================================================================

function runExternalProcessBlocking( program, args, options )
{
    options = options || {};

    var process  = new ExternalProcess;
    var started  = false;
    var finished = false;
    var sawOnError = false;
    var errorCodes = [];
    var stderrText = "";
    var stdoutText = "";

    process.onStarted = () =>
    {
        started = true;
        console.noteln( "Started: " + program + " " + args.join( " " ) );
    };

    process.onStandardOutputDataAvailable = () =>
    {
        var out = String( process.stdout );
        if ( out && out.length > 0 )
        {
            stdoutText += out;
            if ( options.onStdOutText ) options.onStdOutText( out );
        }
    };

    process.onStandardErrorDataAvailable = () =>
    {
        var err = String( process.stderr );
        if ( err && err.length > 0 )
        {
            stderrText += err;
            if ( options.onStdErrText ) options.onStdErrText( err );
        }
    };

    process.onError = code =>
    {
        sawOnError = true;
        errorCodes.push( code );
        console.warningln( "Process onError event code: " + code + " (ignoring unless process never starts)" );
    };

    process.onFinished = () =>
    {
        finished = true;
        console.noteln( "Process finished." );
    };

    var okStart = process.start( program, args );
    if ( !okStart )
        return { ok: false, started: false, finished: false, stdout: stdoutText,
                 stderr: (stderrText ? stderrText + "\n" : "") + "Failed to start process.",
                 sawOnError: sawOnError, errorCodes: errorCodes };

    while ( process.isStarting ) CoreApplication.processEvents();
    while ( process.isRunning  ) CoreApplication.processEvents();

    return { ok: started && finished, started: started, finished: finished,
             stdout: stdoutText, stderr: stderrText,
             sawOnError: sawOnError, errorCodes: errorCodes };
}

function createProgressTextHandler()
{
    var lastPercent = -1;
    var lineBuffer  = "";

    return {
        feedStdout: function( text )
        {
            lineBuffer += text;
            var lines = lineBuffer.split( /\r?\n/ );
            if ( lines.length > 0 ) lineBuffer = lines.pop();

            for ( var i = 0; i < lines.length; i++ )
            {
                var line = lines[i];
                if ( !line || line.length === 0 ) continue;
                var m = line.match( /PROGRESS:\s*(\d+)%/i );
                if ( m )
                {
                    var p = parseInt( m[1], 10 );
                    if ( p !== lastPercent )
                    {
                        lastPercent = p;
                        console.writeln( format( "SASpro Cosmic Clarity Progress: %3d%%", p ) );
                    }
                }
                else { console.writeln( line ); }
            }
        },
        feedStderr: function( text )
        {
            var lines = String( text ).split( /\r?\n/ );
            for ( var i = 0; i < lines.length; i++ )
                if ( lines[i] && lines[i].length > 0 ) console.warningln( lines[i] );
        }
    };
}

function runSasproCliWithCandidate( candidate, ccArgs )
{
    var handler = createProgressTextHandler();
    return runExternalProcessBlocking(
        candidate.program,
        candidate.prefixArgs.concat( ccArgs ),
        { onStdOutText: t => handler.feedStdout( t ),
          onStdErrText: t => handler.feedStderr( t ) } );
}

function runSasproCli( launcherOrAuto, ccArgs )
{
    if ( launcherOrAuto.isAuto )
    {
        var candidates = launcherOrAuto.autoCandidates;
        var lastError = "";
        for ( var i = 0; i < candidates.length; i++ )
        {
            var c = candidates[i];
            console.noteln( "Trying launcher: " + c.label );
            var r = runSasproCliWithCandidate( c, ccArgs );
            if ( r.started && r.finished )
                return { ok: true, launcher: c, result: r };
            lastError = (r.stderr && r.stderr.length > 0) ? r.stderr : "Launcher failed.";
            console.warningln( "Launcher did not complete: " + c.label );
        }
        return { ok: false, error: lastError };
    }

    var r2 = runSasproCliWithCandidate( launcherOrAuto, ccArgs );
    if ( r2.started && r2.finished )
        return { ok: true, launcher: launcherOrAuto, result: r2 };
    return { ok: false, error: (r2.stderr && r2.stderr.length > 0) ? r2.stderr : "Failed to run configured launcher." };
}

function _cc_normalizePathForExternal( p )
{
    if ( !p ) return p;
    var s = String( p );
    if ( IS_WIN ) s = s.split( "/" ).join( "\\" );
    else          s = s.split( "\\" ).join( "/" );
    return s;
}

// ============================================================================
// Main CC execution
// ============================================================================

function runCosmicClarityViaSasproCLI( selectedView )
{
    var tempFiles      = saveViewForSasproCLI( selectedView );
    var inputFilePath  = tempFiles.inputFilePath;
    var outputFilePath = tempFiles.outputFilePath;
    var success        = false;

    try
    {
        var inputTimeoutMs  = Math.max( 5000,  _cc_toInt( SetiAstroSharpParameters.inputReadyTimeoutSec,  30  ) * 1000 );
        var outputTimeoutMs = Math.max( 10000, _cc_toInt( SetiAstroSharpParameters.outputReadyTimeoutSec, 300 ) * 1000 );

        if ( !_cc_waitForFileReady( inputFilePath, inputTimeoutMs, 1000 ) )
            throw new Error( "Temporary input file was not found/ready in time:\n" + inputFilePath );

        console.noteln( "Input file ready: " + inputFilePath );
        if ( SetiAstroSharpParameters.removeAberrationFirst )
        {
            console.noteln( "Aberration Remover model and weights © Riccardo Alberghi" );
            console.noteln( "More information: https://github.com/riccardoalberghi" );
        }

        var ccArgs    = buildCosmicClarityArgs( inputFilePath, outputFilePath );
        var launcher  = resolveSasproCliLauncher();
        var runResult = runSasproCli( launcher, ccArgs );

        try
        {
            if ( runResult && runResult.launcher && runResult.launcher.label )
                console.noteln( "Launcher used: " + runResult.launcher.label );
        }
        catch ( eTelemetry ) {}

        if ( !_cc_waitForFileReady( outputFilePath, outputTimeoutMs, 1500 ) )
        {
            var extra = "";
            try
            {
                if ( runResult && runResult.result )
                {
                    var rr = runResult.result;
                    if ( rr.stderr && rr.stderr.length > 0 )
                    {
                        var sErr = rr.stderr;
                        if ( sErr.length > 2000 ) sErr = sErr.substring( sErr.length - 2000 );
                        extra += "\n\n--- CLI stderr (tail) ---\n" + sErr;
                    }
                    if ( rr.stdout && rr.stdout.length > 0 )
                    {
                        var sOut = rr.stdout;
                        if ( sOut.length > 2000 ) sOut = sOut.substring( sOut.length - 2000 );
                        extra += "\n\n--- CLI stdout (tail) ---\n" + sOut;
                    }
                }
                else if ( runResult && runResult.error )
                    extra += "\n\n--- Launcher error ---\n" + runResult.error;
            }
            catch ( eTail ) {}

            throw new Error( "SASpro CLI did not produce an output file in time:\n" + outputFilePath + extra );
        }

        if ( (SetiAstroSharpParameters.processMode || "sharpen") == "darkstar" )
            processDarkStarOutput( outputFilePath, selectedView );
        else
            processOutputImage( outputFilePath, selectedView );

        success = true;
    }
    finally
    {
        if ( success )
        {
            _cc_deleteFileQuiet( inputFilePath );
            _cc_deleteFileQuiet( outputFilePath );
        }
        else
        {
            console.warningln( "Keeping temp files for debugging:" );
            console.warningln( "  input:  " + inputFilePath );
            console.warningln( "  output: " + outputFilePath );
        }
    }
}

// ============================================================================
// UI Dialog
// ============================================================================

var SetiAstroSharpDialog = class extends Dialog
{
    constructor()
    {
        super();

        SetiAstroSharpParameters.load();

        // ---- Title / Description ----
        this.titleLabel = new Label( this );
        this.titleLabel.text = "Cosmic Clarity - SASpro " + VERSION;
        this.titleLabel.textAlignment = TextAlignment.Center;

        this.description = new TextBox( this );
        this.description.readOnly = true;
        this.description.setMinWidth( 760 );
        this.description.setMaxHeight( 140 );
        this.description.text =
            "This script sends the selected image to Seti Astro Suite Pro Cosmic Clarity (CLI).\n" +
            "It saves a temporary FITS, runs SASpro headless, then replaces the image with the processed result.\n\n" +
            "Supported modes here: Sharpen, Denoise, Sharpen + Denoise, Super Resolution, and DarkStar star removal.\n" +
            "Launcher modes support pip installs, frozen executables, and Python/module development environments.\n\n" +
            "Note: Aberration Remover model and weights © Riccardo Alberghi.\n" +
            "More information: https://github.com/riccardoalberghi";

        // ---- Image Selection ----
        this.imageSelectionLabel = new Label( this );
        this.imageSelectionLabel.text = "Select Image:";
        this.imageSelectionLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.imageSelectionDropdown = new ComboBox( this );
        this.imageSelectionDropdown.editEnabled = false;

        let windows = ImageWindow.windows;
        if ( windows && windows.length > 0 )
        {
            let activeId = "";
            try
            {
                if ( ImageWindow.activeWindow && ImageWindow.activeWindow.mainView )
                    activeId = ImageWindow.activeWindow.mainView.id;
            }
            catch ( e ) {}

            for ( let i = 0; i < windows.length; ++i )
            {
                this.imageSelectionDropdown.addItem( windows[i].mainView.id );
                if ( windows[i].mainView.id == activeId )
                    this.imageSelectionDropdown.currentItem = i;
            }
        }

        this.imageSelectionSizer = new HorizontalSizer;
        this.imageSelectionSizer.spacing = 6;
        this.imageSelectionSizer.add( this.imageSelectionLabel );
        this.imageSelectionSizer.add( this.imageSelectionDropdown, 100 );

        // ---- Process Mode ----
        this.processModeLabel = new Label( this );
        this.processModeLabel.text = "Process Mode:";
        this.processModeLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.processModeRow = new HorizontalSizer;
        this.processModeRow.spacing = 12;

        this.processSharpenCheck  = new CheckBox( this ); this.processSharpenCheck.text  = "Sharpen";
        this.processDenoiseCheck  = new CheckBox( this ); this.processDenoiseCheck.text  = "Denoise";
        this.processBothCheck     = new CheckBox( this ); this.processBothCheck.text     = "Sharpen + Denoise";
        this.processDarkStarCheck = new CheckBox( this ); this.processDarkStarCheck.text = "DarkStar";
        this.processSuperResCheck = new CheckBox( this ); this.processSuperResCheck.text = "Super Resolution";

        this._procGroup = [
            this.processSharpenCheck, this.processDenoiseCheck, this.processBothCheck,
            this.processDarkStarCheck, this.processSuperResCheck
        ];

        this.processSharpenCheck.checked  = (SetiAstroSharpParameters.processMode == "sharpen");
        this.processDenoiseCheck.checked  = (SetiAstroSharpParameters.processMode == "denoise");
        this.processBothCheck.checked     = (SetiAstroSharpParameters.processMode == "both");
        this.processDarkStarCheck.checked = (SetiAstroSharpParameters.processMode == "darkstar");
        this.processSuperResCheck.checked = (SetiAstroSharpParameters.processMode == "superres");

        if ( !this._anyChecked( this._procGroup ) ) this.processSharpenCheck.checked = true;

        this.processSharpenCheck.onCheck  = checked => { if ( checked ) _cc_setExclusive( this._procGroup, this.processSharpenCheck  ); else if ( !this._anyChecked( this._procGroup ) ) this.processSharpenCheck.checked = true; this.updateVisibility(); };
        this.processDenoiseCheck.onCheck  = checked => { if ( checked ) _cc_setExclusive( this._procGroup, this.processDenoiseCheck  ); else if ( !this._anyChecked( this._procGroup ) ) this.processSharpenCheck.checked = true; this.updateVisibility(); };
        this.processBothCheck.onCheck     = checked => { if ( checked ) _cc_setExclusive( this._procGroup, this.processBothCheck     ); else if ( !this._anyChecked( this._procGroup ) ) this.processSharpenCheck.checked = true; this.updateVisibility(); };
        this.processDarkStarCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._procGroup, this.processDarkStarCheck ); else if ( !this._anyChecked( this._procGroup ) ) this.processSharpenCheck.checked = true; this.updateVisibility(); };
        this.processSuperResCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._procGroup, this.processSuperResCheck ); else if ( !this._anyChecked( this._procGroup ) ) this.processSharpenCheck.checked = true; this.updateVisibility(); };

        this.processModeRow.add( this.processSharpenCheck );
        this.processModeRow.add( this.processDenoiseCheck );
        this.processModeRow.add( this.processBothCheck );
        this.processModeRow.add( this.processDarkStarCheck );
        this.processModeRow.add( this.processSuperResCheck );
        this.processModeRow.addStretch();

        // ---- Sharpen section ----
        this.sharpenSectionLabel = new Label( this ); this.sharpenSectionLabel.text = "Sharpen Settings"; this.sharpenSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.sharpeningModeLabel = new Label( this ); this.sharpeningModeLabel.text = "Sharpening Mode:"; this.sharpeningModeLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.sharpeningModeRow = new HorizontalSizer; this.sharpeningModeRow.spacing = 12;

        this.sharpStellarCheck    = new CheckBox( this ); this.sharpStellarCheck.text    = "Stellar";
        this.sharpNonStellarCheck = new CheckBox( this ); this.sharpNonStellarCheck.text = "Non-Stellar";
        this.sharpBothCheck       = new CheckBox( this ); this.sharpBothCheck.text       = "Both";

        this._sharpModeGroup = [this.sharpStellarCheck, this.sharpNonStellarCheck, this.sharpBothCheck];

        this.sharpStellarCheck.checked    = (SetiAstroSharpParameters.sharpeningMode == "Stellar Only");
        this.sharpNonStellarCheck.checked = (SetiAstroSharpParameters.sharpeningMode == "Non-Stellar Only");
        this.sharpBothCheck.checked       = (SetiAstroSharpParameters.sharpeningMode == "Both");
        if ( !this._anyChecked( this._sharpModeGroup ) ) this.sharpBothCheck.checked = true;

        this.sharpStellarCheck.onCheck    = checked => { if ( checked ) _cc_setExclusive( this._sharpModeGroup, this.sharpStellarCheck );    else if ( !this._anyChecked( this._sharpModeGroup ) ) this.sharpBothCheck.checked = true; this.updateVisibility(); };
        this.sharpNonStellarCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._sharpModeGroup, this.sharpNonStellarCheck ); else if ( !this._anyChecked( this._sharpModeGroup ) ) this.sharpBothCheck.checked = true; this.updateVisibility(); };
        this.sharpBothCheck.onCheck       = checked => { if ( checked ) _cc_setExclusive( this._sharpModeGroup, this.sharpBothCheck );       else if ( !this._anyChecked( this._sharpModeGroup ) ) this.sharpBothCheck.checked = true; this.updateVisibility(); };

        this.sharpeningModeRow.add( this.sharpStellarCheck ); this.sharpeningModeRow.add( this.sharpNonStellarCheck ); this.sharpeningModeRow.add( this.sharpBothCheck ); this.sharpeningModeRow.addStretch();

        this.sharpenChannelsCheckbox = new CheckBox( this );
        this.sharpenChannelsCheckbox.text = "Sharpen RGB Channels Separately";
        this.sharpenChannelsCheckbox.checked = SetiAstroSharpParameters.sharpenChannelsSeparately;
        this.sharpenChannelsCheckbox.onCheck = checked => { SetiAstroSharpParameters.sharpenChannelsSeparately = checked; };

        this.sharpenChannelsSizer = new HorizontalSizer; this.sharpenChannelsSizer.addStretch(); this.sharpenChannelsSizer.add( this.sharpenChannelsCheckbox ); this.sharpenChannelsSizer.addStretch();

        this.autoPSFCheckbox = new CheckBox( this );
        this.autoPSFCheckbox.text = "Auto PSF (ignore manual Non-Stellar PSF)";
        this.autoPSFCheckbox.checked = SetiAstroSharpParameters.autoPSF;
        this.autoPSFCheckbox.onCheck = checked => { SetiAstroSharpParameters.autoPSF = checked; this.updateVisibility(); };

        this.autoPSFSizer = new HorizontalSizer; this.autoPSFSizer.addStretch(); this.autoPSFSizer.add( this.autoPSFCheckbox ); this.autoPSFSizer.addStretch();

        this.stellarAmountSlider = new NumericControl( this );
        this.stellarAmountSlider.label.text = "Stellar Amount:"; this.stellarAmountSlider.setRange( 0, 1 ); this.stellarAmountSlider.setPrecision( 2 ); this.stellarAmountSlider.setValue( SetiAstroSharpParameters.stellarAmount );
        this.stellarAmountSlider.toolTip = "Amount of stellar sharpening to apply (0 to 1).";
        this.stellarAmountSlider.onValueUpdated = value => { SetiAstroSharpParameters.stellarAmount = value; };

        this.nonStellarStrengthSlider = new NumericControl( this );
        this.nonStellarStrengthSlider.label.text = "Non-Stellar Feature Size (PSF):"; this.nonStellarStrengthSlider.setRange( 1, 8 ); this.nonStellarStrengthSlider.setPrecision( 2 ); this.nonStellarStrengthSlider.setValue( SetiAstroSharpParameters.nonStellarStrength );
        this.nonStellarStrengthSlider.toolTip = "Manual non-stellar feature size (PSF). Used only when Auto PSF is OFF.";
        this.nonStellarStrengthSlider.onValueUpdated = value => { SetiAstroSharpParameters.nonStellarStrength = value; };

        this.nonStellarAmountSlider = new NumericControl( this );
        this.nonStellarAmountSlider.label.text = "Non-Stellar Amount:"; this.nonStellarAmountSlider.setRange( 0, 1 ); this.nonStellarAmountSlider.setPrecision( 2 ); this.nonStellarAmountSlider.setValue( SetiAstroSharpParameters.nonStellarAmount );
        this.nonStellarAmountSlider.toolTip = "Amount of non-stellar sharpening to apply (0 to 1).";
        this.nonStellarAmountSlider.onValueUpdated = value => { SetiAstroSharpParameters.nonStellarAmount = value; };

        // ---- Denoise section ----
        this.denoiseSectionLabel = new Label( this ); this.denoiseSectionLabel.text = "Denoise Settings"; this.denoiseSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.denoiseModeLabel    = new Label( this ); this.denoiseModeLabel.text    = "Denoise Mode:";    this.denoiseModeLabel.textAlignment    = TextAlignment.Left | TextAlignment.VertCenter;

        this.denoiseModeRow = new HorizontalSizer; this.denoiseModeRow.spacing = 12;

        this.denoiseFullCheck      = new CheckBox( this ); this.denoiseFullCheck.text      = "Full";
        this.denoiseLuminanceCheck = new CheckBox( this ); this.denoiseLuminanceCheck.text = "Luminance Only";

        this._denModeGroup = [this.denoiseFullCheck, this.denoiseLuminanceCheck];

        this.denoiseFullCheck.checked      = (SetiAstroSharpParameters.denoiseMode == "full");
        this.denoiseLuminanceCheck.checked = (SetiAstroSharpParameters.denoiseMode == "luminance");
        if ( !this._anyChecked( this._denModeGroup ) ) this.denoiseFullCheck.checked = true;

        this.denoiseFullCheck.onCheck      = checked => { if ( checked ) _cc_setExclusive( this._denModeGroup, this.denoiseFullCheck );      else if ( !this._anyChecked( this._denModeGroup ) ) this.denoiseFullCheck.checked = true; this.updateVisibility(); };
        this.denoiseLuminanceCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._denModeGroup, this.denoiseLuminanceCheck ); else if ( !this._anyChecked( this._denModeGroup ) ) this.denoiseFullCheck.checked = true; this.updateVisibility(); };

        this.denoiseModeRow.add( this.denoiseFullCheck ); this.denoiseModeRow.add( this.denoiseLuminanceCheck ); this.denoiseModeRow.addStretch();

        this.denoiseLumaSlider = new NumericControl( this );
        this.denoiseLumaSlider.label.text = "Denoise Luma:"; this.denoiseLumaSlider.setRange( 0, 1 ); this.denoiseLumaSlider.setPrecision( 2 ); this.denoiseLumaSlider.setValue( SetiAstroSharpParameters.denoiseLuma );
        this.denoiseLumaSlider.toolTip = "Luminance denoise strength (0 to 1).";
        this.denoiseLumaSlider.onValueUpdated = value => { SetiAstroSharpParameters.denoiseLuma = value; };

        this.denoiseColorSlider = new NumericControl( this );
        this.denoiseColorSlider.label.text = "Denoise Color:"; this.denoiseColorSlider.setRange( 0, 1 ); this.denoiseColorSlider.setPrecision( 2 ); this.denoiseColorSlider.setValue( SetiAstroSharpParameters.denoiseColor );
        this.denoiseColorSlider.toolTip = "Color denoise strength (0 to 1).";
        this.denoiseColorSlider.onValueUpdated = value => { SetiAstroSharpParameters.denoiseColor = value; };

        this.denoiseSeparateChannelsCheckbox = new CheckBox( this );
        this.denoiseSeparateChannelsCheckbox.text = "Denoise RGB Channels Separately";
        this.denoiseSeparateChannelsCheckbox.checked = SetiAstroSharpParameters.separateDenoiseChannels;
        this.denoiseSeparateChannelsCheckbox.onCheck = checked => { SetiAstroSharpParameters.separateDenoiseChannels = checked; };

        this.denoiseSeparateChannelsSizer = new HorizontalSizer; this.denoiseSeparateChannelsSizer.addStretch(); this.denoiseSeparateChannelsSizer.add( this.denoiseSeparateChannelsCheckbox ); this.denoiseSeparateChannelsSizer.addStretch();

        this.denoiseModelLabel = new Label( this ); this.denoiseModelLabel.text = "Denoise Model:"; this.denoiseModelLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.denoiseModelCombo = new ComboBox( this );
        this.denoiseModelCombo.editEnabled = false;
        this.denoiseModelCombo.addItem( "Standard" ); this.denoiseModelCombo.addItem( "Walking Noise" ); this.denoiseModelCombo.addItem( "Lite (faster)" );
        this.denoiseModelCombo.toolTip =
            "Standard: general-purpose AI4 denoise model.\n" +
            "Walking Noise: specialist model for fixed-pattern drift streaks.\n" +
            "Lite: smaller faster model, slightly less detail.";
        let denoiseModelItems = ["Standard","Walking Noise","Lite (faster)"];
        for ( let dm = 0; dm < denoiseModelItems.length; dm++ )
            if ( denoiseModelItems[dm] == SetiAstroSharpParameters.denoiseModel )
                this.denoiseModelCombo.currentItem = dm;
        this.denoiseModelCombo.onItemSelected = index => { SetiAstroSharpParameters.denoiseModel = this.denoiseModelCombo.itemText( index ); };

        this.denoiseModelSizer = new HorizontalSizer; this.denoiseModelSizer.spacing = 6; this.denoiseModelSizer.add( this.denoiseModelLabel ); this.denoiseModelSizer.add( this.denoiseModelCombo, 100 );

        // ---- DarkStar section ----
        this.darkStarSectionLabel = new Label( this ); this.darkStarSectionLabel.text = "DarkStar Settings"; this.darkStarSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.darkStarModeLabel    = new Label( this ); this.darkStarModeLabel.text    = "Star Removal Mode:"; this.darkStarModeLabel.textAlignment    = TextAlignment.Left | TextAlignment.VertCenter;

        this.darkStarModeRow = new HorizontalSizer; this.darkStarModeRow.spacing = 12;

        this.darkStarUnscreenCheck = new CheckBox( this ); this.darkStarUnscreenCheck.text = "Unscreen";
        this.darkStarAdditiveCheck = new CheckBox( this ); this.darkStarAdditiveCheck.text = "Additive";

        this._darkStarModeGroup = [this.darkStarUnscreenCheck, this.darkStarAdditiveCheck];

        this.darkStarUnscreenCheck.checked = (SetiAstroSharpParameters.darkStarMode == "unscreen");
        this.darkStarAdditiveCheck.checked = (SetiAstroSharpParameters.darkStarMode == "additive");
        if ( !this._anyChecked( this._darkStarModeGroup ) ) this.darkStarUnscreenCheck.checked = true;

        this.darkStarUnscreenCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._darkStarModeGroup, this.darkStarUnscreenCheck ); else if ( !this._anyChecked( this._darkStarModeGroup ) ) this.darkStarUnscreenCheck.checked = true; this.updateVisibility(); };
        this.darkStarAdditiveCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._darkStarModeGroup, this.darkStarAdditiveCheck ); else if ( !this._anyChecked( this._darkStarModeGroup ) ) this.darkStarUnscreenCheck.checked = true; this.updateVisibility(); };

        this.darkStarModeRow.add( this.darkStarUnscreenCheck ); this.darkStarModeRow.add( this.darkStarAdditiveCheck ); this.darkStarModeRow.addStretch();

        this.darkStarProcessingLabel = new Label( this ); this.darkStarProcessingLabel.text = "Processing Path:"; this.darkStarProcessingLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.darkStarProcessingCombo = new ComboBox( this );
        this.darkStarProcessingCombo.editEnabled = false;
        this.darkStarProcessingCombo.addItem( "Mono AI per channel" ); this.darkStarProcessingCombo.addItem( "Hybrid Luma + Color" ); this.darkStarProcessingCombo.addItem( "Color AI only" );
        this.darkStarProcessingCombo.currentItem =
            SetiAstroSharpParameters.darkStarProcessingPath == "mono_per_channel" ? 0 :
            SetiAstroSharpParameters.darkStarProcessingPath == "color_only"       ? 2 : 1;
        this.darkStarProcessingCombo.onItemSelected = index =>
        {
            SetiAstroSharpParameters.darkStarProcessingPath =
                index == 0 ? "mono_per_channel" : index == 2 ? "color_only" : "hybrid_luma_color";
        };

        this.darkStarProcessingSizer = new HorizontalSizer; this.darkStarProcessingSizer.spacing = 6; this.darkStarProcessingSizer.add( this.darkStarProcessingLabel ); this.darkStarProcessingSizer.add( this.darkStarProcessingCombo, 100 );

        this.darkStarStarsOnlyCheckbox = new CheckBox( this );
        this.darkStarStarsOnlyCheckbox.text = "Create Stars Only Image";
        this.darkStarStarsOnlyCheckbox.checked = SetiAstroSharpParameters.darkStarShowStarsOnly;
        this.darkStarStarsOnlyCheckbox.onCheck = checked => { SetiAstroSharpParameters.darkStarShowStarsOnly = checked; };

        this.darkStarStarsOnlySizer = new HorizontalSizer; this.darkStarStarsOnlySizer.addStretch(); this.darkStarStarsOnlySizer.add( this.darkStarStarsOnlyCheckbox ); this.darkStarStarsOnlySizer.addStretch();

        this.darkStarOverlapFracControl = new NumericControl( this );
        this.darkStarOverlapFracControl.label.text = "Overlap Fraction:"; this.darkStarOverlapFracControl.setRange( 0.05, 0.50 ); this.darkStarOverlapFracControl.setPrecision( 3 ); this.darkStarOverlapFracControl.setValue( SetiAstroSharpParameters.darkStarOverlapFrac );
        this.darkStarOverlapFracControl.onValueUpdated = v => { SetiAstroSharpParameters.darkStarOverlapFrac = v; };

        this.darkStarEdgePaddingControl = new NumericControl( this );
        this.darkStarEdgePaddingControl.label.text = "Edge Padding:"; this.darkStarEdgePaddingControl.setRange( 0, 256 ); this.darkStarEdgePaddingControl.setPrecision( 0 ); this.darkStarEdgePaddingControl.setValue( SetiAstroSharpParameters.darkStarEdgePadding );
        this.darkStarEdgePaddingControl.onValueUpdated = v => { SetiAstroSharpParameters.darkStarEdgePadding = Math.round( v ); };

        this.darkStarCompatibilityCheckbox = new CheckBox( this );
        this.darkStarCompatibilityCheckbox.text = "GPU Compatibility Mode";
        this.darkStarCompatibilityCheckbox.checked = SetiAstroSharpParameters.darkStarCompatibilityMode;
        this.darkStarCompatibilityCheckbox.onCheck = checked => { SetiAstroSharpParameters.darkStarCompatibilityMode = checked; };

        this.darkStarCompatibilitySizer = new HorizontalSizer; this.darkStarCompatibilitySizer.addStretch(); this.darkStarCompatibilitySizer.add( this.darkStarCompatibilityCheckbox ); this.darkStarCompatibilitySizer.addStretch();

        // ---- Super Resolution section ----
        this.superResSectionLabel = new Label( this ); this.superResSectionLabel.text = "Super Resolution Settings"; this.superResSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.superResScaleLabel   = new Label( this ); this.superResScaleLabel.text   = "Scale:";                    this.superResScaleLabel.textAlignment   = TextAlignment.Left | TextAlignment.VertCenter;

        this.superResScaleRow = new HorizontalSizer; this.superResScaleRow.spacing = 12;

        this.superRes2xCheck = new CheckBox( this ); this.superRes2xCheck.text = "2x";
        this.superRes3xCheck = new CheckBox( this ); this.superRes3xCheck.text = "3x";
        this.superRes4xCheck = new CheckBox( this ); this.superRes4xCheck.text = "4x";

        this._srGroup = [this.superRes2xCheck, this.superRes3xCheck, this.superRes4xCheck];

        this.superRes2xCheck.checked = (SetiAstroSharpParameters.superResScale == 2);
        this.superRes3xCheck.checked = (SetiAstroSharpParameters.superResScale == 3);
        this.superRes4xCheck.checked = (SetiAstroSharpParameters.superResScale == 4);
        if ( !this._anyChecked( this._srGroup ) ) this.superRes2xCheck.checked = true;

        this.superRes2xCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._srGroup, this.superRes2xCheck ); else if ( !this._anyChecked( this._srGroup ) ) this.superRes2xCheck.checked = true; this.updateVisibility(); };
        this.superRes3xCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._srGroup, this.superRes3xCheck ); else if ( !this._anyChecked( this._srGroup ) ) this.superRes2xCheck.checked = true; this.updateVisibility(); };
        this.superRes4xCheck.onCheck = checked => { if ( checked ) _cc_setExclusive( this._srGroup, this.superRes4xCheck ); else if ( !this._anyChecked( this._srGroup ) ) this.superRes2xCheck.checked = true; this.updateVisibility(); };

        this.superResScaleRow.add( this.superRes2xCheck ); this.superResScaleRow.add( this.superRes3xCheck ); this.superResScaleRow.add( this.superRes4xCheck ); this.superResScaleRow.addStretch();

        // ---- Right column: shared settings ----
        this.sharedSectionLabel = new Label( this ); this.sharedSectionLabel.text = "Shared Processing Settings"; this.sharedSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.removeAberrationFirstCheckbox = new CheckBox( this );
        this.removeAberrationFirstCheckbox.text = "Remove Aberration First";
        this.removeAberrationFirstCheckbox.checked = SetiAstroSharpParameters.removeAberrationFirst;
        this.removeAberrationFirstCheckbox.toolTip =
            "Run Aberration Remover before Cosmic Clarity processing.\n\n" +
            "Aberration Remover model and weights © Riccardo Alberghi.\n" +
            "More information: https://github.com/riccardoalberghi";
        this.removeAberrationFirstCheckbox.onCheck = checked => { SetiAstroSharpParameters.removeAberrationFirst = checked; };

        this.gpuAccelerationCheckbox = new CheckBox( this );
        this.gpuAccelerationCheckbox.text = "Enable GPU Acceleration";
        this.gpuAccelerationCheckbox.checked = SetiAstroSharpParameters.useGPU;
        this.gpuAccelerationCheckbox.onCheck = checked => { SetiAstroSharpParameters.useGPU = checked; };

        this.tempStretchCheckbox = new CheckBox( this );
        this.tempStretchCheckbox.text = "Temporarily Stretch Linear Images Before AI Processing";
        this.tempStretchCheckbox.checked = SetiAstroSharpParameters.tempStretch;
        this.tempStretchCheckbox.toolTip = "If enabled, linear images will be temporarily stretched before sharpen/denoise, then unstretched afterward.";
        this.tempStretchCheckbox.onCheck = checked => { SetiAstroSharpParameters.tempStretch = checked; this.updateVisibility(); };

        this.tempStretchTargetMedianControl = new NumericControl( this );
        this.tempStretchTargetMedianControl.label.text = "Temp Stretch Target Median:"; this.tempStretchTargetMedianControl.setRange( 0.01, 0.50 ); this.tempStretchTargetMedianControl.setPrecision( 3 ); this.tempStretchTargetMedianControl.setValue( SetiAstroSharpParameters.tempStretchTargetMedian );
        this.tempStretchTargetMedianControl.toolTip = "Target median used for temporary stretch before AI processing.";
        this.tempStretchTargetMedianControl.onValueUpdated = v => { SetiAstroSharpParameters.tempStretchTargetMedian = v; };

        this.tilingSectionLabel = new Label( this ); this.tilingSectionLabel.text = "Tiling Settings"; this.tilingSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.chunkSizeControl = new NumericControl( this );
        this.chunkSizeControl.label.text = "Chunk Size:"; this.chunkSizeControl.setRange( 64, 2048 ); this.chunkSizeControl.setPrecision( 0 ); this.chunkSizeControl.setValue( SetiAstroSharpParameters.chunkSize || 256 );
        this.chunkSizeControl.toolTip = "Tile size used for chunked processing (pixels). Typical: 256 or 512.";
        this.chunkSizeControl.onValueUpdated = v => { SetiAstroSharpParameters.chunkSize = Math.round( v ); this.updateVisibility(); };

        this.overlapControl = new NumericControl( this );
        this.overlapControl.label.text = "Overlap:"; this.overlapControl.setRange( 0, 512 ); this.overlapControl.setPrecision( 0 ); this.overlapControl.setValue( SetiAstroSharpParameters.overlap || 64 );
        this.overlapControl.toolTip = "Overlap between tiles (pixels). Must be < chunk size.";
        this.overlapControl.onValueUpdated = v => { SetiAstroSharpParameters.overlap = Math.round( v ); this.updateVisibility(); };

        this.timeoutSectionLabel = new Label( this ); this.timeoutSectionLabel.text = "File Wait Timeouts"; this.timeoutSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.inputReadyTimeoutControl = new NumericControl( this );
        this.inputReadyTimeoutControl.label.text = "Input Ready Timeout (sec):"; this.inputReadyTimeoutControl.setRange( 5, 3600 ); this.inputReadyTimeoutControl.setPrecision( 0 ); this.inputReadyTimeoutControl.setValue( SetiAstroSharpParameters.inputReadyTimeoutSec );
        this.inputReadyTimeoutControl.toolTip = "How long to wait for the temporary input FITS to become readable.";
        this.inputReadyTimeoutControl.onValueUpdated = v => { SetiAstroSharpParameters.inputReadyTimeoutSec = Math.round( v ); };

        this.outputReadyTimeoutControl = new NumericControl( this );
        this.outputReadyTimeoutControl.label.text = "Output Ready Timeout (sec):"; this.outputReadyTimeoutControl.setRange( 10, 14400 ); this.outputReadyTimeoutControl.setPrecision( 0 ); this.outputReadyTimeoutControl.setValue( SetiAstroSharpParameters.outputReadyTimeoutSec );
        this.outputReadyTimeoutControl.toolTip = "How long to wait for SASpro CLI to produce a readable output file.";
        this.outputReadyTimeoutControl.onValueUpdated = v => { SetiAstroSharpParameters.outputReadyTimeoutSec = Math.round( v ); };

        // ---- Launcher settings ----
        this.launcherSectionLabel = new Label( this ); this.launcherSectionLabel.text = "SASpro CLI Launcher Settings"; this.launcherSectionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
        this.launcherModeLabel    = new Label( this ); this.launcherModeLabel.text    = "Launcher Mode:"; this.launcherModeLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.launcherModeCombo = new ComboBox( this );
        this.launcherModeCombo.editEnabled = false;

        let launcherModes = [
            "Auto Detect",
            "setiastrosuitepro cc (installed command)",
            "Frozen setiastrosuitepro executable",
            "python -m setiastro.saspro cc",
            "python setiastrosuitepro.py cc"
        ];

        let selectedLauncherIndex = 0;
        for ( let lm = 0; lm < launcherModes.length; lm++ )
        {
            this.launcherModeCombo.addItem( launcherModes[lm] );
            if ( launcherModes[lm] == SetiAstroSharpParameters.cliLauncherMode )
                selectedLauncherIndex = lm;
        }
        this.launcherModeCombo.currentItem = selectedLauncherIndex;
        this.launcherModeCombo.onItemSelected = index =>
        {
            SetiAstroSharpParameters.cliLauncherMode = this.launcherModeCombo.itemText( index );
            this.updateLauncherUIVisibility();
            if ( SetiAstroSharpParameters.cliLauncherMode == "Frozen setiastrosuitepro executable" )
            {
                if ( (!SetiAstroSharpParameters.cliLauncherPath || SetiAstroSharpParameters.cliLauncherPath.trim().length == 0) && !IS_LIN )
                {
                    let defp = getDefaultFrozenSasproPath();
                    if ( defp.length > 0 )
                    {
                        SetiAstroSharpParameters.cliLauncherPath = defp;
                        this.launcherPathEdit.text = defp;
                    }
                }
            }
        };

        this.launcherModeSizer = new HorizontalSizer; this.launcherModeSizer.spacing = 6; this.launcherModeSizer.add( this.launcherModeLabel ); this.launcherModeSizer.add( this.launcherModeCombo, 100 );

        this.launcherPathLabel = new Label( this ); this.launcherPathLabel.text = "Launcher Path:"; this.launcherPathLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.launcherPathEdit = new Edit( this );
        this.launcherPathEdit.text = SetiAstroSharpParameters.cliLauncherPath;
        this.launcherPathEdit.toolTip = "Path to setiastrosuitepro executable (frozen mode), or Python executable (python modes).";
        this.launcherPathEdit.onTextUpdated = text => { SetiAstroSharpParameters.cliLauncherPath = text; };

        this.launcherPathBrowseButton = new ToolButton( this );
        this.launcherPathBrowseButton.icon = this.scaledResource( ":/icons/select-file.png" );
        this.launcherPathBrowseButton.setScaledFixedSize( 20, 20 );
        this.launcherPathBrowseButton.toolTip = "Browse for executable (or Python).";
        this.launcherPathBrowseButton.onClick = () =>
        {
            let mode = this.launcherModeCombo.itemText( this.launcherModeCombo.currentItem );

            if ( mode == "Frozen setiastrosuitepro executable" )
            {
                if ( (!SetiAstroSharpParameters.cliLauncherPath || SetiAstroSharpParameters.cliLauncherPath.length == 0) && !IS_LIN )
                {
                    let def = getDefaultFrozenSasproPath();
                    if ( def.length > 0 ) { SetiAstroSharpParameters.cliLauncherPath = def; this.launcherPathEdit.text = def; }
                }
                if ( IS_LIN )
                {
                    let chosen = promptForFrozenSasproExecutableLinux( this );
                    if ( chosen && chosen.length > 0 ) this.launcherPathEdit.text = chosen;
                    return;
                }
            }

            let ofd = new OpenFileDialog;
            ofd.caption = (mode == "Frozen setiastrosuitepro executable") ? "Select SetiAstroSuitePro Executable" : "Select Launcher Executable";
            ofd.multipleSelections = false;
            if ( SetiAstroSharpParameters.cliLauncherPath && SetiAstroSharpParameters.cliLauncherPath.length > 0 )
                ofd.initialPath = SetiAstroSharpParameters.cliLauncherPath;

            if ( ofd.execute() && ofd.fileNames.length > 0 )
            {
                SetiAstroSharpParameters.cliLauncherPath = ofd.fileNames[0];
                this.launcherPathEdit.text = SetiAstroSharpParameters.cliLauncherPath;
                SetiAstroSharpParameters.save();
            }
        };

        this.launcherPathSizer = new HorizontalSizer; this.launcherPathSizer.spacing = 6; this.launcherPathSizer.add( this.launcherPathLabel ); this.launcherPathSizer.add( this.launcherPathEdit, 100 ); this.launcherPathSizer.add( this.launcherPathBrowseButton );

        this.pythonScriptPathLabel = new Label( this ); this.pythonScriptPathLabel.text = "SASpro Script Path:"; this.pythonScriptPathLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.pythonScriptPathEdit = new Edit( this );
        this.pythonScriptPathEdit.text = SetiAstroSharpParameters.pythonScriptPath;
        this.pythonScriptPathEdit.toolTip = "Path to setiastrosuitepro.py (only used for 'python setiastrosuitepro.py cc').";
        this.pythonScriptPathEdit.onTextUpdated = text => { SetiAstroSharpParameters.pythonScriptPath = text; };

        this.pythonScriptBrowseButton = new ToolButton( this );
        this.pythonScriptBrowseButton.icon = this.scaledResource( ":/icons/select-file.png" );
        this.pythonScriptBrowseButton.setScaledFixedSize( 20, 20 );
        this.pythonScriptBrowseButton.toolTip = "Browse for setiastrosuitepro.py";
        this.pythonScriptBrowseButton.onClick = () =>
        {
            let ofd = new OpenFileDialog;
            ofd.caption = "Select setiastrosuitepro.py";
            ofd.multipleSelections = false;
            if ( SetiAstroSharpParameters.pythonScriptPath && SetiAstroSharpParameters.pythonScriptPath.length > 0 )
                ofd.initialPath = SetiAstroSharpParameters.pythonScriptPath;

            if ( IS_LIN && SetiAstroSharpParameters.cliLauncherMode == "Frozen setiastrosuitepro executable" )
            {
                if ( !SetiAstroSharpParameters.cliLauncherPath || SetiAstroSharpParameters.cliLauncherPath.trim().length == 0 )
                {
                    let chosenLin = promptForFrozenSasproExecutableLinux( this );
                    if ( !chosenLin || chosenLin.length == 0 )
                    {
                        new MessageBox(
                            "Frozen executable mode requires selecting the Linux SASpro executable.\n" +
                            "Please choose your SetiAstroSuitePro_linux_ubuntu24.04 file, or switch launcher mode.",
                            "Cosmic Clarity - SASpro", StdIcon.Error, StdButton.Ok ).execute();
                        return;
                    }
                    this.launcherPathEdit.text = chosenLin;
                }
            }

            if ( ofd.execute() && ofd.fileNames.length > 0 )
            {
                SetiAstroSharpParameters.pythonScriptPath = ofd.fileNames[0];
                this.pythonScriptPathEdit.text = SetiAstroSharpParameters.pythonScriptPath;
                SetiAstroSharpParameters.save();
            }
        };

        this.pythonScriptPathSizer = new HorizontalSizer; this.pythonScriptPathSizer.spacing = 6; this.pythonScriptPathSizer.add( this.pythonScriptPathLabel ); this.pythonScriptPathSizer.add( this.pythonScriptPathEdit, 100 ); this.pythonScriptPathSizer.add( this.pythonScriptBrowseButton );

        this.launcherHelp = new TextBox( this );
        this.launcherHelp.readOnly = true;
        this.launcherHelp.setMaxHeight( 140 );
        this.launcherHelp.text =
            "Tips:\n" +
            "• Auto Detect tries: setiastrosuitepro cc → frozen default path → configured frozen path → python module fallback.\n" +
            "• Windows frozen default path:\n  C:\\Program Files\\SetiAstroSuitePro\\SetiAstroSuitePro.exe\n" +
            "• macOS frozen app executable path:\n  /Applications/SetiAstroSuitePro.app/Contents/MacOS/SetiAstroSuitePro\n" +
            "• Linux frozen path is user-chosen. Browse to your executable (e.g. SetiAstroSuitePro_linux_ubuntu24.04).\n" +
            "• For source/dev usage, use 'python setiastrosuitepro.py cc' and select the script path.";

        this.testLauncherButton = new PushButton( this );
        this.testLauncherButton.text = "Test Launcher";
        this.testLauncherButton.toolTip = "Runs '<launcher> ... cc --help' to validate the configuration.";
        this.testLauncherButton.onClick = () => { this.testConfiguredLauncher(); };

        this.launcherButtonsRow = new HorizontalSizer; this.launcherButtonsRow.addStretch(); this.launcherButtonsRow.add( this.testLauncherButton ); this.launcherButtonsRow.addStretch();

        // ---- Bottom buttons ----
        this.okButton = new PushButton( this );
        this.okButton.text = "OK";
        this.okButton.onClick = () =>
        {
            SetiAstroSharpParameters.cliLauncherMode  = this.launcherModeCombo.itemText( this.launcherModeCombo.currentItem );
            SetiAstroSharpParameters.cliLauncherPath  = this.launcherPathEdit.text;
            SetiAstroSharpParameters.pythonScriptPath = this.pythonScriptPathEdit.text;
            SetiAstroSharpParameters.save();
            this.ok();
        };

        this.cancelButton = new PushButton( this );
        this.cancelButton.text = "Cancel";
        this.cancelButton.onClick = () => { this.cancel(); };

        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "Save a new instance of this script";
        this.newInstanceButton.onMousePress = () =>
        {
            SetiAstroSharpParameters.cliLauncherMode  = this.launcherModeCombo.itemText( this.launcherModeCombo.currentItem );
            SetiAstroSharpParameters.cliLauncherPath  = this.launcherPathEdit.text;
            SetiAstroSharpParameters.pythonScriptPath = this.pythonScriptPathEdit.text;
            SetiAstroSharpParameters.save();
            this.newInstance();
        };

        this.buttonsSizer = new HorizontalSizer;
        this.buttonsSizer.spacing = 6;
        this.buttonsSizer.add( this.newInstanceButton );
        this.buttonsSizer.addStretch();
        this.buttonsSizer.add( this.okButton );
        this.buttonsSizer.add( this.cancelButton );
        this.buttonsSizer.addStretch();

        // ---- Two-column layout ----
        this.leftColumn = new VerticalSizer; this.leftColumn.spacing = 6;
        this.leftColumn.add( this.sharpenSectionLabel );
        this.leftColumn.add( this.sharpeningModeLabel );
        this.leftColumn.add( this.sharpeningModeRow );
        this.leftColumn.add( this.sharpenChannelsSizer );
        this.leftColumn.add( this.autoPSFSizer );
        this.leftColumn.add( this.stellarAmountSlider );
        this.leftColumn.add( this.nonStellarStrengthSlider );
        this.leftColumn.add( this.nonStellarAmountSlider );
        this.leftColumn.addSpacing( 8 );
        this.leftColumn.add( this.denoiseSectionLabel );
        this.leftColumn.add( this.denoiseModeLabel );
        this.leftColumn.add( this.denoiseModeRow );
        this.leftColumn.add( this.denoiseLumaSlider );
        this.leftColumn.add( this.denoiseColorSlider );
        this.leftColumn.add( this.denoiseSeparateChannelsSizer );
        this.leftColumn.add( this.denoiseModelSizer );
        this.leftColumn.addSpacing( 8 );
        this.leftColumn.add( this.darkStarSectionLabel );
        this.leftColumn.add( this.darkStarModeLabel );
        this.leftColumn.add( this.darkStarModeRow );
        this.leftColumn.add( this.darkStarProcessingSizer );
        this.leftColumn.add( this.darkStarStarsOnlySizer );
        this.leftColumn.add( this.darkStarOverlapFracControl );
        this.leftColumn.add( this.darkStarEdgePaddingControl );
        this.leftColumn.add( this.darkStarCompatibilitySizer );
        this.leftColumn.addSpacing( 8 );
        this.leftColumn.add( this.superResSectionLabel );
        this.leftColumn.add( this.superResScaleLabel );
        this.leftColumn.add( this.superResScaleRow );
        this.leftColumn.addStretch();

        this.rightColumn = new VerticalSizer; this.rightColumn.spacing = 6;
        this.rightColumn.add( this.sharedSectionLabel );
        this.rightColumn.add( this.removeAberrationFirstCheckbox );
        this.rightColumn.add( this.gpuAccelerationCheckbox );
        this.rightColumn.add( this.tempStretchCheckbox );
        this.rightColumn.add( this.tempStretchTargetMedianControl );
        this.rightColumn.addSpacing( 8 );
        this.rightColumn.add( this.tilingSectionLabel );
        this.rightColumn.add( this.chunkSizeControl );
        this.rightColumn.add( this.overlapControl );
        this.rightColumn.addSpacing( 8 );
        this.rightColumn.add( this.timeoutSectionLabel );
        this.rightColumn.add( this.inputReadyTimeoutControl );
        this.rightColumn.add( this.outputReadyTimeoutControl );
        this.rightColumn.addStretch();

        this.contentColumns = new HorizontalSizer; this.contentColumns.spacing = 12;
        this.contentColumns.add( this.leftColumn,  50 );
        this.contentColumns.add( this.rightColumn, 50 );

        this.sizer = new VerticalSizer;
        this.sizer.margin = 6; this.sizer.spacing = 6;
        this.sizer.add( this.titleLabel );
        this.sizer.add( this.description );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.imageSelectionSizer );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.processModeLabel );
        this.sizer.add( this.processModeRow );
        this.sizer.addSpacing( 6 );
        this.sizer.add( this.contentColumns );
        this.sizer.addSpacing( 8 );
        this.sizer.add( this.launcherSectionLabel );
        this.sizer.add( this.launcherModeSizer );
        this.sizer.add( this.launcherPathSizer );
        this.sizer.add( this.pythonScriptPathSizer );
        this.sizer.add( this.launcherHelp );
        this.sizer.add( this.launcherButtonsRow );
        this.sizer.addSpacing( 8 );
        this.sizer.add( this.buttonsSizer );

        this.windowTitle = "Cosmic Clarity - SASpro";
        this.adjustToContents();

        this.updateVisibility();
        this.updateLauncherUIVisibility();
    }

    _anyChecked( group )
    {
        for ( var i = 0; i < group.length; i++ )
            if ( group[i].checked ) return true;
        return false;
    }

    updateVisibility()
    {
        let isSharpen  = this.processSharpenCheck.checked;
        let isDenoise  = this.processDenoiseCheck.checked;
        let isBoth     = this.processBothCheck.checked;
        let isDarkStar = this.processDarkStarCheck.checked;
        let isSuper    = this.processSuperResCheck.checked;

        if ( !isSharpen && !isDenoise && !isBoth && !isDarkStar && !isSuper )
        { this.processSharpenCheck.checked = true; isSharpen = true; }

        SetiAstroSharpParameters.processMode =
            isSharpen  ? "sharpen"  : isDenoise  ? "denoise"  :
            isBoth     ? "both"     : isDarkStar ? "darkstar" : "superres";

        let stellarMode    = this.sharpStellarCheck.checked;
        let nonStellarMode = this.sharpNonStellarCheck.checked;
        let bothMode       = this.sharpBothCheck.checked;
        if ( !stellarMode && !nonStellarMode && !bothMode ) { this.sharpBothCheck.checked = true; bothMode = true; }

        SetiAstroSharpParameters.sharpeningMode =
            stellarMode ? "Stellar Only" : nonStellarMode ? "Non-Stellar Only" : "Both";

        if ( !this.denoiseFullCheck.checked && !this.denoiseLuminanceCheck.checked )
            this.denoiseFullCheck.checked = true;
        SetiAstroSharpParameters.denoiseMode =
            this.denoiseLuminanceCheck.checked ? "luminance" : "full";

        if ( !this.darkStarUnscreenCheck.checked && !this.darkStarAdditiveCheck.checked )
            this.darkStarUnscreenCheck.checked = true;
        SetiAstroSharpParameters.darkStarMode =
            this.darkStarAdditiveCheck.checked ? "additive" : "unscreen";

        if ( !this.superRes2xCheck.checked && !this.superRes3xCheck.checked && !this.superRes4xCheck.checked )
            this.superRes2xCheck.checked = true;
        SetiAstroSharpParameters.superResScale =
            this.superRes4xCheck.checked ? 4 : this.superRes3xCheck.checked ? 3 : 2;

        let cs = _cc_toInt( SetiAstroSharpParameters.chunkSize, 256 );
        let ov = _cc_toInt( SetiAstroSharpParameters.overlap,   64  );
        if ( cs < 64 ) cs = 64; if ( cs > 2048 ) cs = 2048;
        if ( ov < 0  ) ov = 0;  if ( ov >= cs   ) ov = Math.max( 0, cs - 1 );
        SetiAstroSharpParameters.chunkSize = cs; SetiAstroSharpParameters.overlap = ov;
        if ( this.chunkSizeControl ) this.chunkSizeControl.setValue( cs );
        if ( this.overlapControl   ) this.overlapControl.setValue( ov );

        let dsFrac = _cc_toFloat( SetiAstroSharpParameters.darkStarOverlapFrac, 0.125 );
        if ( dsFrac < 0.05 ) dsFrac = 0.05; if ( dsFrac > 0.50 ) dsFrac = 0.50;
        SetiAstroSharpParameters.darkStarOverlapFrac = dsFrac;
        if ( this.darkStarOverlapFracControl ) this.darkStarOverlapFracControl.setValue( dsFrac );

        let dsPad = _cc_toInt( SetiAstroSharpParameters.darkStarEdgePadding, 64 );
        if ( dsPad < 0 ) dsPad = 0; if ( dsPad > 256 ) dsPad = 256;
        SetiAstroSharpParameters.darkStarEdgePadding = dsPad;
        if ( this.darkStarEdgePaddingControl ) this.darkStarEdgePaddingControl.setValue( dsPad );

        let showSharpenGroup  = isSharpen || isBoth;
        let showDenoiseGroup  = isDenoise || isBoth;
        let showDarkStarGroup = isDarkStar;
        let showSuperGroup    = isSuper;
        let showTempStretch   = isSharpen || isDenoise || isBoth;
        let showTiling        = isSharpen || isDenoise || isBoth || isSuper || isDarkStar;

        // Sharpen
        this.sharpenSectionLabel.visible     = showSharpenGroup;
        this.sharpeningModeLabel.visible     = showSharpenGroup;
        this.sharpeningModeRow.visible       = showSharpenGroup;
        this.sharpStellarCheck.visible       = showSharpenGroup;
        this.sharpNonStellarCheck.visible    = showSharpenGroup;
        this.sharpBothCheck.visible          = showSharpenGroup;
        this.sharpenChannelsSizer.visible    = showSharpenGroup;
        this.sharpenChannelsCheckbox.visible = showSharpenGroup;
        this.autoPSFSizer.visible            = showSharpenGroup;
        this.autoPSFCheckbox.visible         = showSharpenGroup;
        this.stellarAmountSlider.visible     = showSharpenGroup && (stellarMode || bothMode);
        this.nonStellarAmountSlider.visible  = showSharpenGroup && (nonStellarMode || bothMode);
        this.nonStellarStrengthSlider.visible = showSharpenGroup && (nonStellarMode || bothMode) && !SetiAstroSharpParameters.autoPSF;

        // Denoise
        this.denoiseSectionLabel.visible            = showDenoiseGroup;
        this.denoiseModeLabel.visible               = showDenoiseGroup;
        this.denoiseModeRow.visible                 = showDenoiseGroup;
        this.denoiseFullCheck.visible               = showDenoiseGroup;
        this.denoiseLuminanceCheck.visible          = showDenoiseGroup;
        this.denoiseLumaSlider.visible              = showDenoiseGroup;
        this.denoiseColorSlider.visible             = showDenoiseGroup && (SetiAstroSharpParameters.denoiseMode != "luminance");
        this.denoiseSeparateChannelsSizer.visible   = showDenoiseGroup;
        this.denoiseSeparateChannelsCheckbox.visible = showDenoiseGroup;
        this.denoiseModelSizer.visible              = showDenoiseGroup;
        this.denoiseModelLabel.visible              = showDenoiseGroup;
        this.denoiseModelCombo.visible              = showDenoiseGroup;

        // DarkStar
        this.darkStarSectionLabel.visible          = showDarkStarGroup;
        this.darkStarModeLabel.visible             = showDarkStarGroup;
        this.darkStarModeRow.visible               = showDarkStarGroup;
        this.darkStarUnscreenCheck.visible         = showDarkStarGroup;
        this.darkStarAdditiveCheck.visible         = showDarkStarGroup;
        this.darkStarProcessingSizer.visible       = showDarkStarGroup;
        this.darkStarProcessingLabel.visible       = showDarkStarGroup;
        this.darkStarProcessingCombo.visible       = showDarkStarGroup;
        this.darkStarStarsOnlySizer.visible        = showDarkStarGroup;
        this.darkStarStarsOnlyCheckbox.visible     = showDarkStarGroup;
        this.darkStarOverlapFracControl.visible    = showDarkStarGroup;
        this.darkStarEdgePaddingControl.visible    = showDarkStarGroup;
        this.darkStarCompatibilitySizer.visible    = showDarkStarGroup;
        this.darkStarCompatibilityCheckbox.visible = showDarkStarGroup;

        // SuperRes
        this.superResSectionLabel.visible = showSuperGroup;
        this.superResScaleLabel.visible   = showSuperGroup;
        this.superResScaleRow.visible     = showSuperGroup;
        this.superRes2xCheck.visible      = showSuperGroup;
        this.superRes3xCheck.visible      = showSuperGroup;
        this.superRes4xCheck.visible      = showSuperGroup;

        // Shared
        this.sharedSectionLabel.visible              = true;
        this.gpuAccelerationCheckbox.visible         = true;
        this.removeAberrationFirstCheckbox.visible   = true;
        this.tempStretchCheckbox.visible             = showTempStretch;
        this.tempStretchTargetMedianControl.visible  = showTempStretch && SetiAstroSharpParameters.tempStretch;
        this.tilingSectionLabel.visible              = showTiling;
        this.chunkSizeControl.visible                = showTiling;
        this.overlapControl.visible                  = isSharpen || isDenoise || isBoth || isSuper;
        this.timeoutSectionLabel.visible             = true;
        this.inputReadyTimeoutControl.visible        = true;
        this.outputReadyTimeoutControl.visible       = true;

        this.adjustToContents();
    }

    updateLauncherUIVisibility()
    {
        let mode = this.launcherModeCombo.itemText( this.launcherModeCombo.currentItem );

        let showLauncherPath = (
            mode == "Frozen setiastrosuitepro executable" ||
            mode == "python -m setiastro.saspro cc" ||
            mode == "python setiastrosuitepro.py cc" );

        let showPythonScriptPath = (mode == "python setiastrosuitepro.py cc");

        this.launcherPathLabel.visible        = showLauncherPath;
        this.launcherPathEdit.visible         = showLauncherPath;
        this.launcherPathBrowseButton.visible = showLauncherPath;

        this.pythonScriptPathLabel.visible        = showPythonScriptPath;
        this.pythonScriptPathEdit.visible         = showPythonScriptPath;
        this.pythonScriptBrowseButton.visible     = showPythonScriptPath;

        this.adjustToContents();
    }

    testConfiguredLauncher()
    {
        try
        {
            SetiAstroSharpParameters.cliLauncherMode  = this.launcherModeCombo.itemText( this.launcherModeCombo.currentItem );
            SetiAstroSharpParameters.cliLauncherPath  = this.launcherPathEdit.text;
            SetiAstroSharpParameters.pythonScriptPath = this.pythonScriptPathEdit.text;
            SetiAstroSharpParameters.save();

            let launcher = resolveSasproCliLauncher();

            if ( launcher.isAuto )
            {
                let candidates = launcher.autoCandidates;
                let anyOk = false;
                for ( let i = 0; i < candidates.length; i++ )
                {
                    console.noteln( "Testing launcher candidate: " + candidates[i].label );
                    let r = runExternalProcessBlocking( candidates[i].program, candidates[i].prefixArgs.concat( ["--help"] ) );
                    if ( r.ok || (r.stdout && r.stdout.length > 0) || (r.stderr && r.stderr.length > 0) )
                    { console.noteln( "Launcher candidate responded: " + candidates[i].label ); anyOk = true; break; }
                }
                if ( anyOk )
                    new MessageBox( "Launcher test completed. Check the PixInsight console output.", "SASpro CLI Test", StdIcon.Information, StdButton.Ok ).execute();
                else
                    new MessageBox( "No auto-detect launcher responded. Configure a manual launcher mode/path.", "SASpro CLI Test", StdIcon.Error, StdButton.Ok ).execute();
                return;
            }

            let r2 = runExternalProcessBlocking( launcher.program, launcher.prefixArgs.concat( ["--help"] ) );
            if ( r2.ok || (r2.stdout && r2.stdout.length > 0) || (r2.stderr && r2.stderr.length > 0) )
                new MessageBox( "Launcher test completed. Check the PixInsight console output.", "SASpro CLI Test", StdIcon.Information, StdButton.Ok ).execute();
            else
                new MessageBox( "Launcher test failed. Check launcher mode/path and try again.", "SASpro CLI Test", StdIcon.Error, StdButton.Ok ).execute();
        }
        catch ( e )
        {
            new MessageBox( "Launcher test error:\n" + e.message, "SASpro CLI Test", StdIcon.Error, StdButton.Ok ).execute();
        }
    }
};

// ============================================================================
// Entry point
// ============================================================================

console.show();
console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/__/ \\___/ \n                                         " );
console.noteln( "Cosmic Clarity - SASpro " + VERSION );
console.flush();

let dialog = new SetiAstroSharpDialog();

if ( dialog.execute() )
{
    console.writeln( "Cosmic Clarity - SASpro process started." );
    console.flush();

    let selectedIndex = dialog.imageSelectionDropdown.currentItem;
    let windows2 = ImageWindow.windows;

    if ( !windows2 || windows2.length === 0 || selectedIndex < 0 || selectedIndex >= windows2.length )
    {
        new MessageBox( "Please open and select an image first.", "Cosmic Clarity - SASpro", StdIcon.Error, StdButton.Ok ).execute();
    }
    else
    {
        let selectedView = windows2[selectedIndex];
        if ( !selectedView )
        {
            new MessageBox( "Please select a valid image.", "Cosmic Clarity - SASpro", StdIcon.Error, StdButton.Ok ).execute();
        }
        else
        {
            try
            {
                runCosmicClarityViaSasproCLI( selectedView );
                console.noteln( "Cosmic Clarity - SASpro processing complete." );
            }
            catch ( e )
            {
                console.criticalln( "Error: " + e.message );
                new MessageBox( "Cosmic Clarity - SASpro failed:\n\n" + e.message,
                                "Cosmic Clarity - SASpro", StdIcon.Error, StdButton.Ok ).execute();
            }
        }
    }
}
