
#engine v8

#feature-id WhatsInMyImage : SetiAstro > Whats In My Image
#feature-icon  wimi.svg
#feature-info This script will use Simbad lookup to identify objects in your image

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * What's In My Image Script
 * Version: V2.7.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

// Guard SETTINGS_MODULE so this can coexist with ImageSolver if included
if ( typeof SETTINGS_MODULE === 'undefined' )
    var SETTINGS_MODULE = "MyScriptModule";

// ============================================================================
// Type lookup table
// ============================================================================

var typeLookupTable = [
{"cond":"?","extd":"Object of unknown nature"},{"cond":"ev","extd":"transient event"},
{"cond":"","extd":""},{"cond":"Rad","extd":"Radio-source"},{"cond":"mR","extd":"metric Radio-source"},
{"cond":"cm","extd":"centimetric Radio-source"},{"cond":"mm","extd":"millimetric Radio-source"},
{"cond":"smm","extd":"sub-millimetric source"},{"cond":"HI","extd":"HI (21cm) source"},
{"cond":"rB","extd":"radio Burst"},{"cond":"Mas","extd":"Maser"},{"cond":"","extd":""},
{"cond":"IR","extd":"Infra-Red source"},{"cond":"FIR","extd":"Far-Infrared source"},
{"cond":"MIR","extd":"Mid-Infrared source"},{"cond":"NIR","extd":"Near-Infrared source"},
{"cond":"","extd":""},{"cond":"blu","extd":"Blue object"},{"cond":"","extd":""},
{"cond":"UV","extd":"UV-emission source"},{"cond":"","extd":""},{"cond":"X","extd":"X-ray source"},
{"cond":"UX?","extd":"Ultra-luminous X-ray candidate"},{"cond":"ULX","extd":"Ultra-luminous X-ray source"},
{"cond":"","extd":""},{"cond":"gam","extd":"gamma-ray source"},{"cond":"gB","extd":"gamma-ray Burst"},
{"cond":"","extd":""},{"cond":"err","extd":"Not an object (error, artefact, ...)"},{"cond":"","extd":""},
{"cond":"grv","extd":"Gravitational Source"},{"cond":"Lev","extd":"(Micro)Lensing Event"},
{"cond":"LS?","extd":"Possible gravitational lens System"},{"cond":"Le?","extd":"Possible gravitational lens"},
{"cond":"LI?","extd":"Possible gravitationally lensed image"},{"cond":"gLe","extd":"Gravitational Lens"},
{"cond":"gLS","extd":"Gravitational Lens System (lens+images)"},{"cond":"GWE","extd":"Gravitational Wave Event"},
{"cond":"","extd":""},{"cond":"..?","extd":"Candidate objects"},{"cond":"G?","extd":"Possible Galaxy"},
{"cond":"SC?","extd":"Possible Supercluster of Galaxies"},{"cond":"C?G","extd":"Possible Cluster of Galaxies"},
{"cond":"Gr?","extd":"Possible Group of Galaxies"},{"cond":"As?","extd":""},
{"cond":"**?","extd":"Physical Binary Candidate"},{"cond":"EB?","extd":"Eclipsing Binary Candidate"},
{"cond":"Sy?","extd":"Symbiotic Star Candidate"},{"cond":"CV?","extd":"Cataclysmic Binary Candidate"},
{"cond":"No?","extd":"Nova Candidate"},{"cond":"XB?","extd":"X-ray binary Candidate"},
{"cond":"LX?","extd":"Low-Mass X-ray binary Candidate"},{"cond":"HX?","extd":"High-Mass X-ray binary Candidate"},
{"cond":"Pec?","extd":"Possible Peculiar Star"},{"cond":"Y*?","extd":"Young Stellar Object Candidate"},
{"cond":"TT?","extd":"T Tau star Candidate"},{"cond":"C*?","extd":"Possible Carbon Star"},
{"cond":"S*?","extd":"Possible S Star"},{"cond":"OH?","extd":"Possible Star with envelope of OH/IR type"},
{"cond":"WR?","extd":"Possible Wolf-Rayet Star"},{"cond":"Be?","extd":"Possible Be Star"},
{"cond":"Ae?","extd":"Possible Herbig Ae/Be Star"},{"cond":"HB?","extd":"Possible Horizontal Branch Star"},
{"cond":"RR?","extd":"Possible Star of RR Lyr type"},{"cond":"Ce?","extd":"Possible Cepheid"},
{"cond":"WV?","extd":"Possible Variable Star of W Vir type"},{"cond":"RB?","extd":"Possible Red Giant Branch star"},
{"cond":"sg?","extd":"Possible Supergiant star"},{"cond":"s?r","extd":"Possible Red supergiant star"},
{"cond":"s?y","extd":"Possible Yellow supergiant star"},{"cond":"s?b","extd":"Possible Blue supergiant star"},
{"cond":"AB?","extd":"Asymptotic Giant Branch Star candidate"},{"cond":"LP?","extd":"Long Period Variable candidate"},
{"cond":"Mi?","extd":"Mira candidate"},{"cond":"pA?","extd":"Post-AGB Star Candidate"},
{"cond":"BS?","extd":"Candidate blue Straggler Star"},{"cond":"HS?","extd":"Hot subdwarf candidate"},
{"cond":"WD?","extd":"White Dwarf Candidate"},{"cond":"N*?","extd":"Neutron Star Candidate"},
{"cond":"BH?","extd":"Black Hole Candidate"},{"cond":"SN?","extd":"SuperNova Candidate"},
{"cond":"LM?","extd":"Low-mass star candidate"},{"cond":"BD?","extd":"Brown Dwarf Candidate"},
{"cond":"","extd":""},{"cond":"mul","extd":"Composite object"},{"cond":"reg","extd":"Region defined in the sky"},
{"cond":"vid","extd":"Underdense region of the Universe"},{"cond":"SCG","extd":"Supercluster of Galaxies"},
{"cond":"ClG","extd":"Cluster of Galaxies"},{"cond":"GrG","extd":"Group of Galaxies"},
{"cond":"CGG","extd":"Compact Group of Galaxies"},{"cond":"PaG","extd":"Pair of Galaxies"},
{"cond":"IG","extd":"Interacting Galaxies"},{"cond":"C?*","extd":"Possible (open) star cluster"},
{"cond":"Gl?","extd":"Possible Globular Cluster"},{"cond":"Cl*","extd":"Cluster of Stars"},
{"cond":"GlC","extd":"Globular Cluster"},{"cond":"OpC","extd":"Open (galactic) Cluster"},
{"cond":"As*","extd":"Association of Stars"},{"cond":"St*","extd":"Stellar Stream"},
{"cond":"MGr","extd":"Moving Group"},{"cond":"**","extd":"Double or multiple star"},
{"cond":"EB*","extd":"Eclipsing binary"},{"cond":"Al*","extd":"Eclipsing binary of Algol type"},
{"cond":"bL*","extd":"Eclipsing binary of beta Lyr type"},{"cond":"WU*","extd":"Eclipsing binary of W UMa type"},
{"cond":"SB*","extd":"Spectroscopic binary"},{"cond":"El*","extd":"Ellipsoidal variable Star"},
{"cond":"Sy*","extd":"Symbiotic Star"},{"cond":"CV*","extd":"Cataclysmic Variable Star"},
{"cond":"DQ*","extd":"CV DQ Her type (intermediate polar)"},{"cond":"AM*","extd":"CV of AM Her type (polar)"},
{"cond":"NL*","extd":"Nova-like Star"},{"cond":"No*","extd":"Nova"},{"cond":"DN*","extd":"Dwarf Nova"},
{"cond":"XB*","extd":"X-ray Binary"},{"cond":"LXB","extd":"Low Mass X-ray Binary"},
{"cond":"HXB","extd":"High Mass X-ray Binary"},{"cond":"","extd":""},
{"cond":"ISM","extd":"Interstellar matter"},{"cond":"PoC","extd":"Part of Cloud"},
{"cond":"PN?","extd":"Possible Planetary Nebula"},{"cond":"CGb","extd":"Cometary Globule"},
{"cond":"bub","extd":"Bubble"},{"cond":"EmO","extd":"Emission Object"},{"cond":"Cld","extd":"Cloud"},
{"cond":"GNe","extd":"Galactic Nebula"},{"cond":"DNe","extd":"Dark Cloud (nebula)"},
{"cond":"RNe","extd":"Reflection Nebula"},{"cond":"MoC","extd":"Molecular Cloud"},
{"cond":"glb","extd":"Globule (low-mass dark cloud)"},{"cond":"cor","extd":"Dense core"},
{"cond":"SFR","extd":"Star forming region"},{"cond":"HVC","extd":"High-velocity Cloud"},
{"cond":"HII","extd":"HII (ionized) region"},{"cond":"PN","extd":"Planetary Nebula"},
{"cond":"sh","extd":"HI shell"},{"cond":"SR?","extd":"SuperNova Remnant Candidate"},
{"cond":"SNR","extd":"SuperNova Remnant"},{"cond":"of?","extd":"Outflow candidate"},
{"cond":"out","extd":"Outflow"},{"cond":"HH","extd":"Herbig-Haro Object"},{"cond":"","extd":""},
{"cond":"*","extd":"Star"},{"cond":"V*?","extd":"Star suspected of Variability"},
{"cond":"Pe*","extd":"Peculiar Star"},{"cond":"HB*","extd":"Horizontal Branch Star"},
{"cond":"Y*O","extd":"Young Stellar Object"},{"cond":"Ae*","extd":"Herbig Ae/Be star"},
{"cond":"Em*","extd":"Emission-line Star"},{"cond":"Be*","extd":"Be Star"},
{"cond":"BS*","extd":"Blue Straggler Star"},{"cond":"RG*","extd":"Red Giant Branch star"},
{"cond":"AB*","extd":"Asymptotic Giant Branch Star (He-burning)"},{"cond":"C*","extd":"Carbon Star"},
{"cond":"S*","extd":"S Star"},{"cond":"sg*","extd":"Evolved supergiant star"},
{"cond":"s*r","extd":"Red supergiant star"},{"cond":"s*y","extd":"Yellow supergiant star"},
{"cond":"s*b","extd":"Blue supergiant star"},{"cond":"HS*","extd":"Hot subdwarf"},
{"cond":"pA*","extd":"Post-AGB Star (proto-PN)"},{"cond":"WD*","extd":"White Dwarf"},
{"cond":"LM*","extd":"Low-mass star (M<1solMass)"},{"cond":"BD*","extd":"Brown Dwarf (M<0.08solMass)"},
{"cond":"N*","extd":"Confirmed Neutron Star"},{"cond":"OH*","extd":"OH/IR star"},
{"cond":"TT*","extd":"T Tau-type Star"},{"cond":"WR*","extd":"Wolf-Rayet Star"},
{"cond":"PM*","extd":"High proper-motion Star"},{"cond":"HV*","extd":"High-velocity Star"},
{"cond":"V*","extd":"Variable Star"},{"cond":"Ir*","extd":"Variable Star of irregular type"},
{"cond":"Or*","extd":"Variable Star of Orion Type"},{"cond":"Er*","extd":"Eruptive variable Star"},
{"cond":"RC*","extd":"Variable Star of R CrB type"},{"cond":"RC?","extd":"Variable Star of R CrB type candiate"},
{"cond":"Ro*","extd":"Rotationally variable Star"},{"cond":"a2*","extd":"Variable Star of alpha2 CVn type"},
{"cond":"Psr","extd":"Pulsar"},{"cond":"BY*","extd":"Variable of BY Dra type"},
{"cond":"RS*","extd":"Variable of RS CVn type"},{"cond":"Pu*","extd":"Pulsating variable Star"},
{"cond":"RR*","extd":"Variable Star of RR Lyr type"},{"cond":"Ce*","extd":"Cepheid variable Star"},
{"cond":"dS*","extd":"Variable Star of delta Sct type"},{"cond":"RV*","extd":"Variable Star of RV Tau type"},
{"cond":"WV*","extd":"Variable Star of W Vir type"},{"cond":"bC*","extd":"Variable Star of beta Cep type"},
{"cond":"cC*","extd":"Classical Cepheid (delta Cep type)"},{"cond":"gD*","extd":"Variable Star of gamma Dor type"},
{"cond":"SX*","extd":"Variable Star of SX Phe type (subdwarf)"},{"cond":"LP*","extd":"Long-period variable star"},
{"cond":"Mi*","extd":"Variable Star of Mira Cet type"},{"cond":"SN*","extd":"SuperNova"},
{"cond":"su*","extd":"Sub-stellar object"},{"cond":"Pl?","extd":"Extra-solar Planet Candidate"},
{"cond":"Pl","extd":"Extra-solar Confirmed Planet"},{"cond":"","extd":""},
{"cond":"G","extd":"Galaxy"},{"cond":"PoG","extd":"Part of a Galaxy"},
{"cond":"GiC","extd":"Galaxy in Cluster of Galaxies"},{"cond":"BiC","extd":"Brightest galaxy in a Cluster (BCG)"},
{"cond":"GiG","extd":"Galaxy in Group of Galaxies"},{"cond":"GiP","extd":"Galaxy in Pair of Galaxies"},
{"cond":"rG","extd":"Radio Galaxy"},{"cond":"H2G","extd":"HII Galaxy"},
{"cond":"LSB","extd":"Low Surface Brightness Galaxy"},{"cond":"AG?","extd":"Possible Active Galaxy Nucleus"},
{"cond":"Q?","extd":"Possible Quasar"},{"cond":"Bz?","extd":"Possible Blazar"},
{"cond":"BL?","extd":"Possible BL Lac"},{"cond":"EmG","extd":"Emission-line galaxy"},
{"cond":"SBG","extd":"Starburst Galaxy"},{"cond":"bCG","extd":"Blue compact Galaxy"},
{"cond":"LeI","extd":"Gravitationally Lensed Image"},{"cond":"LeG","extd":"Gravitationally Lensed Image of a Galaxy"},
{"cond":"LeQ","extd":"Gravitationally Lensed Image of a Quasar"},{"cond":"AGN","extd":"Active Galaxy Nucleus"},
{"cond":"LIN","extd":"LINER-type Active Galaxy Nucleus"},{"cond":"SyG","extd":"Seyfert Galaxy"},
{"cond":"Sy1","extd":"Seyfert 1 Galaxy"},{"cond":"Sy2","extd":"Seyfert 2 Galaxy"},
{"cond":"Bla","extd":"Blazar"},{"cond":"BLL","extd":"BL Lac - type object"},
{"cond":"OVV","extd":"Optically Violently Variable object"},{"cond":"QSO","extd":"Quasar"}
];

// ============================================================================
// Constants and global parameters
// ============================================================================

#define TITLE   "What's In My Image"
#define VERSION "2.7.1"

var formatModesAlpha = [
    ['Decimal Degrees', 1],
    ['HHh MMm SSs', 2]
];

var formatModesDelta = [
    ['Decimal Degrees', 1],
    ['DDº MM\' SS"', 2]
];

var scriptParameters = {
    imageActiveWindow:    null,
    zoomFactor:           1,
    formatAlpha:          formatModesAlpha[1][1],
    formatDelta:          formatModesDelta[1][1],
    imageImage:           null,
    rectangle:            null,
    maxDownloads:         500,
    scrollPosition:       new Point(0, 0),
    rectangleCoordinates: null,
    centerPoint:          null,
    radius:               null,
    markers:              [],
    highlightedMarker:    null,
    selectedFont:         "DejaVu Sans",
    selectedFontSize:     10,
    selectedFontColor:    0xffffffff,
    selectedShapeColor:   0xffffff00,
    selectedMarkerShape:  "Circle",
    visibilityThresholdN: 1,
    saveCroppedViewOnly:  false,
    isStretched:          false,
    originalImageState:   null,
    selectedObjectTypes:  [],
    selectedObjectIDs:    [],
    circle:               null,
    shapes:               [],
    line:                 null,
    orientation:          null,

    newInstance: function() { console.writeln("New instance created."); },

    save: function()
    {
        Parameters.set("imageActiveWindow",  this.imageActiveWindow.mainView.id);
        Parameters.set("zoomFactor",         this.zoomFactor);
        Parameters.set("formatAlpha",        this.formatAlpha);
        Parameters.set("formatDelta",        this.formatDelta);
        Parameters.set("maxDownloads",       this.maxDownloads);
        Parameters.set("selectedFont",       this.selectedFont);
        Parameters.set("selectedFontSize",   this.selectedFontSize);
        Parameters.set("selectedFontColor",  this.selectedFontColor);
        Parameters.set("saveCroppedViewOnly",this.saveCroppedViewOnly);
        Parameters.set("isStretched",        this.isStretched);
        Parameters.set("selectedObjectTypes",this.selectedObjectTypes);
        Parameters.set("selectedObjectIDs",  this.selectedObjectIDs);
        if ( this.originalImageState )
            Parameters.set("originalImageState", this.originalImageState.toSource());
    },

    load: function()
    {
        console.writeln("Loading script parameters...");
        if ( Parameters.has("imageActiveWindow") )
        {
            let imageId = Parameters.getString("imageActiveWindow");
            this.imageActiveWindow = ImageWindow.windowById(imageId);
        }
        if ( Parameters.has("zoomFactor") )          this.zoomFactor          = Parameters.getReal("zoomFactor");
        if ( Parameters.has("formatAlpha") )         this.formatAlpha         = Parameters.getInteger("formatAlpha");
        if ( Parameters.has("formatDelta") )         this.formatDelta         = Parameters.getInteger("formatDelta");
        if ( Parameters.has("maxDownloads") )        this.maxDownloads        = Parameters.getInteger("maxDownloads");
        if ( Parameters.has("selectedFont") )        this.selectedFont        = Parameters.getString("selectedFont");
        if ( Parameters.has("selectedFontSize") )    this.selectedFontSize    = Parameters.getInteger("selectedFontSize");
        if ( Parameters.has("selectedFontColor") )   this.selectedFontColor   = parseInt(Parameters.getString("selectedFontColor"), 10);
        if ( Parameters.has("saveCroppedViewOnly") ) this.saveCroppedViewOnly = Parameters.getBoolean("saveCroppedViewOnly");
        if ( Parameters.has("isStretched") )         this.isStretched         = Parameters.getBoolean("isStretched");
        if ( Parameters.has("selectedObjectTypes") )
        {
            let t = Parameters.getString("selectedObjectTypes");
            this.selectedObjectTypes = t ? t.split(",") : [];
        }
        if ( Parameters.has("selectedObjectIDs") )
        {
            let s = Parameters.getString("selectedObjectIDs");
            this.selectedObjectIDs = s ? s.split(",").map(id => parseInt(id, 10)) : [];
        }
        if ( Parameters.has("originalImageState") )
            this.originalImageState = eval(Parameters.getString("originalImageState"));
        console.writeln("Finished loading script parameters.");
    }
};

// ============================================================================
// Utility functions
// ============================================================================

function findMarkerIndex( markers, point )
{
    if ( !Array.isArray(markers) ) return -1;
    return markers.findIndex(marker => marker.x === point.x && marker.y === point.y);
}

function getCelestial( x, y )
{
    return scriptParameters.imageActiveWindow.imageToCelestial(x, y);
}

function getCoordinates( ra, dec )
{
    return scriptParameters.imageActiveWindow.celestialToImage(ra, dec);
}

function degreesToHMS( degrees )
{
    let hDecimal = (degrees * 24) / 360;
    let h = Math.trunc(hDecimal);
    let mDecimal = (hDecimal - h) * 60;
    let m = Math.trunc(mDecimal);
    let s = (mDecimal - m) * 60;
    return [h, m, s];
}

function degreesToDMS( degrees )
{
    return Math.decimalToSexagesimal(degrees);
}

function arcsecondsToArcminutes( arcseconds )
{
    let totalSeconds = Math.round(arcseconds);
    return { minutes: Math.floor(totalSeconds / 60), seconds: totalSeconds % 60 };
}

function zeroPadding( number )
{
    return number < 10 ? "0" + number.toString() : number.toString();
}

function angularSeparation( ra1, dec1, ra2, dec2 )
{
    let a1 = ra1 * Math.PI / 180, a2 = ra2 * Math.PI / 180;
    let d1 = dec1 * Math.PI / 180, d2 = dec2 * Math.PI / 180;
    let z = Math.acos(Math.sin(d1)*Math.sin(d2) + Math.cos(d1)*Math.cos(d2)*Math.cos(a1-a2));
    return Math.abs(z) * 180 / Math.PI;
}

function getTypeLongName( typeCode )
{
    typeCode = typeCode.replace(/"/g, "").trim().toUpperCase();
    for ( let i = 0; i < typeLookupTable.length; i++ )
        if ( typeLookupTable[i].cond.trim().toUpperCase() === typeCode )
            return typeLookupTable[i].extd;
    return typeCode;
}

function loadAstrometricRotation()
{
    try
    {
        let window = ImageWindow.activeWindow;
        if ( !window ) { console.writeln("No active window found."); return null; }
        let metadata = new ImageMetadata(SETTINGS_MODULE);
        metadata.ExtractMetadata(window);
        let rotationData = metadata.GetRotation();
        return (rotationData && rotationData.length > 0) ? rotationData[0] : null;
    }
    catch (error) { console.writeln("Error loading astrometric rotation: " + error.message); return null; }
}

// ============================================================================
// Drawing helpers
// ============================================================================

function drawCircle( graphics, centerX, centerY, radius, pen )
{
    graphics.pen = pen;
    graphics.drawCircle(centerX, centerY, radius);
}

function drawText( graphics, startX, startY, text, pen, font )
{
    graphics.pen = pen;
    graphics.font = font;
    graphics.drawText(startX, startY, text);
}

function drawEllipse( graphics, startX, startY, endX, endY, pen )
{
    graphics.pen = pen;
    graphics.drawEllipse(startX, startY, endX, endY);
}

function drawRect( graphics, startX, startY, endX, endY, pen )
{
    graphics.pen = pen;
    graphics.drawRect(startX, startY, endX, endY);
}

function drawFreehand( graphics, points, pen )
{
    graphics.pen = pen;
    for ( let i = 0; i < points.length - 1; i++ )
        graphics.drawLine(points[i][0], points[i][1], points[i+1][0], points[i+1][1]);
}

function drawArrow( graphics, startX, startY, endX, endY, headLength, headAngle )
{
    headLength = headLength || 10;
    headAngle  = headAngle  || Math.PI / 6;
    graphics.drawLine(startX, startY, endX, endY);
    let angle = Math.atan2(endY - startY, endX - startX);
    graphics.drawLine(endX, endY,
        endX - headLength * Math.cos(angle - headAngle),
        endY - headLength * Math.sin(angle - headAngle));
    graphics.drawLine(endX, endY,
        endX - headLength * Math.cos(angle + headAngle),
        endY - headLength * Math.sin(angle + headAngle));
}

function drawLine( graphics, startX, startY, endX, endY, pen )
{
    graphics.pen = pen;
    graphics.drawLine(startX, startY, endX, endY);
}

function drawCompass( graphics, centerX, centerY, rotationAngle )
{
    let arrowLength = 50;
    let adjustedAngle = (rotationAngle - 90) * Math.PI / 180;
    let nX = Math.cos(adjustedAngle),  nY = Math.sin(adjustedAngle);
    let eX = Math.cos(adjustedAngle + Math.PI/2), eY = Math.sin(adjustedAngle + Math.PI/2);

    graphics.pen = new Pen(0xffff0000, 2);
    graphics.drawLine(centerX, centerY, centerX + nX*arrowLength, centerY + nY*arrowLength);
    graphics.drawText(centerX + nX*arrowLength, centerY + nY*arrowLength, "N");

    graphics.pen = new Pen(0xff0000ff, 2);
    graphics.drawLine(centerX, centerY, centerX + eX*-arrowLength, centerY + eY*-arrowLength);
    graphics.drawText(centerX + eX*-arrowLength, centerY + eY*-arrowLength, "E");
}

// ============================================================================
// Image processing helpers
// ============================================================================

function applyPixelMathStretch( view )
{
    let P = new PixelMath;
    P.expression =
        "C = -2.8  ;  //Shadow Clipping\n" +
        "B = 0.20  ;  //Background value\n" +
        "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
        "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
    P.expression1 = P.expression2 = P.expression3 = "";
    P.useSingleExpression = true; P.symbols = "C,B,c";
    P.clearImageCacheAndExit = false; P.cacheGeneratedImages = false;
    P.generateOutput = true; P.singleThreaded = false; P.optimization = true;
    P.use64BitWorkingImage = false; P.rescale = false;
    P.rescaleLower = 0; P.rescaleUpper = 1;
    P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
    P.createNewImage = false; P.showNewImage = true;
    P.newImageId = ""; P.newImageWidth = 0; P.newImageHeight = 0; P.newImageAlpha = false;
    P.newImageColorSpace   = PixelMath.SameAsTarget;
    P.newImageSampleFormat = PixelMath.SameAsTarget;
    P.executeOn(view, false);
}

function resetStretch( view )
{
    if ( scriptParameters.originalImageState )
    {
        view.beginProcess(UndoFlag.NoSwapFile);
        view.image.assign(scriptParameters.originalImageState);
        view.endProcess();
    }
}

function isMarkerVisible( marker, image, median, stdDev, n )
{
    let threshold = median + n * stdDev;
    let checkSize = 4;
    let xStart = Math.max(0, Math.floor(marker.x) - 2);
    let yStart = Math.max(0, Math.floor(marker.y) - 2);
    let xEnd   = Math.min(image.width  - 1, xStart + checkSize);
    let yEnd   = Math.min(image.height - 1, yStart + checkSize);
    let sum = 0, count = 0;
    for ( let y = yStart; y <= yEnd; y++ )
        for ( let x = xStart; x <= xEnd; x++ )
        {
            let pv;
            if ( image.isColor )
                pv = (image.sample(x,y,0) + image.sample(x,y,1) + image.sample(x,y,2)) / 3;
            else
                pv = image.sample(x, y);
            sum += pv; count++;
        }
    return (sum / count) > threshold;
}

// ============================================================================
// WIMIColorComboBox
// ============================================================================

var WIMIColorComboBox = class extends ComboBox
{
    constructor( parent, initialColor )
    {
        super( parent );
        this.addItem("Red"); this.addItem("Green"); this.addItem("Blue");
        this.addItem("Yellow"); this.addItem("White"); this.addItem("Black");
        this.toolTip = "Select the font color for annotations.";
        this.currentItem = WIMIColorComboBox.colorIndex(initialColor);
    }

    static colorIndex( color )
    {
        switch ( color )
        {
        case 0xffff0000: return 0;
        case 0xff00ff00: return 1;
        case 0xff0000ff: return 2;
        case 0xffffff00: return 3;
        case 0xffffffff: return 4;
        case 0xff000000: return 5;
        default:         return 4;
        }
    }

    getColorValue()
    {
        switch ( this.itemText(this.currentItem) )
        {
        case "Red":    return 0xffff0000;
        case "Green":  return 0xff00ff00;
        case "Blue":   return 0xff0000ff;
        case "Yellow": return 0xffffff00;
        case "White":  return 0xffffffff;
        case "Black":  return 0xff000000;
        default:       return 0xffffffff;
        }
    }
};

// ============================================================================
// MaxDownloadsDialog
// ============================================================================

var MaxDownloadsDialog = class extends Dialog
{
    constructor( initialValue, initialFont, initialFontSize, initialFontColor,
                 scrollControl, miniPreviewControl, initialVisibilityThresholdN )
    {
        super();

        this.windowTitle      = "Max Downloads Options";
        this.scrollControl    = scrollControl;
        this.miniPreviewControl = miniPreviewControl;

        this.maxDownloadsLabel = new Label(this);
        this.maxDownloadsLabel.text = "Max Downloads: (not to exceed 25,000)";
        this.maxDownloadsLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.maxDownloadsSpinBox = new SpinBox(this);
        this.maxDownloadsSpinBox.minValue = 1; this.maxDownloadsSpinBox.maxValue = 25000;
        this.maxDownloadsSpinBox.value = initialValue;

        this.fontLabel = new Label(this);
        this.fontLabel.text = "Font:";
        this.fontLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.fontComboBox = new ComboBox(this);
        ["Arial","Courier New","Times New Roman","Verdana","DejaVu Sans"].forEach(f => this.fontComboBox.addItem(f));
        this.fontComboBox.currentItem = this.fontComboBox.findItem(initialFont);

        this.fontSizeLabel = new Label(this);
        this.fontSizeLabel.text = "Font Size:";
        this.fontSizeLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.fontSizeComboBox = new ComboBox(this);
        for ( let size = 8; size <= 36; size += 2 ) this.fontSizeComboBox.addItem(size.toString());
        this.fontSizeComboBox.currentItem = this.fontSizeComboBox.findItem(initialFontSize.toString());

        this.fontColorLabel = new Label(this);
        this.fontColorLabel.text = "Font Color:";
        this.fontColorLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.fontColorComboBox = new WIMIColorComboBox(this, initialFontColor);

        this.visibilityThresholdLabel = new Label(this);
        this.visibilityThresholdLabel.text = "Visibility Threshold (n):";
        this.visibilityThresholdLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.visibilityThresholdSlider = new HorizontalSlider(this);
        this.visibilityThresholdSlider.minValue = 0; this.visibilityThresholdSlider.maxValue = 50;
        this.visibilityThresholdSlider.pageSize = 5;
        this.visibilityThresholdSlider.value = Math.round(initialVisibilityThresholdN * 10);
        this.visibilityThresholdSlider.onValueUpdated = value =>
        {
            this.visibilityThresholdValueLabel.text = (value / 10).toFixed(1);
        };

        this.visibilityThresholdValueLabel = new Label(this);
        this.visibilityThresholdValueLabel.text = (this.visibilityThresholdSlider.value / 10).toFixed(1);
        this.visibilityThresholdValueLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.okButton = new PushButton(this);
        this.okButton.text = "OK";
        this.okButton.onClick = () =>
        {
            this.visibilityThresholdN = this.visibilityThresholdSlider.value / 10.0;
            scriptParameters.selectedFontColor = this.fontColorComboBox.getColorValue();
            if ( this.scrollControl )      this.scrollControl.viewport.update();
            if ( this.miniPreviewControl ) this.miniPreviewControl.viewport.update();
            this.ok();
        };

        this.cancelButton = new PushButton(this);
        this.cancelButton.text = "Cancel";
        this.cancelButton.onClick = () => { this.cancel(); };

        let visSizer = new HorizontalSizer; visSizer.spacing = 6;
        visSizer.add(this.visibilityThresholdLabel);
        visSizer.add(this.visibilityThresholdSlider);
        visSizer.add(this.visibilityThresholdValueLabel);

        this.sizer = new VerticalSizer; this.sizer.margin = 6; this.sizer.spacing = 4;
        this.sizer.add(this.maxDownloadsLabel); this.sizer.add(this.maxDownloadsSpinBox);
        this.sizer.addSpacing(10);
        this.sizer.add(this.fontLabel); this.sizer.add(this.fontComboBox);
        this.sizer.addSpacing(10);
        this.sizer.add(this.fontSizeLabel); this.sizer.add(this.fontSizeComboBox);
        this.sizer.addSpacing(10);
        this.sizer.add(this.fontColorLabel); this.sizer.add(this.fontColorComboBox);
        this.sizer.add(visSizer);
        this.sizer.addSpacing(10);
        this.sizer.add(this.okButton); this.sizer.addSpacing(4); this.sizer.add(this.cancelButton);
        this.adjustToContents();
    }

    get maxDownloads()    { return this.maxDownloadsSpinBox.value; }
    get selectedFont()    { return this.fontComboBox.itemText(this.fontComboBox.currentItem); }
    get selectedFontSize(){ return parseInt(this.fontSizeComboBox.itemText(this.fontSizeComboBox.currentItem), 10); }
    get selectedFontColor(){ return this.fontColorComboBox.getColorValue(); }
};

// ============================================================================
// Simbad / MAST / VizieR query functions
// ============================================================================

function adqlQuerySimbad( server, ra, dec, radius, outputmax )
{
    let query = "simbad/sim-tap/sync?request=doQuery&lang=adql&format=text&query=SELECT TOP " +
        outputmax.toString() + " MAIN_ID,RA,DEC,galdim_majaxis,otype FROM BASIC" +
        " WHERE CONTAINS(POINT('ICRS',ra, dec)," +
        " CIRCLE('ICRS'," + ra.toFixed(8) + "," + dec.toFixed(8) + "," + radius.toFixed(3) + ")) = 1" +
        " AND ra IS NOT NULL AND dec IS NOT NULL";

    let filename = File.systemTempDirectory + '/adql.txt';
    if ( File.exists(filename) ) File.remove(filename);

    let url = server + query;
    console.writeln('Download ' + url);
    let downloader = new FileDownload(url, filename);
    if ( downloader.perform() && File.exists(filename) )
    {
        let objects = [], datapart = false;
        let lines = File.readLines(filename);
        for ( let i = 0; i < lines.length; i++ )
        {
            let line = lines[i];
            let items = line.split('|');
            if ( items.length != 5 ) continue;
            if ( !datapart ) { datapart = line.startsWith('--------'); continue; }
            let name     = items[0].trim().unquote();
            let raValue  = parseFloat(items[1].trim());
            let decValue = parseFloat(items[2].trim());
            let diameter = parseFloat(items[3].trim() || 0);
            let type     = items[4].trim();
            if ( !isNaN(raValue) && !isNaN(decValue) )
                objects.push({ ra: raValue, dec: decValue, name: name, diameter: diameter, type: type, isSimbad: true });
        }
        File.remove(filename);
        console.writeln('Download completed: ' + objects.length + ' objects found');
        return objects;
    }
    return null;
}

function adqlQueryMast( server, ra, dec, radius, outputmax )
{
    let query = {
        service: "Mast.Caom.Cone",
        params: { ra: ra, dec: dec, radius: radius },
        format: "csv", pagesize: outputmax, page: 1
    };
    let url = server + "request=" + encodeURIComponent(JSON.stringify(query));
    let filename = File.systemTempDirectory + '/mast_adql.csv';
    console.writeln("Download " + url);
    let downloader = new FileDownload(url, filename);
    if ( downloader.perform() && File.exists(filename) )
    {
        let objects = [], lines = File.readLines(filename);
        for ( let i = 4; i < lines.length; i++ )
        {
            let items = lines[i].split(',');
            if ( items.length < 20 ) continue;
            let raValue  = parseFloat(items[10].trim());
            let decValue = parseFloat(items[11].trim());
            if ( !isNaN(raValue) && !isNaN(decValue) )
                objects.push({
                    s_ra: raValue, s_dec: decValue,
                    target_name: items[7].trim(),
                    t_obs_release_date: items[20].trim(),
                    instrument_name: items[1].trim(),
                    obs_collection: items[3].trim(),
                    jpegURL: items[26].trim()
                });
        }
        File.remove(filename);
        console.writeln("Download completed: " + objects.length + " objects found");
        return objects;
    }
    return null;
}

function adqlQueryVizier( server, ra, dec, radius, outputmax, catalogs )
{
    let catalogQuery = catalogs.map(c => "-source=" + c).join("&");
    let query = catalogQuery + "&-c=" + ra.toFixed(6) + "+" + dec.toFixed(6) +
        "&-c.rs=" + (radius * 60).toFixed(3) + "&-out.max=" + outputmax;
    let filename = File.systemTempDirectory + '/vizier.txt';
    if ( File.exists(filename) ) File.remove(filename);
    let downloader = new FileDownload(server + query, filename);
    if ( downloader.perform() && File.exists(filename) )
    {
        let objects = [], lines = File.readLines(filename), catalogTitle = '';
        for ( let i = 0; i < lines.length; i++ )
        {
            if ( lines[i].startsWith("#Title:") ) catalogTitle = lines[i].substring(8).trim();
            if ( lines[i].startsWith("RAJ2000") || lines[i].startsWith("RA_ICRS") ||
                 lines[i].startsWith("UCAC4")   || lines[i].startsWith("objID") )
                parseDataBlock(lines, i, objects, catalogTitle);
        }
        File.remove(filename);
        return objects;
    }
    return null;
}

function parseDataBlock( lines, headerLineIndex, objects, catalogTitle )
{
    let raIndex = -1, decIndex = -1, nameIndex = -1;
    let header = lines[headerLineIndex].split('\t');
    for ( let i = 0; i < header.length; i++ )
    {
        let token = header[i].toLowerCase();
        if ( token == "raj2000" || token == "ra_icrs" )        raIndex   = i;
        else if ( token == "dej2000" || token == "de_icrs" )   decIndex  = i;
        else if ( token == "source" || token == "2mass" ||
                  token == "ucac4"  || token == "objid" )      nameIndex = i;
    }
    if ( raIndex < 0 || decIndex < 0 || nameIndex < 0 )
        throw new Error("Missing required columns in VizieR catalog file");
    for ( let j = headerLineIndex + 3; j < lines.length; j++ )
    {
        if ( lines[j].startsWith("#") ) continue;
        if ( lines[j].trim() === "" ) break;
        let tokens = lines[j].split('\t');
        let obj = {
            name: tokens[nameIndex].trim(),
            ra: parseFloat(tokens[raIndex]),
            dec: parseFloat(tokens[decIndex]),
            type: catalogTitle,
            diameter: 0.0
        };
        if ( !isNaN(obj.ra) && !isNaN(obj.dec) ) objects.push(obj);
    }
}

// ============================================================================
// Shared query helpers (used by both button handlers and advanced search panel)
// ============================================================================

function performSimbadQuery( parent, centerX, centerY, radius, maxDownloads, isDeepSearch )
{
    isDeepSearch = isDeepSearch || false;
    console.writeln("Query Simbad for RA: " + centerX + ", Dec: " + centerY + ", Radius: " + radius);

    let simbadObjects = null, attempts = 0;
    while ( attempts < 3 && simbadObjects === null )
    {
        try { simbadObjects = adqlQuerySimbad("http://simbad.u-strasbg.fr/", centerX, centerY, radius, maxDownloads); }
        catch (e) { console.warningln("Attempt " + (attempts+1) + " failed: " + e.message); attempts++; }
    }
    if ( simbadObjects === null ) { console.warningln("Connection to Simbad not established."); return; }

    let selectedObjectTypes = (scriptParameters.selectedObjectTypes || []).map(t => t.replace(/"/g,"").trim().toUpperCase());
    if ( !isDeepSearch && selectedObjectTypes.length > 0 )
        simbadObjects = simbadObjects.filter(obj => selectedObjectTypes.indexOf(obj.type.replace(/"/g,"").trim().toUpperCase()) !== -1);

    populateResultTreeBox(parent, simbadObjects, 'Simbad');
}

function performVizierQuery( parent, centerX, centerY, radius, maxDownloads )
{
    let radiusArcmin = 60 * radius;
    let catalogs = ["II/246","I/350/gaiaedr3","V/147/sdss12","I/322A","V/154"];
    let vizierObjects = adqlQueryVizier("http://vizier.u-strasbg.fr/viz-bin/asu-tsv?",
        centerX, centerY, radiusArcmin, maxDownloads, catalogs);
    if ( !vizierObjects ) { console.writeln("No objects found."); return; }

    // Deduplicate
    let seen = new Set(), unique = [];
    for ( let obj of vizierObjects )
    {
        let key = obj.ra.toFixed(4) + ',' + obj.dec.toFixed(4);
        if ( !seen.has(key) ) { seen.add(key); unique.push(obj); }
    }
    populateResultTreeBox(parent, unique, 'Vizier');
}

function populateResultTreeBox( parent, objects, source )
{
    parent.resultTreeBox.clear();
    scriptParameters.markers = [];
    if ( !objects || objects.length === 0 )
    {
        console.writeln("No objects found after filtering.");
        parent.ScrollControl.viewport.update();
        parent.MiniPreviewControl.viewport.update();
        return;
    }
    objects.forEach((obj, index) =>
    {
        let node = new TreeBoxNode(parent.resultTreeBox);
        let ra   = source === 'MAST' ? (obj.s_ra  || 0) : (obj.ra  || 0);
        let dec  = source === 'MAST' ? (obj.s_dec || 0) : (obj.dec || 0);
        let name = source === 'MAST' ? (obj.target_name || "N/A") : (obj.name || "N/A");
        node.setText(0, ra.toFixed(6));
        node.setText(1, dec.toFixed(6));
        node.setText(2, name);
        node.setText(3, source === 'MAST' ? "N/A" : (obj.diameter || 0).toFixed(3));
        node.setText(4, source === 'MAST' ? (obj.instrument_name || "N/A") : (obj.type || "N/A"));
        node.setText(5, source === 'MAST' ? (obj.jpegURL || "N/A") : getTypeLongName(obj.type || ""));
        node.setText(6, (index + 1).toString());
        node.setText(7, source);

        let point = getCoordinates(parseFloat(ra.toFixed(6)), parseFloat(dec.toFixed(6)));
        if ( point )
        {
            point.index   = index;
            point.name    = name;
            point.ra      = parseFloat(ra.toFixed(6));
            point.dec     = parseFloat(dec.toFixed(6));
            point.isSimbad = (source === 'Simbad');
            point.isVizier = (source === 'Vizier');
            scriptParameters.markers.push(point);
        }
    });
    parent.ScrollControl.viewport.update();
    parent.MiniPreviewControl.viewport.update();
}

// ============================================================================
// Advanced search panel factory
// ============================================================================

function createAdvancedSearchPanel( parent )
{
    let panel = new Control(parent);
    panel.sizer = new VerticalSizer; panel.sizer.spacing = 4;
    panel.hide();

    let treeBox = new TreeBox(panel);
    treeBox.numberOfColumns = 2; treeBox.headerVisible = true; treeBox.headerSorting = true;
    treeBox.setHeaderText(0, "Object Type"); treeBox.setHeaderText(1, "Description");
    treeBox.setMinSize(300, 600); treeBox.setScaledMinSize(300, 600);
    treeBox.multipleSelection = true; treeBox.alternateRowColor = true;
    treeBox.setScaledMinHeight(600);

    for ( let i = 0; i < typeLookupTable.length; i++ )
    {
        let type = typeLookupTable[i];
        if ( type.cond !== "" )
        {
            let node = new TreeBoxNode(treeBox);
            node.setText(0, type.cond); node.setText(1, type.extd);
            node.checked = false; node.objectType = type.cond; node.numericID = i;
            if ( scriptParameters.selectedObjectIDs )
                for ( let j = 0; j < scriptParameters.selectedObjectIDs.length; j++ )
                    if ( parseInt(scriptParameters.selectedObjectIDs[j], 10) === node.numericID )
                    { node.checked = true; break; }
        }
    }
    panel.sizer.add(treeBox);

    // Toggle buttons
    let toggleSizer = new HorizontalSizer; toggleSizer.spacing = 6;

    let btnToggleAll = new PushButton(panel); btnToggleAll.text = "Toggle All";
    btnToggleAll.onClick = () =>
    {
        let allChecked = true;
        for ( let i = 0; i < treeBox.numberOfChildren; i++ )
            if ( !treeBox.child(i).checked ) { allChecked = false; break; }
        for ( let i = 0; i < treeBox.numberOfChildren; i++ )
            treeBox.child(i).checked = !allChecked;
    };
    toggleSizer.add(btnToggleAll);

    let btnToggleStars = new PushButton(panel); btnToggleStars.text = "Toggle Stars";
    btnToggleStars.onClick = () =>
    {
        for ( let i = 0; i < treeBox.numberOfChildren; i++ )
        {
            let node = treeBox.child(i);
            let objectType = node.text(0);
            for ( let j = 0; j < typeLookupTable.length; j++ )
            {
                if ( typeLookupTable[j].cond === objectType )
                {
                    let extd = typeLookupTable[j].extd.toLowerCase();
                    if ( extd.indexOf("star") !== -1 ||
                         ["eclipsing binary of w uma type","spectroscopic binary","variable of rs cvn type",
                          "mira candidate","long period variable candidate","hot subdwarf","hot subdwarf candidate",
                          "eclipsing binary candidate","eclipsing binary","cv dq her type (intermediate polar)",
                          "cataclysmic binary candidate","possible cepheid","variable of by dra type",
                          "possible bl lac","eclipsing binary of beta lyr type","cv of am her type (polar)",
                          "white dwarf","white dwarf candidate","eclipsing binary of algol type"].indexOf(typeLookupTable[j].extd) !== -1 )
                        node.checked = !node.checked;
                    break;
                }
            }
        }
    };
    toggleSizer.add(btnToggleStars);

    let btnToggleGalaxies = new PushButton(panel); btnToggleGalaxies.text = "Toggle Galaxies";
    btnToggleGalaxies.onClick = () =>
    {
        for ( let i = 0; i < treeBox.numberOfChildren; i++ )
        {
            let node = treeBox.child(i);
            for ( let j = 0; j < typeLookupTable.length; j++ )
            {
                if ( typeLookupTable[j].cond === node.text(0) )
                {
                    let extd = typeLookupTable[j].extd.toLowerCase();
                    if ( extd.indexOf("galaxy") !== -1 || extd.indexOf("galaxies") !== -1 )
                        node.checked = !node.checked;
                    break;
                }
            }
        }
    };
    toggleSizer.add(btnToggleGalaxies);
    panel.sizer.add(toggleSizer);

    // Confirm / Clear
    let buttonSizer = new HorizontalSizer; buttonSizer.spacing = 6;

    let confirmButton = new PushButton(panel); confirmButton.text = "Confirm Selections";
    confirmButton.icon = ":/icons/ok.png";
    confirmButton.onClick = () =>
    {
        scriptParameters.selectedObjectTypes = [];
        scriptParameters.selectedObjectIDs   = [];
        for ( let i = 0; i < treeBox.numberOfChildren; i++ )
        {
            let node = treeBox.child(i);
            if ( node.checked )
            {
                scriptParameters.selectedObjectTypes.push(node.objectType);
                scriptParameters.selectedObjectIDs.push(node.numericID);
            }
        }
        parent.applyAdvancedSearchSelection(treeBox);
    };
    buttonSizer.add(confirmButton);

    let clearButton = new PushButton(panel); clearButton.text = "Clear Selections";
    clearButton.icon = ":/icons/cancel.png";
    clearButton.onClick = () =>
    {
        for ( let i = 0; i < treeBox.numberOfChildren; i++ ) treeBox.child(i).checked = false;
        scriptParameters.selectedObjectTypes = [];
        scriptParameters.selectedObjectIDs   = [];
        console.writeln("Selections cleared.");
    };
    buttonSizer.add(clearButton);
    panel.sizer.add(buttonSizer);

    // Query buttons
    let queryButtonSizer = new HorizontalSizer; queryButtonSizer.spacing = 6;

    let queryDefinedButton = new PushButton(panel); queryDefinedButton.text = "Query Simbad Defined Region";
    queryDefinedButton.icon = ":/icons/execute.png";
    queryDefinedButton.onClick = () =>
    {
        performSimbadQuery(parent, scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec,
            scriptParameters.radius, scriptParameters.maxDownloads);
    };
    queryButtonSizer.add(queryDefinedButton);

    let queryEntireButton = new PushButton(panel); queryEntireButton.text = "Query Simbad Entire Image";
    queryEntireButton.icon = ":/icons/search.png";
    queryEntireButton.onClick = () =>
    {
        let activeWindow = ImageWindow.activeWindow;
        if ( !activeWindow || !activeWindow.mainView ) { console.writeln("No active image window found."); return; }
        let w = activeWindow.mainView.image.width, h = activeWindow.mainView.image.height;
        let tl = getCelestial(0,0), tr = getCelestial(w,0);
        let bl = getCelestial(0,h), br = getCelestial(w,h);
        if ( !tl || !tr || !bl || !br ) { console.writeln("Could not calculate corner coordinates."); return; }
        let cRA  = (tl.x + tr.x + bl.x + br.x) / 4;
        let cDec = (tl.y + tr.y + bl.y + br.y) / 4;
        let r = Math.max(
            angularSeparation(cRA,cDec,tl.x,tl.y), angularSeparation(cRA,cDec,tr.x,tr.y),
            angularSeparation(cRA,cDec,bl.x,bl.y), angularSeparation(cRA,cDec,br.x,br.y));
        performSimbadQuery(parent, cRA, cDec, r, 25000);
    };
    queryButtonSizer.add(queryEntireButton);
    panel.sizer.add(queryButtonSizer);

    // MAST button
    let mastSizer = new HorizontalSizer; mastSizer.spacing = 6;
    let mastButton = new PushButton(panel);
    mastButton.text = " Query MAST (Swift, Hubble, JWST, Spitzer, etc) ";
    mastButton.icon = ":/icons/search.png";
    mastButton.toolTip = "Searches MAST database for various missions.";
    mastButton.onClick = () =>
    {
        if ( !scriptParameters.centerPoint || !scriptParameters.radius )
        { console.writeln("Please select a region first."); return; }
        parent.queryMastWithRetry();
    };
    mastSizer.add(mastButton); panel.sizer.add(mastSizer);

    // VizieR deep search
    let deepSizer = new HorizontalSizer; deepSizer.spacing = 6;
    let deepButton = new PushButton(panel);
    deepButton.text = "CAUTION - Deep Search Query - Vizier";
    deepButton.icon = ":/icons/burn.png";
    deepButton.toolTip = "Searches GAIA, 2MASS, SDSS, UCAC4.... Use with CAUTION";
    deepButton.onClick = () =>
    {
        if ( !scriptParameters.centerPoint || !scriptParameters.radius )
        { console.writeln("Please select a region first."); return; }
        performVizierQuery(parent, scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec,
            scriptParameters.radius, scriptParameters.maxDownloads);
    };
    deepSizer.add(deepButton); panel.sizer.add(deepSizer);

    // NED
    let nedSizer = new HorizontalSizer; nedSizer.spacing = 6;
    let nedLabel = new Label(panel); nedLabel.text = "External Search:";
    nedSizer.add(nedLabel);
    let nedButton = new PushButton(panel); nedButton.text = "Search N.E.D."; nedButton.icon = ":/icons/search.png";
    nedButton.onClick = () => { parent.queryNED(); };
    nedSizer.add(nedButton); panel.sizer.add(nedSizer);

    // Store treeBox reference for populateAdvancedSearchSelections
    panel.treeBox = treeBox;
    return panel;
}

// ============================================================================
// mainDialog
// ============================================================================

var mainDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.orientation = loadAstrometricRotation();
        scriptParameters.orientation = this.orientation;

        this.userResizable  = true;
        this.scaledMinWidth = 800;
        this.scaledMinHeight = 600;
        this.windowTitle    = TITLE + " Script";

        this.adjustDialogSize = () =>
        {
            let widthAdjustment = this.advancedSearchPanel.visible ? 300 : -300;
            this.scaledMinWidth += widthAdjustment;
            this.adjustToContents();
        };

        // ---- Title label ----
        this.titleLabel = new Label(this);
        this.titleLabel.frameStyle   = FrameStyle.Box;
        this.titleLabel.margin       = 10;
        this.titleLabel.wordWrapping = true;
        this.titleLabel.useRichText  = true;
        this.titleLabel.text =
            "<p><b>" + TITLE + " " + VERSION + "</b> &mdash; " +
            "Shift + Click and Drag to define a reference point and radius to perform a Simbad Lookup. " +
            "Mouse wheel to zoom out or in.<br>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
            "Ctrl + Click and Drag to determine the distance between 2 points.</p>";

        // ---- Main scroll control ----
        this.ScrollControl = new ScrollBox;
        this.ScrollControl.bmp        = scriptParameters.imageImage;
        this.ScrollControl.autoScroll = true;
        this.ScrollControl.tracking   = true;
        this.ScrollControl.setVariableWidth();
        this.ScrollControl.setMinSize(700, 500);

        // ---- Mini preview ----
        this.MiniPreviewControl = new ScrollBox;
        this.MiniPreviewControl.autoScroll = false;
        this.MiniPreviewControl.tracking   = false;

        this.createTemporaryImage = (activeWindow, previewControl) =>
        {
            let selectedImage = activeWindow.mainView.image;
            let window = new ImageWindow(selectedImage.width, selectedImage.height, selectedImage.numberOfChannels);
            window.mainView.beginProcess();
            window.mainView.image.assign(selectedImage);
            window.mainView.endProcess();

            let P = new IntegerResample;
            const previewWidth = previewControl.viewport.width;
            const widthScale   = Math.floor(selectedImage.width / previewWidth);
            P.zoomFactor = -Math.max(widthScale, 1);
            P.executeOn(window.mainView);

            let PM = new PixelMath;
            PM.expression = "mtf(mtf(0.2, med($T) - min(max(0, med($T) + -2.8 * 1.4826 * mdev($T)), 1)), max(0, ($T - min(max(0, med($T) + -2.8 * 1.4826 * mdev($T)), 1)) / ~(min(max(0, med($T) + -2.8 * 1.4826 * mdev($T)), 1))))";
            PM.useSingleExpression = true;
            PM.executeOn(window.mainView);

            let resizedImage = new Image(window.mainView.image);
            if ( resizedImage.width > 0 && resizedImage.height > 0 )
            {
                previewControl.displayImage = resizedImage.render();
                previewControl.viewport.update();
                this.updateMiniPreviewControlSize(resizedImage.width, resizedImage.height);
            }
            window.forceClose();
            return resizedImage;
        };

        this.updateMiniPreviewControlSize = (imageWidth, imageHeight) =>
        {
            const fixedWidth  = 400;
            const fixedHeight = Math.floor(fixedWidth * imageHeight / imageWidth);
            this.MiniPreviewControl.setFixedSize(fixedWidth, fixedHeight);
            this.adjustToContents();
        };

        this.updateMiniPreview = () =>
        {
            let activeWindow = ImageWindow.activeWindow;
            if ( activeWindow && activeWindow.mainView )
                this.createTemporaryImage(activeWindow, this.MiniPreviewControl);
        };

        this.MiniPreviewControl.setImage = function(image)
        {
            this.displayImage = image;
            this.viewport.update();
        };

        this.updateMiniPreview();

        // Mini preview mouse handlers
        this.MiniPreviewControl.dragging  = false;
        this.MiniPreviewControl.dragOrigin = new Point(0, 0);

        this.MiniPreviewControl.viewport.onMousePress = (x, y, button, buttons, modifiers) =>
        {
            let clickX = x * this.ScrollControl.bmp.width  / this.MiniPreviewControl.viewport.width;
            let clickY = y * this.ScrollControl.bmp.height / this.MiniPreviewControl.viewport.height;
            let scrollToX = Math.max(0, Math.min(clickX - (this.ScrollControl.viewport.width  / 2), (this.ScrollControl.bmp.width  / scriptParameters.zoomFactor)));
            let scrollToY = Math.max(0, Math.min(clickY - (this.ScrollControl.viewport.height / 2), (this.ScrollControl.bmp.height / scriptParameters.zoomFactor)));
            this.ScrollControl.scrollPosition = new Point(scrollToX / scriptParameters.zoomFactor, scrollToY / scriptParameters.zoomFactor);
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
            this.MiniPreviewControl.dragOrigin = new Point(x, y);
            this.MiniPreviewControl.dragging   = true;
        };

        this.MiniPreviewControl.viewport.onMouseMove = (x, y, buttons, modifiers) =>
        {
            if ( this.MiniPreviewControl.dragging )
            {
                let dx = (x - this.MiniPreviewControl.dragOrigin.x) / scriptParameters.zoomFactor;
                let dy = (y - this.MiniPreviewControl.dragOrigin.y) / scriptParameters.zoomFactor;
                let scaleX = this.ScrollControl.bmp.width  / this.MiniPreviewControl.viewport.width;
                let scaleY = this.ScrollControl.bmp.height / this.MiniPreviewControl.viewport.height;
                let scrollToX = Math.max(0, Math.min(this.ScrollControl.scrollPosition.x + dx * scaleX, this.ScrollControl.bmp.width  / scriptParameters.zoomFactor));
                let scrollToY = Math.max(0, Math.min(this.ScrollControl.scrollPosition.y + dy * scaleY, this.ScrollControl.bmp.height / scriptParameters.zoomFactor));
                this.ScrollControl.scrollPosition = new Point(scrollToX, scrollToY);
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
                this.MiniPreviewControl.dragOrigin = new Point(x, y);
            }
        };

        this.MiniPreviewControl.viewport.onMouseRelease = () => { this.MiniPreviewControl.dragging = false; };

        this.MiniPreviewControl.viewport.onMouseWheel = (x, y, delta, buttons, modifiers) =>
        {
            let oldZ = scriptParameters.zoomFactor;
            let maxH = (this.ScrollControl.bmp.width  / oldZ) - this.ScrollControl.viewport.width;
            let maxV = (this.ScrollControl.bmp.height / oldZ) - this.ScrollControl.viewport.height;
            let pctX = this.ScrollControl.scrollPosition.x / maxH;
            let pctY = this.ScrollControl.scrollPosition.y / maxV;
            if ( delta > 0 ) scriptParameters.zoomFactor = Math.min(scriptParameters.zoomFactor * 1.25, this.maxZoomFactor);
            else             scriptParameters.zoomFactor = Math.max(scriptParameters.zoomFactor * 0.8,  this.minZoomFactor);
            let newZ = scriptParameters.zoomFactor;
            this.ScrollControl.initScrollBars();
            maxH = (this.ScrollControl.bmp.width  / newZ) - this.ScrollControl.viewport.width;
            maxV = (this.ScrollControl.bmp.height / newZ) - this.ScrollControl.viewport.height;
            this.ScrollControl.scrollPosition = new Point(
                Math.max(0, Math.min(pctX * maxH, maxH)),
                Math.max(0, Math.min(pctY * maxV, maxV)));
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        this.MiniPreviewControl.viewport.onPaint = () =>
        {
            let g = new Graphics(this.MiniPreviewControl.viewport);
            let result = this.MiniPreviewControl.displayImage;
            if ( result == null )
            {
                g.fillRect(0, 0, this.MiniPreviewControl.viewport.width, this.MiniPreviewControl.viewport.height, new Brush(0xff000000));
            }
            else
            {
                result.selectedRect = new Rect(0, 0, this.MiniPreviewControl.viewport.width, this.MiniPreviewControl.viewport.height).translated(this.MiniPreviewControl.scrollPosition);
                g.drawBitmap(0, 0, result);

                let scaleX = this.MiniPreviewControl.viewport.width  / (this.ScrollControl.bmp.width  / scriptParameters.zoomFactor);
                let scaleY = this.MiniPreviewControl.viewport.height / (this.ScrollControl.bmp.height / scriptParameters.zoomFactor);
                let rectX  = this.ScrollControl.scrollPosition.x * scaleX;
                let rectY  = this.ScrollControl.scrollPosition.y * scaleY;
                let rectW  = (this.ScrollControl.viewport.width  * scaleX / scriptParameters.zoomFactor) / scriptParameters.zoomFactor;
                let rectH  = (this.ScrollControl.viewport.height * scaleY / scriptParameters.zoomFactor) / scriptParameters.zoomFactor;
                g.pen = new Pen(0xff00ff00, 1);
                g.drawRect(rectX, rectY, rectX + rectW, rectY + rectH);

                if ( scriptParameters.circle )
                {
                    g.pen = new Pen(0xff00ff00);
                    g.drawCircle(scriptParameters.circle.center[0] * scaleX / scriptParameters.zoomFactor,
                                 scriptParameters.circle.center[1] * scaleY / scriptParameters.zoomFactor,
                                 scriptParameters.circle.radius    * scaleX / scriptParameters.zoomFactor);
                }

                // Draw markers
                for ( let marker of scriptParameters.markers )
                {
                    let mx = marker.x * scaleX / scriptParameters.zoomFactor;
                    let my = marker.y * scaleY / scriptParameters.zoomFactor;
                    let highlighted = scriptParameters.highlightedMarker &&
                        marker.x === scriptParameters.highlightedMarker.x &&
                        marker.y === scriptParameters.highlightedMarker.y;
                    g.pen = highlighted ? new Pen(0xff00ff00, 2) : new Pen(0xffff0000, 2);
                    if ( scriptParameters.selectedMarkerShape === "Circle" )
                        g.drawCircle(mx, my, 2);
                    else
                    {
                        let cs = 6;
                        g.drawLine(mx-cs, my, mx+cs, my);
                        g.drawLine(mx, my-cs, mx, my+cs);
                    }
                }
            }
            g.end();
        };

        // ---- ScrollControl init ----
        this.initialUpdateCompleted = false;
        this.miniPreviewInitialized = false;
        this.ScrollControl.dragOrigin = new Point(0, 0);
        this.zoomFactor    = 1;
        this.minZoomFactor = 0.1;
        this.maxZoomFactor = 10;
        this.activeShapeIndex   = -1;
        this.currentDrawingMode = '';

        this.ScrollControl.viewport.onResize = () =>
        {
            this.ScrollControl.initScrollBars(this.ScrollControl.scrollPosition);
            if ( !this.miniPreviewInitialized )
            {
                this.updateMiniPreview();
                this.miniPreviewInitialized = true;
            }
        };

        this.ScrollControl.initScrollBars = (scrollPoint) =>
        {
            let maxH = Math.max(0, this.ScrollControl.bmp.width  / scriptParameters.zoomFactor);
            let maxV = Math.max(0, this.ScrollControl.bmp.height / scriptParameters.zoomFactor);
            this.ScrollControl.setHorizontalScrollRange(0, maxH);
            this.ScrollControl.setVerticalScrollRange(0, maxV);
            if ( scrollPoint )
                this.ScrollControl.scrollPosition = scrollPoint;
            else
                this.ScrollControl.scrollPosition = new Point(
                    Math.min(this.ScrollControl.scrollPosition.x, maxH),
                    Math.min(this.ScrollControl.scrollPosition.y, maxV));
            this.ScrollControl.viewport.update();
        };

        this.ScrollControl.viewport.cursor = new Cursor(StdCursor.Cross);

        // Drawing state
        let currentShape  = null;
        let currentLine   = null;
        let startX = null, startY = null;
        let startLineX = null, startLineY = null;
        let drawing = false, drawingLine = false, dragging = false;

        this.clearShapeCheckboxes = () =>
        {
            this.ellipseCheckbox.checked      = false;
            this.freehandCheckbox.checked     = false;
            this.rectangleCheckbox.checked    = false;
            this.arrowCheckbox.checked        = false;
            this.placeCompassCheckbox.checked = false;
            this.textCheckbox.checked         = false;
        };

        this.cycleActiveShape = () =>
        {
            if ( scriptParameters.shapes.length > 0 )
            {
                this.activeShapeIndex = (this.activeShapeIndex + 1) % scriptParameters.shapes.length;
                this.ScrollControl.viewport.update();
            }
        };

        this.ScrollControl.viewport.onKeyPress = (keyCode, modifiers) =>
        {
            if ( keyCode === 0x20 ) this.cycleActiveShape();
        };

        this.ScrollControl.viewport.onMousePress = (x, y, button, buttons, modifiers) =>
        {
            if ( button !== 1 ) return;
            let img_x = (x / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor;
            let img_y = (y / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor;

            // Check marker click
            for ( let i = 0; i < scriptParameters.markers.length; i++ )
            {
                let marker = scriptParameters.markers[i];
                let mx = (marker.x - this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor) * scriptParameters.zoomFactor;
                let my = (marker.y - this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor) * scriptParameters.zoomFactor;
                if ( Math.sqrt(Math.pow(mx-x,2) + Math.pow(my-y,2)) <= 5 / scriptParameters.zoomFactor )
                {
                    for ( let j = 0; j < this.resultTreeBox.numberOfChildren; j++ )
                        this.resultTreeBox.child(j).selected = false;
                    for ( let j = 0; j < this.resultTreeBox.numberOfChildren; j++ )
                    {
                        let node = this.resultTreeBox.child(j);
                        if ( parseInt(node.text(6)) === marker.index + 1 ) { node.selected = true; break; }
                    }
                    scriptParameters.highlightedMarker = marker;
                    this.ScrollControl.viewport.update();
                    this.MiniPreviewControl.viewport.update();
                    return;
                }
            }

            let selectedColor = scriptParameters.selectedShapeColor;

            if ( modifiers === 1 ) // Shift — search circle
            {
                this.clearShapeCheckboxes();
                startX = img_x; startY = img_y;
                drawing = true; dragging = false;
                this.currentDrawingMode = "searchCircle";
            }
            else if ( modifiers === 2 ) // Ctrl — measure distance
            {
                this.clearShapeCheckboxes();
                startLineX = img_x; startLineY = img_y;
                drawingLine = true; dragging = false;
                this.currentDrawingMode = "measureDistance";
            }
            else if ( modifiers === 4 ) // Alt — shapes
            {
                startX = img_x; startY = img_y;
                drawing = true; dragging = false;
                switch ( this.currentDrawingMode )
                {
                case "ellipse":
                    currentShape = { type:"ellipse",   start:[startX,startY], end:[startX,startY], color:selectedColor }; break;
                case "rectangle":
                    currentShape = { type:"rectangle", start:[startX,startY], end:[startX,startY], color:selectedColor }; break;
                case "freehand":
                    currentShape = { type:"freehand",  points:[[startX,startY]],                   color:selectedColor }; break;
                case "arrow":
                    currentShape = { type:"arrow",     start:[startX,startY], end:[startX,startY], color:selectedColor }; break;
                case "text":
                    currentShape = { type:"text", position:[startX,startY], text:this.textInput.text, color:selectedColor }; break;
                case "compass":
                    currentShape = { type:"compass", center:[startX,startY],
                        orientation: scriptParameters.orientation !== null ? scriptParameters.orientation : 0,
                        color:selectedColor }; break;
                default:
                    console.writeln("Please set a drawing mode first."); break;
                }
            }
            else
            {
                this.ScrollControl.viewport.cursor = new Cursor(StdCursor.ClosedHand);
                this.ScrollControl.dragOrigin.x = x;
                this.ScrollControl.dragOrigin.y = y;
                dragging = true;
            }
        };

        this.ScrollControl.viewport.onMouseDoubleClick = (x, y, button, buttons, modifiers) =>
        {
            if ( button !== 1 ) return;
            for ( let i = 0; i < scriptParameters.markers.length; i++ )
            {
                let marker = scriptParameters.markers[i];
                let mx = (marker.x - this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor) * scriptParameters.zoomFactor;
                let my = (marker.y - this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor) * scriptParameters.zoomFactor;
                if ( Math.sqrt(Math.pow(mx-x,2) + Math.pow(my-y,2)) <= 5 / scriptParameters.zoomFactor )
                {
                    for ( let j = 0; j < this.resultTreeBox.numberOfChildren; j++ )
                        this.resultTreeBox.child(j).selected = false;
                    for ( let j = 0; j < this.resultTreeBox.numberOfChildren; j++ )
                    {
                        let node = this.resultTreeBox.child(j);
                        if ( parseInt(node.text(6)) === marker.index + 1 )
                        {
                            node.selected = true;
                            scriptParameters.highlightedMarker = marker;
                            if ( marker.isSimbad )
                            {
                                let objectName = node.text(2).trim();
                                Dialog.openBrowser("http://simbad.u-strasbg.fr/simbad/sim-id?Ident=" + encodeURIComponent(objectName) + "&NbIdent=1&Radius=2&Radius.unit=arcmin&submit=submit+id");
                            }
                            else if ( marker.isVizier )
                            {
                                let ra = marker.ra, dec = marker.dec;
                                let decSign = dec >= 0 ? "%2B" : "-";
                                Dialog.openBrowser("http://ned.ipac.caltech.edu/conesearch?search_type=Near%20Position%20Search&ra=" + ra.toFixed(6) + "d&dec=" + decSign + Math.abs(dec).toFixed(6) + "d&radius=0.083&in_csys=Equatorial&in_equinox=J2000.0");
                            }
                            else
                                Dialog.openBrowser("https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html?searchQuery=" + marker.ra.toFixed(6) + "%2C" + marker.dec.toFixed(6) + "radius%3D0.0006");
                            this.ScrollControl.viewport.update();
                            return;
                        }
                    }
                }
            }
            scriptParameters.highlightedMarker = null;
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        this.ScrollControl.viewport.onMouseMove = (x, y, buttons, modifiers) =>
        {
            let img_x = (x / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor;
            let img_y = (y / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor;
            let cp    = getCelestial(img_x, img_y);

            switch ( scriptParameters.formatAlpha )
            {
            case 1: this.cursorDataLabelAlpha.text = cp.x.toFixed(6) + "º"; break;
            case 2:
                let alphaHMS = degreesToHMS(cp.x);
                this.cursorDataLabelAlpha.text = zeroPadding(alphaHMS[0]) + "<sup>h</sup> " +
                    zeroPadding(alphaHMS[1]) + "<sup>m</sup> " + zeroPadding(alphaHMS[2].toFixed(3)) + "<sup>s</sup>";
                break;
            }
            switch ( scriptParameters.formatDelta )
            {
            case 1: this.cursorDataLabelDelta.text = cp.y.toFixed(6) + "º"; break;
            case 2:
                let deltaDMS = degreesToDMS(cp.y);
                let sign = deltaDMS[0] == -1 ? "-" : "+";
                this.cursorDataLabelDelta.text = sign + zeroPadding(deltaDMS[1]) + "º " +
                    zeroPadding(deltaDMS[2]) + "' " + zeroPadding(deltaDMS[3].toFixed(3)) + "\"";
                break;
            }

            if ( drawing )
            {
                let endX = img_x, endY = img_y;
                switch ( this.currentDrawingMode )
                {
                case "searchCircle":
                    currentShape = { type:"searchCircle", center:[startX,startY],
                        radius: Math.sqrt(Math.pow(endX-startX,2) + Math.pow(endY-startY,2)),
                        color: scriptParameters.selectedShapeColor }; break;
                case "ellipse":
                    currentShape = { type:"ellipse",   start:[startX,startY], end:[endX,endY], color:scriptParameters.selectedShapeColor }; break;
                case "rectangle":
                    currentShape = { type:"rectangle", start:[startX,startY], end:[endX,endY], color:scriptParameters.selectedShapeColor }; break;
                case "freehand":
                    if ( !currentShape ) currentShape = { type:"freehand", points:[[startX,startY]], color:scriptParameters.selectedShapeColor };
                    currentShape.points.push([endX,endY]); break;
                case "arrow":
                    currentShape = { type:"arrow", start:[startX,startY], end:[endX,endY], color:scriptParameters.selectedShapeColor }; break;
                case "text":
                    currentShape = { type:"text", position:[startX,startY], text:this.textInput.text||"Sample Text", color:scriptParameters.selectedShapeColor }; break;
                case "compass":
                    currentShape = { type:"compass", center:[startX,startY],
                        orientation: scriptParameters.orientation !== null ? scriptParameters.orientation : 0,
                        color:scriptParameters.selectedShapeColor }; break;
                }
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            }
            else if ( drawingLine )
            {
                currentLine = { type:"measureDistance", start:[startLineX,startLineY], end:[img_x,img_y],
                    distance:null, color:scriptParameters.selectedShapeColor };
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            }
            else if ( dragging )
            {
                let dx = (this.ScrollControl.dragOrigin.x - x) / (0.2 * scriptParameters.zoomFactor);
                let dy = (this.ScrollControl.dragOrigin.y - y) / (0.2 * scriptParameters.zoomFactor);
                this.ScrollControl.scrollPosition = new Point(this.ScrollControl.scrollPosition).translatedBy(dx, dy);
                this.ScrollControl.dragOrigin.x = x; this.ScrollControl.dragOrigin.y = y;
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            }
            else
            {
                this.ScrollControl.viewport.cursor = new Cursor(StdCursor.Cross);
            }
        };

        this.ScrollControl.viewport.onMouseRelease = (x, y, button, buttons, modifiers) =>
        {
            if ( drawing )
            {
                drawing = false;
                if ( currentShape && currentShape.type === "searchCircle" )
                {
                    scriptParameters.circle = currentShape;
                    let cc = getCelestial(scriptParameters.circle.center[0], scriptParameters.circle.center[1]);
                    scriptParameters.centerPoint = { ra: cc.x, dec: cc.y };
                    let endX = (x / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor);
                    let endY = (y / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor);
                    scriptParameters.radius = angularSeparation(cc.x, cc.y, getCelestial(endX,endY).x, getCelestial(endX,endY).y);
                    console.writeln(format("Center: RA=%.6f, Dec=%.6f  Radius=%.6f deg", cc.x, cc.y, scriptParameters.radius));
                }
                else if ( currentShape )
                {
                    scriptParameters.shapes.push(currentShape);
                    this.activeShapeIndex = scriptParameters.shapes.length - 1;
                }
                currentShape = null;
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            }
            else if ( drawingLine )
            {
                drawingLine = false;
                let endX = (x / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor;
                let endY = (y / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor;
                let sc = getCelestial(startLineX, startLineY);
                let ec = getCelestial(endX, endY);
                let distArcsec = angularSeparation(sc.x, sc.y, ec.x, ec.y) * 3600;
                let distArcmin = arcsecondsToArcminutes(distArcsec);
                console.writeln(format("Distance: %d' %.2f\"", distArcmin.minutes, distArcmin.seconds));
                scriptParameters.line = { type:"measureDistance", start:[startLineX,startLineY], end:[endX,endY],
                    distance: format("%d' %.2f\"", distArcmin.minutes, distArcmin.seconds),
                    color: scriptParameters.selectedShapeColor };
                currentLine = null;
                scriptParameters.shapes.push(scriptParameters.line);
                this.activeShapeIndex = scriptParameters.shapes.length - 1;
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            }
            else
            {
                this.ScrollControl.viewport.cursor = new Cursor(StdCursor.Cross);
                dragging = false;
            }
        };

        this.ScrollControl.viewport.onMouseWheel = (x, y, delta, buttons, modifiers) =>
        {
            let oldZ = scriptParameters.zoomFactor;
            let maxH = (this.ScrollControl.bmp.width  / oldZ) - this.ScrollControl.viewport.width;
            let maxV = (this.ScrollControl.bmp.height / oldZ) - this.ScrollControl.viewport.height;
            let pctX = this.ScrollControl.scrollPosition.x / maxH;
            let pctY = this.ScrollControl.scrollPosition.y / maxV;
            if ( delta > 0 ) scriptParameters.zoomFactor = Math.min(scriptParameters.zoomFactor * 1.25, this.maxZoomFactor);
            else             scriptParameters.zoomFactor = Math.max(scriptParameters.zoomFactor * 0.8,  this.minZoomFactor);
            let newZ = scriptParameters.zoomFactor;
            this.ScrollControl.initScrollBars();
            maxH = (this.ScrollControl.bmp.width  / newZ) - newZ * this.ScrollControl.viewport.width;
            maxV = (this.ScrollControl.bmp.height / newZ) - newZ * this.ScrollControl.viewport.height;
            this.ScrollControl.scrollPosition = new Point(
                Math.max(0, Math.min(pctX * maxH, maxH)),
                Math.max(0, Math.min(pctY * maxV, maxV)));
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        this.ScrollControl.zoomIn  = () => { this.ScrollControl.zoom(1);  };
        this.ScrollControl.zoomOut = () => { this.ScrollControl.zoom(-1); };
        this.ScrollControl.zoom    = (delta) =>
        {
            if ( delta > 0 ) scriptParameters.zoomFactor = Math.min(scriptParameters.zoomFactor * 1.25, this.maxZoomFactor);
            else             scriptParameters.zoomFactor = Math.max(scriptParameters.zoomFactor * 0.8,  this.minZoomFactor);
            this.ScrollControl.initScrollBars();
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        // Main viewport paint
        this.ScrollControl.viewport.onPaint = (x0, y0, x1, y1) =>
        {
            let g = new Graphics(this.ScrollControl.viewport);
            g.antialiasing = true; g.smoothInterpolation = false;
            let scaledW = scriptParameters.imageImage.width  * scriptParameters.zoomFactor;
            let scaledH = scriptParameters.imageImage.height * scriptParameters.zoomFactor;
            let offsetX = Math.max(0, (this.ScrollControl.viewport.width  - scaledW) / 2);
            let offsetY = Math.max(0, (this.ScrollControl.viewport.height - scaledH) / 2);
            g.scaleTransformation(scriptParameters.zoomFactor);
            g.translateTransformation(
                offsetX - this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor,
                offsetY - this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor);
            g.drawBitmap(0, 0, scriptParameters.imageImage.render());

            if ( scriptParameters.circle )
            {
                g.pen = new Pen(0xff00ff00);
                g.drawCircle(scriptParameters.circle.center[0], scriptParameters.circle.center[1], scriptParameters.circle.radius);
            }

            // Current shape being drawn
            if ( currentShape )
            {
                g.pen = new Pen(currentShape.color);
                switch ( currentShape.type )
                {
                case "searchCircle": g.drawCircle(currentShape.center[0], currentShape.center[1], currentShape.radius); break;
                case "ellipse":   g.drawEllipse(currentShape.start[0], currentShape.start[1], currentShape.end[0], currentShape.end[1]); break;
                case "rectangle": g.drawRect(currentShape.start[0], currentShape.start[1], currentShape.end[0], currentShape.end[1]); break;
                case "freehand":
                    for ( let i = 0; i < currentShape.points.length-1; i++ )
                        g.drawLine(currentShape.points[i][0], currentShape.points[i][1], currentShape.points[i+1][0], currentShape.points[i+1][1]);
                    break;
                case "arrow":  drawArrow(g, currentShape.start[0], currentShape.start[1], currentShape.end[0], currentShape.end[1]); break;
                case "text":
                    g.pen = new Pen(scriptParameters.selectedFontColor);
                    g.font = new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize);
                    g.drawText(currentShape.position[0], currentShape.position[1], currentShape.text); break;
                case "compass": drawCompass(g, currentShape.center[0], currentShape.center[1], currentShape.orientation); break;
                }
            }

            if ( currentLine )
            {
                g.pen = new Pen(0xff0000ff, 2);
                g.drawLine(currentLine.start[0], currentLine.start[1], currentLine.end[0], currentLine.end[1]);
            }

            // Stored shapes
            for ( let i = 0; i < scriptParameters.shapes.length; i++ )
            {
                let shape = scriptParameters.shapes[i];
                g.pen = new Pen(i === this.activeShapeIndex ? 0xffff0000 : shape.color);
                switch ( shape.type )
                {
                case "searchCircle":
                    g.pen = new Pen(0xff00ff00);
                    g.drawCircle(shape.center[0], shape.center[1], shape.radius); break;
                case "ellipse":   g.drawEllipse(shape.start[0], shape.start[1], shape.end[0], shape.end[1]); break;
                case "rectangle": g.drawRect(shape.start[0], shape.start[1], shape.end[0], shape.end[1]); break;
                case "freehand":
                    for ( let j = 0; j < shape.points.length-1; j++ )
                        g.drawLine(shape.points[j][0], shape.points[j][1], shape.points[j+1][0], shape.points[j+1][1]);
                    break;
                case "arrow":  drawArrow(g, shape.start[0], shape.start[1], shape.end[0], shape.end[1]); break;
                case "text":
                    g.pen = new Pen(scriptParameters.selectedFontColor);
                    g.font = new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize);
                    g.drawText(shape.position[0], shape.position[1], shape.text); break;
                case "measureDistance":
                    g.drawLine(shape.start[0], shape.start[1], shape.end[0], shape.end[1]);
                    g.font = new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize);
                    g.drawText((shape.start[0]+shape.end[0])/2, (shape.start[1]+shape.end[1])/2, shape.distance); break;
                case "compass": drawCompass(g, shape.center[0], shape.center[1], shape.orientation); break;
                }
            }

            // Markers
            for ( let marker of scriptParameters.markers )
            {
                let radius = 5 / scriptParameters.zoomFactor;
                let highlighted = scriptParameters.highlightedMarker &&
                    marker.x === scriptParameters.highlightedMarker.x &&
                    marker.y === scriptParameters.highlightedMarker.y;
                g.pen = highlighted ? new Pen(0xff00ff00, 2) : new Pen(0xffff0000, 2);
                if ( scriptParameters.selectedMarkerShape === "Circle" )
                    g.drawCircle(marker.x, marker.y, radius);
                else
                {
                    let cs = 12 / scriptParameters.zoomFactor, gap = 4 / scriptParameters.zoomFactor;
                    g.drawLine(marker.x-cs, marker.y, marker.x-gap, marker.y);
                    g.drawLine(marker.x+gap, marker.y, marker.x+cs, marker.y);
                    g.drawLine(marker.x, marker.y-cs, marker.x, marker.y-gap);
                    g.drawLine(marker.x, marker.y+gap, marker.x, marker.y+cs);
                }
                if ( this.showObjectNamesCheckbox.checked )
                {
                    g.pen = new Pen(scriptParameters.selectedFontColor, 1);
                    g.font = new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize);
                    g.drawText(marker.x + 6 / scriptParameters.zoomFactor, marker.y, marker.name);
                }
            }
            g.end();
        };

        this.ScrollControl.initScrollBars();

        // ---- Format combos ----
        this.resultModeAlphaLabel = new Label(this);
        this.resultModeAlphaLabel.text = "RA Format (&alpha;)";
        this.resultModeAlphaLabel.useRichText = true;
        this.resultModeAlphaLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.resultModeAlphaModeCombo = new ComboBox(this);
        this.resultModeAlphaModeCombo.minWidth = 150;
        formatModesAlpha.forEach((type, idx) =>
        {
            this.resultModeAlphaModeCombo.addItem(type[0]);
            if ( scriptParameters.formatAlpha == type[1] )
                this.resultModeAlphaModeCombo.currentItem = type[1] - 1;
        });
        this.resultModeAlphaModeCombo.onItemSelected = index =>
        {
            scriptParameters.formatAlpha = formatModesAlpha[index][1];
        };

        this.resultModeDeltaLabel = new Label(this);
        this.resultModeDeltaLabel.text = "Dec Format (&delta;)";
        this.resultModeDeltaLabel.useRichText = true;
        this.resultModeDeltaLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.resultModeDeltaModeCombo = new ComboBox(this);
        this.resultModeDeltaModeCombo.toolTip = "Declination (Dec) format.";
        this.resultModeDeltaModeCombo.minWidth = 150;
        formatModesDelta.forEach((type, idx) =>
        {
            this.resultModeDeltaModeCombo.addItem(type[0]);
            if ( scriptParameters.formatDelta == type[1] )
                this.resultModeDeltaModeCombo.currentItem = type[1] - 1;
        });
        this.resultModeDeltaModeCombo.onItemSelected = index =>
        {
            scriptParameters.formatDelta = formatModesDelta[index][1];
        };

        // Cursor data labels
        this.cursorDataLabelTitleAlpha = new Label(this);
        this.cursorDataLabelTitleAlpha.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.cursorDataLabelTitleAlpha.useRichText = true;
        this.cursorDataLabelTitleAlpha.text = "&alpha;";

        this.cursorDataLabelAlpha = new Label(this);
        this.cursorDataLabelAlpha.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.cursorDataLabelAlpha.useRichText = true;
        this.cursorDataLabelAlpha.text = "-";

        this.cursorDataLabelTitleDelta = new Label(this);
        this.cursorDataLabelTitleDelta.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.cursorDataLabelTitleDelta.useRichText = true;
        this.cursorDataLabelTitleDelta.text = "&delta;";

        this.cursorDataLabelDelta = new Label(this);
        this.cursorDataLabelDelta.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.cursorDataLabelDelta.useRichText = true;
        this.cursorDataLabelDelta.text = "-";

        this.cursorDataLabelOrientation = new Label(this);
        this.cursorDataLabelOrientation.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.cursorDataLabelOrientation.useRichText = true;
        this.cursorDataLabelOrientation.text = scriptParameters.orientation !== null
            ? "Orientation: " + scriptParameters.orientation.toFixed(2) + "°"
            : "Orientation: -";

        this.resultAlphaFormatGroupBoxH = new HorizontalSizer;
        this.resultAlphaFormatGroupBoxH.margin = 0; this.resultAlphaFormatGroupBoxH.spacing = 10;
        this.resultAlphaFormatGroupBoxH.add(this.resultModeAlphaLabel);
        this.resultAlphaFormatGroupBoxH.add(this.resultModeAlphaModeCombo);

        this.resultDeltaFormatGroupBoxH = new HorizontalSizer;
        this.resultDeltaFormatGroupBoxH.margin = 0; this.resultDeltaFormatGroupBoxH.spacing = 10;
        this.resultDeltaFormatGroupBoxH.add(this.resultModeDeltaLabel);
        this.resultDeltaFormatGroupBoxH.add(this.resultModeDeltaModeCombo);

        this.cursorDataHorizontal = new HorizontalSizer;
        this.cursorDataHorizontal.margin = 10; this.cursorDataHorizontal.spacing = 0;
        this.cursorDataHorizontal.add(this.cursorDataLabelTitleAlpha);
        this.cursorDataHorizontal.add(this.cursorDataLabelAlpha);
        this.cursorDataHorizontal.addSpacing(10);
        this.cursorDataHorizontal.add(this.cursorDataLabelTitleDelta);
        this.cursorDataHorizontal.add(this.cursorDataLabelDelta);
        this.cursorDataHorizontal.addSpacing(10);
        this.cursorDataHorizontal.add(this.cursorDataLabelOrientation);

        // ---- Auto Stretch button ----
        this.autoStretchButton = new PushButton(this);
        this.autoStretchButton.text = " Auto Stretch ";
        this.autoStretchButton.icon = ":/icons/burn.png";
        this.autoStretchButton.onClick = () =>
        {
            if ( scriptParameters.isStretched )
            {
                resetStretch(scriptParameters.workingPreview.mainView);
                scriptParameters.isStretched = false;
            }
            else
            {
                if ( !scriptParameters.originalImageState )
                    scriptParameters.originalImageState = new Image(scriptParameters.workingPreview.mainView.image);
                applyPixelMathStretch(scriptParameters.workingPreview.mainView);
                scriptParameters.isStretched = true;
            }
            this.ScrollControl.viewport.update();
        };

        this.autoStretchButtonSizer = new VerticalSizer;
        this.autoStretchButtonSizer.margin = 0;
        this.autoStretchButtonSizer.add(this.autoStretchButton);

        // ---- Query Simbad button ----
        this.simbadButton = new PushButton(this);
        this.simbadButton.text = " Query Simbad ";
        this.simbadButton.icon = ":/icons/ok.png";
        this.simbadButton.onClick = () => { this.querySimbadWithRetry(); };

        this.querySimbadWithRetry = (isDeepSearch) =>
        {
            isDeepSearch = isDeepSearch || false;
            if ( !scriptParameters.centerPoint || scriptParameters.radius === undefined )
            { console.writeln("Center point or radius is undefined."); return; }
            performSimbadQuery(this, scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec,
                scriptParameters.radius, scriptParameters.maxDownloads, isDeepSearch);
        };

        // ---- Result tree box ----
        this.resultTreeBox = new TreeBox(this);
        this.resultTreeBox.numberOfColumns = 6;
        this.resultTreeBox.headerVisible   = true;
        this.resultTreeBox.headerSorting   = true;
        this.resultTreeBox.multipleSelection = true;
        this.resultTreeBox.setHeaderText(0, "RA");   this.resultTreeBox.setHeaderText(1, "Dec");
        this.resultTreeBox.setHeaderText(2, "Name"); this.resultTreeBox.setHeaderText(3, "Diameter");
        this.resultTreeBox.setHeaderText(4, "Type"); this.resultTreeBox.setHeaderText(5, "Long Type");
        this.resultTreeBox.setMinHeight(200); this.resultTreeBox.setMaxHeight(200);

        this.resultTreeBox.onNodeClicked = (item) =>
        {
            if ( item )
            {
                let point = getCoordinates(parseFloat(item.text(0)), parseFloat(item.text(1)));
                scriptParameters.highlightedMarker = point || null;
            }
            else scriptParameters.highlightedMarker = null;
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        this.resultTreeBox.onKeyPress = (keyCode) =>
        {
            let currentItem = this.resultTreeBox.currentNode;
            if ( currentItem && (keyCode === 268435458 || keyCode === 268435460) )
            {
                let point = getCoordinates(parseFloat(currentItem.text(0)), parseFloat(currentItem.text(1)));
                scriptParameters.highlightedMarker = point || null;
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            }
        };

        this.resultTreeBox.onNodeDoubleClicked = (item) =>
        {
            if ( !item ) return;
            let source = item.text(7).trim(), objectName = item.text(2).trim();
            if ( source === 'Simbad' )
                Dialog.openBrowser("http://simbad.u-strasbg.fr/simbad/sim-id?Ident=" + encodeURIComponent(objectName) + "&NbIdent=1&Radius=2&Radius.unit=arcmin&submit=submit+id");
            else if ( source === 'Vizier' )
            {
                let ra = parseFloat(item.text(0)), dec = parseFloat(item.text(1));
                let decSign = dec >= 0 ? "%2B" : "-";
                Dialog.openBrowser("http://ned.ipac.caltech.edu/conesearch?search_type=Near%20Position%20Search&ra=" + ra.toFixed(6) + "d&dec=" + decSign + Math.abs(dec).toFixed(6) + "d&radius=0.083&in_csys=Equatorial&in_equinox=J2000.0");
            }
            else
                Dialog.openBrowser("https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html?searchQuery=" + parseFloat(item.text(0)).toFixed(6) + "%2C" + parseFloat(item.text(1)).toFixed(6) + "radius%3D0.0006");
        };

        // ---- CSV save button ----
        this.saveCsvButton = new PushButton(this);
        this.saveCsvButton.text = " Save CSV ";
        this.saveCsvButton.icon = ":/icons/save.png";
        this.saveCsvButton.onClick = () =>
        {
            let sfd = new SaveFileDialog();
            sfd.caption = "Save CSV"; sfd.filters = [["CSV Files","*.csv"]];
            sfd.initialPath = File.systemTempDirectory;
            if ( sfd.execute() )
            {
                let lines = ["RA,Dec,Name,Diameter,Type,LongType"];
                for ( let i = 0; i < this.resultTreeBox.numberOfChildren; i++ )
                {
                    let node = this.resultTreeBox.child(i);
                    lines.push([node.text(0),node.text(1),node.text(2),node.text(3),node.text(4),node.text(5)].join(","));
                }
                File.writeTextFile(sfd.fileName, lines.join("\n"));
            }
        };

        // ---- Toggle visible objects ----
        this.toggleVisibleObjectsButton = new PushButton(this);
        this.toggleVisibleObjectsButton.text    = "Show Visible Objects Only";
        this.toggleVisibleObjectsButton.toolTip = "Toggle the visibility of all objects currently visible on the main preview.";
        this.toggleVisibleObjectsButton.icon    = ":/icons/zoom.png";
        this.toggleVisibleObjectsButton.onClick = () =>
        {
            let activeWindow = ImageWindow.activeWindow;
            if ( !activeWindow || !activeWindow.mainView ) { console.writeln("No active window."); return; }
            let image = activeWindow.mainView.image;
            let median = image.median(), stdDev = image.stdDev(), n = scriptParameters.visibilityThresholdN || 1;
            for ( let i = scriptParameters.markers.length - 1; i >= 0; i-- )
            {
                let marker = scriptParameters.markers[i];
                if ( !isMarkerVisible(marker, image, median, stdDev, n) )
                {
                    scriptParameters.markers.splice(i, 1);
                    for ( let j = 0; j < this.resultTreeBox.numberOfChildren; j++ )
                    {
                        let node = this.resultTreeBox.child(j);
                        if ( parseFloat(node.text(0)) === marker.ra && parseFloat(node.text(1)) === marker.dec )
                        { this.resultTreeBox.remove(j); break; }
                    }
                }
            }
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        // ---- Show object names checkbox ----
        this.showObjectNamesCheckbox = new CheckBox(this);
        this.showObjectNamesCheckbox.text    = "Show Object Names";
        this.showObjectNamesCheckbox.checked = false;
        this.showObjectNamesCheckbox.toolTip = "Toggle to display object names next to markers.";
        this.showObjectNamesCheckbox.onClick = () =>
        {
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        this.toggleAndNamesSizer = new HorizontalSizer; this.toggleAndNamesSizer.spacing = 6;
        this.toggleAndNamesSizer.add(this.toggleVisibleObjectsButton);
        this.toggleAndNamesSizer.add(this.showObjectNamesCheckbox);

        // ---- Cancel / exit button ----
        this.cancelButton = new PushButton(this);
        this.cancelButton.text = "Exit";
        this.cancelButton.icon = ":/toolbar/file-exit.png";
        this.cancelButton.onClick = () =>
        {
            let msg = new MessageBox("Exit?", "Confirm Exit", StdIcon.Question, StdButton.Yes, StdButton.No);
            if ( msg.execute() == StdButton.Yes ) this.cancel();
        };

        // ---- Max downloads / settings button ----
        this.maxDownloadsButton = new PushButton(this);
        this.maxDownloadsButton.text = "";
        this.maxDownloadsButton.icon = ":/icons/wrench.png";
        this.maxDownloadsButton.onClick = () =>
        {
            let dialog = new MaxDownloadsDialog(
                scriptParameters.maxDownloads  || 500,
                scriptParameters.selectedFont  || "DejaVu Sans",
                scriptParameters.selectedFontSize || 10,
                scriptParameters.selectedFontColor || 0xffffffff,
                this.ScrollControl, this.MiniPreviewControl,
                scriptParameters.visibilityThresholdN || 1);
            if ( dialog.execute() === 1 )
            {
                scriptParameters.maxDownloads         = dialog.maxDownloads;
                scriptParameters.selectedFont         = dialog.selectedFont;
                scriptParameters.selectedFontSize     = dialog.selectedFontSize;
                scriptParameters.selectedFontColor    = dialog.selectedFontColor;
                scriptParameters.visibilityThresholdN = dialog.visibilityThresholdN;
            }
        };

        // ---- Toggle all markers button ----
        this.toggleMarkersButton = new PushButton(this);
        this.toggleMarkersButton.text = " Toggle All Markers ";
        this.toggleMarkersButton.icon = ":/icons/clear.png";
        this.toggleMarkersButton.onClick = () =>
        {
            if ( scriptParameters.markers.length > 0 )
            {
                scriptParameters.markers = [];
            }
            else
            {
                for ( let i = 0; i < this.resultTreeBox.numberOfChildren; i++ )
                {
                    let node = this.resultTreeBox.child(i);
                    let point = getCoordinates(parseFloat(node.text(0)), parseFloat(node.text(1)));
                    if ( point ) { point.name = node.text(2); scriptParameters.markers.push(point); }
                }
            }
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        // ---- Labels ----
        this.instructionLabel = new Label(this);
        this.instructionLabel.text = "Click and Drag in the MiniPreview to Zoom to that Location";
        this.instructionLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;

        this.clickLabel = new Label(this);
        this.clickLabel.text = "Click any Row to highlight the Marker or Vice Versa on the Main Preview.\nDouble Click a Marker or Row to Open that object in Simbad.";
        this.clickLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;

        // ---- Authorship ----
        this.authorshipLabel = new Label(this);
        this.authorshipLabel.text = "<p style='text-align:center;'>Written by Franklin Marek 2026.<br><a href='http://www.setiastro.com'>www.setiastro.com</a></p>";
        this.authorshipLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.authorshipLabel.useRichText = true;

        // ---- Advanced search button ----
        this.advancedSearchButton = new PushButton(this);
        this.advancedSearchButton.text = "Advanced Search";
        this.advancedSearchButton.onClick = () =>
        {
            this.toggleAdvancedSearchPanel();
        };

        // ---- MAST query ----
        this.queryMastWithRetry = () =>
        {
            if ( !scriptParameters.centerPoint || !scriptParameters.radius ) { console.writeln("No search region."); return; }
            let objects = null, attempts = 0;
            while ( attempts < 3 && objects === null )
            {
                try { objects = adqlQueryMast("https://mast.stsci.edu/api/v0/invoke?",
                    scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec,
                    scriptParameters.radius / 60, scriptParameters.maxDownloads); }
                catch (e) { console.warningln("Attempt " + (attempts+1) + " failed: " + e.message); attempts++; }
            }
            if ( !objects ) { console.warningln("Connection to MAST not established."); return; }
            populateResultTreeBox(this, objects, 'MAST');
        };

        // ---- NED query ----
        this.queryNED = () =>
        {
            if ( !scriptParameters.centerPoint || !scriptParameters.radius ) return;
            let ra  = scriptParameters.centerPoint.ra, dec = scriptParameters.centerPoint.dec;
            let radius = Math.min(scriptParameters.radius * 60, 60);
            let decSign = dec >= 0 ? "%2B" : "-";
            Dialog.openBrowser("http://ned.ipac.caltech.edu/conesearch?search_type=Near%20Position%20Search&ra=" +
                ra.toFixed(6) + "d&dec=" + decSign + Math.abs(dec).toFixed(6) + "d&radius=" + radius +
                "&in_csys=Equatorial&in_equinox=J2000.0");
        };

        this.applyAdvancedSearchSelection = (treeBox) =>
        {
            this.selectedObjectTypes = [];
            for ( let i = 0; i < treeBox.numberOfChildren; i++ )
            {
                let node = treeBox.child(i);
                if ( node.checked ) this.selectedObjectTypes.push(node.objectType);
            }
        };

        this.toggleAdvancedSearchPanel = () =>
        {
            if ( this.advancedSearchPanel.visible ) this.advancedSearchPanel.hide();
            else                                    this.advancedSearchPanel.show();
            this.adjustDialogSize();
        };

        this.advancedSearchPanel = createAdvancedSearchPanel(this);

        // ---- Copy RA/Dec button ----
        this.copyRaDecButton = new PushButton(this);
        this.copyRaDecButton.text = "Copy Center RA/DEC";
        this.copyRaDecButton.icon = ":/icons/copy.png";
        this.copyRaDecButton.onClick = () =>
        {
            if ( !scriptParameters.centerPoint ) { console.writeln("No center point defined."); return; }
            let text = "RA: " + scriptParameters.centerPoint.ra.toFixed(6) + ", DEC: " + scriptParameters.centerPoint.dec.toFixed(6);
            if ( scriptParameters.orientation !== null )
                text += ", Orientation: " + scriptParameters.orientation.toFixed(2) + "°";
            new MessageBox("Highlight and Copy Your Coordinates:\n\n" + text,
                "Center RA/DEC and Orientation", StdIcon.Information, StdButton.Ok).execute();
        };

        // ---- Save annotated image button ----
        this.saveAnnotatedImageButton = new PushButton(this);
        this.saveAnnotatedImageButton.text    = "Save Annotated Image";
        this.saveAnnotatedImageButton.icon    = ":/icons/save.png";
        this.saveAnnotatedImageButton.toolTip = "Save the annotated image as a .jpg file.";
        this.saveAnnotatedImageButton.onClick = () => { this.saveAnnotatedImage(); };

        this.saveCroppedViewOnlyCheckbox = new CheckBox(this);
        this.saveCroppedViewOnlyCheckbox.text    = "Save Annotated Cropped View Only";
        this.saveCroppedViewOnlyCheckbox.checked = scriptParameters.saveCroppedViewOnly;

        this.saveCollageCheckbox = new CheckBox(this);
        this.saveCollageCheckbox.text    = "Save Collage of Objects";
        this.saveCollageCheckbox.toolTip = "Save a collage of detected objects based on markers.";

        this.saveAnnotatedImage = () =>
        {
            let tempImageWindow = new ImageWindow(
                scriptParameters.imageImage.width, scriptParameters.imageImage.height,
                scriptParameters.imageImage.numberOfChannels,
                scriptParameters.imageImage.bitsPerSample,
                scriptParameters.imageImage.isReal,
                scriptParameters.imageImage.isColor);

            tempImageWindow.mainView.beginProcess(UndoFlag.NoSwapFile);
            tempImageWindow.mainView.image.assign(scriptParameters.imageImage);
            tempImageWindow.mainView.endProcess();

            if ( scriptParameters.imageImage.numberOfChannels == 1 )
            {
                let conv = new ConvertToRGBColor;
                conv.executeOn(tempImageWindow.mainView, false);
            }

            let bitmap   = new Bitmap(tempImageWindow.mainView.image.width, tempImageWindow.mainView.image.height);
            let graphics = new Graphics(bitmap);
            graphics.antialiasing = true;
            let fcolor   = scriptParameters.selectedFontColor;

            for ( let shape of scriptParameters.shapes )
            {
                graphics.pen = new Pen(shape.color);
                switch ( shape.type )
                {
                case "searchCircle": drawCircle(graphics, shape.center[0], shape.center[1], shape.radius, new Pen(0xff00ff00)); break;
                case "ellipse":      drawEllipse(graphics, shape.start[0], shape.start[1], shape.end[0], shape.end[1], graphics.pen); break;
                case "rectangle":    drawRect(graphics, shape.start[0], shape.start[1], shape.end[0], shape.end[1], graphics.pen); break;
                case "freehand":     drawFreehand(graphics, shape.points, graphics.pen); break;
                case "arrow":        drawArrow(graphics, shape.start[0], shape.start[1], shape.end[0], shape.end[1]); break;
                case "text":         drawText(graphics, shape.position[0], shape.position[1], shape.text, new Pen(fcolor), new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize)); break;
                case "measureDistance":
                    drawLine(graphics, shape.start[0], shape.start[1], shape.end[0], shape.end[1], new Pen(0xff0000ff, 2));
                    drawText(graphics, (shape.start[0]+shape.end[0])/2, (shape.start[1]+shape.end[1])/2, shape.distance, new Pen(fcolor), new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize)); break;
                case "compass": drawCompass(graphics, shape.center[0], shape.center[1], shape.orientation); break;
                }
            }

            scriptParameters.markers.forEach(marker =>
            {
                drawCircle(graphics, marker.x, marker.y, 5, new Pen(0xffff0000, 2));
                if ( this.showObjectNamesCheckbox.checked )
                    drawText(graphics, marker.x+10, marker.y, marker.name, new Pen(fcolor), new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize));
            });
            graphics.end();

            tempImageWindow.mainView.beginProcess(UndoFlag.NoSwapFile);
            tempImageWindow.mainView.image.blend(bitmap);
            tempImageWindow.mainView.endProcess();

            if ( this.saveCroppedViewOnlyCheckbox.checked )
            {
                let scrollX = Math.round(this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor);
                let scrollY = Math.round(this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor);
                let vW = Math.round(this.ScrollControl.viewport.width  / scriptParameters.zoomFactor);
                let vH = Math.round(this.ScrollControl.viewport.height / scriptParameters.zoomFactor);
                let rW = scriptParameters.imageImage.width, rH = scriptParameters.imageImage.height;
                let P = new DynamicCrop;
                P.refWidth = rW; P.refHeight = rH;
                P.outWidth = Math.floor(vW); P.outHeight = Math.floor(vH);
                P.centerX = (scrollX + vW/2) / rW; P.centerY = (scrollY + vH/2) / rH;
                P.noGUIMessages = true;
                let croppedWin = new ImageWindow(rW, rH, scriptParameters.imageImage.numberOfChannels,
                    scriptParameters.imageImage.bitsPerSample, scriptParameters.imageImage.isReal, scriptParameters.imageImage.isColor);
                croppedWin.mainView.beginProcess(UndoFlag.NoSwapFile);
                croppedWin.mainView.image.assign(tempImageWindow.mainView.image);
                croppedWin.mainView.endProcess();
                P.executeOn(croppedWin.mainView);
                tempImageWindow.forceClose();
                tempImageWindow = croppedWin;
            }

            if ( this.saveCollageCheckbox.checked && scriptParameters.markers.length > 0 )
            {
                let patchSize = 128, space = 64, n = scriptParameters.markers.length;
                let gridSize  = Math.ceil(Math.sqrt(n));
                let cW = patchSize * gridSize + space * (gridSize-1) + 128;
                let cH = patchSize * gridSize + space * (gridSize-1) + 128;
                let collageImage = new Image(cW, cH, 3, 1, 32);
                collageImage.fill(0);
                for ( let i = 0; i < n; i++ )
                {
                    let marker = scriptParameters.markers[i];
                    let row = Math.floor(i / gridSize), col = i % gridSize;
                    let offX = 64 + col * (patchSize + space);
                    let offY = 64 + row * (patchSize + space);
                    for ( let y = 0; y < patchSize; y++ )
                        for ( let x = 0; x < patchSize; x++ )
                        {
                            let px = marker.x - Math.floor(patchSize/2) + x;
                            let py = marker.y - Math.floor(patchSize/2) + y;
                            if ( px >= 0 && px < scriptParameters.imageImage.width &&
                                 py >= 0 && py < scriptParameters.imageImage.height )
                            {
                                if ( scriptParameters.imageImage.numberOfChannels === 1 )
                                {
                                    let gv = scriptParameters.imageImage.sample(px, py, 0);
                                    for ( let c = 0; c < 3; c++ ) collageImage.setSample(gv, offX+x, offY+y, c);
                                }
                                else
                                    for ( let c = 0; c < 3; c++ )
                                        collageImage.setSample(scriptParameters.imageImage.sample(px,py,c), offX+x, offY+y, c);
                            }
                        }
                }
                let collageBitmap = new Bitmap(cW, cH);
                let cg = new Graphics(collageBitmap); cg.antialiasing = true;
                for ( let i = 0; i < n; i++ )
                {
                    let marker = scriptParameters.markers[i];
                    let row = Math.floor(i/gridSize), col = i % gridSize;
                    let offX = 64 + col*(patchSize+space);
                    let offY = 64 + row*(patchSize+space);
                    let textYOffset = (col % 2 === 0) ? patchSize+15 : patchSize+30;
                    drawText(cg, offX+10, offY+textYOffset, marker.name, new Pen(fcolor), new Font("Arial", 12));
                }
                cg.end();
                collageImage.blend(collageBitmap);
                let collageWin = new ImageWindow(cW, cH, 3, 32, true, false);
                collageWin.mainView.beginProcess(UndoFlag.NoSwapFile);
                collageWin.mainView.image.assign(collageImage);
                collageWin.mainView.endProcess();
                let sfdC = new SaveFileDialog();
                sfdC.caption = "Save Collage Image";
                sfdC.filters = [["JPEG Files",".jpg"],["PNG Files",".png"],["TIFF Files",".tiff"],["All Files","*"]];
                if ( sfdC.execute() ) { collageWin.saveAs(sfdC.fileName); console.writeln("Collage saved: " + sfdC.fileName); }
                collageWin.forceClose();
            }

            let sfd = new SaveFileDialog;
            sfd.caption = "Save Annotated Image";
            sfd.filters = [["JPEG Files",".jpg"],["PNG Files",".png"],["TIFF Files",".tiff"],["All Files","*"]];
            if ( sfd.execute() ) { tempImageWindow.saveAs(sfd.fileName); tempImageWindow.forceClose(); }
            else tempImageWindow.forceClose();
        };

        // ---- Annotation tools ----
        this.annotationToolsButton = new PushButton(this);
        this.annotationToolsButton.text    = "Annotation Tools";
        this.annotationToolsButton.icon    = ":/icons/brush.png";
        this.annotationToolsButton.toolTip = "Open the annotation tools panel.";
        this.annotationToolsButton.onClick = () => { this.toggleAnnotationToolsPanel(); };

        this.setDrawingMode = (mode) =>
        {
            this.currentDrawingMode = mode;
            console.writeln("Drawing mode set to: " + mode);
        };

        this.createAnnotationToolsPanel = (parent) =>
        {
            let panel = new Control(parent);
            panel.sizer = new HorizontalSizer; panel.sizer.spacing = 4;
            panel.hide();

            // Font options column
            let fontOptionsSizer = new VerticalSizer; fontOptionsSizer.spacing = 4;

            let fontLabel = new Label(panel); fontLabel.text = "Font:"; fontLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
            fontOptionsSizer.add(fontLabel);

            this.fontComboBox = new ComboBox(panel);
            ["Arial","Courier New","Times New Roman","Verdana","DejaVu Sans"].forEach(f => this.fontComboBox.addItem(f));
            this.fontComboBox.currentItem = this.fontComboBox.findItem(scriptParameters.selectedFont);
            this.fontComboBox.onItemSelected = index => { scriptParameters.selectedFont = this.fontComboBox.itemText(index); this.ScrollControl.viewport.update(); };
            fontOptionsSizer.add(this.fontComboBox);

            let fontSizeLabel = new Label(panel); fontSizeLabel.text = "Font Size:"; fontSizeLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
            fontOptionsSizer.add(fontSizeLabel);

            this.fontSizeComboBox = new ComboBox(panel);
            for ( let size = 8; size <= 36; size += 2 ) this.fontSizeComboBox.addItem(size.toString());
            this.fontSizeComboBox.currentItem = this.fontSizeComboBox.findItem(scriptParameters.selectedFontSize.toString());
            this.fontSizeComboBox.onItemSelected = index => { scriptParameters.selectedFontSize = parseInt(this.fontSizeComboBox.itemText(index), 10); this.ScrollControl.viewport.update(); };
            fontOptionsSizer.add(this.fontSizeComboBox);

            let fontColorLabel = new Label(panel); fontColorLabel.text = "Font Color:"; fontColorLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
            fontOptionsSizer.add(fontColorLabel);

            this.fontColorComboBox = new WIMIColorComboBox(panel, scriptParameters.selectedFontColor);
            this.fontColorComboBox.onItemSelected = index => { scriptParameters.selectedFontColor = this.fontColorComboBox.getColorValue(); this.ScrollControl.viewport.update(); };
            fontOptionsSizer.add(this.fontColorComboBox);

            let markerShapeLabel = new Label(panel); markerShapeLabel.text = "Marker Shape:"; markerShapeLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
            fontOptionsSizer.add(markerShapeLabel);

            this.markerShapeComboBox = new ComboBox(panel);
            this.markerShapeComboBox.addItem("Circle"); this.markerShapeComboBox.addItem("Cross");
            this.markerShapeComboBox.currentItem = this.markerShapeComboBox.findItem(scriptParameters.selectedMarkerShape);
            this.markerShapeComboBox.onItemSelected = index => { scriptParameters.selectedMarkerShape = this.markerShapeComboBox.itemText(index); this.ScrollControl.viewport.update(); };
            fontOptionsSizer.add(this.markerShapeComboBox);
            panel.sizer.add(fontOptionsSizer);

            // Tools column
            let toolsSizer = new VerticalSizer; toolsSizer.spacing = 4;

            let instrLabel = new Label(panel);
            instrLabel.text = "Select a Drawing Function then Alt+Click and Drag to draw.\nUse the Spacebar to cycle through drawn shapes";
            instrLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
            toolsSizer.add(instrLabel);

            let shapeColorLabel = new Label(panel); shapeColorLabel.text = "Shape Color:"; shapeColorLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
            toolsSizer.add(shapeColorLabel);

            this.shapeColorComboBox = new WIMIColorComboBox(panel, 0xffffff00);
            this.shapeColorComboBox.onItemSelected = index => { scriptParameters.selectedShapeColor = this.shapeColorComboBox.getColorValue(); this.ScrollControl.viewport.update(); };
            toolsSizer.add(this.shapeColorComboBox);

            let checkboxSizer = new HorizontalSizer; checkboxSizer.spacing = 4;
            let leftColSizer  = new VerticalSizer; leftColSizer.spacing = 4;
            let rightColSizer = new VerticalSizer; rightColSizer.spacing = 4;

            const makeDrawCheckbox = (label, mode, target, others) =>
            {
                let cb = new CheckBox(panel); cb.text = label;
                cb.onCheck = () =>
                {
                    if ( cb.checked )
                    {
                        this.setDrawingMode(mode);
                        others.forEach(o => { if ( o !== cb ) o.checked = false; });
                    }
                };
                return cb;
            };

            this.ellipseCheckbox   = new CheckBox(panel); this.ellipseCheckbox.text   = "Draw Ellipse";
            this.freehandCheckbox  = new CheckBox(panel); this.freehandCheckbox.text  = "Freehand (Lasso)";
            this.rectangleCheckbox = new CheckBox(panel); this.rectangleCheckbox.text = "Draw Rectangle";
            this.arrowCheckbox     = new CheckBox(panel); this.arrowCheckbox.text     = "Draw Arrow";
            this.placeCompassCheckbox = new CheckBox(panel); this.placeCompassCheckbox.text = "Place Celestial Compass";
            this.textCheckbox      = new CheckBox(panel); this.textCheckbox.text      = "Add Text";

            let allDrawCbs = [this.ellipseCheckbox, this.freehandCheckbox, this.rectangleCheckbox,
                              this.arrowCheckbox, this.placeCompassCheckbox, this.textCheckbox];

            const wireDrawCb = (cb, mode) =>
            {
                cb.onCheck = () =>
                {
                    if ( cb.checked )
                    {
                        this.setDrawingMode(mode);
                        allDrawCbs.forEach(o => { if ( o !== cb ) o.checked = false; });
                    }
                };
            };
            wireDrawCb(this.ellipseCheckbox,      "ellipse");
            wireDrawCb(this.freehandCheckbox,     "freehand");
            wireDrawCb(this.rectangleCheckbox,    "rectangle");
            wireDrawCb(this.arrowCheckbox,        "arrow");
            wireDrawCb(this.placeCompassCheckbox, "compass");
            wireDrawCb(this.textCheckbox,         "text");

            leftColSizer.add(this.ellipseCheckbox);
            leftColSizer.add(this.freehandCheckbox);
            leftColSizer.add(this.rectangleCheckbox);
            rightColSizer.add(this.arrowCheckbox);
            rightColSizer.add(this.placeCompassCheckbox);
            checkboxSizer.add(leftColSizer); checkboxSizer.add(rightColSizer);
            toolsSizer.add(checkboxSizer);

            let textSizer = new HorizontalSizer; textSizer.spacing = 4;
            textSizer.add(this.textCheckbox);
            this.textInput = new Edit(panel); this.textInput.setMinWidth(200);
            textSizer.add(this.textInput);
            toolsSizer.add(textSizer);
            panel.sizer.add(toolsSizer);

            // Buttons column
            let buttonsSizer = new VerticalSizer; buttonsSizer.spacing = 4;

            this.undoButton = new PushButton(panel); this.undoButton.text = "Remove Active Shape"; this.undoButton.icon = ":/icons/undo.png";
            this.undoButton.onClick = () =>
            {
                if ( this.activeShapeIndex !== -1 && scriptParameters.shapes.length > 0 )
                {
                    scriptParameters.shapes.splice(this.activeShapeIndex, 1);
                    this.activeShapeIndex = scriptParameters.shapes.length > 0
                        ? (this.activeShapeIndex - 1 + scriptParameters.shapes.length) % scriptParameters.shapes.length
                        : -1;
                    this.ScrollControl.viewport.update();
                    this.MiniPreviewControl.viewport.update();
                }
            };
            buttonsSizer.add(this.undoButton);

            let clearAllButton = new PushButton(panel); clearAllButton.text = "Clear All"; clearAllButton.icon = ":/icons/cancel.png";
            clearAllButton.onClick = () =>
            {
                scriptParameters.shapes = [];
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            };
            buttonsSizer.add(clearAllButton);

            this.deleteMarkerButton = new PushButton(panel); this.deleteMarkerButton.text = "Delete Marker"; this.deleteMarkerButton.icon = ":/icons/delete.png";
            this.deleteMarkerButton.onClick = () => { this.deleteHighlightedMarker(); };
            buttonsSizer.add(this.deleteMarkerButton);
            panel.sizer.add(buttonsSizer);

            return panel;
        };

        this.deleteHighlightedMarker = () =>
        {
            let selectedNodes = this.resultTreeBox.selectedNodes;
            if ( selectedNodes.length === 0 ) { console.writeln("No marker selected for deletion."); return; }
            for ( let j = 0; j < selectedNodes.length; j++ )
            {
                let node = selectedNodes[j];
                let selectedRA = parseFloat(node.text(0)), selectedDec = parseFloat(node.text(1));
                let idx = -1;
                for ( let i = 0; i < scriptParameters.markers.length; i++ )
                    if ( scriptParameters.markers[i].ra === selectedRA && scriptParameters.markers[i].dec === selectedDec )
                    { idx = i; break; }
                if ( idx !== -1 ) scriptParameters.markers.splice(idx, 1);
                this.resultTreeBox.remove(this.resultTreeBox.childIndex(node));
            }
            scriptParameters.highlightedMarker = null;
            this.ScrollControl.viewport.update();
            this.MiniPreviewControl.viewport.update();
        };

        this.annotationToolsPanel = this.createAnnotationToolsPanel(this);

        this.toggleAnnotationToolsPanel = () =>
        {
            if ( this.annotationToolsPanel.visible ) this.annotationToolsPanel.hide();
            else                                     this.annotationToolsPanel.show();
            this.adjustDialogSize();
        };

        // ---- Zoom buttons ----
        this.zoomInButton = new PushButton(this);
        this.zoomInButton.text = ""; this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
        this.zoomInButton.toolTip = "Zoom In";
        this.zoomInButton.onClick = () => { this.ScrollControl.zoomIn(); };

        this.zoomOutButton = new PushButton(this);
        this.zoomOutButton.text = ""; this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
        this.zoomOutButton.toolTip = "Zoom Out";
        this.zoomOutButton.onClick = () => { this.ScrollControl.zoomOut(); };

        this.zoomLabel = new Label(this);
        this.zoomLabel.text = "Buttons to Zoom In/Out or Use Mouse Wheel";

        this.zoomSizer = new HorizontalSizer; this.zoomSizer.spacing = 6;
        this.zoomSizer.add(this.zoomInButton); this.zoomSizer.add(this.zoomOutButton);
        this.zoomSizer.add(this.zoomLabel); this.zoomSizer.addStretch();

        // ---- New Instance button ----
        this.newInstanceButton = new ToolButton(this);
        this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
        this.newInstanceButton.setScaledFixedSize(24, 24);
        this.newInstanceButton.toolTip = "New Instance";
        this.newInstanceButton.onMousePress = () => { scriptParameters.save(); this.newInstance(); };

        // ---- Layout assembly ----
        this.saveButtonSizer = new HorizontalSizer; this.saveButtonSizer.addStretch();
        this.saveButtonSizer.add(this.annotationToolsButton);
        this.saveButtonSizer.addSpacing(10);
        this.saveButtonSizer.add(this.saveAnnotatedImageButton);
        this.saveButtonSizer.addSpacing(10);
        this.saveButtonSizer.add(this.saveCroppedViewOnlyCheckbox);
        this.saveButtonSizer.add(this.saveCollageCheckbox);
        this.saveButtonSizer.addStretch();

        this.searchButtonSizer = new HorizontalSizer; this.searchButtonSizer.margin = 0;
        this.searchButtonSizer.add(this.simbadButton);
        this.searchButtonSizer.addSpacing(10);
        this.searchButtonSizer.add(this.saveCsvButton);

        this.advancedSearchButtonSizer = new HorizontalSizer; this.advancedSearchButtonSizer.margin = 0;
        this.advancedSearchButtonSizer.add(this.advancedSearchButton);
        this.advancedSearchButtonSizer.addSpacing(10);
        this.advancedSearchButtonSizer.add(this.toggleMarkersButton);

        this.utilButtonSizer = new VerticalSizer; this.utilButtonSizer.margin = 0;
        this.utilButtonSizer.add(this.advancedSearchButtonSizer);
        this.utilButtonSizer.addSpacing(10);
        this.utilButtonSizer.add(this.searchButtonSizer);

        this.execButtonSizer = new HorizontalSizer; this.execButtonSizer.margin = 0; this.execButtonSizer.spacing = 10;
        this.execButtonSizer.add(this.newInstanceButton);
        this.execButtonSizer.add(this.cancelButton);
        this.execButtonSizer.add(this.maxDownloadsButton);

        this.rightSidebarVertical = new VerticalSizer; this.rightSidebarVertical.margin = 0;
        this.rightSidebarVertical.add(this.resultAlphaFormatGroupBoxH);
        this.rightSidebarVertical.addSpacing(10);
        this.rightSidebarVertical.add(this.resultDeltaFormatGroupBoxH);
        this.rightSidebarVertical.addSpacing(10);
        this.rightSidebarVertical.add(this.autoStretchButtonSizer);
        this.rightSidebarVertical.addSpacing(10);
        this.rightSidebarVertical.add(this.utilButtonSizer);
        this.rightSidebarVertical.addSpacing(10);
        this.rightSidebarVertical.add(this.toggleAndNamesSizer);
        this.rightSidebarVertical.addStretch();
        this.rightSidebarVertical.add(this.MiniPreviewControl);
        this.rightSidebarVertical.add(this.instructionLabel);
        this.rightSidebarVertical.addStretch();
        this.rightSidebarVertical.add(this.authorshipLabel);
        this.rightSidebarVertical.addStretch();
        this.rightSidebarVertical.add(this.cursorDataHorizontal);
        this.rightSidebarVertical.addSpacing(10);
        this.rightSidebarVertical.add(this.copyRaDecButton);
        this.rightSidebarVertical.addSpacing(10);
        this.rightSidebarVertical.add(this.execButtonSizer);

        this.leftBodyVertical = new VerticalSizer; this.leftBodyVertical.margin = 0;
        this.leftBodyVertical.add(this.zoomSizer);
        this.leftBodyVertical.add(this.ScrollControl);
        this.leftBodyVertical.add(this.saveButtonSizer);
        this.leftBodyVertical.add(this.clickLabel);
        this.leftBodyVertical.add(this.resultTreeBox);

        this.advancedSearchVertical = new VerticalSizer; this.advancedSearchVertical.margin = 0;
        this.advancedSearchVertical.add(this.advancedSearchPanel);

        this.mainHorizontal = new HorizontalSizer; this.mainHorizontal.margin = 0;
        this.mainHorizontal.add(this.rightSidebarVertical);
        this.mainHorizontal.addSpacing(10);
        this.mainHorizontal.add(this.leftBodyVertical, 1);
        this.mainHorizontal.addSpacing(10);
        this.mainHorizontal.add(this.advancedSearchVertical);

        this.sizer = new VerticalSizer; this.sizer.margin = 10;
        this.sizer.add(this.titleLabel);
        this.sizer.addSpacing(10);
        this.sizer.add(this.mainHorizontal);
        this.sizer.addSpacing(10);
        this.sizer.add(this.annotationToolsPanel);
    }
};

// ============================================================================
// WCS / Metadata infrastructure (unchanged algorithm — V8 enum fixes only)
// ============================================================================

#define Ext_DataType_Complex     1000
#define Ext_DataType_StringArray 1001
#define Ext_DataType_JSON        1002

#define WCS_MAX_STARS_IN_SOLUTION 50000
#define WCS_MAX_SPLINE_POINTS     2100

#include <pjsr/PropertyType.jsh>
#include <pjsr/PropertyAttribute.jsh>
#include <pjsr/RBFType.jsh>

function ObjectWithSettings( module, prefix, properties )
{
    this.module     = module;
    this.prefix     = prefix ? prefix.replace(/ /g,'') : null;
    this.properties = properties;

    this.MakeSettingsKey = function( property )
    {
        let key = "";
        if ( this.module && this.module.length > 0 ) key = this.module + "/";
        if ( this.prefix && prefix.length > 0 )      key = key + this.prefix + "/";
        return key + property;
    };

    this.LoadSettings = function()
    {
        for ( let i = 0; i < this.properties.length; ++i )
        {
            let property = this.properties[i][0];
            if ( property )
                if ( this.properties[i][1] == Ext_DataType_Complex )
                {
                    if ( this[property] && typeof(this[property].LoadSettings) === 'function' )
                        this[property].LoadSettings();
                }
                else if ( this.properties[i][1] == Ext_DataType_JSON )
                {
                    let value = Settings.read(this.MakeSettingsKey(property), DataType_UCString);
                    if ( Settings.lastReadOK ) this[property] = JSON.parse(value);
                }
                else if ( this.properties[i][1] == Ext_DataType_StringArray )
                {
                    let value = Settings.read(this.MakeSettingsKey(property), DataType_UCString);
                    if ( Settings.lastReadOK ) this[property] = value.split("|");
                }
                else
                {
                    let value = Settings.read(this.MakeSettingsKey(property), this.properties[i][1]);
                    if ( Settings.lastReadOK ) this[property] = value;
                }
        }
    };

    this.SaveSettings = function()
    {
        for ( let i = 0; i < this.properties.length; ++i )
        {
            let property = this.properties[i][0];
            if ( this[property] != null )
            {
                if ( this.properties[i][1] == Ext_DataType_Complex )
                    this[property].SaveSettings();
                else if ( this.properties[i][1] == Ext_DataType_JSON )
                    Settings.write(this.MakeSettingsKey(property), DataType_UCString, JSON.stringify(this[property]));
                else if ( this.properties[i][1] == Ext_DataType_StringArray )
                {
                    let concatString = this.CreateStringArray(this[property]);
                    if ( concatString != null )
                        Settings.write(this.MakeSettingsKey(property), DataType_UCString, concatString);
                }
                else
                    Settings.write(this.MakeSettingsKey(property), this.properties[i][1], this[property]);
            }
            else Settings.remove(this.MakeSettingsKey(property));
        }
    };

    this.DeleteSettings = function() { Settings.remove(this.prefix); };

    this.MakeParamsKey = function( property )
    {
        let key = "";
        if ( this.prefix && this.prefix.length > 0 ) key = this.prefix.replace("-","") + "_";
        return key + property;
    };

    this.LoadParameters = function()
    {
        for ( let i = 0; i < this.properties.length; ++i )
        {
            let property = this.properties[i][0];
            if ( property )
                if ( this.properties[i][1] == Ext_DataType_Complex )
                    this[property].LoadParameters();
                else
                {
                    let key = this.MakeParamsKey(property);
                    if ( Parameters.has(key) )
                    {
                        switch( this.properties[i][1] )
                        {
                        case DataType_Boolean:  this[property] = Parameters.getBoolean(key); break;
                        case DataType_Int8: case DataType_UInt8: case DataType_Int16: case DataType_UInt16:
                        case DataType_Int32: case DataType_UInt32: case DataType_Int64: case DataType_UInt64:
                            this[property] = parseInt(Parameters.get(key)); break;
                        case DataType_Double: case DataType_Float:
                            this[property] = Parameters.getReal(key); break;
                        case DataType_String: case DataType_UCString:
                            this[property] = Parameters.getString(key); break;
                        case Ext_DataType_JSON:
                            this[property] = JSON.parse(Parameters.getString(key).replace(/\'\'/g,"\"")); break;
                        case Ext_DataType_StringArray:
                        {
                            let value = Parameters.getString(key);
                            if ( value ) this[property] = value.split("|");
                            break;
                        }
                        default: console.writeln("Unknown property type '", this.properties[i][1] + "'");
                        }
                    }
                }
        }
    };

    this.SaveParameters = function()
    {
        for ( let i = 0; i < this.properties.length; ++i )
        {
            let property = this.properties[i][0];
            if ( this[property] != null )
            {
                if ( this.properties[i][1] == Ext_DataType_Complex )
                    this[property].SaveParameters();
                else if ( this.properties[i][1] == Ext_DataType_JSON )
                    Parameters.set(this.MakeParamsKey(property), JSON.stringify(this[property]).replace(/\"/g,"\'\'"));
                else if ( this.properties[i][1] == Ext_DataType_StringArray )
                {
                    let array = this.CreateStringArray(this[property]);
                    if ( array != null ) Parameters.set(this.MakeParamsKey(property), array);
                }
                else Parameters.set(this.MakeParamsKey(property), this[property]);
            }
        }
    };

    this.CreateStringArray = function( array )
    {
        let str = null;
        for ( let j = 0; j < array.length; ++j )
            str = (str == null) ? (array[j] || "") : str + "|" + (array[j] || "");
        return str;
    };
}


// ----------------------------------------------------------------------------

function WCSKeywords()
{
   this.radesys = null;
   this.objctra = null;
   this.objctdec = null;
   this.epoch = null;
   this.endTime = null;
   this.longobs = null;
   this.latobs = null;
   this.altobs = null;
   this.focallen = null;
   this.xpixsz = null;
   this.ctype1 = null;
   this.ctype2 = null;
   this.crval1 = null;
   this.crval2 = null;
   this.crpix1 = null;
   this.crpix2 = null;
   this.pv1_1 = null;
   this.pv1_2 = null;
   this.lonpole = null;
   this.latpole = null;
   this.cd1_1 = null;
   this.cd1_2 = null;
   this.cd2_1 = null;
   this.cd2_2 = null;
   this.cdelt1 = null;
   this.cdelt2 = null;
   this.crota1 = null;
   this.crota2 = null;

   // Synthesized observation time from DATE-OBS and DATE-END/EXPTIME.
   this.observationTime = null;

   this.Read = function( window )
   {
      let expTime = null; // only if Observation:Time:End is not available

      let view = window.mainView;

      /*
       * Basic image metadata
       */
      if ( view.hasProperty( "Observation:CelestialReferenceSystem" ) )
         this.radesys = view.propertyValue( "Observation:CelestialReferenceSystem" );
      if ( view.hasProperty( "Observation:Center:RA" ) )
         this.objctra = view.propertyValue( "Observation:Center:RA" );
      if ( view.hasProperty( "Observation:Center:Dec" ) )
         this.objctdec = view.propertyValue( "Observation:Center:Dec" );
      if ( view.hasProperty( "Observation:Time:Start" ) )
         this.epoch = Math.calendarTimeToJD( view.propertyValue( "Observation:Time:Start" ).toISOString() );
      if ( view.hasProperty( "Observation:Time:End" ) )
         this.endTime = Math.calendarTimeToJD( view.propertyValue( "Observation:Time:End" ).toISOString() );
      if ( view.hasProperty( "Observation:Location:Longitude" ) )
         this.longobs = view.propertyValue( "Observation:Location:Longitude" );
      if ( view.hasProperty( "Observation:Location:Latitude" ) )
         this.latobs = view.propertyValue( "Observation:Location:Latitude" );
      if ( view.hasProperty( "Observation:Location:Elevation" ) )
         this.altobs = view.propertyValue( "Observation:Location:Elevation" );
      if ( view.hasProperty( "Instrument:Telescope:FocalLength" ) )
         this.focallen = view.propertyValue( "Instrument:Telescope:FocalLength" ) * 1000;
      if ( view.hasProperty( "Instrument:Sensor:XPixelSize" ) )
         this.xpixsz = view.propertyValue( "Instrument:Sensor:XPixelSize" );
      if ( view.hasProperty( "Instrument:ExposureTime" ) )
         expTime = view.propertyValue( "Instrument:ExposureTime" );

      /*
       * Native astrometric solution - since core version 1.8.9-2
       * ### TODO: When defined by the XISF standard, remove the PCL prefix.
       */
      if ( view.hasProperty( "PCL:AstrometricSolution:ProjectionSystem" ) )
      {
         let projId = view.propertyValue( "PCL:AstrometricSolution:ProjectionSystem" );
         let wcsCode = "";
         switch ( projId )
         {
         case "Gnomonic":
            wcsCode = "TAN";
            break;
         case "Stereographic":
            wcsCode = "STG";
            break;
         case "PlateCarree":
            wcsCode = "CAR";
            break;
         case "Mercator":
            wcsCode = "MER";
            break;
         case "HammerAitoff":
            wcsCode = "AIT";
            break;
         case "ZenithalEqualArea":
            wcsCode = "ZEA";
            break;
         case "Orthographic":
            wcsCode = "SIN";
            break;
         default:
            throw new Error( "WCSKeywords: Invalid/unsupported projection identifier \'" + projId + '\'' );
         }
         this.ctype1 = "'RA---" + wcsCode + "'";
         this.ctype2 = "'DEC--" + wcsCode + "'";
      }

      if ( view.hasProperty( "PCL:AstrometricSolution:ReferenceCelestialCoordinates" ) )
      {
         let p = view.propertyValue( "PCL:AstrometricSolution:ReferenceCelestialCoordinates" );
         if ( (p instanceof Vector) && p.length >= 2 )
         {
            this.crval1 = p.at( 0 );
            this.crval2 = p.at( 1 );
         }
         else
            console.warningln( "** Warning: WCSKeywords: Invalid PCL:AstrometricSolution:ReferenceCelestialCoordinates property value." );
      }

      if ( view.hasProperty( "PCL:AstrometricSolution:ReferenceImageCoordinates" ) )
      {
         let p = view.propertyValue( "PCL:AstrometricSolution:ReferenceImageCoordinates" );
         if ( (p instanceof Vector) && p.length >= 2 )
         {
            this.crpix1 = p.at( 0 );
            this.crpix2 = p.at( 1 );
         }
         else
            console.warningln( "** Warning: WCSKeywords: Invalid PCL:AstrometricSolution:ReferenceImageCoordinates property value." );
      }

      if ( view.hasProperty( "PCL:AstrometricSolution:ReferenceNativeCoordinates" ) )
      {
         let p = view.propertyValue( "PCL:AstrometricSolution:ReferenceNativeCoordinates" );
         if ( (p instanceof Vector) && p.length >= 2 )
         {
            this.pv1_1 = p.at( 0 );
            this.pv1_2 = p.at( 1 );
         }
         else
            console.warningln( "** Warning: WCSKeywords: Invalid PCL:AstrometricSolution:ReferenceNativeCoordinates property value." );
      }

      if ( view.hasProperty( "PCL:AstrometricSolution:CelestialPoleNativeCoordinates" ) )
      {
         let p = view.propertyValue( "PCL:AstrometricSolution:CelestialPoleNativeCoordinates" );
         if ( (p instanceof Vector) && p.length >= 2 )
         {
            this.lonpole = p.at( 0 );
            this.latpole = p.at( 1 );
         }
         else
            console.warningln( "** Warning: WCSKeywords: Invalid PCL:AstrometricSolution:CelestialPoleNativeCoordinates property value." );
      }

      if ( view.hasProperty( "PCL:AstrometricSolution:LinearTransformationMatrix" ) )
      {
         let L = view.propertyValue( "PCL:AstrometricSolution:LinearTransformationMatrix" );
         if ( (L instanceof Matrix) && L.rows == 2 && L.columns == 2 )
         {
            this.cd1_1 = L.at( 0, 0 );
            this.cd1_2 = L.at( 0, 1 );
            this.cd2_1 = L.at( 1, 0 );
            this.cd2_2 = L.at( 1, 1 );
         }
         else
            console.warningln( "** Warning: WCSKeywords: Invalid PCL:AstrometricSolution:LinearTransformationMatrix property value." );
      }

      this.fromFITS = this.cd1_1 === null;

      /*
       * Standard WCS FITS keywords
       */
      let keywords = window.keywords;
      for ( let i = 0; i < keywords.length; ++i )
      {
         let name = keywords[i].name;
         let value = keywords[i].strippedValue;
         if ( this.ctype1 === null && name == "CTYPE1" )
            this.ctype1 = "'" + value + "'";
         else if ( this.ctype2 === null && name == "CTYPE2" )
            this.ctype2 = "'" + value + "'";
         else if ( this.crval1 === null && name == "CRVAL1" )
            this.crval1 = parseFloat( value );
         else if ( this.crval2 === null && name == "CRVAL2" )
            this.crval2 = parseFloat( value );
         else if ( this.crpix1 === null && name == "CRPIX1" )
            this.crpix1 = parseFloat( value );
         else if ( this.crpix2 === null && name == "CRPIX2" )
            this.crpix2 = parseFloat( value );
         else if ( this.cd1_1 === null && name == "CD1_1" )
            this.cd1_1 = parseFloat( value );
         else if ( this.cd1_2 === null && name == "CD1_2" )
            this.cd1_2 = parseFloat( value );
         else if ( this.cd2_1 === null && name == "CD2_1" )
            this.cd2_1 = parseFloat( value );
         else if ( this.cd2_2 === null && name == "CD2_2" )
            this.cd2_2 = parseFloat( value );
         else if ( this.pv1_1 === null && name == "PV1_1" )
            this.pv1_1 = parseFloat( value );
         else if ( this.pv1_2 === null && name == "PV1_2" )
            this.pv1_2 = parseFloat( value );
         else if ( this.lonpole === null && (name == "PV1_3" || name == "LONPOLE") )
            this.lonpole = parseFloat( value );
         else if ( this.latpole === null && (name == "PV1_4" || name == "LATPOLE") )
            this.latpole = parseFloat( value );
         // AIPS keywords
         else if ( name == "CDELT1" )
            this.cdelt1 = parseFloat( value );
         else if ( name == "CDELT2" )
            this.cdelt2 = parseFloat( value );
         else if ( name == "CROTA1" )
            this.crota1 = parseFloat( value );
         else if ( name == "CROTA2" )
            this.crota2 = parseFloat( value );
      }

      /*
       * Primary optional FITS keywords.
       */
      for ( let i = 0; i < keywords.length; ++i )
      {
         let name = keywords[i].name;
         let value = keywords[i].strippedValue;

         if ( this.radesys === null && name == "RADESYS" )
         {
            /*
             * Reference system of celestial coordinates.
             */
            this.radesys = value;
         }
         else if ( this.objctra === null && name == "RA" )
         {
            /*
             * The RA keyword value can be either a complex angular
             * representation in hours (hh mm ss.sss) or a scalar in degrees
             * ([+|-]ddd.dddddd).
             */
            if ( value.indexOf( ' ' ) > 0 || value.indexOf( ':' ) > 0 )
            {
               let angle = DMSangle.FromString( value, 0, 24 );
               if ( angle != null )
                  this.objctra = 15*angle.GetValue();
            }
            else
               this.objctra = parseFloat( value );
         }
         else if ( this.objctdec === null && name == "DEC" )
         {
            /*
             * The DEC keyword value can be either a complex angular
             * representation in degrees ([+|-]dd mm ss.sss) or a scalar
             * ([+|-]ddd.dddddd), also in degrees.
             */
            if ( value.indexOf( ' ' ) > 0 || value.indexOf( ':' ) > 0 )
            {
               let angle = DMSangle.FromString( value, 0, 90 );
               if ( angle != null )
                  this.objctdec = angle.GetValue();
            }
            else
               this.objctdec = parseFloat( value );
         }
         else if ( this.epoch === null && name == "DATE-BEG" )
         {
            let date = this.ExtractDate( value );
            if ( date )
               this.epoch = date;
         }
         else if ( this.endTime === null && name == "DATE-END" )
         {
            let date = this.ExtractDate( value );
            if ( date )
               this.endTime = date;
         }
         else if ( this.longobs === null && name == "OBSGEO-L" )
         {
            /*
             * The OBSGEO-L keyword value can be either a complex angular
             * representation in degrees ([+|-]ddd mm ss.sss) or a scalar in
             * degrees ([+|-]ddd.dddddd).
             */
            if ( value.indexOf( ' ' ) > 0 || value.indexOf( ':' ) > 0 )
            {
               let angle = DMSangle.FromString( value, 0, 180 ); // positive East
               if ( angle != null )
                  this.longobs = angle.GetValue();
            }
            else
               this.longobs = parseFloat( value );
         }
         else if ( this.latobs === null && name == "OBSGEO-B" )
         {
            /*
             * The OBSGEO-B keyword value can be either a complex angular
             * representation in degrees ([+|-]dd mm ss.sss) or a scalar in
             * degrees ([+|-]dd.dddddd).
             */
            if ( value.indexOf( ' ' ) > 0 || value.indexOf( ':' ) > 0 )
            {
               let angle = DMSangle.FromString( value, 0, 90 ); // positive North
               if ( angle != null )
                  this.latobs = angle.GetValue();
            }
            else
               this.latobs = parseFloat( value );
         }
         else if ( this.altobs === null && name == "OBSGEO-H" )
            this.altobs = parseFloat( value );
         else if ( this.focallen === null && name == "FOCALLEN" )
            this.focallen = parseFloat( value );
         else if ( this.xpixsz === null && name == "XPIXSZ" )
            this.xpixsz = parseFloat( value );
         else if ( expTime === null && name == "EXPTIME" )
            expTime = parseFloat( value );
      }

      /*
       * Secondary optional FITS keywords, supported for compatibility with
       * some applications.
       */
      for ( let i = 0; i < keywords.length; ++i )
      {
         let name = keywords[i].name;
         let value = keywords[i].strippedValue;

         if ( this.objctra == null && name == "OBJCTRA" )
         {
            /*
             * The OBJCTRA keyword value must be a complex angular
             * representation in hours (hh mm ss.sss)
             */
            let angle = DMSangle.FromString( value, 0, 24 );
            if ( angle != null )
               this.objctra = 15*angle.GetValue();
         }
         else if ( this.objctdec == null && name == "OBJCTDEC" )
         {
            /*
             * The OBJCTDEC keyword value must be a complex angular
             * representation in degrees ([+|-]dd mm ss.ss)
             */
            let angle = DMSangle.FromString( value, 0, 90 );
            if ( angle != null )
               this.objctdec = angle.GetValue();
         }
         else if ( this.epoch == null && name == "DATE-OBS" )
         {
            let date = this.ExtractDate( value );
            if ( date )
               this.epoch = date;
         }
         else if ( this.longobs == null && (name == "LONG-OBS" || name == "SITELONG") )
         {
            /*
             * The LONG-OBS or SITELONG keyword value must be a complex angular
             * representation in degrees ([+|-]ddd mm ss.sss).
             */
            let angle = DMSangle.FromString( value, 0, 180 ); // positive East
            this.longobs = (angle != null) ? angle.GetValue() : parseFloat( value );
         }
         else if ( this.latobs == null && (name == "LAT-OBS" || name == "SITELAT") )
         {
            /*
             * The LAT-OBS or SITELAT keyword value must be a complex angular
             * representation in degrees ([+|-]dd mm ss.sss).
             */
            let angle = DMSangle.FromString( value, 0, 90 ); // positive North
            this.latobs = (angle != null) ? angle.GetValue() : parseFloat( value );
         }
         else if ( this.altobs == null && (name == "ALT-OBS" || name == "SITEELEV") )
         {
            this.altobs = parseFloat( value );
         }
         else if ( this.xpixsz == null && name == "PIXSIZE" )
            this.xpixsz = parseFloat( value );
         else if ( expTime == null && name == "EXPOSURE" )
            expTime = parseFloat( value );
      }

      if ( this.epoch == null )
      {
         // Don't let funny FITS header data fool us.
         this.endTime = this.observationTime = null;
      }
      else
      {
         let endTime = null;

         /*
          * If Observation:Time:End (DATE-END) is not available, try to
          * approximate it from the observation start time and exposure time.
          */
         if ( this.endTime == null )
         {
            if ( expTime != null )
               endTime = this.epoch + expTime/86400;
         }
         else
         {
            // For mental sanity.
            if ( this.endTime < this.epoch )
            {
               let t = this.epoch;
               this.epoch = this.endTime;
               this.endTime = t;
            }
            endTime = this.endTime;
         }

         /*
          * Try to synthesize the observation middle time. This is the time
          * point we should use for all solar system ephemeris calculations.
          */
         if ( endTime != null )
            this.observationTime = this.epoch + (endTime - this.epoch)/2;
         else
            this.observationTime = this.epoch;
      }
   };

   this.ExtractDate = function( timeStr )
   {
      let match = timeStr.match("'?([0-9]*)-([0-9]*)-([0-9]*)(T([0-9]*):([0-9]*):([0-9]*(\.[0-9]*)?))?'?");
      if( match == null)
         return null;
      let year = parseInt( match[1], 10 );
      let month = parseInt( match[2], 10 );
      let day = parseInt( match[3], 10 );
      let hour = match[5] ? parseInt( match[5], 10 ) : 0;
      let min = match[6] ? parseInt( match[6], 10 ) : 0;
      let sec = match[7] ? parseFloat( match[7] ) : 0;
      let frac = (hour + min/60 + sec/3600)/24;

      return Math.calendarTimeToJD( year, month, day, frac );
   };

   this.CreateProjection = function()
   {
      let ptype1 = this.ctype1.substr( 6, 3 );
      let ptype2 = this.ctype2.substr( 6, 3 );
      if ( ptype1 != ptype2 )
         throw "Invalid/unsupported WCS coordinates: Axes with different projections";
      if ( ptype1 == "TAN" )
         return new Gnomonic( Math.DEG, this.crval1, this.crval2 );
      let proj = null;
      if ( ptype1 == "MER" )
         proj = new ProjectionMercator();
      else if ( ptype1 == "STG" )
         proj = new ProjectionStereographic();
      else if ( ptype1 == "CAR" )
         proj = new ProjectionPlateCarree();
      else if ( ptype1 == "ZEA" )
         proj = new ProjectionZenithalEqualArea();
      else if ( ptype1 == "AIT" )
         proj = new ProjectionHammerAitoff();
      else if ( ptype1 == "SIN" )
         proj = new ProjectionOrthographic();
      else
         throw "Invalid WCS coordinates: Unsupported projection '" + ptype1 + "'";
      proj.InitFromWCS( this );
      return proj;
   };
}

// ----------------------------------------------------------------------------

function DMath()
{
}

DMath.DEG2RAD = Math.PI / 180;
DMath.RAD2DEG = 180 / Math.PI;

DMath.sin = function( x )
{
   return Math.sin( x * this.DEG2RAD );
};

DMath.cos = function( x )
{
   return Math.cos( x * this.DEG2RAD );
};

DMath.tan = function( x )
{
   return Math.tan( x * this.DEG2RAD );
};

DMath.asin = function( x )
{
   return Math.asin( x ) * this.RAD2DEG;
};

DMath.acos = function( x )
{
   return Math.acos( x ) * this.RAD2DEG;
};

DMath.atan = function( x )
{
   return Math.atan( x ) * this.RAD2DEG;
};

DMath.atan2 = function( y, x )
{
   return Math.atan2( y, x ) * this.RAD2DEG;
};

// ----------------------------------------------------------------------------

function DeepCopy( obj )
{
   if ( obj === null || obj === undefined || typeof obj != "object" )
      return obj;
   if ( obj instanceof Date )
   {
      let copy = new Date();
      copy.setTime( obj.getTime() );
      return copy;
   }
   if ( obj instanceof Array )
   {
      let copy = [];
      for ( let i = 0, len = obj.length; i < len; ++i )
         copy[i] = DeepCopy( obj[i] );
      return copy;
   }
   if ( obj instanceof Object )
   {
      let copy = {};
      for ( let attr in obj )
         if ( obj.hasOwnProperty( attr ) )
            copy[attr] = DeepCopy( obj[attr] );
      return copy;
   }
   throw new Error( "Unable to copy obj this object." );
}

// ----------------------------------------------------------------------------

/*
 * ImageMetadata: Metadata of an image including an astrometric solution.
 */
function ImageMetadata( module, scalingFactor )
{
   this.__base__ = ObjectWithSettings;
   this.__base__(
      module ? module : SETTINGS_MODULE,
      "metadata",
      new Array(
         ["focal", DataType_Double],
         ["useFocal", DataType_Boolean],
         ["xpixsz", DataType_Float],
         // ["ypixsz", DataType_Float],
         ["resolution", DataType_Double],
         ["referenceSystem", DataType_String],
         ["ra", DataType_Double],
         ["dec", DataType_Double],
         ["epoch", DataType_Double],
         ["observationTime", DataType_Double],
         ["topocentric", DataType_Boolean],
         ["obsLongitude", DataType_Double],
         ["obsLatitude", DataType_Double],
         ["obsHeight", DataType_Double]
      )
   );

   this.focal = 1000;
   this.useFocal = true;
   this.xpixsz = 7.4;
   // this.ypixsz = 7.4;
   this.resolution = null;
   this.referenceSystem = "ICRS";
   this.ra = null;
   this.dec = null;
   this.epoch = null; // ### TODO: Rename to startTime
   this.endTime = null;
   this.observationTime = null;
   this.topocentric = false;
   this.obsLongitude = null;
   this.obsLatitude = null;
   this.obsHeight = null;
   this.scalingFactor = scalingFactor ? scalingFactor : 1;
   this.sourceImageWindow = null;

   this.Clone = function()
   {
      let clone = new ImageMetadata();
      for ( let key in this )
         clone[key] = this[key];
      return clone;
   };

   this.ExtractMetadata = function( window )
   {
      this.ref_I_G_linear = null;
      this.ref_I_G = null;
      this.ref_G_I = null;

      if ( window === null || window === undefined || window.isNull )
         return;

      let wcs = new WCSKeywords();
      wcs.Read( window );

      this.referenceSystem = wcs.radesys ? wcs.radesys : "ICRS";
      this.epoch = wcs.epoch;
      this.endTime = wcs.endTime;
      this.observationTime = wcs.observationTime;

      if ( wcs.longobs != null && wcs.latobs != null )
      {
         this.obsLongitude = wcs.longobs;
         this.obsLatitude = wcs.latobs;
         this.obsHeight = wcs.altobs;
         this.topocentric = true;
      }
      else
      {
         this.obsLongitude = this.obsLatitude = this.obsHeight = null;
         this.topocentric = false;
      }

      if ( wcs.xpixsz )
         this.xpixsz = wcs.xpixsz;

      this.sourceImageWindow = window;
      this.width = window.mainView.image.width;
      this.height = window.mainView.image.height;
      this.scaledWidth = Math.roundTo( this.width * this.scalingFactor, 2 );
      this.scaledHeight = Math.roundTo( this.height * this.scalingFactor, 2 );

      if ( wcs.ctype1 && wcs.ctype1.substr( 0, 5 ) == "'RA--" &&
           wcs.ctype2 && wcs.ctype2.substr( 0, 5 ) == "'DEC-" &&
           wcs.crpix1 != null && wcs.crpix2 != null && wcs.crval1 != null && wcs.crval2 != null )
      {
         try
         {
            this.projection = wcs.CreateProjection();

            let ref_F_G = null;
            let bottomUp = true;
            if ( wcs.cd1_1 != null && wcs.cd1_2 != null && wcs.cd2_1 != null && wcs.cd2_2 != null )
            {
               ref_F_G = new Matrix(
                  wcs.cd1_1, wcs.cd1_2, -wcs.cd1_1*wcs.crpix1 - wcs.cd1_2*wcs.crpix2,
                  wcs.cd2_1, wcs.cd2_2, -wcs.cd2_1*wcs.crpix1 - wcs.cd2_2*wcs.crpix2,
                  0, 0, 1 );

               if ( wcs.fromFITS )
               {
                  /*
                   * See "Representations of celestial coordinates in FITS", Sect. 6.2.
                   */
                  let rot1;
                  if ( wcs.cd2_1 > 0 )
                     rot1 = Math.atan2( wcs.cd2_1, wcs.cd1_1 );
                  else if ( wcs.cd2_1 < 0 )
                     rot1 = Math.atan2( -wcs.cd2_1, -wcs.cd1_1 );
                  else
                     rot1 = 0;

                  let rot2;
                  if ( wcs.cd1_2 > 0 )
                     rot2 = Math.atan2( wcs.cd1_2, -wcs.cd2_2 );
                  else if ( wcs.cd1_2 < 0 )
                     rot2 = Math.atan2( -wcs.cd1_2, wcs.cd2_2 );
                  else
                     rot2 = 0;

                  let rot = (rot1 + rot2)/2;
                  let cdelt2 = (Math.abs( Math.cos( rot ) ) > Math.abs( Math.sin( rot ) )) ? wcs.cd2_2/Math.cos( rot ) : -wcs.cd1_2/Math.sin( rot );
                  if ( cdelt2 < 0 )
                     bottomUp = false;
               }
            }
            else if ( wcs.cdelt1 != null && wcs.cdelt2 != null /*&& crota2 != null*/ )
            {
               if ( wcs.crota2 == null )
                  wcs.crota2 = 0;
               let rot = Math.rad( wcs.crota2 );
               let cd1_1 = wcs.cdelt1 * Math.cos( rot );
               let cd1_2 = -wcs.cdelt2 * Math.sin( rot );
               let cd2_1 = wcs.cdelt1 * Math.sin( rot );
               let cd2_2 = wcs.cdelt2 * Math.cos( rot );
               ref_F_G = new Matrix(
                  cd1_1, cd1_2, -cd1_1*wcs.crpix1 - cd1_2*wcs.crpix2,
                  cd2_1, cd2_2, -cd2_1*wcs.crpix1 - cd2_2*wcs.crpix2,
                  0, 0, 1 );
               if ( wcs.fromFITS )
                  if ( wcs.cdelt2 < 0 )
                     bottomUp = false;
            }

            if ( ref_F_G != null )
            {
               if ( window.mainView.hasProperty( "PCL:AstrometricSolution:SplineWorldTransformation:ControlPoints:Image" ) ||
                    window.mainView.hasProperty( "PCL:AstrometricSolution:SplineWorldTransformation" ) || // core == 1.8.9-2
                    window.mainView.hasProperty( "Transformation_ImageToProjection" ) )                   // core < 1.8.9-2
               {
                  this.loadControlPoints( window );
               }
               else
               {
                  if ( wcs.fromFITS )
                  {
                     let ref_F_I;
                     if ( bottomUp )
                        ref_F_I = new Matrix( 1,  0,            -0.5,
                                              0, -1, this.height+0.5,
                                              0,  0,             1 );
                     else
                        ref_F_I = new Matrix( 1,  0,            -0.5,
                                              0,  1,            -0.5,
                                              0,  0,             1 );
                     this.ref_I_G_linear = ref_F_G.mul( ref_F_I.inverse() );
                  }
                  else
                     this.ref_I_G_linear = ref_F_G;

                  this.ref_I_G = this.ref_I_G_linear;
                  this.ref_G_I = this.ref_I_G.inverse();
               }

               let centerG = this.ref_I_G.apply( new Point( this.width/2, this.height/2 ) );
               let center = this.projection.Inverse( centerG );
               this.ra = center.x;
               this.dec = center.y;

               let resx = Math.sqrt( ref_F_G.at( 0, 0 )*ref_F_G.at( 0, 0 ) + ref_F_G.at( 0, 1 )*ref_F_G.at( 0, 1 ) );
               let resy = Math.sqrt( ref_F_G.at( 1, 0 )*ref_F_G.at( 1, 0 ) + ref_F_G.at( 1, 1 )*ref_F_G.at( 1, 1 ) );
               this.resolution = (resx + resy)/2;
               this.useFocal = false;
               if ( this.xpixsz > 0 )
                  this.focal = this.FocalFromResolution( this.resolution );
            }
         }
         catch ( ex )
         {
            console.writeln( ex );
         }
      }

      if ( this.ref_I_G == null )
      {
         if ( wcs.objctra != null )
            this.ra = wcs.objctra;
         if ( wcs.objctdec != null )
            this.dec = wcs.objctdec;
         if ( wcs.focallen > 0 )
         {
            this.focal = wcs.focallen;
            this.useFocal = true;
         }
         if ( this.useFocal && this.xpixsz > 0 )
            this.resolution = this.ResolutionFromFocal( this.focal );
      }
   };

   this.GetDateString = function( jd )
   {
      let dateArray = Math.jdToCalendarTime( jd );
      let hours = Math.trunc( dateArray[3]*24 );
      let min = Math.trunc( dateArray[3]*24*60 ) - hours*60;
      let sec = dateArray[3]*24*3600 - hours*3600 - min*60;
      return format( "%04d-%02d-%02dT%02d:%02d:%0.2f", dateArray[0], dateArray[1], dateArray[2], hours, min, sec );
   };

   this.ResolutionFromFocal = function( focal )
   {
      return (focal > 0) ? this.xpixsz/focal*0.18/Math.PI : 0;
   };

   this.FocalFromResolution = function( resolution )
   {
      return (resolution > 0) ? this.xpixsz/resolution*0.18/Math.PI : 0;
   };

   this.GetWCSvalues = function()
   {
      let ref_F_I = new Matrix(
         1,  0,              -0.5,
         0, -1, this.height + 0.5,
         0,  0,               1 );
      let ref_F_G;
      if ( this.ref_I_G instanceof ReferSpline )
         ref_F_G = this.ref_I_G_linear.mul( ref_F_I );
      else
      {
         if ( this.ref_I_G.ToLinearMatrix )
            ref_F_G = this.ref_I_G.ToLinearMatrix().mul( ref_F_I );
         else
            ref_F_G = this.ref_I_G.mul( ref_F_I );
      }

      let wcs = this.projection.GetWCS();

      wcs.cd1_1 = ref_F_G.at( 0, 0 );
      wcs.cd1_2 = ref_F_G.at( 0, 1 );
      wcs.cd2_1 = ref_F_G.at( 1, 0 );
      wcs.cd2_2 = ref_F_G.at( 1, 1 );

      let orgF = ref_F_G.inverse().apply( new Point( 0, 0 ) );
      wcs.crpix1 = orgF.x;
      wcs.crpix2 = orgF.y;

      // CDELT1, CDELT2 and CROTA2 are computed using the formulas
      // in section 6.2 of http://fits.gsfc.nasa.gov/fits_wcs.html
      // "Representations of celestial coordinates in FITS"

      let rot1;
      if ( wcs.cd2_1 > 0 )
         rot1 = Math.atan2( wcs.cd2_1, wcs.cd1_1 );
      else if ( wcs.cd2_1 < 0 )
         rot1 = Math.atan2( -wcs.cd2_1, -wcs.cd1_1 );
      else
         rot1 = 0;

      let rot2;
      if ( wcs.cd1_2 > 0 )
         rot2 = Math.atan2( wcs.cd1_2, -wcs.cd2_2 );
      else if ( wcs.cd1_2 < 0 )
         rot2 = Math.atan2( -wcs.cd1_2, wcs.cd2_2 );
      else
         rot2 = 0;

      let rot = (rot1 + rot2)/2;

      if ( Math.abs( Math.cos( rot ) ) > Math.abs( Math.sin( rot ) ) )
      {
         wcs.cdelt1 = wcs.cd1_1/Math.cos( rot );
         wcs.cdelt2 = wcs.cd2_2/Math.cos( rot );
      }
      else
      {
         wcs.cdelt1 = wcs.cd2_1/Math.sin( rot );
         wcs.cdelt2 = -wcs.cd1_2/Math.sin( rot );
      }

      wcs.crota1 = Math.deg( rot );
      wcs.crota2 = Math.deg( rot );

      return wcs;
   };

   this.GetRotation = function()
   {
      if ( this.ref_I_G_linear )
      {
         let ref = this.ref_I_G_linear ? this.ref_I_G_linear : this.ref_I_G;
         let rotation = Math.deg( Math.atan2( ref.at( 0, 0 ) + ref.at( 0, 1 ),
                                              ref.at( 1, 0 ) + ref.at( 1, 1 ) ) ) + 135;
         let det = ref.at( 0, 0 )*ref.at( 1, 1 ) - ref.at( 0, 1 )*ref.at( 1, 0 );
         let flipped = det < 0;
         if ( flipped )
            rotation = -90 - rotation;
         if ( rotation < -180 )
            rotation += 360;
         if ( rotation > 180 )
            rotation -= 360;

         return [rotation, flipped];
      }

      return null;
   };

   this.SearchRadius = function()
   {
      if ( this.ref_I_G )
      {
         let r1 = this.DistanceI( new Point( this.width/2, this.height/2 ),
                                  new Point( 0,            0             ), true/*unscaled*/ );
         let r2 = this.DistanceI( new Point( this.width/2, this.height/2 ),
                                  new Point( this.width,   0             ), true/*unscaled*/ );
         let r3 = this.DistanceI( new Point( this.width/2, this.height/2 ),
                                  new Point( 0,            this.height   ), true/*unscaled*/ );
         let r4 = this.DistanceI( new Point( this.width/2, this.height/2 ),
                                  new Point( this.width,   this.height   ), true/*unscaled*/ );
         if ( !r1 || !r2 || !r3 || !r4 )
            return 180;
         return Math.max( r1, r2, r3, r4 );
      }

      return Math.max( this.width, this.height )*this.resolution;
   }

   this.modifyKeywords = function( keywords, newKeywords, removeNames )
   {
      let newNames = [];
      for ( let i = 0; i < newKeywords.length; ++i )
         newNames.push( newKeywords[i].name );

      let modifiedKeywords = [];
      for ( let i = 0; i < keywords.length; ++i )
      {
         let keyword = keywords[i];
         if ( removeNames.indexOf( keyword.name ) < 0 )
         {
            let j = newNames.indexOf( keyword.name );
            modifiedKeywords.push( (j < 0) ? keyword : newKeywords[j] );
         }
      }
      keywords = modifiedKeywords;
   };

   this.UpdateBasicKeywords = function( keywords )
   {
      let newKeywords = [];
      let removeNames = [];

      if ( this.focal > 0 )
         newKeywords.push( new FITSKeyword( "FOCALLEN", format( "%.3f", this.focal ), "Focal Length (mm)" ) );
      else
         removeNames.push( "FOCALLEN" );

      if ( this.xpixsz > 0 )
      {
         newKeywords.push( new FITSKeyword( "XPIXSZ", format( "%.3f", this.xpixsz ), "Pixel size, X-axis (um)" ) );
         newKeywords.push( new FITSKeyword( "YPIXSZ", format( "%.3f", this.xpixsz ), "Pixel size, Y-axis (um)" ) );
         removeNames.push( "PIXSIZE" );
      }

      if ( this.ra != null )
      {
         newKeywords.push( new FITSKeyword( "RA", format( "%.16f", this.ra ), "Right ascension of the center of the image (deg)" ) );
         removeNames.push( "OBJCTRA" );
      }

      if ( this.dec != null )
      {
         newKeywords.push( new FITSKeyword( "DEC", format( "%.16f", this.dec ), "Declination of the center of the image (deg)" ) );
         removeNames.push( "OBJCTDEC" );
      }

      if ( this.epoch != null )
      {
         newKeywords.push( new FITSKeyword( "DATE-OBS", this.GetDateString( this.epoch ), "Observation start time (UTC)" ) );
         removeNames.push( "DATE-BEG" );
      }

      if ( this.endTime != null )
         newKeywords.push( new FITSKeyword( "DATE-END", this.GetDateString( this.endTime ), "Observation end time (UTC)" ) );

      if ( this.obsLongitude != null )
      {
         newKeywords.push( new FITSKeyword( "OBSGEO-L", format( "%.7f", this.obsLongitude ), "Geodetic longitude (deg)" ) );
         removeNames.push( "LONG-OBS" );
         removeNames.push( "SITELONG" );
      }

      if ( this.obsLatitude != null )
      {
         newKeywords.push( new FITSKeyword( "OBSGEO-B", format( "%.7f", this.obsLatitude ), "Geodetic latitude (deg)" ) );
         removeNames.push( "LAT-OBS" );
         removeNames.push( "SITELAT" );
      }

      if ( this.obsHeight != null )
      {
         newKeywords.push( new FITSKeyword( "OBSGEO-H", format( "%.0f", this.obsHeight ), "Geodetic elevation (m)" ) );
         removeNames.push( "ALT-OBS" );
         removeNames.push( "SITEELEV" );
      }

      this.modifyKeywords( keywords, newKeywords, removeNames );
   };

   this.UpdateWCSKeywords = function( keywords, generate )
   {
      let newKeywords = [];
      let removeNames = [];

      removeNames.push( "RADESYS" );
      removeNames.push( "EQUINOX" ); // See Calabretta and Greisen, Section 3.1
      removeNames.push( "EPOCH" );   // See FITS standard 4.0, Section 8.3
      removeNames.push( "CTYPE1" );
      removeNames.push( "CTYPE2" );
      removeNames.push( "CRVAL1" );
      removeNames.push( "CRVAL2" );
      removeNames.push( "CRPIX1" );
      removeNames.push( "CRPIX2" );
      removeNames.push( "CD1_1" );
      removeNames.push( "CD1_2" );
      removeNames.push( "CD2_1" );
      removeNames.push( "CD2_2" );
      removeNames.push( "PC1_1" );
      removeNames.push( "PC1_2" );
      removeNames.push( "PC2_1" );
      removeNames.push( "PC2_2" );
      removeNames.push( "PV1_1" );
      removeNames.push( "PV1_2" );
      removeNames.push( "PV1_3" );
      removeNames.push( "PV1_4" );
      removeNames.push( "LONPOLE" );
      removeNames.push( "LATPOLE" );
      removeNames.push( "CDELT1" );
      removeNames.push( "CDELT2" );
      removeNames.push( "CROTA1" );
      removeNames.push( "CROTA2" );

      /*
       * Remove obsolete FITS keywords generated by plate solving scripts and
       * processes before core version 1.8.9-2.
       */
      removeNames.push( "POLYNDEG" );
      removeNames.push( "REFSPLIN" );
      removeNames.push( "REFSPLINE" ); // N.B. 9-char keyword name written by old versions, not FITS-compliant.

      this.modifyKeywords( keywords, newKeywords, removeNames );

      if ( generate )
      {
         removeNames = [];

         let wcs = this.GetWCSvalues();

         newKeywords.push( new FITSKeyword( "RADESYS",    "'" + this.referenceSystem + "'", "Reference system of celestial coordinates" ) );

         newKeywords.push( new FITSKeyword( "CTYPE1",     wcs.ctype1,                       "Axis1 projection: "+ this.projection.name ) );
         newKeywords.push( new FITSKeyword( "CTYPE2",     wcs.ctype2,                       "Axis2 projection: "+ this.projection.name ) );

         newKeywords.push( new FITSKeyword( "CRPIX1",     format( "%.8f", wcs.crpix1 ),     "Axis1 reference pixel" ) );
         newKeywords.push( new FITSKeyword( "CRPIX2",     format( "%.8f", wcs.crpix2 ),     "Axis2 reference pixel" ) );

         if ( wcs.crval1 != null )
            newKeywords.push( new FITSKeyword( "CRVAL1",  format( "%.16f", wcs.crval1 ),    "Axis1 reference value" ) );
         if ( wcs.crval2 != null )
            newKeywords.push( new FITSKeyword( "CRVAL2",  format( "%.16f", wcs.crval2 ),    "Axis2 reference value" ) );

         if ( wcs.pv1_1 != null )
            newKeywords.push( new FITSKeyword( "PV1_1",   format( "%.16f", wcs.pv1_1 ),     "Native longitude of the reference point" ) );
         if ( wcs.pv1_2 != null )
            newKeywords.push( new FITSKeyword( "PV1_2",   format( "%.16f", wcs.pv1_2 ),     "Native latitude of the reference point" ) );

         if ( wcs.lonpole != null )
            newKeywords.push( new FITSKeyword( "LONPOLE", format( "%.16f", wcs.lonpole ),   "Longitude of the celestial pole" ) );
         if ( wcs.latpole != null )
            newKeywords.push( new FITSKeyword( "LATPOLE", format( "%.16f", wcs.latpole ),   "Latitude of the celestial pole" ) );

         newKeywords.push( new FITSKeyword( "CD1_1",      format( "%.16f", wcs.cd1_1 ),     "Scale matrix (1,1)" ) );
         newKeywords.push( new FITSKeyword( "CD1_2",      format( "%.16f", wcs.cd1_2 ),     "Scale matrix (1,2)" ) );
         newKeywords.push( new FITSKeyword( "CD2_1",      format( "%.16f", wcs.cd2_1 ),     "Scale matrix (2,1)" ) );
         newKeywords.push( new FITSKeyword( "CD2_2",      format( "%.16f", wcs.cd2_2 ),     "Scale matrix (2,2)" ) );

         // AIPS keywords
         newKeywords.push( new FITSKeyword( "CDELT1",     format( "%.16f", wcs.cdelt1 ),    "Axis1 scale" ) );
         newKeywords.push( new FITSKeyword( "CDELT2",     format( "%.16f", wcs.cdelt2 ),    "Axis2 scale" ) );
         newKeywords.push( new FITSKeyword( "CROTA1",     format( "%.16f", wcs.crota1 ),    "Axis1 rotation angle (deg)" ) );
         newKeywords.push( new FITSKeyword( "CROTA2",     format( "%.16f", wcs.crota2 ),    "Axis2 rotation angle (deg)" ) );

         this.modifyKeywords( keywords, newKeywords, removeNames );
      }
   };

   this.SaveKeywords = function( window, beginProcess )
   {
      console.writeln( "<end><cbr>Saving keywords..." );
      if ( beginProcess )
         window.mainView.beginProcess( UndoFlag_Keywords );

      let keywords = window.keywords;
      this.UpdateBasicKeywords( keywords );
      this.UpdateWCSKeywords( keywords );
      window.keywords = keywords;

      if ( beginProcess )
         window.mainView.endProcess();
   };

   this.ModifyProperty = function( view, identifier, value, type  )
   {
      view.setPropertyValue( identifier, value, type, PropertyAttribute_Storable | PropertyAttribute_Permanent );
   };

   this.RemoveProperty = function( view, identifier )
   {
      view.deleteProperty( identifier );
   };

   this.SaveProperties = function( window, creatorModule, catalogName )
   {
      console.writeln( "<end><cbr>Saving properties..." );

      let view = window.mainView;

      // Remove all SplineWorldTransformation properties to prevent conflicts.
      for ( let i = 0, properties = view.properties; i < properties.length; ++i )
         if ( properties[i].startsWith( "PCL:AstrometricSolution:SplineWorldTransformation:" ) )
            this.RemoveProperty( view, properties[i] );
      this.RemoveProperty( view, "PCL:AstrometricSolution:SplineWorldTransformation" ); // core 1.8.9-2
      this.RemoveProperty( view, "Transformation_ImageToProjection" );                  // core < 1.8.9-2

      if ( this.focal > 0 )
         this.ModifyProperty( view, "Instrument:Telescope:FocalLength", Math.roundTo( this.focal/1000, 6 ), PropertyType_Float64 );
      else
         this.RemoveProperty( view, "Instrument:Telescope:FocalLength" );

      if ( this.xpixsz > 0 )
      {
         this.ModifyProperty( view, "Instrument:Sensor:XPixelSize", Math.roundTo( this.xpixsz, 3 ), PropertyType_Float64 );
         this.ModifyProperty( view, "Instrument:Sensor:YPixelSize", Math.roundTo( this.xpixsz, 3 ), PropertyType_Float64 );
      }

      if ( this.epoch != null )
         this.ModifyProperty( view, "Observation:Time:Start", this.epoch, PropertyType_TimePoint );

      if ( this.endTime != null )
         this.ModifyProperty( view, "Observation:Time:End", this.endTime, PropertyType_TimePoint );

      if ( this.obsLongitude != null && this.obsLatitude != null )
      {
         this.ModifyProperty( view, "Observation:Location:Longitude", Math.roundTo( this.obsLongitude, 6 ), PropertyType_Float64 );
         this.ModifyProperty( view, "Observation:Location:Latitude", Math.roundTo( this.obsLatitude, 6 ), PropertyType_Float64 );
         if ( this.obsHeight != null )
            this.ModifyProperty( view, "Observation:Location:Elevation", Math.round( this.obsHeight ), PropertyType_Float64 );
      }

      let pRD = this.Convert_I_RD( new Point( view.image.width/2, view.image.height/2 ), true/*unscaled*/ );
      if ( pRD != null )
      {
         this.ModifyProperty( view, "Observation:Center:RA", pRD.x, PropertyType_Float64 );
         this.ModifyProperty( view, "Observation:Center:Dec", pRD.y, PropertyType_Float64 );
         this.ModifyProperty( view, "Observation:CelestialReferenceSystem", this.referenceSystem, PropertyType_String8 );
         this.ModifyProperty( view, "Observation:Equinox", 2000.0, PropertyType_Float64 );
         // The default reference point is the geometric center of the image.
         this.RemoveProperty( view, "Observation:Center:X" );
         this.RemoveProperty( view, "Observation:Center:Y" );
      }

      this.ModifyProperty( view, "PCL:AstrometricSolution:ProjectionSystem",
                           this.projection.identifier, PropertyType_String8 );

      let vC0 = new Vector( [Math.deg( this.projection.ra0 ), Math.deg( this.projection.dec0 )] );
      let pI0 = this.ref_I_G_linear.inverse().apply( new Point( 0, 0 ) );
          pI0 = new Vector( [pI0.x, pI0.y] );
      this.ModifyProperty( view, "PCL:AstrometricSolution:ReferenceCelestialCoordinates",
                           vC0, PropertyType_F64Vector );
      this.ModifyProperty( view, "PCL:AstrometricSolution:ReferenceImageCoordinates",
                           pI0, PropertyType_F64Vector );

      let LT = new Matrix( 2, 2 );
      LT.at( 0, 0, this.ref_I_G_linear.at( 0, 0 ) );
      LT.at( 0, 1, this.ref_I_G_linear.at( 0, 1 ) );
      LT.at( 1, 0, this.ref_I_G_linear.at( 1, 0 ) );
      LT.at( 1, 1, this.ref_I_G_linear.at( 1, 1 ) );

      this.ModifyProperty( view, "PCL:AstrometricSolution:LinearTransformationMatrix",
                           LT, PropertyType_F64Matrix );

      let nlon = this.projection.phi0;
      let nlat = this.projection.theta0;

      let plon = ((vC0.at( 1 ) < nlat) ? 180 : 0) + nlon;
      if ( plon < -180 )
         plon += 360;
      else if ( plon > 180 )
         plon -= 360;
      let plat = 90;

      if ( this.projection.wcs )
      {
         if ( this.projection.wcs.pv1_1 != null )
            nlon = this.projection.wcs.pv1_1;
         if ( this.projection.wcs.pv1_2 != null )
            nlat = this.projection.wcs.pv1_2;
         if ( this.projection.wcs.lonpole != null )
            plon = this.projection.wcs.lonpole;
         if ( this.projection.wcs.latpole != null )
            plat = this.projection.wcs.latpole;
      }

      this.ModifyProperty( view, "PCL:AstrometricSolution:ReferenceNativeCoordinates",
                           new Vector( [nlon, nlat] ), PropertyType_F64Vector );
      this.ModifyProperty( view, "PCL:AstrometricSolution:CelestialPoleNativeCoordinates",
                           new Vector( [plon, plat] ), PropertyType_F64Vector );

      this.ModifyProperty( view, "PCL:AstrometricSolution:CreationTime", (new Date).toISOString(), PropertyType_TimePoint );
      this.ModifyProperty( view, "PCL:AstrometricSolution:CreatorOS", CoreApplication.platform, PropertyType_String );

      {
         let creatorApp = format( "PixInsight %s%d.%d.%d",
                                  CoreApplication.versionLE ? "LE " : "",
                                  CoreApplication.versionMajor,
                                  CoreApplication.versionMinor,
                                  CoreApplication.versionRelease );
         if ( CoreApplication.versionRevision != 0 )
            creatorApp += format( "-%d", CoreApplication.versionRevision );
         if ( CoreApplication.versionBeta != 0 )
            creatorApp += format( " %s%d", (CoreApplication.versionBeta < 0) ? "RC" : "beta ", Math.abs( CoreApplication.versionBeta ) );

         this.ModifyProperty( view, "PCL:AstrometricSolution:CreatorApplication", creatorApp, PropertyType_String );
      }

      if ( creatorModule )
         this.ModifyProperty( view, "PCL:AstrometricSolution:CreatorModule", creatorModule, PropertyType_String );

      if ( catalogName )
         this.ModifyProperty( view, "PCL:AstrometricSolution:Catalog", catalogName.replace( "(XPSD)", "" ).trim(), PropertyType_String );

      if ( this.controlPoints )
         if ( this.ref_I_G instanceof ReferSpline )
            this.saveControlPoints( window );
   };

   this.saveControlPoints = function( window )
   {
      let view = window.mainView;

      this.ModifyProperty( view, "PCL:AstrometricSolution:SplineWorldTransformation:SplineOrder", this.ref_I_G.order, PropertyType_Int32 );
      this.ModifyProperty( view, "PCL:AstrometricSolution:SplineWorldTransformation:SplineSmoothness", this.ref_I_G.smoothing, PropertyType_Float32 );
      this.ModifyProperty( view, "PCL:AstrometricSolution:SplineWorldTransformation:UseSimplifiers", this.ref_I_G.simplify, PropertyType_Boolean );
      this.ModifyProperty( view, "PCL:AstrometricSolution:SplineWorldTransformation:SimplifierRejectFraction", this.ref_I_G.rejectFraction, PropertyType_Float32 );

      let n = 0;
      for ( let i = 0; i < this.controlPoints.pI.length; ++i )
         if ( this.controlPoints.pI[i] && this.controlPoints.pG[i] )
            ++n;
      let cI = new Vector( n << 1 );
      let cW = new Vector( n << 1 );
      for ( let i = 0, j = 0; i < this.controlPoints.pI.length; ++i )
         if ( this.controlPoints.pI[i] && this.controlPoints.pG[i] )
         {
            cI.at( j,   this.controlPoints.pI[i].x );
            cI.at( j+1, this.controlPoints.pI[i].y );
            cW.at( j,   this.controlPoints.pG[i].x );
            cW.at( j+1, this.controlPoints.pG[i].y );
            j += 2;
         }
      this.ModifyProperty( view, "PCL:AstrometricSolution:SplineWorldTransformation:ControlPoints:Image", cI, PropertyType_F64Vector );
      this.ModifyProperty( view, "PCL:AstrometricSolution:SplineWorldTransformation:ControlPoints:World", cW, PropertyType_F64Vector );
   };

   this.loadControlPoints = function( window )
   {
      let view = window.mainView;

      /*
       * Compatibility with core versions <= 1.8.9-2 (metadata version <= 1.2)
       */
      let rawData = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation" );
      if ( rawData === null || !(rawData instanceof ByteArray) )
         rawData = view.propertyValue( "Transformation_ImageToProjection" );
      if ( rawData !== null && (rawData instanceof ByteArray) )
      {
         this.loadControlPoints_V1_2( rawData );
         return;
      }

      let cI = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:ControlPoints:Image" );
      if ( cI === null )
         throw "Invalid spline world transformation: no image control point coordinates.";

      let cW = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:ControlPoints:World" );
      if ( cW === null )
         throw "Invalid spline world transformation: no world control point coordinates.";

      let weights = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:ControlPoints:Weights" );

      if ( !(cI instanceof Vector) || !(cW instanceof Vector) ||
            (cI.length & 1) != 0 ||
             cI.length < 6 ||
             cI.length != cW.length ||
           weights !== null && (!(weights instanceof Vector) || cI.length != (weights.length >> 1)) )
         throw "Invalid spline world transformation: invalid or corrupted control point structures.";

      let controlPoints = { pI:      [],
                            pG:      [],
                            weights: (weights === null) ? null : [] };

      for ( let i = 0, n = cI.length; i < n; i += 2 )
      {
         controlPoints.pI.push( new Point( cI.at( i ), cI.at( i+1 ) ) );
         controlPoints.pG.push( new Point( cW.at( i ), cW.at( i+1 ) ) );
         if ( weights !== null )
            controlPoints.weights.push( weights.at( i >> 1 ) );
      }

      let version = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:Version" );
      if ( version === null )
         version = "1.3";

      let order = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:SplineOrder" );
      if ( order === null )
         order = 2;

      let smoothness = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:SplineSmoothness" );
      if ( smoothness === null )
         smoothness = 0.005;

      let simplify = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:UseSimplifiers" );
      if ( simplify === null )
         simplify = true;

      let rejectFraction = view.propertyValue( "PCL:AstrometricSolution:SplineWorldTransformation:SimplifierRejectFraction" );
      if ( rejectFraction === null )
         rejectFraction = 0.10;

      this.controlPoints = controlPoints;

      this.ref_I_G_linear = Math.homography( controlPoints.pI, controlPoints.pG );

      this.ref_I_G = new ReferSpline( controlPoints.pI, controlPoints.pG,
                                      order,
                                      smoothness,
                                      simplify,
                                      rejectFraction );

      this.ref_G_I = new ReferSpline( controlPoints.pG, controlPoints.pI,
                                      order,
                                      smoothness,
                                      simplify,
                                      rejectFraction );

      console.writeln( format( "Loaded %u control points (metadata version %s).", controlPoints.pI.length, version ) );
   };

   /*
    * Compatibility with core versions <= 1.8.9-2 (metadata version <= 1.2)
    */
   this.loadControlPoints_V1_2 = function( byteArray )
   {
      console.writeln( "<end><cbr>Loading control points..." );
      let lines = byteArray.toString().split( "\n" );
      if ( lines.length == 0 )
         throw "Invalid coordinate transformation data.";
      let tokens = lines[0].split( ':' );
      if ( tokens.length != 2 || tokens[0] != "VERSION" )
         throw "Invalid coordinate transformation version data.";
      let version = tokens[1].trim();
      if ( version != "1" && version != "1.1" && version != "1.2" )
         throw "Unsupported coordinate transformation version '" + version + "'";

      let controlPoints = null, order = 2, smoothing = 0.005,
          simplify = true, rejectFraction = 0.10;

      for ( let i = 1; i < lines.length; ++i )
      {
         tokens = lines[i].split( ':' );
         if ( tokens.length != 2 )
            continue;
         switch ( tokens[0] )
         {
         case "ORDER":
            order = parseInt( tokens[1] );
            break;
         case "SMOOTHING":
            smoothing = parseFloat( tokens[1] );
            break;
         case "SIMPLIFIER":
            simplify = parseInt( tokens[1] ) != 0;
            break;
         case "REJECTFRACTION":
            rejectFraction = parseFloat( tokens[1] );
            break;
         case "CONTROLPOINTS":
            if ( tokens[1].trim() != '[' )
               throw "Invalid coordinate transformation control points.";
            i++;
            controlPoints = { pI:      [],
                              pG:      [],
                              weights: null };
            for ( ; i < lines.length && lines[i] != ']'; ++i )
            {
               let coords = lines[i].split( ';' );
               if ( coords.length < 4 )
                  throw "Invalid coordinate transformation control points.";
               if ( coords.length < 5 && controlPoints.weights != null )
                  throw "Invalid coordinate transformation control points.";
               if ( coords.length > 5 )
                  throw "Invalid coordinate transformation control points.";
               controlPoints.pI.push( new Point( parseFloat( coords[0] ), parseFloat( coords[1] ) ) );
               controlPoints.pG.push( new Point( parseFloat( coords[2] ), parseFloat( coords[3] ) ) );
               if ( coords.length == 5 )
               {
                  if ( controlPoints.weights == null )
                     controlPoints.weights = [];
                  controlPoints.weights.push( parseFloat( coords[4] ) );
               }
            }
            if ( controlPoints.weights && controlPoints.pI.length != controlPoints.weights.length )
               throw "Invalid coordinate transformation control points: Mismatched weights.";
            break;
         }
      }

      if ( controlPoints == null )
         throw "Invalid coordinate transformation: no control points were loaded.";
      this.controlPoints = controlPoints;

      this.ref_I_G_linear = Math.homography( controlPoints.pI, controlPoints.pG );

      this.ref_I_G = new ReferSpline( controlPoints.pI, controlPoints.pG,
                                      order,
                                      smoothing,
                                      simplify,
                                      rejectFraction );

      this.ref_G_I = new ReferSpline( controlPoints.pG, controlPoints.pI,
                                      order,
                                      smoothing,
                                      simplify,
                                      rejectFraction );

      console.writeln( format( "Loaded %u control points (metadata version %s).", controlPoints.pI.length, version ) );
   };

   this.RectExpand = function( r, p )
   {
      if ( p )
      {
         let ra0 = Math.deg( this.projection.ra0 );
         let x = p.x;
         if ( x < ra0 - 180 )
            x += 360;
         if ( x > ra0 + 180 )
            x -= 360;

         if ( r )
         {
            r.x0 = Math.min( r.x0, x );
            r.x1 = Math.max( r.x1, x );
            r.y0 = Math.min( r.y0, p.y, 90 );
            r.y1 = Math.max( r.y1, p.y, -90 );
         }
         else
            r = new Rect( x, p.y, x, p.y );
      }
      return r;
   };

   this.FindImageBounds = function()
   {
      let bounds = null;

      let numSteps = 32;
      let sx = this.width/(numSteps - 1);
      let sy = this.height/(numSteps - 1);
      for ( let y = 0; y < numSteps; ++y )
         for ( let x = 0; x < numSteps; ++x )
            bounds = this.RectExpand( bounds, this.Convert_I_RD( new Point( x*sx, y*sy ), true/*unscaled*/ ) );
      let ra0 = Math.deg( this.projection.ra0 );

      // Check North Pole
      let north_I = this.Convert_RD_I( new Point( ra0, 90 ), true/*unscaled*/ );
      if ( north_I
        && north_I.x >= 0
        && north_I.x < this.width
        && north_I.y >= 0
        && north_I.y < this.height )
      {
         bounds.x0 = 0;
         bounds.x1 = 360;
         bounds.y1 = +90;
      }

      // Check South Pole
      let south_I = this.Convert_RD_I( new Point( ra0, -90 ), true/*unscaled*/ );
      if ( south_I
        && south_I.x >= 0
        && south_I.x < this.width
        && south_I.y >= 0
        && south_I.y < this.height )
      {
         bounds.x0 = 0;
         bounds.x1 = 360;
         bounds.y0 = -90;
      }

      bounds.x0 /= 15;
      bounds.x1 /= 15;

      return bounds;
   };

   this.Convert_I_RD = function( pI, unscaled )
   {
      let spI = pI;
      if ( !unscaled )
      {
         spI.x /= this.scalingFactor;
         spI.y /= this.scalingFactor;
      }
      return this.projection.Inverse( this.ref_I_G.apply( spI ) );
   };

   this.Convert_RD_I = function( pRD, unscaled )
   {
      let pG = this.projection.Direct( pRD );
      if ( pG )
      {
         let pI = this.ref_G_I.apply( pG );
         if ( !unscaled )
         {
            pI.x *= this.scalingFactor;
            pI.y *= this.scalingFactor;
         }
         return pI;
      }
      return null;
   };

   this.Convert_RD_I_Points = function( pointsRD, unscaled )
   {
      let pointsG = [];
      for ( let i = 0; i < pointsRD.length; ++i )
      {
         let pG = this.projection.Direct( pointsRD[i] );
         if ( pG )
            pointsG.push( pG );
      }
      let pointsI = this.ref_G_I.applyToPoints( pointsG );
      if ( !unscaled )
         for ( let i = 0; i < pointsI.length; ++i )
            pointsI[i].mul( this.scalingFactor );
      return pointsI;
   };

   this.DistanceI = function( p1, p2, unscaled )
   {
      return ImageMetadata.Distance( this.Convert_I_RD( p1, unscaled ), this.Convert_I_RD( p2, unscaled ) );
   };

   this.CheckOscillation = function( pRD, pI )
   {
      let spI;
      if ( !pI )
         spI = this.Convert_RD_I( pRD, true/*unscaled*/ );
      else
         spI = new Point( pI.x/this.scalingFactor, pI.y/this.scalingFactor );
      let pG = this.projection.Direct( pRD );
      let pIl = this.ref_I_G_linear.inverse().apply( pG );
      return (pIl.x - spI.x)*(pIl.x - spI.x) + (pIl.y - spI.y)*(pIl.y - spI.y) < this.width*this.height/4;
   };

   this.insideImageBoundaries = function( posRD )
   {
      let posI = this.Convert_RD_I( posRD, true/*unscaled*/ );
      if ( !posI
         || posI.x < 0
         || posI.y < 0
         || posI.x >= this.width
         || posI.y >= this.height )
         return false;

      /*
       * Perform an additional inverse transformation to validate object
       * inclusion.
       *
       * On rare ocassions, high-order surface splines can lead to false
       * inclusions in coordinate transformations extrapolated far away from
       * image boundaries. This can happen when checking visibility of
       * arbitrarily selected objects such as planets, asteroids, and local or
       * custom catalogs.
       */
      let posRD1 = this.Convert_I_RD( posI, true/*unscaled*/ );
      if ( !posRD1 )
         return false;
      if ( posRD1.x < 0 )
         posRD1.x += 360;
      else if ( posRD1.x >= 360 )
         posRD1.x -= 360;
      if ( Math.abs( posRD.x - posRD1.x ) > this.resolution
        || Math.abs( posRD.y - posRD1.y ) > this.resolution )
         return false;

      return true;
   };

   this.insideImageBoundariesFast = function( posRD )
   {
      let posI = this.Convert_RD_I( posRD, true/*unscaled*/ );
      return posI
          && posI.x >= 0
          && posI.y >= 0
          && posI.x < this.width
          && posI.y < this.height;
   };

   this.hasOfDateCoordinates = function()
   {
      switch ( this.referenceSystem.toLowerCase() )
      {
      case "true":
      case "mean":
      case "apparent":
      case "gappt":
         return true;
      default:
         return false;
      }
   };

   /*
    * Returns the ICRS center coordinates suitable for catalog search
    * operations.
    */
   this.searchCenterCoordinates = function()
   {
      if ( !this.hasOfDateCoordinates() )
         return new Point( this.ra, this.dec );

      let P = new Position( this.observationTime, "UTC" );
      P.initEquinoxBasedParameters();
      let u3 = Vector.fromSpherical( Math.rad( this.ra ), Math.rad( this.dec ) );
      let u2 = P.equinoxBPNInverseMatrix.transform( u3 );
      let s2 = u2.toSpherical2Pi();
      let u1 = P.proper( new StarPosition( Math.deg( s2[0] ), Math.deg( s2[1] ) ) );
      let s1 = u1.toSpherical2Pi();
      let ra = Math.deg( 2*s2[0] - s1[0] );
      while ( ra < 0 )
         ra += 360;
      while ( ra >= 360 )
         ra -= 360;
      let dec = Math.deg( 2*s2[1] - s1[1] );
      return new Point( ra, dec );
   };

   /*
    * Approximate transformation from apparent or 'of date' to astrometric
    * coordinates by 'undoing' the effects of bias/precession/nutation and
    * annual aberration. This routine has typical accuracy better than 0".01.
    */
   this.convertRADecFromApparentToAstrometric = function()
   {
      let P = new Position( this.observationTime, "UTC" );
      P.initEquinoxBasedParameters();
      let u3 = Vector.fromSpherical( Math.rad( this.ra ), Math.rad( this.dec ) );
      let u2 = P.equinoxBPNInverseMatrix.transform( u3 );
      let s2 = u2.toSpherical2Pi();
      let u1 = P.proper( new StarPosition( Math.deg( s2[0] ), Math.deg( s2[1] ) ) );
      let s1 = u1.toSpherical2Pi();
      this.ra = Math.deg( 2*s2[0] - s1[0] );
      while ( this.ra < 0 )
         this.ra += 360;
      while ( this.ra >= 360 )
         this.ra -= 360;
      this.dec = Math.deg( 2*s2[1] - s1[1] );
      this.referenceSystem = "ICRS";
   };

   /*
    * Ensure the celestial reference system is either ICRS or GCRS. These are
    * the only valid reference systems for our astrometric solutions.
    *
    * If we know the center coordinates are apparent or 'of the date'
    * coordinates, apply the required inverse transformation to get approximate
    * astrometric coordinates, and change the reference system to ICRS.
    */
   this.ensureValidReferenceSystemForSolution = function()
   {
      this.mightBeApparent = true;
      switch ( this.referenceSystem.toLowerCase() )
      {
      case "true":
      case "mean":
      case "apparent":
      case "gappt":
         this.convertRADecFromApparentToAstrometric();
         this.mightBeApparent = false;
         break;
      default:
         /*
          * Ensure we don't propagate 'exotic' reference system values. In
          * these cases we assume ICRS for sanity. The coordinates could be
          * of date, but we can only know if that's true by generating a new
          * astrometric solution.
          */
         if ( this.referenceSystem != "ICRS" )
            if ( this.referenceSystem != "GCRS" )
               this.referenceSystem = "ICRS";
         break;
      }
   };
}

ImageMetadata.prototype = new ObjectWithSettings;

ImageMetadata.Distance = function( cp1, cp2 )
{
   if ( !cp1 || !cp2 )
      return NaN;
   let dX = Math.abs( cp1.x - cp2.x );
   let cosX = DMath.cos( dX );
   let sinX = DMath.sin( dX );
   let cosY1 = DMath.cos( cp1.y );
   let cosY2 = DMath.cos( cp2.y );
   let sinY1 = DMath.sin( cp1.y );
   let sinY2 = DMath.sin( cp2.y );
   let K = cosY1*sinY2 - sinY1*cosY2*cosX;
   return DMath.atan2( Math.sqrt( cosY2*sinX*cosY2*sinX + K*K ),
                       sinY1*sinY2 + cosY1*cosY2*cosX );
};

ImageMetadata.DistanceFast = function( cp1, cp2 )
{
   if ( !cp1 || !cp2 )
      return NaN;
   return DMath.acos( DMath.sin( cp1.y ) * DMath.sin( cp2.y ) +
                      DMath.cos( cp1.y ) * DMath.cos( cp2.y ) * DMath.cos( cp1.x - cp2.x ) );
};

// ----------------------------------------------------------------------------

/*
 * DMSangle: Helper class to simplify the use of angles in DMS format.
 */
function DMSangle()
{
   this.deg = 0;
   this.min = 0;
   this.sec = 0;
   this.sign = 1;

   this.GetValue = function()
   {
      return this.sign*(this.deg + (this.min + this.sec/60)/60);
   };

   this.ToString = function( hours, precision )
   {
      if ( precision === undefined )
         precision = 2;
      if ( hours )
         ++precision;
      let secWidth = 2;
      if ( precision > 0 )
         secWidth += 1 + precision;
      let plus = hours ? "" : "+";
      if ( this.deg != null && this.min != null && this.sec != null && this.sign != null )
         return ((this.sign < 0) ? "-": plus) +
               format( "%02d %02d %0*.*f", this.deg, this.min, secWidth, precision, this.sec );
      return "<* invalid *>";
   };
}

DMSangle.FromString = function( coordStr, mindeg, maxdeg, noSecs )
{
   let match = coordStr.match( noSecs ? "'?([+-]?)([0-9]*)[ :]([0-9]*(.[0-9]*)?)'?" :
                                        "'?([+-]?)([0-9]*)[ :]([0-9]*)[ :]([0-9]*(.[0-9]*)?)'?" );
   if ( match == null )
      return null;
   let coord = new DMSangle();
   if ( match.length < (noSecs ? 3 : 4) )
      throw new Error( "Invalid coordinates" );
   coord.deg = parseInt( match[2], 10 );
   if ( coord.deg < mindeg || coord.deg > maxdeg )
      throw new Error( "Invalid coordinates" );
   coord.min = parseInt( match[3], 10 );
   if ( coord.min < 0 || coord.min >= 60 )
      throw new Error( "Invalid coordinates (minutes)" );
   if ( noSecs )
      coord.sec = 0;
   else
   {
      coord.sec = parseFloat( match[4] );
      if ( coord.sec < 0 || coord.sec >= 60 )
         throw new Error( "Invalid coordinates (seconds)" );
   }
   coord.sign = (match[1] == '-') ? -1 : 1;
   return coord;
};

DMSangle.FromAngle = function( angle )
{
   let coord = new DMSangle();
   if ( angle < 0 )
   {
      coord.sign = -1;
      angle = -angle;
   }
   coord.deg = Math.trunc( angle );
   coord.min = Math.trunc( (angle - coord.deg)*60 );
   coord.sec = (angle - coord.deg - coord.min/60)*3600;

   if ( coord.sec > 59.999 )
   {
      coord.sec = 0;
      coord.min++;
      if ( coord.min == 60 )
      {
         coord.min = 0;
         coord.deg++;
      }
   }

   return coord;
};

// ----------------------------------------------------------------------------

Point.prototype.PrintAsRaDec = function()
{
   console.writeln( "RA: ", DMSangle.FromAngle( this.x/15 ).ToString(),
                    "  Dec: ", DMSangle.FromAngle( this.y ).ToString() );
};

Point.prototype.Print = function()
{
   console.writeln( format( "%f %f", this.x, this.y ) );
};

// ----------------------------------------------------------------------------

Matrix.prototype.applyToPoints = function( points )
{
   let result = [];
   for ( let i = 0; i < points.length; ++i )
      result.push( this.apply( points[i] ) );
   return result;
};

Matrix.prototype.Print = function()
{
   for ( let y = 0; y < this.rows; ++y )
   {
      console.write( "   " );
      for ( let x = 0; x < this.cols; ++x )
         //console.write( format( "%+20.12f", this.at( y, x ) ) );
         console.write( format( "%+20g", this.at( y, x ) ) );
      console.writeln( "" );
   }
};

Matrix.prototype.toString = function()
{
   let str = "[";
   for ( let row = 0; row < this.rows; ++row )
   {
      let rowStr = "[";
      for ( let col = 0; col < this.columns; ++col )
      {
         if ( col > 0 )
            rowStr += ";";
         rowStr += this.at( row, col ).toString();
      }
      str += rowStr + "]";
   }
   return str + "]";
};

// ----------------------------------------------------------------------------

function ReferNPolyn( polDegree )
{
   this.__base__ = Matrix;
   this.__base__( 2, ((polDegree + 1)*(polDegree + 2))/2 );
   this.polDegree = polDegree;
};

ReferNPolyn.prototype = new Matrix;

ReferNPolyn.prototype.apply = function( p )
{
   let coef = this.GetPointCoef( p );
   let x = 0, y = 0;
   for ( let i = 0; i < coef.length; ++i )
   {
      x += coef[i]*this.at( 0, i );
      y += coef[i]*this.at( 1, i );
   }
   return new Point( x, y );
};

ReferNPolyn.prototype.applyToPoints = function( points )
{
   let result = [];
   for ( let i = 0; i < points.length; ++i )
      result.push( this.apply( points[i] ) );
   return result;
};

ReferNPolyn.prototype.GetPointCoef = function( p )
{
   let values = Array( this.GetNumCoef() );
   let idx = 0;
   for ( let o = 0; o <= this.polDegree; ++o )
   {
      let x = 1;
      for ( let i = 0; i <= o; ++i )
      {
         values[idx+o-i] = x;
         x *= p.x;
      }
      let y = 1;
      for ( let i = 0; i <= o; ++i )
      {
         values[idx+i] *= y;
         y *= p.y;
      }
      idx += o+1;
   }
   return values;
};

ReferNPolyn.prototype.GetNumCoef = function( degree )
{
   if ( degree == null )
      return ((this.polDegree + 1)*(this.polDegree + 2))/2;
   return ((degree + 1)*(degree + 2))/2;
};

ReferNPolyn.prototype.ToLinearMatrix = function()
{
   let m = new Matrix( 3, 3 );
   m.at( 0, 0, this.at( 0, 1 ) ); m.at( 0, 1, this.at( 0, 2 ) ); m.at( 0, 2, this.at( 0, 0 ) );
   m.at( 1, 0, this.at( 1, 1 ) ); m.at( 1, 1, this.at( 1, 2 ) ); m.at( 1, 2, this.at( 1, 0 ) );
   m.at( 2, 0, 0 );               m.at( 2, 1, 0);                m.at( 2, 2, 1 );
   return m;
};

ReferNPolyn.prototype.FromLinearMatrix = function( m )
{
   let ref = new ReferNPolyn( 1 );
   ref.at( 0, 0, m.at( 0, 2 ) ); ref.at( 0, 1, m.at( 0, 0 ) ); ref.at( 0, 2, m.at( 0, 1 ) );
   ref.at( 1, 0, m.at( 1, 2 ) ); ref.at( 1, 1, m.at( 1, 0 ) ); ref.at( 1, 2, m.at( 1, 1 ) );
   return ref;
};

// ----------------------------------------------------------------------------

function ReferSpline( P1, P2, order, smoothing, simplify, rejectFraction, incremental )
{
   this.order = (order === undefined || order === null) ? 2 : order;
   this.smoothing = (smoothing === undefined || smoothing === null) ? 0 : smoothing;
   this.simplify = (simplify === undefined || simplify === null) ? true : simplify;
   this.rejectFraction = (rejectFraction === undefined || rejectFraction === null) ? 0.10 : rejectFraction;
   this.incremental = (incremental === undefined || incremental === null) ? true : incremental;
   this.truncated = false;
   if ( P1 && P2 )
      this.InitFromControlPoints( P1, P2 );
}

ReferSpline.prototype.InitFromControlPoints = function( p1, p2 )
{
   let P1 = [], P2 = [];
   for ( let i = 0, n = Math.min( p1.length, p2.length ); i < n; ++i )
      if ( p1[i] && p2[i] )
      {
         P1.push( p1[i] );
         P2.push( p2[i] );
      }

   this.spline = new PointSurfaceSpline;

   this.spline.maxSplinePoints = WCS_MAX_SPLINE_POINTS;
   this.spline.simplifiersEnabled = this.simplify;
   this.spline.simplifierRejectFraction = this.rejectFraction;

   if ( this.incremental )
   {
      this.spline.incrementalFunctionEnabled = true;
      this.spline.linearFunction = Math.homography( P1, P2 );
   }

   this.spline.initialize( P1, P2,
                           this.smoothing,
                           null/*weights*/,
                           this.order,
                           (this.order == 2) ? RBFType_ThinPlateSpline : RBFType_VariableOrder );

   this.truncated = this.spline.truncatedX || this.spline.truncatedY;
   this.simpleX = this.spline.pointsX;
   this.simpleY = this.spline.pointsY;
};

ReferSpline.prototype.apply = function( p )
{
   return this.spline.evaluate( p );
};

ReferSpline.prototype.applyToPoints = function( points )
{
   return this.spline.evaluate( points );
};

// ----------------------------------------------------------------------------

function MultipleLinearRegression( polDegree, coords1, coords2 )
{
   if ( coords1.length != coords2.length )
      throw "Input arrays of different size in Multiple Linear Regression";
   let numSamples =0;
   for ( let i = 0; i < coords1.length; ++i )
      if ( coords1[i] && coords2[i] )
         numSamples++;
   //console.writeln("Samples: ", numSamples);
   if ( numSamples < 4 )
      throw "There are too few valid samples";
   // Uses independent multiple linear regression for x and y
   // The model is: Y = X * B + err
   // The regresand Y contains the x (or y) of the predicted coordinates coords2
   // The regresors X contains the vectors (x,y,1) with the source coordinates coords1
   // The parameter vector B contains the factors of the expression xc = xi*B0 + yi*B1 + B2
   let ref_1_2 = new ReferNPolyn( polDegree );
   let numCoefs = ref_1_2.GetNumCoef();
   let Y1 = new Matrix( numSamples, 1 );
   let Y2 = new Matrix( numSamples, 1 );
   let X = new Matrix( numSamples, numCoefs );
   let row = 0;
   for ( let i = 0; i < coords1.length; ++i )
      if ( coords1[i] && coords2[i] )
      {
         //console.writeln(coords1[i]," ",coords2[i]);
         Y1.at( row, 0, coords2[i].x );
         Y2.at( row, 0, coords2[i].y );

         let Xval = ref_1_2.GetPointCoef( coords1[i] );
         for ( let c = 0; c < numCoefs; ++c )
            X.at( row, c, Xval[c] );
         row++;
      }

   // Solve the two multiple regressions
   let XT = X.transpose();
   let XT_X_inv_XT = (XT.mul( X )).inverse().mul( XT );
   let B1 = XT_X_inv_XT.mul( Y1 );
   let B2 = XT_X_inv_XT.mul( Y2 );

   // Create the correction matrix that transform from coords1 to coords2
   //console.writeln( "B1:" ); B1.Print();
   //console.writeln( "B2:" ); B2.Print();
   for ( let i = 0; i < numCoefs; ++i )
   {
      ref_1_2.at( 0, i, B1.at( i, 0 ) );
      ref_1_2.at( 1, i, B2.at( i, 0 ) );
   }
   //console.writeln( "Correction matrix:" );
   //ref_1_2.Print();

   // Calculate R2 and RMS
/*   let SSR = 0;
   for ( let i = 0; i < coords1.length; ++i )
   {
      if ( coords1[i] && coords2[i] )
      {
         let c2 = ref_1_2.apply( coords1[i] );
         let errX = c2.x-coords2[i].x;
         let errY = c2.y-coords2[i].y;
         //console.writeln( format( "%f;%f;%f;%f", coords1[i].x, coords1[i].y, errX, errY ) );
         SSR += errX*errX + errY*errY;
      }
   }
   let RMSerr = Math.sqrt( SSR/numSamples );*/

   //return { ref_1_2: ref_1_2, rms: RMSerr };
   return ref_1_2;
}

// ----------------------------------------------------------------------------

function MultipleLinearRegressionHelmert( coords1, coords2, ref1, ref2 )
{
   if ( coords1.length != coords2.length )
      throw "Input arrays of different size in Multiple Linear Regression";
   let numSamples = 0;
   for ( let i = 0; i < coords1.length; ++i )
      if ( coords1[i] && coords2[i] )
         numSamples++;
   //console.writeln( "Samples: ", numSamples );
   if ( numSamples < 4 )
      throw "There are too few valid samples";

   // Detect mirror case
   let refMirror = MultipleLinearRegression( 1, coords1, coords2 ).ToLinearMatrix();
   let mirrorFactor = (refMirror.at( 0, 1 ) * refMirror.at( 1, 0 ) > 0) ? 1 : -1;

   // Uses independent multiple linear regression for x and y
   // The model is: Y = X * B + err
   // The regresand Y contains the x (or y) of the predicted coordinates coords2
   // The regresors X contains the vectors (x,y,1) with the source coordinates coords1
   // The parameter vector B contains the factors of the expression xc = xi*B0 + yi*B1 + B2
   let Y = new Matrix( numSamples*2, 1 );
   let X = new Matrix( numSamples*2, 2 );
   let row = 0;
   for ( let i = 0; i < coords1.length; ++i )
      if ( coords1[i] && coords2[i] )
      {
         //console.writeln( coords1[i], " ", coords2[i] );
         Y.at( row*2,     0, coords2[i].x - ref2.x );
         Y.at( row*2 + 1, 0, coords2[i].y - ref2.y );

         X.at( row*2,     0,  coords1[i].x - ref1.x );
         X.at( row*2,     1,  coords1[i].y - ref1.y );
         X.at( row*2 + 1, 1,  mirrorFactor*(coords1[i].x - ref1.x) );
         X.at( row*2 + 1, 0, -mirrorFactor*(coords1[i].y - ref1.y) );

         ++row;
      }

   // Solve the two multiple regressions
   let XT = X.transpose();
   let XT_X_inv_XT = (XT.mul( X )).inverse().mul( XT );
   let B = XT_X_inv_XT.mul( Y );

   // Create the correction matrix that transform from coords1 to coords2
   let m = new Matrix( 3, 3 );
   m.at( 0, 0, B.at( 0, 0 ) );              m.at( 0, 1, B.at( 1, 0 ) );               m.at( 0, 2, 0 );
   m.at( 1, 0, mirrorFactor*B.at( 1, 0 ) ); m.at( 1, 1, -mirrorFactor*B.at( 0, 0 ) ); m.at( 1, 2, 0 );
   m.at( 2, 0, 0 );                         m.at( 2, 1, 0 );                          m.at( 2, 2, 1 );
   //console.writeln( "m" ); m.Print();

   let t1 = new Matrix( 1, 0, -ref1.x,
                        0, 1, -ref1.y,
                        0, 0, 1 );
   let t2 = new Matrix( 1, 0, ref2.x,
                        0, 1, ref2.y,
                        0, 0, 1 );
   let ref_1_2 = t2.mul( m.mul( t1 ) );
   //console.writeln( "ref_1_2" ); ref_1_2.Print();
   //console.writeln( "refMirror" ); refMirror.Print();
   return ref_1_2;
}

// ----------------------------------------------------------------------------

function ApplySTF( view, stf )
{
   let HT = new HistogramTransformation;
   if ( view.image.isColor )
   {
      let stfActive = false;
      for ( let i = 0; i < 3 && !stfActive; ++i )
         stfActive |= stf[i][1] != 0 || stf[i][0] != 0.5 || stf[i][2] != 1;
      if ( !stfActive )
         return;
      HT.H = [ [ stf[0][1], stf[0][0], stf[0][2], 0, 1 ],
               [ stf[1][1], stf[1][0], stf[1][2], 0, 1 ],
               [ stf[2][1], stf[2][0], stf[2][2], 0, 1 ],
               [ 0,         0.5,       1,         0, 1 ],
               [ 0,         0.5,       1,         0, 1 ] ];
   }
   else
   {
      if ( stf[0][1] == 0 && stf[0][0] == 0.5 && stf[0][2] == 1 )
         return;
      HT.H = [ [ 0,         0.5,       1,         0, 1 ],
               [ 0,         0.5,       1,         0, 1 ],
               [ 0,         0.5,       1,         0, 1 ],
               [ stf[0][1], stf[0][0], stf[0][2], 0, 1 ],
               [ 0,         0.5,       1,         0, 1 ] ];
   }

   console.writeln( format( "<b>Applying STF to '%ls'</b>:\x1b[38;2;100;100;100m", view.id ) );
   HT.executeOn( view, false/*swapFile*/ );
   console.write( "\x1b[0m" );
}

/*
 * Projections
 *
 * Implementation of various projection systems.
 *
 * Copyright (C) 2013-2024, Andres del Pozo
 * Copyright (C) 2019-2024, Juan Conejero (PTeam)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __ADP_PROJECTIONS_jsh
#define __ADP_PROJECTIONS_jsh

// ****************************************************************************
// ProjectionBase
// ****************************************************************************

function ProjectionBase()
{
   "use strict";

   this.GetWCS = function()
   {
      return this.wcs;
   };

   this.InitFromRefpoint = function( lng0, lat0, phip )
   {
      this.wcs = new WCSKeywords();
      this.wcs.ctype1 = "'RA---" + this.projCode + "'";
      this.wcs.ctype2 = "'DEC--" + this.projCode + "'";
      this.wcs.crval1 = lng0;
      this.wcs.crval2 = lat0;
      this.ra0 = lng0 * Math.RAD;
      this.dec0 = lat0 * Math.RAD;

      if ( phip === undefined || phip === null )
      {
         // Default value for the native longitude of the celestial pole.
         phip = (lat0 < this.theta0) ? 180 : 0;
         phip += this.phi0;
         if ( phip < -180 )
            phip += 360;
         else if ( phip > 180 )
            phip -= 360;
      }

      if ( this.theta0 )
         this.wcs.pv1_2 = this.theta0;

      this.sph = new SphericalRotation();
      this.sph.Init( lng0, lat0, this.phi0, this.theta0, phip, null/*latpole*/ );
   };

   this.InitFromWCS = function( wcs )
   {
      if ( wcs.pv1_1 != null )
         this.phi0 = wcs.pv1_1;

      if ( wcs.pv1_2 != null )
      {
         this.theta0 = wcs.pv1_2;
         if ( Math.abs( this.theta0 ) > 90 )
         {
            if ( Math.abs( this.theta0 ) > 90 + 1e-5 )
               throw "Invalid WCS coordinates: theta0 > 90";
            if ( this.theta0 > 90 )
               this.theta0 = 90;
            else
               this.theta0 = -90;
         }
      }

      let phip = wcs.lonpole;
      if ( phip === undefined || phip === null )
      {
         // Default value for the native longitude of the celestial pole.
         phip = (wcs.crval2 < this.theta0) ? 180 : 0;
         phip += this.phi0;
         if ( phip < -180 )
            phip += 360;
         else if ( phip > 180 )
            phip -= 360;
      }

      this.sph = new SphericalRotation();
      this.sph.Init( wcs.crval1, wcs.crval2, this.phi0, this.theta0, phip, wcs.latpole );
      this.wcs = wcs;
      this.ra0 = wcs.crval1 * Math.RAD;
      this.dec0 = wcs.crval2 * Math.RAD;
   };

   this.Direct = function( p )
   {
      let np = this.sph.CelestialToNative( p );
      if ( np == null )
         return null;
      if ( !isFinite( np.x ) || !isFinite( np.y ) )
         return null;
      return this.Project( np );
   };

   this.Inverse = function( p )
   {
      let np = this.Unproject( p );
      if ( np == null )
         return null;
      if ( !isFinite( np.x ) || !isFinite( np.y ) )
         return null;
      return this.sph.NativeToCelestial( np );
   };

   this.CheckBrokenLine = function( cp1, cp2 )
   {
      if ( !cp1 || !cp2 )
         return false;
      let np1 = this.sph.CelestialToNative( cp1 );
      let np2 = this.sph.CelestialToNative( cp2 );
      let dist = ImageMetadata.DistanceFast( np1, np2 );
      return dist < 150;
   };
}

// ****************************************************************************
// ProjectionZenithalBase
// ****************************************************************************

function ProjectionZenithalBase()
{
   this.__base__ = ProjectionBase;
   this.__base__();

   this.phi0 = 0;
   this.theta0 = 90;

   this.Project = function( np )
   {
      let rTheta = this.GetRTheta( np );
      return new Point( rTheta * DMath.sin( np.x ), -rTheta * DMath.cos( np.x ) );
   };

   this.Unproject = function( np )
   {
      let rTheta = Math.sqrt( np.x * np.x + np.y * np.y );
      return new Point( DMath.atan2( np.x, -np.y ), this.GetTheta( rTheta ) );
   };
}

ProjectionZenithalBase.prototype = new ProjectionBase();

// ****************************************************************************
// Zenithal Equal Area Projection
// ****************************************************************************

function ProjectionZenithalEqualArea()
{
   this.__base_1__ = ProjectionZenithalBase;
   this.__base_1__();

   this.identifier = "ZenithalEqualArea";
   this.projCode = "ZEA";
   this.name = "Zenithal Equal Area";

   this.GetRTheta = function( np )
   {
      return 360/Math.PI * DMath.sin( (90 - np.y)/2 );
   };

   this.GetTheta = function( rTheta )
   {
      return 90 - 2*DMath.asin( Math.PI/360 * rTheta );
   };

   this.CheckBrokenLine = function( cp1, cp2 )
   {
      let np1 = this.sph.CelestialToNative( cp1 );
      let np2 = this.sph.CelestialToNative( cp2 );
      let y = (np1.y + np2.y)/2;
      let dist = Math.min( Math.abs( np1.x - np2.x - 360 ) % 360, Math.abs( np1.x - np2.x + 360 ) % 360 );
      return dist < DMath.sin( 45 + y/2 ) * 180;
   };
}

ProjectionZenithalEqualArea.prototype = new ProjectionZenithalBase();

// ****************************************************************************
// Stereographic Projection
// ****************************************************************************

function ProjectionStereographic()
{
   this.__base_1__ = ProjectionZenithalBase;
   this.__base_1__();

   this.identifier = "Stereographic";
   this.projCode = "STG";
   this.name = "Stereographic";

   this.GetRTheta = function( np )
   {
      return 360/Math.PI * DMath.tan( (90 - np.y)/2 );
   };

   this.GetTheta = function( rTheta )
   {
      return 90 - 2*DMath.atan( Math.PI/360 * rTheta );
   };

   this.CheckBrokenLine = function( cp1, cp2 )
   {
      return true;
   };
}

ProjectionStereographic.prototype = new ProjectionZenithalBase();

// ****************************************************************************
// Orthographic Projection
// ****************************************************************************

function ProjectionOrthographic()
{
   this.__base__ = ProjectionBase;
   this.__base__();

   this.phi0 = 0;
   this.theta0 = 90;
   this.r0 = Math.DEG;
   this.x0 = 0;
   this.y0 = 0;
   this.w = [ 1/this.r0, 0, 1, -1 ];

   this.identifier = "Orthographic";
   this.projCode = "SIN";
   this.name = "Orthographic";

   this.CheckBrokenLine = function( cp1, cp2 )
   {
      if ( !cp1 || !cp2 )
         return false;
      let np1 = this.sph.CelestialToNative( cp1 );
      let np2 = this.sph.CelestialToNative( cp2 );
      let dist = ImageMetadata.DistanceFast( np1, np2 );
      return dist < 150;
   };

   this.Project = function( np ) // Native to projection plane
   {
      if ( np.y < 0 || np.y > 180 )
         return null;
      let sinphi = DMath.sin( np.x );
      let cosphi = DMath.cos( np.x );
      let res = new Point();
      res.x = sinphi;
      res.y = cosphi;
      let t = (90 - Math.abs( np.y )) * Math.RAD;
      let z, costhe;
      if ( t < 1e-5 )
      {
         if ( np.y > 0 )
            z = t*t/2;
         else
            z = 2 - t*t/2;
         costhe = t;
      }
      else
      {
         z = 1 - DMath.sin( np.y );
         costhe = DMath.cos( np.y );
      }
      let r = this.r0 * costhe;
      if ( this.w[ 1 ] == 0 )
      {
         res.x = r*res.x - this.x0;
         res.y = -r*res.y - this.y0;
         return res;
      }
      else
         throw "Unsupported Slant Orthographic projection";
   };

   this.Unproject = function( p )
   {
      let x0 = this.w[0] * ( p.x + this.x0 );
      let y0 = (p.y + this.y0) * this.w[0];
      let y02 = y0*y0;
      let r2 = x0*x0 + y02;
      if ( this.w[1] == 0 )
      {
         let res = new Point();
         if ( r2 != 0 )
            res.x = DMath.atan2( x0, -y0 );
         else
            res.x = 0;
         if ( r2 < 0.5 )
            res.y = DMath.acos( Math.sqrt( r2 ) );
         else if ( r2 <= 1 )
            res.y = DMath.asin( Math.sqrt( 1 - r2 ) );
         return res;
      }
      else
         throw "Unsupported Slant Orthographic projection";
   };
}

ProjectionOrthographic.prototype = new ProjectionBase();

// ****************************************************************************
// Mercator Projection
// ****************************************************************************

function ProjectionMercator()
{
   this.__base__ = ProjectionBase;
   this.__base__();

   this.phi0 = 0;
   this.theta0 = 0;
   this.r0 = Math.DEG;
   this.w = [ 1, 1 ];
   this.x0 = 0;
   this.y0 = 0;

   this.identifier = "Mercator";
   this.projCode = "MER";
   this.name = "Mercator";

   this.Project = function( np ) // Native to projection plane
   {
      return new Point( np.x - this.x0, this.r0 * Math.log( DMath.tan( ( np.y + 90 )/2 ) ) - this.y0 );
   };

   this.Unproject = function( p )
   {
      let theta = 2 * DMath.atan( Math.exp( (p.y + this.y0)/this.r0 ) ) - 90;
      return new Point( p.x + this.x0, theta );
   };
}

ProjectionMercator.prototype = new ProjectionBase();

// ****************************************************************************
// Plate-Carree Projection
// ****************************************************************************

function ProjectionPlateCarree()
{
   this.__base__ = ProjectionBase;
   this.__base__();

   this.phi0 = 0;
   this.theta0 = 0;

   this.identifier = "PlateCarree";
   this.projCode = "CAR";
   this.name = "Plate-Carree";

   this.Project = function( np ) // Native to projection plane
   {
      return new Point( np.x, np.y );
   };

   this.Unproject = function( p )
   {
      return new Point( p.x, p.y );
   };
}

ProjectionPlateCarree.prototype = new ProjectionBase();

// ****************************************************************************
// Hammer-Aitoff Projection
// ****************************************************************************

function ProjectionHammerAitoff()
{
   this.__base__ = ProjectionBase;
   this.__base__();

   this.phi0 = 0;
   this.theta0 = 0;
   this.Zmin = 1 / Math.sqrt( 2 );

   this.identifier = "HammerAitoff";
   this.projCode = "AIT";
   this.name = "Hammer-Aitoff";

   this.Project = function( np ) // Native to projection plane
   {
      let cosTheta = DMath.cos( np.y );
      let gamma = Math.DEG * Math.sqrt( 2 / (1 + cosTheta * DMath.cos( np.x/2 )) );
      return new Point( 2 * gamma * cosTheta * DMath.sin( np.x/2 ), gamma * DMath.sin( np.y ) );
   };

   this.Unproject = function( p )
   {
      let X = Math.PI * p.x / 720;
      let Y = Math.PI * p.y / 360;
      let Z = Math.sqrt( 1 - X * X - Y * Y );
      if ( Z < this.Zmin )
         return null;
      return new Point( 2 * DMath.atan2( 2*Z*X, 2*Z*Z - 1 ), DMath.asin( Math.RAD * p.y * Z ) );
   };
}

ProjectionHammerAitoff.prototype = new ProjectionBase();

// ****************************************************************************
// Gnomonic Projection
// ****************************************************************************

function Gnomonic( scale, ra0, dec0 )
{
   this.__base__ = ProjectionBase;
   this.__base__();

   this.phi0 = 0;
   this.theta0 = 90;
   this.scale = scale;
   this.ra0 = ra0 * Math.RAD;
   this.dec0 = dec0 * Math.RAD;

   this.identifier = "Gnomonic";
   this.projCode = "TAN";
   this.name = "Gnomonic";

   this.sinDec0 = Math.sin( this.dec0 );
   this.cosDec0 = Math.cos( this.dec0 );

   this.GetWCS = function()
   {
      let wcs = new WCSKeywords();
      wcs.ctype1 = "'RA---TAN'";
      wcs.ctype2 = "'DEC--TAN'";
      wcs.crval1 = this.ra0 * Math.DEG;
      wcs.crval2 = this.dec0 * Math.DEG;
      return wcs;
   };

   this.Direct = function( p )
   {
      let dra = p.x * Math.RAD - this.ra0;
      let dec = p.y * Math.RAD;
      let sinDec = Math.sin( dec );
      let cosDec = Math.cos( dec );
      let A = cosDec * Math.cos( dra );
      let cosD = this.sinDec0 * sinDec + this.cosDec0 * A;
      if ( cosD < 1.0e-5 ) // distance > 89.999 deg ?
         return null;
      let F = this.scale/cosD;
      return new Point( F * cosDec * Math.sin( dra ),
                        F * (this.cosDec0 * sinDec - this.sinDec0 * A) );
   };

   this.Inverse = function( p )
   {
      let X = -p.x / this.scale;
      let Y = -p.y / this.scale;
      let D = Math.atan( Math.sqrt( X*X + Y*Y ) );
      let B = Math.atan2( -X, Y );
      let sinD = Math.sin( D );
      let cosD = Math.cos( D );
      let cosB = Math.cos( B );
      let XX = this.sinDec0 * sinD * cosB + this.cosDec0 * cosD;
      let YY = sinD * Math.sin( B );
      return new Point( Math.DEG * (this.ra0 + Math.atan2( YY, XX )),
                        Math.DEG * Math.asin( this.sinDec0 * cosD - this.cosDec0 * sinD * cosB ) );
   };

   this.CheckBrokenLine = function( cp1, cp2 )
   {
      let gp1 = this.Direct( cp1 );
      if ( !gp1 )
         return false;
      let gp2 = this.Direct( cp2 );
      if ( !gp2 )
         return false;
      let dx = gp2.x - gp1.x;
      let dy = gp2.y - gp1.y;
      return dx*dx + dy*dy < 45*45;
   };
}

Gnomonic.prototype = new ProjectionBase();

// ****************************************************************************
// CLASS SphericalRotation
// ****************************************************************************

function SphericalRotation()
{
   this.tolerance = 1e-5;

   this.Init = function( lng0, lat0, phi0, theta0, phip, latpole )
   {
      let latpreq = 0;
      let lngp = null;
      let latp = (latpole === null || latpole === undefined) ? 90 : latpole;
      if ( theta0 == 90 )
      {
         // Fiducial point at the native pole.
         lngp = lng0;
         latp = lat0;
      }
      else
      {
         // Fiducial point away from the native pole.
         let slat0 = DMath.sin( lat0 );
         let clat0 = DMath.cos( lat0 );
         let sthe0 = DMath.sin( theta0 );
         let cthe0 = DMath.cos( theta0 );

         let sphip, cphip;
         let u, v;
         if ( phip == phi0 )
         {
            sphip = 0;
            cphip = 1;
            u = theta0;
            v = 90 - lat0;
         }
         else
         {
            sphip = DMath.sin( phip - phi0 );
            cphip = DMath.cos( phip - phi0 );

            let x = cthe0 * cphip;
            let y = sthe0;
            let z = Math.sqrt( x*x + y*y );
            if ( z == 0 )
            {
               if ( slat0 != 0 )
                  throw "Invalid WCS coordinates"; // nlat0 == 0 is required for |phip - phi0| = 90 and theta0 == 0

               // latp determined solely by LATPOLEa in this case.
               latpreq = 2;
               if ( latp > 90 )
                  latp = 90;
               else if ( latp < -90 )
                  latp = -90;
            }
            else
            {
               let slz = slat0 / z;
               if ( Math.abs( slz ) > 1 )
               {
                  if ( (Math.abs( slz ) - 1) < this.tolerance )
                  {
                     if ( slz > 0 )
                        slz = 1;
                     else
                        slz = -1;
                  }
                  else
                     throw format( "Invalid WCS coordinates" ); // |lat0| <= DMath.asin(z) is required  for these values of phip, phi0, and theta0"
               }

               u = DMath.atan2( y, x );
               v = DMath.acos( slz );
            }
         }

         if ( latpreq == 0 )
         {
            let latp1 = u + v;
            if ( latp1 > 180 )
               latp1 -= 360;
            else if ( latp1 < -180 )
               latp1 += 360;

            let latp2 = u - v;
            if ( latp2 > 180 )
               latp2 -= 360;
            else if ( latp2 < -180 )
               latp2 += 360;

            if ( Math.abs( latp1 ) < 90 + this.tolerance &&
                 Math.abs( latp2 ) < 90 + this.tolerance )
            {
               // There are two valid solutions for latp.
               latpreq = 1;
            }

            if ( Math.abs( latp - latp1 ) < Math.abs( latp - latp2 ) )
            {
               if ( Math.abs( latp1 ) < 90 + this.tolerance )
                  latp = latp1;
               else
                  latp = latp2;
            }
            else
            {
               if ( Math.abs( latp2 ) < 90 + this.tolerance )
                  latp = latp2;
               else
                  latp = latp1;
            }

            // Account for rounding errors.
            if ( Math.abs( latp ) < 90 + this.tolerance )
            {
               if ( latp > 90 )
                  latp = 90;
               else if ( latp < -90 )
                  latp = -90;
            }
         }

         let z = DMath.cos( latp ) * clat0;
         if ( Math.abs( z ) < this.tolerance )
         {
            if ( Math.abs( clat0 ) < this.tolerance ) // celestial pole at the fiducial point
               lngp = lng0;
            else if ( latp > 0 ) // celestial north pole at the native pole
               lngp = lng0 + phip - phi0 - 180;
            else // celestial south pole at the native pole
               lngp = lng0 - phip + phi0;
         }
         else
         {
            let x = (sthe0 - DMath.sin( latp )*slat0)/z;
            let y = sphip * cthe0/clat0;
            if ( x == 0 && y == 0 ) // sanity check (shouldn't be possible)
               throw "Invalid WCS coordinates: internal error";
            lngp = lng0 - DMath.atan2( y, x );
         }

         // Make celestial longitude of the native pole the same sign as at the fiducial point.
         if ( lng0 >= 0 )
         {
            if ( lngp < 0 )
               lngp += 360;
            else if ( lngp > 360 )
               lngp -= 360;
         }
         else
         {
            if ( lngp > 0 )
               lngp -= 360;
            else if ( lngp < -360 )
               lngp += 360;
         }
      }

      this.latpole = latp;
      this.alphaP = lngp;
      this.deltaP = 90 - latp;
      this.phiP = phip;
      this.cosdeltaP = DMath.cos( this.deltaP );
      this.sindeltaP = DMath.sin( this.deltaP );
   }; //this.Init()

   var Adjust360 = function( x, min, max )
   {
      while ( x >= max )
         x -= 360;
      while ( x < min )
         x += 360;
      return x;
   };

   this.NativeToCelestial = function( np )
   {
      let cp = new Point();
      if ( this.sindeltaP == 0 )
      {
         if ( this.deltaP == 0 )
         {
            cp.x = np.x + Adjust360( this.alphaP + 180 - this.phiP, 0, 360 );
            cp.y = np.y;
         }
         else
         {
            cp.x = Adjust360( this.alphaP + this.phiP, 0, 360 ) - np.x;
            cp.y = -np.y;
         }
      }
      else
      {
         cp.x = np.x - this.phiP;

         let sinthe = DMath.sin( np.y );
         let costhe = DMath.cos( np.y );
         let costhe3 = costhe * this.cosdeltaP;

         let dphi = cp.x;
         let cosphi = DMath.cos( dphi );

         // Compute the celestial longitude.
         let x = sinthe * this.sindeltaP - costhe3 * cosphi;
         if ( Math.abs( x ) < this.tolerance )
         {
            // Rearrange formula to reduce roundoff errors.
            x = -DMath.cos( np.y + this.deltaP ) + costhe3 * (1 - cosphi);
         }

         let y = -costhe * DMath.sin( dphi );
         let dlng;
         if ( Math.abs( x ) > this.tolerance || Math.abs( y ) > this.tolerance )
         {
            dlng = DMath.atan2( y, x );
         }
         else
         {
            // Change of origin of longitude.
            if ( this.deltaP < 90 )
               dlng = dphi + 180;
            else
               dlng = -dphi;
         }
         cp.x = this.alphaP + dlng;

         // Compute the celestial latitude.
         if ( (dphi % 180) == 0 )
         {
            cp.y = np.y + cosphi * this.deltaP;
            if ( cp.y > 90 )
               cp.y = 180 - cp.y;
            if ( cp.y < -90 )
               cp.y = -180 - cp.y;
         }
         else
         {
            let z = sinthe * this.cosdeltaP + costhe * this.sindeltaP * cosphi;
            if ( Math.abs( z ) > 0.99 )
            {
               // Use an alternative formula for greater accuracy.
               cp.y = DMath.acos( Math.sqrt( x*x + y*y ) );
               if ( cp.y * z < 0 )
                  cp.y *= -1;
            }
            else
               cp.y = DMath.asin( z );
         }
      }

      // Normalize the celestial longitude.
      if ( this.alphaP >= 0 )
      {
         if ( cp.x < 0 )
            cp.x += 360;
      }
      else
      {
         if ( cp.x > 0 )
            cp.x -= 360;
      }
      cp.x = Adjust360( cp.x, -360, 360 );

      return cp;
   }; // this.NativeToCelestial()

   this.CelestialToNative = function( cp )
   {
      // Check for a simple change in origin of longitude.
      let np = new Point();
      let dphi;
      if ( this.sindeltaP == 0 )
      {
         if ( this.deltaP == 0 )
         {
            dphi = Adjust360( this.phiP - 180 - this.alphaP, 0, 360 );
            np.x = Adjust360( cp.x + dphi, -180, 180 );
            np.y = cp.y;
         }
         else
         {
            dphi = Adjust360( this.phiP + this.alphaP, 0, 360 );
            np.x = Adjust360( dphi - cp.x, -180, 180 );
            np.y = -cp.y;
         }
      }
      else
      {
         np.x = cp.x - this.alphaP;

         let sinlat = DMath.sin( cp.y );
         let coslat = DMath.cos( cp.y );
         let coslat3 = coslat * this.cosdeltaP;

         let dlng = np.x;
         let coslng = DMath.cos( dlng );

         // Compute the native longitude.
         let x = sinlat * this.sindeltaP - coslat3 * coslng;
         if ( Math.abs( x ) < this.tolerance )
         {
            // Rearrange formula to reduce roundoff errors.
            x = -DMath.cos( cp.y + this.deltaP ) + coslat3*(1 - coslng);
         }

         let y = -coslat * DMath.sin( dlng );
         if ( x != 0 || y != 0 )
            dphi = DMath.atan2( y, x );
         else
            dphi = ( this.deltaP < 90 ) ? dlng - 180 : -dlng;
         np.x = Adjust360( this.phiP + dphi, -180, 180 );

         // Compute the native latitude.
         if ( (dlng % 180) == 0 )
         {
            np.y = cp.y + coslng * this.deltaP;
            if ( np.y > 90 )
               np.y = 180 - np.y;
            if ( np.y < -90 )
               np.y = -180 - np.y;
         }
         else
         {
            let z = sinlat*this.cosdeltaP + coslat*this.sindeltaP*coslng;
            if ( Math.abs( z ) > 0.99 )
            {
               // Use an alternative formula for greater accuracy.
               np.y = DMath.acos( Math.sqrt( x*x + y*y ) );
               if ( np.y*z < 0 )
                  np.y *= -1;
            }
            else
               np.y = DMath.asin( z );
         }
      }

      return np;
   }; // this.CelestialToNative()
} // SphericalRotation

// ****************************************************************************
// ProjectionFactory
// ****************************************************************************

function ProjectionFactory( configObject, ra, dec )
{
   let orgRA = (configObject.projectionOriginMode == 1) ? configObject.projectionOriginRA : ra;
   let orgDec = (configObject.projectionOriginMode == 1) ? configObject.projectionOriginDec : dec;
   let projection = null;
   let initialize = true;
   switch ( configObject.projection )
   {
   case 0:
   case 'TAN':
      projection = new Gnomonic( Math.DEG, orgRA, orgDec );
      initialize = false;
      break;
   case 1: // stereographic
   case 'STG':
      projection = new ProjectionStereographic();
      break;
   case 2: // plate-carree
   case 'CAR':
      projection = new ProjectionPlateCarree();
      break;
   case 3: // mercator
   case 'MER':
      projection = new ProjectionMercator();
      break;
   case 4: // HammerAitoff
   case 'AIT':
      projection = new ProjectionHammerAitoff();
      break;
   case 5: // zenithal equal area
   case 'ZEA':
      projection = new ProjectionZenithalEqualArea();
      break;
   case 6: // orthographic
   case 'SIN':
      projection = new ProjectionOrthographic();
      break;
   default:
      throw "Invalid projection code";
   }
   if ( initialize )
      projection.InitFromRefpoint( orgRA, orgDec );
   return projection;
}

// ****************************************************************************
// ConfigProjectionDialog
// ****************************************************************************

function ConfigProjectionDialog( object, projection )
{
   this.__base__ = Dialog;
   this.__base__();

   this.restyle();
   this.labelWidth = this.font.width( "Right Ascension (hms):M" );

   this.projectionOriginMode = object.projectionOriginMode;

   // ORIGIN
   this.origin_Group = new GroupBox( this );
   this.origin_Group.title = "Projection Origin";
   this.origin_Group.sizer = new VerticalSizer;
   this.origin_Group.sizer.margin = 8;
   this.origin_Group.sizer.spacing = 8;

   this.originImage_Radio = new RadioButton( this );
   this.originImage_Radio.text = "Use the center of the image as the origin of the projection";
   this.originImage_Radio.checked = this.projectionOriginMode != 1;
   //this.originImage_Radio.toolTip = "<p></p>";
   this.originImage_Radio.onCheck = function( value )
   {
      this.dialog.projectionOriginMode = 0;
      this.dialog.EnableOriginControls();
   };
   this.origin_Group.sizer.add( this.originImage_Radio );

   this.EnableOriginControls = function()
   {
      this.originCoords_Editor.enabled = this.projectionOriginMode == 1;
   };

   this.originCoords_Radio = new RadioButton( this );
   this.originCoords_Radio.text = "Use the following coordinates as the origin of the projection";
   this.originCoords_Radio.checked = this.projectionOriginMode == 1;
   //this.originCoords_Radio.toolTip = "<p></p>";
   this.originCoords_Radio.onCheck = function( value )
   {
      this.dialog.projectionOriginMode = 1;
      this.dialog.EnableOriginControls();
   };
   this.origin_Group.sizer.add( this.originCoords_Radio );

   let originCoords = null;
   if ( object.projectionOriginRA != null && object.projectionOriginDec != null )
      originCoords = new Point( object.projectionOriginRA, object.projectionOriginDec );
   this.originCoords_Editor = new CoordinatesEditor( this, originCoords, this.labelWidth, null, "Coordinates of the origin of the projection" );
   this.origin_Group.sizer.add( this.originCoords_Editor );

   this.EnableOriginControls();

   // Common Buttons
   this.ok_Button = new PushButton( this );
   this.ok_Button.text = "OK";
   this.ok_Button.icon = this.scaledResource( ":/icons/ok.png" );
   this.ok_Button.onClick = function()
   {
      object.projectionOriginMode = this.dialog.projectionOriginMode;
      let coords = this.dialog.originCoords_Editor.GetCoords();
      object.projectionOriginRA = coords.x;
      object.projectionOriginDec = coords.y;
      this.dialog.ok();
   };

   this.cancel_Button = new PushButton( this );
   this.cancel_Button.text = "Cancel";
   this.cancel_Button.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancel_Button.onClick = function()
   {
      this.dialog.cancel();
   };

   this.buttons_Sizer = new HorizontalSizer;
   this.buttons_Sizer.spacing = 6;
   this.buttons_Sizer.addStretch();
   this.buttons_Sizer.add( this.ok_Button );
   this.buttons_Sizer.add( this.cancel_Button );

   // Global sizer

   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 8;
   this.sizer.add( this.origin_Group );
   this.sizer.add( this.buttons_Sizer );

   this.windowTitle = "Projection Configuration";

   this.ensureLayoutUpdated();
   this.adjustToContents();
   this.setFixedSize();
}

ConfigProjectionDialog.prototype = new Dialog();

#endif   // __ADP_PROJECTIONS_jsh




// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    console.warningln( " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    console.noteln("Opening Dialog...");
    console.flush();

    scriptParameters.load();
    scriptParameters.imageActiveWindow = ImageWindow.activeWindow;

    if ( scriptParameters.imageActiveWindow.isNull )
    {
        new MessageBox("<p>No active image.</p>", TITLE, StdIcon.Warning, StdButton.Ok).execute();
    }
    else if ( scriptParameters.imageActiveWindow.currentView.isPreview )
    {
        new MessageBox("<p>This script cannot work on previews</p>", TITLE, StdIcon.Warning, StdButton.Ok).execute();
    }
    else
    {
        if ( scriptParameters.imageActiveWindow.astrometricSolutionSummary() != "" )
        {
            scriptParameters.imageMainView  = scriptParameters.imageActiveWindow.mainView;
            scriptParameters.imageImage     = scriptParameters.imageActiveWindow.mainView.image;
            scriptParameters.imageView      = new View(scriptParameters.imageMainView);
            scriptParameters.imageID        = scriptParameters.imageView.id;

            scriptParameters.workingPreview = new ImageWindow(
                1, 1, 1,
                scriptParameters.imageMainView.image.bitsPerSample,
                scriptParameters.imageMainView.image.isReal,
                false, "WIMIPreviewImage");

            scriptParameters.workingPreview.mainView.beginProcess(UndoFlag.NoSwapFile);
            scriptParameters.workingPreview.mainView.image.assign(scriptParameters.imageMainView.image);
            scriptParameters.workingPreview.mainView.endProcess();

            scriptParameters.imageMainView = scriptParameters.workingPreview.mainView;
            scriptParameters.imageImage    = scriptParameters.workingPreview.mainView.image;

            let dialog = new mainDialog();
            dialog.ScrollControl.displayImage = scriptParameters.imageImage;
            if ( dialog.execute() )
                console.writeln("Execute -- OK");
            else
            {
                console.writeln("Execute -- CANCEL");
                scriptParameters.workingPreview.forceClose();
            }
        }
        else
        {
            new MessageBox("<p>The image has no astrometric solution.</p>", TITLE, StdIcon.Warning, StdButton.Ok).execute();
        }
    }
}

main();
