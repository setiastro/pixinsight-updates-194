#engine v8

#feature-id MaskMerge : SetiAstro > MaskMerge
#feature-icon  mask.svg
#feature-info This script merges two masks using union, intersection, or subtraction operations.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Mask Merge
 * Version: 1.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "MaskMerge"
#define VERSION "1.1"

let WIDTH = 500;

// ============================================================================
// Parameters
// ============================================================================

var MaskMergeParameters = {
    mask1View:   undefined,
    mask2View:   undefined,
    mask3View:   undefined,
    operation1:  "",
    operation2:  "",
    invertMask1: false,
    invertMask2: false,
    invertMask3: false,
    operations:  [],
    blurAmount:  0,
    save: function() {},
    load: function() {}
};

// ============================================================================
// Mask logic helpers
// ============================================================================

function getPixelMathExpression( operation, mask1Expr, mask2Expr )
{
    switch ( operation )
    {
    case "union":        return mask1Expr + " + " + mask2Expr + " - " + mask1Expr + " * " + mask2Expr;
    case "intersection": return mask1Expr + " * " + mask2Expr;
    case "subtract":     return mask1Expr + " - " + mask2Expr;
    default:
        throw new Error( "Invalid operation: " + operation );
    }
}

function mergeMasks( operation, mask1Id, mask2Id, invertMask1, invertMask2, skipShowingImage )
{
    let mask1Expr = invertMask1 ? "~" + mask1Id : mask1Id;
    let mask2Expr = invertMask2 ? "~" + mask2Id : mask2Id;

    let P = new PixelMath;
    P.expression         = getPixelMathExpression( operation, mask1Expr, mask2Expr );
    P.useSingleExpression = true;
    P.generateOutput     = true;
    P.createNewImage     = true;
    P.newImageId         = mask1Id + "_" + operation + "_" + mask2Id;
    P.newImageColorSpace = PixelMath.SameAsTarget;
    P.showNewImage       = !skipShowingImage;
    P.executeOn( ImageWindow.windowById( mask1Id ).mainView );
    console.noteln( "Mask " + operation + " operation completed successfully with " + mask1Id + " and " + mask2Id );
    return P.newImageId;
}

// ============================================================================
// ScrollControl
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.autoScroll  = true;
        this.tracking    = true;
        this.displayImage = null;
        this.dragging    = false;
        this.dragOrigin  = new Point( 0, 0 );

        this.viewport.cursor = new Cursor( StdCursor.OpenHand );

        this.viewport.onResize = () => { this.initScrollBars(); };

        this.onHorizontalScrollPosUpdated = () => { this.viewport.update(); };
        this.onVerticalScrollPosUpdated   = () => { this.viewport.update(); };

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
            this.dragOrigin.x = x; this.dragOrigin.y = y;
            this.dragging = true;
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            if ( this.dragging )
            {
                this.scrollPosition = new Point( this.scrollPosition ).translatedBy(
                    this.dragOrigin.x - x, this.dragOrigin.y - y );
                this.dragOrigin.x = x; this.dragOrigin.y = y;
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.OpenHand );
            this.dragging = false;
        };

        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this.viewport );
            let result = this.displayImage;
            if ( result == null )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
            }
            else
            {
                result.selectedRect = new Rect( x0, y0, x1, y1 ).translated( this.scrollPosition );
                g.drawBitmap( x0, y0, result.render() );
                result.resetRectSelection();
            }
            g.end();
        };

        this.initScrollBars();
    }

    getImage() { return this.displayImage; }

    doUpdateImage( image )
    {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    }

    initScrollBars()
    {
        let image = this.displayImage;
        if ( image == null || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange(   0, 0 );
        }
        else
        {
            this.setHorizontalScrollRange( 0, Math.max( 0, image.width  - this.viewport.width  ) );
            this.setVerticalScrollRange(   0, Math.max( 0, image.height - this.viewport.height ) );
        }
        this.viewport.update();
    }
};

// ============================================================================
// MaskMergeDialog
// ============================================================================

var MaskMergeDialog = class extends Dialog
{
    constructor()
    {
        super();

        this.userResizable = true;
        this.scaledMinWidth = 450;

        // ---- Title ----
        this.title = new TextBox( this );
        this.title.text = "<b>MaskMerge Tool v" + VERSION + "</b><br>Select masks and operations to merge them.";
        this.title.readOnly = true;
        this.title.backgroundColor = 0xf7f7f7;
        this.title.minHeight = 50; this.title.maxHeight = 50;

        // ---- Instructions ----
        this.instructions = new TextBox( this );
        this.instructions.text =
            "<p>- Choose the operations to perform on the masks and select the masks from the dropdown menus below. 3rd Mask is optional.</p>" +
            "<p>- When using Subtraction ensure the broader mask (typically Range Mask) is in the upper dropdown of the two.</p>" +
            "<p>- Example1: Add Mask 1 and Mask 2, then subtract Mask 3.</p>" +
            "<p>- Example2: Intersect Mask 1 and Mask 2, then add Mask 3.</p>" +
            "<p>- Example3: Since Union is technically Screening: Add Starless and Stars Only Image!";
        this.instructions.readOnly = true;
        this.instructions.backgroundColor = 0xD3D3D3;
        this.instructions.minHeight = 210;

        // ---- Mask 1 ----
        this.mask1Group = new HorizontalSizer; this.mask1Group.spacing = 4;
        this.mask1Label = new Label( this ); this.mask1Label.text = "Mask 1 (Base):";
        this.mask1Group.add( this.mask1Label );

        this.mask1ViewList = new ViewList( this );
        this.mask1ViewList.getAll();
        this.mask1ViewList.maxWidth = WIDTH;
        if ( ImageWindow.activeWindow && ImageWindow.activeWindow.mainView )
        {
            this.mask1ViewList.currentView = ImageWindow.activeWindow.mainView;
            MaskMergeParameters.mask1View  = ImageWindow.activeWindow.mainView;
        }
        this.mask1ViewList.onViewSelected = view => { MaskMergeParameters.mask1View = view; };
        this.mask1ViewList.toolTip = "Select the first mask.";
        this.mask1Group.add( this.mask1ViewList, 100 );

        this.mask1InvertCheckbox = new CheckBox( this );
        this.mask1InvertCheckbox.text    = "Invert";
        this.mask1InvertCheckbox.toolTip = "Invert the first mask.";
        this.mask1InvertCheckbox.onCheck = checked => { MaskMergeParameters.invertMask1 = checked; };
        this.mask1Group.add( this.mask1InvertCheckbox );

        // ---- Operation 1 ----
        this.operationGroup1 = new HorizontalSizer; this.operationGroup1.spacing = 4;

        this.unionCheckbox1 = new CheckBox( this );
        this.unionCheckbox1.text    = "Union (Add)";
        this.unionCheckbox1.toolTip = "Combine the two masks by adding (technically screening) them together.";
        this.unionCheckbox1.onCheck = checked =>
        {
            if ( checked )
            {
                this.intersectionCheckbox1.checked = false;
                this.subtractCheckbox1.checked     = false;
                MaskMergeParameters.operation1     = "union";
            }
            else MaskMergeParameters.operation1 = "";
        };
        this.operationGroup1.add( this.unionCheckbox1 );

        this.intersectionCheckbox1 = new CheckBox( this );
        this.intersectionCheckbox1.text    = "Intersect";
        this.intersectionCheckbox1.toolTip = "Combine the two masks by taking their intersection.";
        this.intersectionCheckbox1.onCheck = checked =>
        {
            if ( checked )
            {
                this.unionCheckbox1.checked    = false;
                this.subtractCheckbox1.checked = false;
                MaskMergeParameters.operation1 = "intersection";
            }
            else MaskMergeParameters.operation1 = "";
        };
        this.operationGroup1.add( this.intersectionCheckbox1 );

        this.subtractCheckbox1 = new CheckBox( this );
        this.subtractCheckbox1.text    = "Subtract";
        this.subtractCheckbox1.toolTip = "Subtract the second mask from the first mask.";
        this.subtractCheckbox1.onCheck = checked =>
        {
            if ( checked )
            {
                this.unionCheckbox1.checked        = false;
                this.intersectionCheckbox1.checked = false;
                MaskMergeParameters.operation1     = "subtract";
            }
            else MaskMergeParameters.operation1 = "";
        };
        this.operationGroup1.add( this.subtractCheckbox1 );

        // ---- Mask 2 ----
        this.mask2Group = new HorizontalSizer; this.mask2Group.spacing = 4;
        this.mask2Label = new Label( this ); this.mask2Label.text = "Mask 2:";
        this.mask2Group.add( this.mask2Label );

        this.mask2ViewList = new ViewList( this );
        this.mask2ViewList.getAll();
        this.mask2ViewList.maxWidth = WIDTH;
        this.mask2ViewList.onViewSelected = view => { MaskMergeParameters.mask2View = view; };
        this.mask2ViewList.toolTip = "Select the second mask.";
        this.mask2Group.add( this.mask2ViewList, 100 );

        this.mask2InvertCheckbox = new CheckBox( this );
        this.mask2InvertCheckbox.text    = "Invert";
        this.mask2InvertCheckbox.toolTip = "Invert the second mask.";
        this.mask2InvertCheckbox.onCheck = checked => { MaskMergeParameters.invertMask2 = checked; };
        this.mask2Group.add( this.mask2InvertCheckbox );

        // ---- Operation 2 ----
        this.operationGroup2 = new HorizontalSizer; this.operationGroup2.spacing = 4;

        this.unionCheckbox2 = new CheckBox( this );
        this.unionCheckbox2.text    = "Union (Add)";
        this.unionCheckbox2.toolTip = "Combine the two masks by adding (technically screening) them together.";
        this.unionCheckbox2.onCheck = checked =>
        {
            if ( checked )
            {
                this.intersectionCheckbox2.checked = false;
                this.subtractCheckbox2.checked     = false;
                MaskMergeParameters.operation2     = "union";
            }
            else MaskMergeParameters.operation2 = "";
        };
        this.operationGroup2.add( this.unionCheckbox2 );

        this.intersectionCheckbox2 = new CheckBox( this );
        this.intersectionCheckbox2.text    = "Intersect";
        this.intersectionCheckbox2.toolTip = "Combine the two masks by taking their intersection.";
        this.intersectionCheckbox2.onCheck = checked =>
        {
            if ( checked )
            {
                this.unionCheckbox2.checked    = false;
                this.subtractCheckbox2.checked = false;
                MaskMergeParameters.operation2 = "intersection";
            }
            else MaskMergeParameters.operation2 = "";
        };
        this.operationGroup2.add( this.intersectionCheckbox2 );

        this.subtractCheckbox2 = new CheckBox( this );
        this.subtractCheckbox2.text    = "Subtract";
        this.subtractCheckbox2.toolTip = "Subtract the second mask from the first mask.";
        this.subtractCheckbox2.onCheck = checked =>
        {
            if ( checked )
            {
                this.unionCheckbox2.checked        = false;
                this.intersectionCheckbox2.checked = false;
                MaskMergeParameters.operation2     = "subtract";
            }
            else MaskMergeParameters.operation2 = "";
        };
        this.operationGroup2.add( this.subtractCheckbox2 );

        // ---- Mask 3 (optional) ----
        this.mask3Group = new HorizontalSizer; this.mask3Group.spacing = 4;
        this.mask3Label = new Label( this ); this.mask3Label.text = "Mask 3 (Optional):";
        this.mask3Group.add( this.mask3Label );

        this.mask3ViewList = new ViewList( this );
        this.mask3ViewList.getAll();
        this.mask3ViewList.maxWidth = WIDTH;
        this.mask3ViewList.onViewSelected = view => { MaskMergeParameters.mask3View = view; };
        this.mask3ViewList.toolTip = "Select the third mask.";
        this.mask3Group.add( this.mask3ViewList, 100 );

        this.mask3InvertCheckbox = new CheckBox( this );
        this.mask3InvertCheckbox.text    = "Invert";
        this.mask3InvertCheckbox.toolTip = "Invert the third mask.";
        this.mask3InvertCheckbox.onCheck = checked => { MaskMergeParameters.invertMask3 = checked; };
        this.mask3Group.add( this.mask3InvertCheckbox );

        // ---- Blur slider ----
        this.blurSlider = new NumericControl( this );
        this.blurSlider.label.text = "Blur (optional):";
        this.blurSlider.setRange( 0, 200 ); this.blurSlider.setPrecision( 0 );
        this.blurSlider.setValue( MaskMergeParameters.blurAmount );
        this.blurSlider.toolTip = "<p>Adjust the amount of blur to apply to the merged mask.</p>";
        this.blurSlider.onValueUpdated = value => { MaskMergeParameters.blurAmount = value; };

        // ---- Preview button ----
        this.previewButton = new PushButton( this );
        this.previewButton.text = "Preview Combined Mask";
        this.previewButton.setFixedWidth( 200 );
        this.previewButton.onClick = () =>
        {
            this.previewControl.visible = true;
            this.performPreview();
        };

        this.previewButtonSizer = new HorizontalSizer;
        this.previewButtonSizer.addStretch();
        this.previewButtonSizer.add( this.previewButton );
        this.previewButtonSizer.addStretch();

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth(  500 );
        this.previewControl.setMinHeight( 500 );
        this.previewControl.visible = false;

        // ---- Authorship ----
        this.authorshipLabel = new Label( this );
        this.authorshipLabel.text = "Written by Franklin Marek";
        this.authorshipLabel.textAlignment = TextAlignment.Center;

        this.websiteLabel = new Label( this );
        this.websiteLabel.text = "www.setiastro.com";
        this.websiteLabel.textAlignment = TextAlignment.Center;

        // ---- Buttons ----
        this.buttons_Sizer = new HorizontalSizer; this.buttons_Sizer.spacing = 6;

        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.toolTip = "New Instance";
        this.newInstanceButton.onMousePress = () =>
        {
            MaskMergeParameters.save();
            this.newInstance();
        };
        this.buttons_Sizer.add( this.newInstanceButton );

        this.executeButton = new PushButton( this );
        this.executeButton.text    = "Execute - Generate My Mask!";
        this.executeButton.onClick = () => { this.ok(); };
        this.buttons_Sizer.add( this.executeButton );

        // ---- Left sizer ----
        this.leftSizer = new VerticalSizer; this.leftSizer.spacing = 6; this.leftSizer.margin = 8;
        this.leftSizer.add( this.title );
        this.leftSizer.add( this.instructions );
        this.leftSizer.add( this.mask1Group );
        this.leftSizer.add( this.operationGroup1 );
        this.leftSizer.add( this.mask2Group );
        this.leftSizer.add( this.operationGroup2 );
        this.leftSizer.add( this.mask3Group );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.blurSlider );
        this.leftSizer.add( this.previewButtonSizer );
        this.leftSizer.add( this.authorshipLabel );
        this.leftSizer.add( this.websiteLabel );
        this.leftSizer.add( this.buttons_Sizer );

        // ---- Main sizer ----
        this.mainSizer = new HorizontalSizer; this.mainSizer.spacing = 6;
        this.mainSizer.add( this.leftSizer );
        this.mainSizer.add( this.previewControl );

        this.sizer = this.mainSizer;
        this.adjustToContents();
    }

    performPreview()
    {
        let intermediateMaskId = mergeMasks(
            MaskMergeParameters.operation1,
            MaskMergeParameters.mask1View.id,
            MaskMergeParameters.mask2View.id,
            MaskMergeParameters.invertMask1,
            MaskMergeParameters.invertMask2,
            true
        );

        let finalMaskId = intermediateMaskId;
        if ( MaskMergeParameters.mask3View && MaskMergeParameters.operation2 )
        {
            finalMaskId = mergeMasks(
                MaskMergeParameters.operation2,
                intermediateMaskId,
                MaskMergeParameters.mask3View.id,
                false,
                MaskMergeParameters.invertMask3,
                true
            );
        }

        if ( MaskMergeParameters.blurAmount > 0 )
        {
            let P = new Convolution;
            P.mode  = Convolution.Parametric;
            P.sigma = MaskMergeParameters.blurAmount;
            P.executeOn( ImageWindow.windowById( finalMaskId ).mainView );
        }

        let finalImage   = ImageWindow.windowById( finalMaskId ).mainView.image;
        let previewImage = this.createPreviewImage( finalImage );
        this.previewControl.doUpdateImage( previewImage );
        this.previewControl.viewport.update();
        this.previewControl.visible = true;
        this.adjustToContents();

        let finalWindow = ImageWindow.windowById( finalMaskId );
        if ( finalWindow ) finalWindow.hide();

        let intermediateWindow = ImageWindow.windowById( intermediateMaskId );
        if ( intermediateWindow ) intermediateWindow.forceClose();

        if ( finalMaskId !== intermediateMaskId )
        {
            let finalIntermediateWindow = ImageWindow.windowById( finalMaskId );
            if ( finalIntermediateWindow ) finalIntermediateWindow.forceClose();
        }
    }

    createPreviewImage( image )
    {
        let win = new ImageWindow(
            image.width, image.height,
            image.numberOfChannels, image.bitsPerSample,
            image.isReal, image.isColor );
        win.mainView.beginProcess( UndoFlag.NoSwapFile );
        win.mainView.image.assign( image );
        win.mainView.endProcess();

        let P = new IntegerResample;
        const previewWidth = 500;
        const widthScale   = Math.floor( image.width / previewWidth );
        P.zoomFactor = -Math.max( widthScale, 1 );
        P.executeOn( win.mainView );

        let resizedImage = new Image( win.mainView.image );
        win.forceClose();
        return resizedImage;
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );

    if ( Parameters.isGlobalTarget || Parameters.isViewTarget )
        MaskMergeParameters.load();

    let dialog = new MaskMergeDialog();

    if ( dialog.execute() )
    {
        if ( !MaskMergeParameters.mask1View || !MaskMergeParameters.mask2View || !MaskMergeParameters.operation1 )
        {
            console.criticalln( "Please ensure both masks are selected and the first operation is chosen." );
            return;
        }

        let intermediateMaskId = mergeMasks(
            MaskMergeParameters.operation1,
            MaskMergeParameters.mask1View.id,
            MaskMergeParameters.mask2View.id,
            MaskMergeParameters.invertMask1,
            MaskMergeParameters.invertMask2,
            false
        );

        let finalMaskId = intermediateMaskId;
        if ( MaskMergeParameters.mask3View && MaskMergeParameters.operation2 )
        {
            finalMaskId = mergeMasks(
                MaskMergeParameters.operation2,
                intermediateMaskId,
                MaskMergeParameters.mask3View.id,
                false,
                MaskMergeParameters.invertMask3,
                false
            );
        }

        if ( MaskMergeParameters.blurAmount > 0 )
        {
            let P = new Convolution;
            P.mode  = Convolution.Parametric;
            P.sigma = MaskMergeParameters.blurAmount;
            P.executeOn( ImageWindow.windowById( finalMaskId ).mainView );
        }

        if ( finalMaskId !== intermediateMaskId )
        {
            let intermediateWindow = ImageWindow.windowById( intermediateMaskId );
            if ( intermediateWindow ) intermediateWindow.forceClose();
        }
    }
    else
    {
        console.noteln( "Mask Merge Dialog Closed." );
    }
}

main();
