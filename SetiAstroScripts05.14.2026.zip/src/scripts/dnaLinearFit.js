#engine v8

#feature-id dnaLinearFit : SetiAstro > dnaLinearFit
#feature-icon  linearfit.svg
#feature-info  Does a linear fit on a target image based on the overlaping area between it and a reference image<br/>\
   <br/>\
   Copyright &copy; 2014 David Ault. All Rights Reserved.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// dnaLinearFit
//
// Original script by David Ault
// Copyright (C) 2014 David Ault. All Rights Reserved.
//
// Ported to PixInsight V8 JavaScript engine (PI 1.9.4 Lockhart).
// The algorithm, logic, and authorship are entirely David Ault's work.
// V8 migration only — no algorithmic changes.
//
// This script is no longer actively maintained by the original author.
// V8 port performed for compatibility with PixInsight 1.9.4+.
// ----------------------------------------------------------------------------

#define VERSION "0.4"
#define TITLE   "DNA Linear Fit"

// ============================================================================
// Core algorithm functions (unchanged from original)
// ============================================================================

function dnaGetLightness( img, i, j, rgbWS )
{
    var sum = 0.0;
    if ( (img.numberOfChannels == 3) && img.isColor )
    {
        var R = rgbWS.Y[0] * img.sample( i, j, 0 );
        var G = rgbWS.Y[1] * img.sample( i, j, 1 );
        var B = rgbWS.Y[2] * img.sample( i, j, 2 );
        sum   = (R + G + B) / (rgbWS.Y[0] + rgbWS.Y[1] + rgbWS.Y[2]);
    }
    else
    {
        for ( var c = 0; c < img.numberOfChannels; ++c )
            sum += img.sample( i, j, c );
        sum /= img.numberOfChannels;
    }
    return sum;
}

function determineLinearFitMeanMedian( referenceImage, targetImage, channel, rgbWS, clipping )
{
    var w = referenceImage.width;
    var h = referenceImage.height;

    var referenceMean = 0.0, targetMean = 0.0, cnt = 0;
    for ( var j = 0; j < h; ++j )
    {
        for ( var i = 0; i < w; ++i )
        {
            var referencePixel = (referenceImage.numberOfChannels == targetImage.numberOfChannels)
                ? referenceImage.sample( i, j, channel )
                : dnaGetLightness( referenceImage, i, j, rgbWS );
            var targetPixel = targetImage.sample( i, j, channel );
            if ( referencePixel > 0.0 && targetPixel > 0.0 && referencePixel < clipping && targetPixel < clipping )
            {
                referenceMean += referencePixel;
                targetMean    += targetPixel;
                cnt++;
            }
        }
        CoreApplication.processEvents();
    }
    referenceMean /= cnt;
    targetMean    /= cnt;

    var referencePixels = new Array( cnt );
    var targetPixels    = new Array( cnt );
    var k = 0;
    for ( var j = 0; j < h; ++j )
    {
        for ( var i = 0; i < w; ++i )
        {
            var referencePixel = (referenceImage.numberOfChannels == targetImage.numberOfChannels)
                ? referenceImage.sample( i, j, channel )
                : dnaGetLightness( referenceImage, i, j, rgbWS );
            var targetPixel = targetImage.sample( i, j, channel );
            if ( referencePixel > 0.0 && targetPixel > 0.0 && referencePixel < clipping && targetPixel < clipping )
            {
                referencePixels[k] = referencePixel;
                targetPixels[k]    = targetPixel;
                k++;
            }
        }
        CoreApplication.processEvents();
    }

    var referenceMedian = Stat.median( referencePixels );
    var targetMedian    = Stat.median( targetPixels );

    var m = (referenceMean - referenceMedian) / (targetMean - targetMedian);
    var b = referenceMean - (m * targetMean);

    if ( m < 0.0 )
    {
        console.writeln( "<b>WARN: calculated slope is negative, inverting</b>:" );
        m = -m;
    }

    return { m: m, b: b };
}

function determineLinearFitLeastSquares( referenceImage, targetImage, channel, rgbWS, clipping )
{
    var w = referenceImage.width;
    var h = referenceImage.height;

    var referenceMean = 0.0, targetMean = 0.0, cnt = 0;
    for ( var j = 0; j < h; ++j )
    {
        for ( var i = 0; i < w; ++i )
        {
            var referencePixel = (referenceImage.numberOfChannels == targetImage.numberOfChannels)
                ? referenceImage.sample( i, j, channel )
                : dnaGetLightness( referenceImage, i, j, rgbWS );
            var targetPixel = targetImage.sample( i, j, channel );
            if ( referencePixel > 0.0 && targetPixel > 0.0 && referencePixel < clipping && targetPixel < clipping )
            {
                referenceMean += referencePixel;
                targetMean    += targetPixel;
                cnt++;
            }
        }
        CoreApplication.processEvents();
    }
    referenceMean /= cnt;
    targetMean    /= cnt;

    var referencePixels = new Array( cnt );
    var targetPixels    = new Array( cnt );
    var k = 0;
    for ( var j = 0; j < h; ++j )
    {
        for ( var i = 0; i < w; ++i )
        {
            var referencePixel = (referenceImage.numberOfChannels == targetImage.numberOfChannels)
                ? referenceImage.sample( i, j, channel )
                : dnaGetLightness( referenceImage, i, j, rgbWS );
            var targetPixel = targetImage.sample( i, j, channel );
            if ( referencePixel > 0.0 && targetPixel > 0.0 && referencePixel < clipping && targetPixel < clipping )
            {
                referencePixels[k] = referencePixel;
                targetPixels[k]    = targetPixel;
                k++;
            }
        }
        CoreApplication.processEvents();
    }

    var rise = 0.0, run = 0.0;
    var midpoint = (cnt - 1) / 2.0;
    for ( var i = 0; i < cnt; i++ )
    {
        rise += (referencePixels[i] - referenceMean) * (i - midpoint);
        run  += Math.pow( referencePixels[i] - referenceMean, 2 );
    }
    var mr = rise / run;

    rise = 0.0; run = 0.0;
    for ( var i = 0; i < cnt; i++ )
    {
        rise += (targetPixels[i] - targetMean) * (i - midpoint);
        run  += Math.pow( targetPixels[i] - targetMean, 2 );
    }
    var mt = rise / run;

    var m = mr / mt;
    var b = referenceMean - m * targetMean;

    return { m: m, b: b };
}

function determineLinearFitScalar( referenceImage, targetImage, channel, rgbWS, clipping )
{
    var w = referenceImage.width;
    var h = referenceImage.height;

    var referenceMean = 0.0, targetMean = 0.0, multAvg = 0.0, cnt = 0;
    for ( var j = 0; j < h; ++j )
    {
        for ( var i = 0; i < w; ++i )
        {
            var referencePixel = (referenceImage.numberOfChannels == targetImage.numberOfChannels)
                ? referenceImage.sample( i, j, channel )
                : dnaGetLightness( referenceImage, i, j, rgbWS );
            var targetPixel = targetImage.sample( i, j, channel );
            if ( referencePixel > 0.0 && targetPixel > 0.0 && referencePixel < clipping && targetPixel < clipping )
            {
                multAvg       += referencePixel / targetPixel;
                referenceMean += referencePixel;
                targetMean    += targetPixel;
                cnt++;
            }
        }
        CoreApplication.processEvents();
    }
    referenceMean /= cnt;
    targetMean    /= cnt;
    multAvg       /= cnt;

    var m = multAvg;
    var b = referenceMean - m * targetMean;

    return { m: m, b: b };
}

function determineLinearFitCombo( referenceImage, targetImage, channel, rgbWS, clipping )
{
    var w = referenceImage.width;
    var h = referenceImage.height;

    var referenceMean = 0.0, targetMean = 0.0, cnt = 0;
    for ( var j = 0; j < h; ++j )
    {
        for ( var i = 0; i < w; ++i )
        {
            var referencePixel = (referenceImage.numberOfChannels == targetImage.numberOfChannels)
                ? referenceImage.sample( i, j, channel )
                : dnaGetLightness( referenceImage, i, j, rgbWS );
            var targetPixel = targetImage.sample( i, j, channel );
            if ( referencePixel > 0.0 && targetPixel > 0.0 && referencePixel < clipping && targetPixel < clipping )
            {
                referenceMean += referencePixel;
                targetMean    += targetPixel;
                cnt++;
            }
        }
        CoreApplication.processEvents();
    }
    referenceMean /= cnt;
    targetMean    /= cnt;

    var mmLine = determineLinearFitMeanMedian(   referenceImage, targetImage, channel, rgbWS, clipping );
    var lsLine = determineLinearFitLeastSquares(  referenceImage, targetImage, channel, rgbWS, clipping );
    var sLine  = determineLinearFitScalar(        referenceImage, targetImage, channel, rgbWS, clipping );
    var m      = (mmLine.m + lsLine.m + sLine.m) / 3.0;
    var b      = referenceMean - m * targetMean;

    return { m: m, b: b };
}

function dnaApplyLinearFit( image, linearData )
{
    var w           = image.width;
    var h           = image.height;
    var clipHighCnt = 0;
    var clipLowCnt  = 0;

    for ( var c = 0; c < image.numberOfChannels; ++c )
    {
        var m = linearData[c].m;
        var b = linearData[c].b;
        for ( var j = 0; j < h; ++j )
        {
            for ( var i = 0; i < w; ++i )
            {
                var value = image.sample( i, j, c );
                if ( value > 0.0 )
                {
                    value = (value * m) + b;
                    if      ( value > 1.0 ) { value = 1.0; clipHighCnt++; }
                    else if ( value < 0.0 ) { value = 0.0; clipLowCnt++;  }
                    image.setSample( value, i, j, c );
                }
            }
            CoreApplication.processEvents();
        }
    }

    return { clc: clipLowCnt, chc: clipHighCnt };
}

function dnaLinearFit( data )
{
    var referenceView = data.referenceView;
    var targetView    = data.targetView;
    var rgbWS         = referenceView.window.rgbWorkingSpace;

    var linearData = new Array( targetView.image.numberOfChannels );
    for ( var i = 0; i < targetView.image.numberOfChannels; ++i )
    {
        switch ( data.method )
        {
        case 0:  linearData[i] = determineLinearFitMeanMedian(  referenceView.image, targetView.image, i, rgbWS, data.clipping ); break;
        case 1:  linearData[i] = determineLinearFitLeastSquares( referenceView.image, targetView.image, i, rgbWS, data.clipping ); break;
        case 2:  linearData[i] = determineLinearFitScalar(       referenceView.image, targetView.image, i, rgbWS, data.clipping ); break;
        case 3:  linearData[i] = determineLinearFitCombo(        referenceView.image, targetView.image, i, rgbWS, data.clipping ); break;
        default: linearData[i] = determineLinearFitMeanMedian(  referenceView.image, targetView.image, i, rgbWS, data.clipping ); break;
        }
        console.writeln( "<b>INFO: Channel = ", i, "</b>:" );
        console.writeln( "<b>INFO:     dnaLinearFit m = ", linearData[i].m, "</b>:" );
        console.writeln( "<b>INFO:     dnaLinearFit b = ", linearData[i].b, "</b>:" );
    }

    targetView.beginProcess();
    var clippingData = dnaApplyLinearFit( targetView.image, linearData );
    targetView.endProcess();
    console.writeln( "<b>INFO: dnaLinearFit clipped ", clippingData.clc, " low pixels and ", clippingData.chc, " high pixels</b>:" );
}

// ============================================================================
// Form data
// ============================================================================

function dnaLinearFitData()
{
    var window = ImageWindow.activeWindow;
    if ( !window.isNull )
    {
        this.referenceView = window.currentView;
        this.targetView    = window.currentView;
        this.method        = 0;
        this.clipping      = 0.92;
    }
}

var data = new dnaLinearFitData;

// ============================================================================
// Dialog
// ============================================================================

var dnaLinearFitDialog = class extends Dialog
{
    constructor()
    {
        super();

        var labelWidth1       = this.font.width( "Linear Fit Method:" );
        var catalogComboWidth = this.font.width( "Mean / Median" );

        // ---- Help label ----
        this.helpLabel = new Label( this );
        this.helpLabel.frameStyle   = FrameStyle.Box;
        this.helpLabel.margin       = 4;
        this.helpLabel.wordWrapping = true;
        this.helpLabel.useRichText  = true;
        this.helpLabel.text =
            "<b>" + TITLE + " v" + VERSION + "</b> &mdash; " +
            "A script that matches brightness levels between areas of two images that overlap<br/>" +
            "<br/>" +
            "Original script by <b>David Ault</b> &mdash; Copyright &copy; 2014 David Ault. All Rights Reserved.<br/>" +
            "Ported to PixInsight V8 (PI 1.9.4+) by <b>Franklin Marek</b> &mdash; www.setiastro.com";

        // ---- Reference image ----
        this.referenceImage_Label = new Label( this );
        this.referenceImage_Label.text          = "Reference View:";
        this.referenceImage_Label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.referenceImage_Label.minWidth      = labelWidth1;

        this.referenceImage_ViewList = new ViewList( this );
        this.referenceImage_ViewList.getAll();
        this.referenceImage_ViewList.minWidth    = 300;
        this.referenceImage_ViewList.currentView = data.referenceView;
        this.referenceImage_ViewList.toolTip     = "<p>Select the reference image</p>";
        this.referenceImage_ViewList.onViewSelected = view => { data.referenceView = view; };

        this.referenceImage_Sizer = new HorizontalSizer;
        this.referenceImage_Sizer.spacing = 4;
        this.referenceImage_Sizer.add( this.referenceImage_Label );
        this.referenceImage_Sizer.add( this.referenceImage_ViewList, 100 );

        // ---- Target image ----
        this.targetImage_Label = new Label( this );
        this.targetImage_Label.text          = "Target View:";
        this.targetImage_Label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.targetImage_Label.minWidth      = labelWidth1;

        this.targetImage_ViewList = new ViewList( this );
        this.targetImage_ViewList.getAll();
        this.targetImage_ViewList.minWidth    = 300;
        this.targetImage_ViewList.currentView = data.targetView;
        this.targetImage_ViewList.toolTip     = "<p>Select the target image</p>";
        this.targetImage_ViewList.onViewSelected = view => { data.targetView = view; };

        this.targetImage_Sizer = new HorizontalSizer;
        this.targetImage_Sizer.spacing = 4;
        this.targetImage_Sizer.add( this.targetImage_Label );
        this.targetImage_Sizer.add( this.targetImage_ViewList, 100 );

        // ---- Method combo ----
        this.method_Label = new Label( this );
        this.method_Label.text          = "LinearFit Method:";
        this.method_Label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.method_Label.minWidth      = labelWidth1;

        this.method_Combo = new ComboBox( this );
        this.method_Combo.editEnabled = false;
        this.method_Combo.toolTip     = "<p>Method used to fit the image to the reference</p>";
        this.method_Combo.minWidth    = catalogComboWidth;
        this.method_Combo.addItem( "Mean / Median" );
        this.method_Combo.addItem( "Least Squares" );
        this.method_Combo.addItem( "Scalar" );
        this.method_Combo.addItem( "Combination" );
        if ( data.method != null ) this.method_Combo.currentItem = data.method;
        this.method_Combo.onItemSelected = () => { data.method = this.method_Combo.currentItem; };

        this.method_Sizer = new HorizontalSizer;
        this.method_Sizer.spacing = 4;
        this.method_Sizer.add( this.method_Label );
        this.method_Sizer.add( this.method_Combo );
        this.method_Sizer.addStretch();

        // ---- Reject High ----
        this.rejectHigh_Control = new NumericControl( this );
        this.rejectHigh_Control.real           = true;
        this.rejectHigh_Control.label.text     = "Reject High:";
        this.rejectHigh_Control.label.minWidth = labelWidth1;
        this.rejectHigh_Control.toolTip        = "<p>Lower values means more bright pixels will be excluded from the fit.</p>";
        this.rejectHigh_Control.onValueUpdated = value => { data.clipping = value; };
        this.rejectHigh_Control.setRange( 0, 1 );
        this.rejectHigh_Control.slider.setRange( 0, 1000 );
        this.rejectHigh_Control.setPrecision( 2 );
        this.rejectHigh_Control.slider.minWidth = 250;
        this.rejectHigh_Control.setValue( data.clipping );

        // ---- OK / Cancel buttons ----
        this.ok_Button = new PushButton( this );
        this.ok_Button.text    = "OK";
        this.ok_Button.cursor  = new Cursor( StdCursor.Checkmark );
        this.ok_Button.onClick = () => { this.ok(); };

        this.cancel_Button = new PushButton( this );
        this.cancel_Button.text    = "Cancel";
        this.cancel_Button.cursor  = new Cursor( StdCursor.Crossmark );
        this.cancel_Button.onClick = () => { this.cancel(); };

        this.buttons_Sizer = new HorizontalSizer;
        this.buttons_Sizer.spacing = 6;
        this.buttons_Sizer.addStretch();
        this.buttons_Sizer.add( this.ok_Button );
        this.buttons_Sizer.add( this.cancel_Button );

        // ---- Main sizer ----
        this.sizer = new VerticalSizer;
        this.sizer.margin  = 6;
        this.sizer.spacing = 6;
        this.sizer.add( this.helpLabel );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.referenceImage_Sizer );
        this.sizer.add( this.targetImage_Sizer );
        this.sizer.add( this.method_Sizer );
        this.sizer.add( this.rejectHigh_Control );
        this.sizer.add( this.buttons_Sizer );

        this.windowTitle = TITLE;
        this.adjustToContents();
        this.setFixedSize();
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    if ( ImageWindow.activeWindow.currentView.isNull )
    {
        new MessageBox(
            "ERROR: there must be at least one image open for this script to function",
            TITLE, StdIcon.Error, StdButton.Ok ).execute();
        return;
    }
    console.writeln( "" );
    console.writeln( "<b>INFO: dnaLinearFit ", VERSION, "</b>:" );

    var dialog = new dnaLinearFitDialog();
    for ( ;; )
    {
        if ( !dialog.execute() ) break;

        if ( data.referenceView.isNull )
        {
            new MessageBox( "WARNING: You must select a view to execute this script",
                TITLE, StdIcon.Error, StdButton.Ok ).execute();
            continue;
        }
        if ( data.targetView.isNull )
        {
            new MessageBox( "WARNING: You must select a view to execute this script",
                TITLE, StdIcon.Error, StdButton.Ok ).execute();
            continue;
        }

        dnaLinearFit( data );
        break;
    }
}

main();
