#engine v8

#feature-id NBtoRGBStars_v1.6 : SetiAstro > NB to RGB Star Combination
#feature-icon  nbtorgb.svg
#feature-info This script performs a combination of NB stars only images and produces a realistic RGB star image. It also has the option to perform a non-linear Star Stretch on the output.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * NB to RGB Stars Script
 * Version: 1.6
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script performs a combination of NB stars only images and produces
 * a realistic RGB star image.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

var SHOParameters = {
    HaView: undefined,
    OIIIView: undefined,
    SIIView: undefined,
    OSCView: undefined,
    applyStarStretch: false,
    stretchFactor: 5,
    colorBoost: 1.0,
    haToOiiRatio: 0.3,
    showPreview: false,

    save: function()
    {
        Parameters.set( "HaView",           this.HaView   ? this.HaView.id   : "" );
        Parameters.set( "OIIIView",         this.OIIIView ? this.OIIIView.id : "" );
        Parameters.set( "SIIView",          this.SIIView  ? this.SIIView.id  : "" );
        Parameters.set( "OSCView",          this.OSCView  ? this.OSCView.id  : "" );
        Parameters.set( "applyStarStretch", this.applyStarStretch );
        Parameters.set( "stretchFactor",    this.stretchFactor );
        Parameters.set( "colorBoost",       this.colorBoost );
        Parameters.set( "haToOiiRatio",     this.haToOiiRatio );
        Parameters.set( "showPreview",      this.showPreview );
    },

    load: function()
    {
        if ( Parameters.has( "HaView" ) )
        {
            let w = ImageWindow.windowById( Parameters.getString( "HaView" ) );
            if ( w && !w.isNull ) this.HaView = w.mainView;
        }
        if ( Parameters.has( "OIIIView" ) )
        {
            let w = ImageWindow.windowById( Parameters.getString( "OIIIView" ) );
            if ( w && !w.isNull ) this.OIIIView = w.mainView;
        }
        if ( Parameters.has( "SIIView" ) && Parameters.getString( "SIIView" ) !== "" )
        {
            let w = ImageWindow.windowById( Parameters.getString( "SIIView" ) );
            if ( w && !w.isNull ) this.SIIView = w.mainView;
        }
        if ( Parameters.has( "OSCView" ) && Parameters.getString( "OSCView" ) !== "" )
        {
            let w = ImageWindow.windowById( Parameters.getString( "OSCView" ) );
            if ( w && !w.isNull ) this.OSCView = w.mainView;
        }
        if ( Parameters.has( "applyStarStretch" ) ) this.applyStarStretch = Parameters.getBoolean( "applyStarStretch" );
        if ( Parameters.has( "stretchFactor" ) )    this.stretchFactor    = Parameters.getReal( "stretchFactor" );
        if ( Parameters.has( "colorBoost" ) )       this.colorBoost       = Parameters.getReal( "colorBoost" );
        if ( Parameters.has( "haToOiiRatio" ) )     this.haToOiiRatio     = Parameters.getReal( "haToOiiRatio" );
        if ( Parameters.has( "showPreview" ) )      this.showPreview      = Parameters.getBoolean( "showPreview" );
    }
};

// ============================================================================
// ScrollControl
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.autoScroll = true;
        this.tracking = true;
        this.displayImage = null;
        this.dragging = false;
        this.dragOrigin = new Point( 0, 0 );

        this.viewport.cursor = new Cursor( StdCursor.OpenHand );

        this.viewport.onResize = () =>
        {
            this.initScrollBars();
        };

        this.onHorizontalScrollPosUpdated = x =>
        {
            this.viewport.update();
        };

        this.onVerticalScrollPosUpdated = y =>
        {
            this.viewport.update();
        };

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
            this.dragOrigin.x = x;
            this.dragOrigin.y = y;
            this.dragging = true;
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            if ( this.dragging )
            {
                this.scrollPosition = new Point( this.scrollPosition )
                    .translatedBy( this.dragOrigin.x - x, this.dragOrigin.y - y );
                this.dragOrigin.x = x;
                this.dragOrigin.y = y;
                this.viewport.update();
            }
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.OpenHand );
            this.dragging = false;
        };

        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this.viewport );
            let result = this.getImage();

            if ( result == null )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
            }
            else
            {
                result.selectedRect = (new Rect( x0, y0, x1, y1 )).translated( this.scrollPosition );
                g.drawBitmap( x0, y0, result.render() );
                result.resetRectSelection();
            }

            g.end();
        };

        this.initScrollBars();
    }

    getImage()
    {
        return this.displayImage;
    }

    doUpdateImage( image )
    {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    }

    initScrollBars()
    {
        let image = this.getImage();
        if ( image == null || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange( 0, 0 );
        }
        else
        {
            this.setHorizontalScrollRange( 0, Math.max( 0, image.width  - this.viewport.width ) );
            this.setVerticalScrollRange(   0, Math.max( 0, image.height - this.viewport.height ) );
        }
        this.viewport.update();
    }
};

// ============================================================================
// Dialog
// ============================================================================

var SHODialog = class extends Dialog
{
    constructor()
    {
        super();

        this.userResizable = true;
        this.scaledMinWidth = 450;

        // ---- Title ----
        this.title = new TextBox( this );
        this.title.text =
            "<b>NB to RGB Star Combination Tool v1.6</b><br>" +
            "Select the H-alpha, OIII, and optionally SII star images for combination.\n\n" +
            "You can also select your OSC Image if a dual NB filter is used.\n\n" +
            "If checked it will also perform a linear to non-linear Star Stretch on the output image.";
        this.title.readOnly = true;
        this.title.backgroundColor = 0xf7f7c625;
        this.title.minHeight = 140;
        this.title.maxHeight = 140;

        // ---- Ha ----
        this.HaLabel = new Label( this );
        this.HaLabel.text = "Ha Stars Image:";

        this.HaViewList = new ViewList( this );
        this.HaViewList.getAll();
        this.HaViewList.maxWidth = 275;
        this.HaViewList.onViewSelected = view => { SHOParameters.HaView = view; };

        this.HaSizer = new HorizontalSizer;
        this.HaSizer.add( this.HaLabel );
        this.HaSizer.add( this.HaViewList );

        // ---- OIII ----
        this.OIIILabel = new Label( this );
        this.OIIILabel.text = "OIII Stars Image:";

        this.OIIIViewList = new ViewList( this );
        this.OIIIViewList.getAll();
        this.OIIIViewList.maxWidth = 275;
        this.OIIIViewList.onViewSelected = view => { SHOParameters.OIIIView = view; };

        this.OIIISizer = new HorizontalSizer;
        this.OIIISizer.add( this.OIIILabel );
        this.OIIISizer.add( this.OIIIViewList );

        // ---- SII ----
        this.SIILabel = new Label( this );
        this.SIILabel.text = "SII Stars Image (optional):";

        this.SIIViewList = new ViewList( this );
        this.SIIViewList.getAll();
        this.SIIViewList.maxWidth = 275;
        this.SIIViewList.onViewSelected = view => { SHOParameters.SIIView = view; };

        this.SIISizer = new HorizontalSizer;
        this.SIISizer.add( this.SIILabel );
        this.SIISizer.add( this.SIIViewList );

        // ---- OR label ----
        this.orLabel = new Label( this );
        this.orLabel.text = "OR";
        this.orLabel.textAlignment = TextAlignment.Center;

        // ---- OSC ----
        this.OSCLabel = new Label( this );
        this.OSCLabel.text = "OSC (for dual band filter) Image:";

        this.OSCViewList = new ViewList( this );
        this.OSCViewList.getAll();
        this.OSCViewList.maxWidth = 275;
        this.OSCViewList.onViewSelected = view => { SHOParameters.OSCView = view; };

        this.OSCSizer = new HorizontalSizer;
        this.OSCSizer.add( this.OSCLabel );
        this.OSCSizer.add( this.OSCViewList );

        // ---- Green Channel Blend Ratio checkbox ----
        this.greenChannelCheckBox = new CheckBox( this );
        this.greenChannelCheckBox.text = "Green Channel Blend Ratio (Optional)";
        this.greenChannelCheckBox.checked = false;
        this.greenChannelCheckBox.toolTip = "Enable the green channel blend ratio adjustment.";
        this.greenChannelCheckBox.onCheck = checked =>
        {
            SHOParameters.haToOiiRatio = checked ? SHOParameters.haToOiiRatio : 0.3;
            this.haToOiiRatioControl.visible = checked;
        };

        // ---- Ha to OIII ratio ----
        this.haToOiiRatioControl = new NumericControl( this );
        this.haToOiiRatioControl.label.text = "Ha to OIII ratio:";
        this.haToOiiRatioControl.setRange( 0, 1 );
        this.haToOiiRatioControl.slider.setRange( 0, 100 );
        this.haToOiiRatioControl.setValue( SHOParameters.haToOiiRatio );
        this.haToOiiRatioControl.setPrecision( 2 );
        this.haToOiiRatioControl.visible = false;
        this.haToOiiRatioControl.onValueUpdated = value =>
        {
            SHOParameters.haToOiiRatio = value;
        };

        // ---- Star Stretch checkbox ----
        this.starStretchCheckBox = new CheckBox( this );
        this.starStretchCheckBox.text = "Apply Star Stretch (Recommended)";
        this.starStretchCheckBox.checked = false;
        this.starStretchCheckBox.toolTip = "Enable additional stretching and color saturation adjustments.";
        this.starStretchCheckBox.onCheck = checked =>
        {
            SHOParameters.applyStarStretch = checked;
            this.stretchFactorControl.visible = checked;
            this.colorBoostControl.visible = checked;
        };

        // ---- Stretch factor ----
        this.stretchFactorControl = new NumericControl( this );
        this.stretchFactorControl.label.text = "Stretch Factor:";
        this.stretchFactorControl.setRange( 0, 8 );
        this.stretchFactorControl.slider.setRange( 10, 100 );
        this.stretchFactorControl.setValue( 5 );
        this.stretchFactorControl.setPrecision( 2 );
        this.stretchFactorControl.visible = false;
        this.stretchFactorControl.onValueUpdated = value =>
        {
            SHOParameters.stretchFactor = value;
        };

        // ---- Color Boost ----
        this.colorBoostControl = new NumericControl( this );
        this.colorBoostControl.label.text = "Color Boost:";
        this.colorBoostControl.setRange( 0, 3 );
        this.colorBoostControl.slider.setRange( 0, 300 );
        this.colorBoostControl.setValue( SHOParameters.colorBoost );
        this.colorBoostControl.setPrecision( 2 );
        this.colorBoostControl.visible = false;
        this.colorBoostControl.onValueUpdated = value =>
        {
            SHOParameters.colorBoost = value;
        };

        // ---- Show Preview checkbox ----
        this.showPreviewCheckBox = new CheckBox( this );
        this.showPreviewCheckBox.text = "Show Preview";
        this.showPreviewCheckBox.checked = SHOParameters.showPreview;
        this.showPreviewCheckBox.toolTip = "<p>Enable or disable preview of the stretch.</p>";
        this.showPreviewCheckBox.onCheck = checked =>
        {
            SHOParameters.showPreview = checked;
            this.previewControl.visible = checked;
            this.zoomSizer.visible = checked;

            if ( checked && (SHOParameters.HaView || SHOParameters.OSCView) )
            {
                let tmpImage = this.createAndDisplayTemporaryImage();
                if ( tmpImage )
                {
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                }
            }

            this.adjustToContents();
        };

        // ---- New Instance button ----
        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "New Instance";
        this.newInstanceButton.onMousePress = () =>
        {
            SHOParameters.save();
            this.newInstance();
        };

        // ---- Zoom controls ----
        this.zoomLabel = new Label( this );
        this.zoomLabel.text = "Zoom: ";
        this.zoomLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.zoomComboBox = new ComboBox( this );
        this.zoomComboBox.addItem( "1:1" );
        this.zoomComboBox.addItem( "1:2" );
        this.zoomComboBox.addItem( "1:4" );
        this.zoomComboBox.addItem( "1:8" );
        this.zoomComboBox.addItem( "Fit to Preview" );
        this.zoomComboBox.currentItem = 2;
        this.zoomComboBox.minWidth = 120;
        this.zoomComboBox.onItemSelected = index =>
        {
            if ( SHOParameters.showPreview )
                this.refreshPreview();
        };

        this.previewRefreshButton = new PushButton( this );
        this.previewRefreshButton.text = "Refresh Preview";
        this.previewRefreshButton.minWidth = 120;
        this.previewRefreshButton.onClick = () =>
        {
            this.refreshPreview();
        };

        this.zoomSizer = new HorizontalSizer;
        this.zoomSizer.margin = 4;
        this.zoomSizer.spacing = 4;
        this.zoomSizer.add( this.zoomLabel );
        this.zoomSizer.add( this.zoomComboBox );
        this.zoomSizer.addSpacing( 12 );
        this.zoomSizer.add( this.previewRefreshButton );

        // ---- Execute button ----
        this.execButton = new PushButton( this );
        this.execButton.text = "Execute";
        this.execButton.width = 80;
        this.execButton.onClick = () =>
        {
            this.processImages();
            this.ok();
        };

        this.execButtonSizer = new HorizontalSizer;
        this.execButtonSizer.margin = 8;
        this.execButtonSizer.add( this.newInstanceButton );
        this.execButtonSizer.addSpacing( 12 );
        this.execButtonSizer.add( this.zoomSizer );
        this.execButtonSizer.addStretch();
        this.execButtonSizer.add( this.execButton );

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth( 300 );
        this.previewControl.setMinHeight( 300 );
        this.previewControl.visible = false;

        // ---- Layout ----
        this.leftSizer = new VerticalSizer;
        this.leftSizer.margin = 8;
        this.leftSizer.spacing = 8;
        this.leftSizer.add( this.title );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.HaSizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.OIIISizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.SIISizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.orLabel );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.OSCSizer );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.greenChannelCheckBox );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.haToOiiRatioControl );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.starStretchCheckBox );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.stretchFactorControl );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.colorBoostControl );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.showPreviewCheckBox );
        this.leftSizer.addSpacing( 8 );
        this.leftSizer.add( this.execButtonSizer );
        this.leftSizer.addStretch();
        this.leftSizer.minWidth = 300;

        this.mainSizer = new HorizontalSizer;
        this.mainSizer.margin = 8;
        this.mainSizer.spacing = 8;
        this.mainSizer.add( this.leftSizer );
        this.mainSizer.add( this.previewControl, 1 );

        this.sizer = this.mainSizer;

        this.onShow = () =>
        {
            this.previewControl.visible = false;
            this.zoomSizer.visible = false;
            this.adjustToContents();
        };

        this.adjustToContents();
    }

    createAndDisplayTemporaryImage()
    {
        if ( !SHOParameters.HaView && !SHOParameters.OSCView )
        {
            console.warningln( "Please ensure H-alpha or OSC image is selected." );
            return null;
        }

        let extractedChannels = [];
        if ( SHOParameters.OSCView )
            extractChannelsFromOSC( SHOParameters.OSCView.id, extractedChannels );

        let newImageId = combineNBtoRGB( true );
        if ( newImageId )
        {
            applyAdjustments( newImageId, true );

            let newImage = ImageWindow.windowById( newImageId ).mainView.image;

            let window = new ImageWindow(
                newImage.width, newImage.height,
                newImage.numberOfChannels,
                newImage.bitsPerSample,
                newImage.isReal,
                newImage.isColor
            );

            window.mainView.beginProcess();
            window.mainView.image.assign( newImage );
            window.mainView.endProcess();

            let P = new IntegerResample;
            switch ( this.zoomComboBox.currentItem )
            {
            case 0: P.zoomFactor = -1; break;
            case 1: P.zoomFactor = -2; break;
            case 2: P.zoomFactor = -4; break;
            case 3: P.zoomFactor = -8; break;
            case 4:
                {
                    let previewWidth = this.previewControl.width;
                    let widthScale = Math.floor( newImage.width / previewWidth );
                    P.zoomFactor = -Math.max( widthScale, 1 );
                }
                break;
            default:
                P.zoomFactor = -2;
                break;
            }

            P.executeOn( window.mainView );

            let resizedImage = new Image( window.mainView.image );

            if ( resizedImage.width > 0 && resizedImage.height > 0 )
            {
                this.previewControl.displayImage = resizedImage;
                this.previewControl.doUpdateImage( resizedImage );
                this.previewControl.initScrollBars();
            }
            else
            {
                console.error( "Resized image has invalid dimensions." );
            }

            window.forceClose();
            ImageWindow.windowById( newImageId ).forceClose();
            closeExtractedChannels( extractedChannels );

            return resizedImage;
        }
        else
        {
            console.criticalln( "Error creating the new image. Please check the settings." );
            return null;
        }
    }

    refreshPreview()
    {
        if ( SHOParameters.showPreview && (SHOParameters.HaView || SHOParameters.OSCView) )
        {
            let tmpImage = this.createAndDisplayTemporaryImage();
            if ( tmpImage )
            {
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();
            }
            else
            {
                console.writeln( "Failed to create a temporary image for preview." );
            }
        }
    }

    processImages()
    {
        if ( (!SHOParameters.HaView || !SHOParameters.OIIIView) && !SHOParameters.OSCView )
        {
            console.warningln( "Please ensure H-alpha and OIII images are selected, or an OSC image is selected." );
            return;
        }

        let extractedChannels = [];
        if ( SHOParameters.OSCView )
            extractChannelsFromOSC( SHOParameters.OSCView.id, extractedChannels );

        let newImageId = combineNBtoRGB();
        if ( newImageId )
        {
            applyAdjustments( newImageId );
            closeExtractedChannels( extractedChannels );
            console.noteln( "NB to RGB Star Process Complete" );
        }
        else
        {
            console.criticalln( "Error creating the new image. Please check the settings." );
        }

        console.show();
    }
};

// ============================================================================
// Processing functions
// ============================================================================

function getAllImageIDs()
{
    let windows = ImageWindow.windows;
    let ids = [];
    for ( let i = 0; i < windows.length; ++i )
        ids.push( windows[i].mainView.id );
    return ids;
}

function findNewImageID( oldIDs, newIDs )
{
    for ( let i = 0; i < newIDs.length; i++ )
    {
        let found = false;
        for ( let j = 0; j < oldIDs.length; j++ )
        {
            if ( newIDs[i] === oldIDs[j] )
            {
                found = true;
                break;
            }
        }
        if ( !found )
            return newIDs[i];
    }
    return null;
}

function extractChannel( imageId, channelIndex, suffix, extractedChannels )
{
    let P = new ChannelExtraction;
    P.colorSpace = ChannelExtraction.RGB;
    P.channels = [
        [channelIndex === 0, ""],
        [channelIndex === 1, ""],
        [channelIndex === 2, ""]
    ];
    P.sampleFormat = ChannelExtraction.SameAsSource;
    P.inheritAstrometricSolution = true;
    P.executeOn( ImageWindow.windowById( imageId ).mainView );

    let extractedImage = ImageWindow.activeWindow;
    extractedImage.mainView.id = imageId + suffix;
    extractedChannels.push( extractedImage.mainView.id );
    extractedImage.hide();
    return extractedImage.mainView.id;
}

function extractChannelsFromOSC( imageId, extractedChannels )
{
    SHOParameters.HaView   = ImageWindow.windowById( extractChannel( imageId, 0, "_Ha",   extractedChannels ) ).mainView;
    SHOParameters.OIIIView = ImageWindow.windowById( extractChannel( imageId, 1, "_OIII", extractedChannels ) ).mainView;
}

function closeExtractedChannels( extractedChannels )
{
    for ( let i = 0; i < extractedChannels.length; i++ )
    {
        let window = ImageWindow.windowById( extractedChannels[i] );
        if ( window && !window.isNull )
            window.forceClose();
    }
}

function combineNBtoRGB( skipShowingImage )
{
    let oldIDs = getAllImageIDs();
    console.writeln( "Old IDs: " + oldIDs.join( ", " ) );

    let P = new PixelMath;
    P.expression  = "0.5*" + SHOParameters.HaView.id + " + 0.5*" + (SHOParameters.SIIView ? SHOParameters.SIIView.id : SHOParameters.HaView.id);
    P.expression1 = SHOParameters.haToOiiRatio + "*" + SHOParameters.HaView.id + " + ~" + SHOParameters.haToOiiRatio + "*" + SHOParameters.OIIIView.id;
    P.expression2 = SHOParameters.OIIIView.id;
    P.expression3 = "";
    P.useSingleExpression = false;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = true;
    P.showNewImage = !skipShowingImage;
    P.newImageId = "NBtoRGB_stars";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.RGB;
    P.newImageSampleFormat = PixelMath.SameAsTarget;
    P.executeOn( SHOParameters.HaView );

    let newIDs = getAllImageIDs();
    console.writeln( "Check newIDs after PixelMath: " + newIDs.join( ", " ) );
    return findNewImageID( oldIDs, newIDs );
}

function applyAdjustments( newImageId, skipShowingImage )
{
    let targetView = ImageWindow.windowById( newImageId )
        ? ImageWindow.windowById( newImageId ).mainView
        : null;

    if ( !targetView )
    {
        console.criticalln( "Error: Image view not found for ID " + newImageId );
        return;
    }

    applySCNR( targetView );
    applyMTF( targetView );
    applySCNR( targetView );
    reverseMTF( targetView );

    if ( SHOParameters.applyStarStretch )
        applyStarStretch( targetView );

    console.noteln( "All adjustments including optional star stretch (if applied) are complete." );

    if ( skipShowingImage )
        ImageWindow.windowById( newImageId ).hide();
}

function applySCNR( view )
{
    let P = new SCNR;
    P.amount = 1.00;
    P.protectionMethod = SCNR.AverageNeutral;
    P.colorToRemove = SCNR.Green;
    P.preserveLightness = true;
    P.executeOn( view );
}

function applyMTF( view )
{
    let P = new PixelMath;
    P.expression = "mtf(0.01, $T)";
    P.useSingleExpression = true;
    P.executeOn( view );
}

function reverseMTF( view )
{
    let P = new PixelMath;
    P.expression = "mtf(~0.01, $T)";
    P.useSingleExpression = true;
    P.executeOn( view );
}

function applyStarStretch( view )
{
    let stretchFactor = SHOParameters.stretchFactor || 5;
    let colorBoost    = SHOParameters.colorBoost    || 1.0;

    let P = new PixelMath;
    P.expression = "((3^" + stretchFactor + ")*$T)/((3^" + stretchFactor + "-1)*$T+1)";
    P.useSingleExpression = true;
    P.executeOn( view );

    let C = new ColorSaturation;
    C.HS = [
        [0.00000, colorBoost * 0.40000],
        [0.50000, colorBoost * 0.70000],
        [1.00000, colorBoost * 0.40000]
    ];
    C.HSt = ColorSaturation.AkimaSubsplines;
    C.hueShift = 0.000;
    C.executeOn( view );
}

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "        ___     __      ___       __                               \n       / __/___/ /__   / _ | ___ / /________                       " );
    console.warningln( "        _\\ \\/ -_) _ _   / __ |(_-</ __/ __/ _ \\                     \n      /___/\\__/_//_/  /_/ |_/___/\\__/_/  \\___/                      " );

    if ( Parameters.isGlobalTarget )
    {
        console.criticalln( "This script cannot run in a global context." );
        return;
    }

    let dialog = new SHODialog();
    dialog.execute();
}

main();
