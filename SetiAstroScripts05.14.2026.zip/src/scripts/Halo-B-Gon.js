#engine v8

#feature-id Halo-B-Gon : SetiAstro > Halo-B-Gon
#feature-icon  halo.svg
#feature-info This script is used to reduce the halo around stars.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Halo-B-Gon
 * Version: 2.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script is used to reduce the halo around stars.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "Halo-B-Gon"
#define VERSION "2.1"

var scriptParameters = {
    newInstance: function() { console.writeln("New instance created."); }
};

// ============================================================================
// Processing functions
// ============================================================================

function createLightnessMask( selectedImage )
{
    try
    {
        let mask = new ImageWindow(
            selectedImage.mainView.image.width,
            selectedImage.mainView.image.height,
            1, 32, true, false);
        mask.mainView.beginProcess(UndoFlag.NoSwapFile);
        mask.mainView.image.assign(selectedImage.mainView.image);
        mask.mainView.endProcess();

        if ( selectedImage.mainView.image.numberOfChannels > 1 )
        {
            let P = new ConvertToGrayscale;
            P.executeOn(mask.mainView);
        }

        let P = new UnsharpMask;
        P.sigma = 2.00; P.amount = 0.66; P.useLuminance = true;
        P.linear = false; P.deringing = false;
        P.deringingDark = 0.1000; P.deringingBright = 0.0000;
        P.outputDeringingMaps = false;
        P.rangeLow = 0.0; P.rangeHigh = 0.0;
        P.executeOn(mask.mainView);

        return mask;
    }
    catch (e) { console.criticalln("Error creating lightness mask: " + e.message); return null; }
}

function createDuplicateImage( original )
{
    try
    {
        let dup = new ImageWindow(
            original.mainView.image.width,
            original.mainView.image.height,
            1, 32, true, false);
        dup.mainView.beginProcess(UndoFlag.NoSwapFile);
        dup.mainView.image.assign(original.mainView.image);
        dup.mainView.endProcess();
        return dup;
    }
    catch (e) { console.criticalln("Error duplicating image: " + e.message); return null; }
}

function applyMMT( image )
{
    try
    {
        let P = new MultiscaleMedianTransform;
        P.layers = [
            [true,  true, 0.000, false, 1.0, 1.00, 0.0],
            [true,  true, 0.000, false, 1.0, 1.00, 0.0],
            [true,  true, 0.000, false, 1.0, 1.00, 0.0],
            [false, true, 0.000, false, 1.0, 1.00, 0.0],
            [false, true, 0.000, false, 1.0, 1.00, 0.0],
            [false, true, 0.000, false, 1.0, 1.00, 0.0],
            [false, true, 0.000, false, 1.0, 1.00, 0.0]
        ];
        P.transform             = MultiscaleMedianTransform.MultiscaleMedianTransform;
        P.medianWaveletThreshold = 5.00;
        P.scaleDelta            = 0;
        P.linearMask            = false;
        P.linearMaskAmpFactor   = 100;
        P.linearMaskSmoothness  = 1.00;
        P.linearMaskInverted    = true;
        P.linearMaskPreview     = false;
        P.lowRange              = 0.0;
        P.highRange             = 0.0;
        P.previewMode           = MultiscaleMedianTransform.Disabled;
        P.previewLayer          = 0;
        P.toLuminance           = true;
        P.toChrominance         = true;
        P.linear                = false;
        P.executeOn(image.mainView);
    }
    catch (e) { console.criticalln("Error applying MMT: " + e.message); }
}

function invertMask( mask )
{
    try { let P = new Invert; P.executeOn(mask.mainView); }
    catch (e) { console.criticalln("Error inverting mask: " + e.message); }
}

function applyMaskToImage( selectedImage, finalMask )
{
    try
    {
        selectedImage.mask        = finalMask;
        selectedImage.maskVisible = true;
        selectedImage.maskInverted = false;
    }
    catch (e) { console.criticalln("Error applying mask: " + e.message); }
}

function applyCurvesToImage( image, reductionAmount )
{
    try
    {
        let P = new CurvesTransformation;
        if ( reductionAmount === 0 )
            P.K = [[0.0,0.0],[0.75,0.575],[1.0,1.0]];
        else
            P.K = [[0.0,0.0],[0.75,0.40],[1.0,1.0]];

        P.Kt = CurvesTransformation.AkimaSubsplines;

        let iterations = (reductionAmount === 0) ? 1 : reductionAmount;
        for ( let i = 0; i < iterations; i++ )
            P.executeOn(image.mainView);
    }
    catch (e) { console.criticalln("Error applying CurvesTransformation: " + e.message); }
}

// ============================================================================
// Dialog
// ============================================================================

var HaloBGonDialog = class extends Dialog
{
    constructor()
    {
        super();

        console.noteln("Ready to Remove those Halos!");
        console.flush();

        this.windowTitle = "Halo-B-Gon: Reduce those UnWanted Halos";

        // Title label
        this.titleLabel = new Label(this);
        this.titleLabel.frameStyle   = FrameStyle.Box;
        this.titleLabel.margin       = 10;
        this.titleLabel.wordWrapping = true;
        this.titleLabel.useRichText  = true;
        this.titleLabel.text =
            "<p style='text-align: center; font-size: 16px;'>" +
            "<b>" + TITLE + "</b> - Version " + VERSION + "<br>" +
            "<i>Reduce Those Unwanted Halos</i></p>";
        this.titleLabel.setMinWidth(300);

        // Image selector
        this.targetImageLabel = new Label(this);
        this.targetImageLabel.text = "Select stars-only image:";
        this.targetImageLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.targetImageComboBox = new ComboBox(this);
        this.targetImageComboBox.editEnabled = false;

        let windowList = ImageWindow.windows;
        let activeWindowIndex = -1;
        for ( let i = 0; i < windowList.length; i++ )
        {
            this.targetImageComboBox.addItem(windowList[i].mainView.id);
            if ( ImageWindow.activeWindow.mainView.id === windowList[i].mainView.id )
                activeWindowIndex = i;
        }
        if ( activeWindowIndex !== -1 )
            this.targetImageComboBox.currentItem = activeWindowIndex;

        // Reduction amount slider + labels
        this.reductionLabel = new Label(this);
        this.reductionLabel.text = "Reduction Amount:";
        this.reductionLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.reductionLabelExtraLow = new Label(this);
        this.reductionLabelExtraLow.text = "Extra Low";
        this.reductionLabelExtraLow.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.reductionLabelLow = new Label(this);
        this.reductionLabelLow.text = "Low";
        this.reductionLabelLow.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.reductionLabelMed = new Label(this);
        this.reductionLabelMed.text = "Med";
        this.reductionLabelMed.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;

        this.reductionLabelHigh = new Label(this);
        this.reductionLabelHigh.text = "High";
        this.reductionLabelHigh.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.reductionLabelSizer = new HorizontalSizer;
        this.reductionLabelSizer.margin = 8; this.reductionLabelSizer.spacing = 6;
        this.reductionLabelSizer.add(this.reductionLabelExtraLow);
        this.reductionLabelSizer.addStretch();
        this.reductionLabelSizer.add(this.reductionLabelLow);
        this.reductionLabelSizer.addStretch();
        this.reductionLabelSizer.add(this.reductionLabelMed);
        this.reductionLabelSizer.addStretch();
        this.reductionLabelSizer.add(this.reductionLabelHigh);

        this.reductionSlider = new Slider(this);
        this.reductionSlider.minValue = 0; this.reductionSlider.maxValue = 3;
        this.reductionSlider.value    = 1;
        this.reductionSlider.toolTip  = "Adjust the amount of halo reduction (Extra Low, Low, Med, High)";

        // Linear data checkbox
        this.linearDataCheckbox = new CheckBox(this);
        this.linearDataCheckbox.text    = "Linear Data";
        this.linearDataCheckbox.checked = false;
        this.linearDataCheckbox.toolTip = "Check if the data is linear";

        // Authorship
        this.authorshipLabel = new Label(this);
        this.authorshipLabel.text = "<p style='text-align:center;'>Written by Franklin Marek 2026.<br><a href='http://www.setiastro.com'>www.setiastro.com</a></p>";
        this.authorshipLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.authorshipLabel.useRichText   = true;

        // New instance button
        this.newInstanceButton = new ToolButton(this);
        this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
        this.newInstanceButton.setScaledFixedSize(24, 24);
        this.newInstanceButton.toolTip    = "New Instance";
        this.newInstanceButton.onMousePress = () => { this.newInstance(); };

        // Execute button
        this.generateButton = new PushButton(this);
        this.generateButton.text = "Execute";
        this.generateButton.onClick = () =>
        {
            console.writeln("Execute button clicked.");

            let selectedImageId = this.targetImageComboBox.itemText(this.targetImageComboBox.currentItem).trim();
            if ( selectedImageId === "" )
            {
                new MessageBox("Please select a valid image.", "Error", StdIcon.Error, StdButton.Ok).execute();
                return;
            }

            let selectedImage = ImageWindow.windowById(selectedImageId);
            if ( selectedImage.isNull )
            {
                new MessageBox("Selected image is not valid or not found.", "Error", StdIcon.Error, StdButton.Ok).execute();
                return;
            }

            // Optional linear pre-stretch
            if ( this.linearDataCheckbox.checked )
            {
                let P = new PixelMath;
                P.expression = "mtf(((.25)^5),$T)";
                P.useSingleExpression = true; P.generateOutput = true;
                P.singleThreaded = false; P.optimization = true;
                P.use64BitWorkingImage = false; P.rescale = false;
                P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
                P.createNewImage = false; P.showNewImage = true;
                P.executeOn(selectedImage.mainView);
            }

            let reductionAmount = this.reductionSlider.value;
            let iterations      = (reductionAmount === 0) ? 1 : reductionAmount;

            for ( let i = 0; i < iterations; i++ )
            {
                let lightnessMask = createLightnessMask(selectedImage);
                if ( !lightnessMask ) { console.writeln("Lightness mask creation failed."); return; }

                let duplicatedLightnessMask = createDuplicateImage(lightnessMask);
                if ( !duplicatedLightnessMask ) { console.writeln("Duplicating lightness mask failed."); return; }

                applyMMT(duplicatedLightnessMask);
                invertMask(lightnessMask);

                // Histogram transformation on the lightness mask
                let HT = new HistogramTransformation;
                HT.H = [
                    [0.0, 0.50, 1.0, 0.0, 1.0],
                    [0.0, 0.50, 1.0, 0.0, 1.0],
                    [0.0, 0.50, 1.0, 0.0, 1.0],
                    [0.0, 0.5725, 0.875, 0.0, 1.0],
                    [0.0, 0.50, 1.0, 0.0, 1.0]
                ];
                HT.executeOn(lightnessMask.mainView);

                // Subtract MMT from inverted lightness mask
                let PM = new PixelMath;
                PM.expression = lightnessMask.mainView.id + " - " +
                    duplicatedLightnessMask.mainView.id + " - " +
                    duplicatedLightnessMask.mainView.id;
                PM.useSingleExpression = true; PM.generateOutput = true; PM.createNewImage = false;
                PM.executeOn(lightnessMask.mainView);

                applyMaskToImage(selectedImage, lightnessMask);
                applyCurvesToImage(selectedImage, reductionAmount);
                selectedImage.removeMask();

                lightnessMask.forceClose();
                duplicatedLightnessMask.forceClose();
            }

            // Optional linear reverse-stretch
            if ( this.linearDataCheckbox.checked )
            {
                let P = new PixelMath;
                P.expression = "mtf(~((.25)^5),$T)";
                P.useSingleExpression = true; P.generateOutput = true;
                P.singleThreaded = false; P.optimization = true;
                P.use64BitWorkingImage = false; P.rescale = false;
                P.truncate = true; P.truncateLower = 0; P.truncateUpper = 1;
                P.createNewImage = false; P.showNewImage = true;
                P.executeOn(selectedImage.mainView);
            }

            console.noteln("Halos Be Gone!");
            this.ok();
        };

        // Layout
        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.spacing = 6;
        this.buttonSizer.add(this.newInstanceButton);
        this.buttonSizer.add(this.generateButton);

        this.sizer = new VerticalSizer;
        this.sizer.margin = 8; this.sizer.spacing = 6;
        this.sizer.add(this.titleLabel);
        this.sizer.addSpacing(8);
        this.sizer.add(this.targetImageLabel);
        this.sizer.add(this.targetImageComboBox);
        this.sizer.addSpacing(8);
        this.sizer.add(this.reductionLabel);
        this.sizer.add(this.reductionLabelSizer);
        this.sizer.add(this.reductionSlider);
        this.sizer.addSpacing(8);
        this.sizer.add(this.linearDataCheckbox);
        this.sizer.addSpacing(8);
        this.sizer.add(this.authorshipLabel);
        this.sizer.addSpacing(8);
        this.sizer.add(this.buttonSizer);

        this.adjustToContents();
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    console.warningln( " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    let dialog = new HaloBGonDialog();
    dialog.execute();
}

main();
