#engine v8

#feature-id   StarStretch : SetiAstro > Star Stretch
#feature-icon  starstretch.svg
#feature-info This script performs a stretch of a linear star image, boosts color, and removes any green cast.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 * Star Stretch Script
 * Version: 2.6
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script performs a stretch of a linear star image, boosts color, and removes any green cast.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/


#define VERSION "v2.6"

// define a global variable containing the script's parameters
var StarStretchParameters = {
   amount: 5,
   targetView: undefined,
   satAmount: 1, // Default saturation amount
   removeGreen: false, // Default SCNR option
   showPreview: false, // Default Show Preview option
   saturationLevel: [
      [0.00000, 0.40000],
      [0.50000, 0.70000],
      [1.00000, 0.40000]
   ],

   // stores the current parameters values into the script instance
   save: function() {
      Parameters.set("amount", StarStretchParameters.amount);
      Parameters.set("satAmount", StarStretchParameters.satAmount);
      Parameters.set("removeGreen", StarStretchParameters.removeGreen);
      Parameters.set("showPreview", StarStretchParameters.showPreview);
   },

   // loads the script instance parameters
   load: function () {
      if (Parameters.has("amount"))
         StarStretchParameters.amount = Parameters.getReal("amount");
      if (Parameters.has("satAmount"))
         StarStretchParameters.satAmount = Parameters.getReal("satAmount");
      if (Parameters.has("removeGreen"))
         StarStretchParameters.removeGreen = Parameters.getBoolean("removeGreen");
      if (Parameters.has("showPreview"))
         StarStretchParameters.showPreview = Parameters.getBoolean("showPreview");
   },

   // Update saturation level matrix based on satAmount
   updateSaturationLevel: function() {
      var satAmount = StarStretchParameters.satAmount;
      StarStretchParameters.saturationLevel = [
         [0.00000, satAmount * 0.40000],
         [0.50000, satAmount * 0.70000],
         [1.00000, satAmount * 0.40000]
      ];
   }
}



function applyPixelMath( view, amount )
{
   let P = new PixelMath;
   P.expression = "((3^" + amount + ")*$T)/((3^" + amount + " - 1)*$T + 1)";
   P.executeOn( view );
}

function applyColorSaturation( view )
{
   let P = new ColorSaturation;
   P.HS = StarStretchParameters.saturationLevel;
   P.HSt = ColorSaturation.AkimaSubsplines;
   P.hueShift = 0.000;
   P.executeOn( view );
}

function applySCNR( view )
{
   let P = new SCNR;
   P.amount = 1.00;
   P.protectionMethod = SCNR.AverageNeutral;
   P.colorToRemove = SCNR.Green;
   P.preserveLightness = true;
   P.executeOn( view );
}

// ScrollControl class definition
var ScrollControl = class extends ScrollBox
{
   constructor( parent )
   {
      super( parent );

      this.autoScroll = true;
      this.tracking = true;

      this.displayImage = null;
      this.dragging = false;
      this.dragOrigin = new Point( 0, 0 );

      this.viewport.cursor = new Cursor( StdCursor.OpenHand );

      this.viewport.onResize = () =>
      {
         this.initScrollBars();
      };

      this.onHorizontalScrollPosUpdated = x =>
      {
         this.viewport.update();
      };

      this.onVerticalScrollPosUpdated = y =>
      {
         this.viewport.update();
      };

      this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
      {
         this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
         this.dragOrigin.x = x;
         this.dragOrigin.y = y;
         this.dragging = true;
      };

      this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
      {
         if ( this.dragging )
         {
            this.scrollPosition = new Point( this.scrollPosition ).translatedBy(
               this.dragOrigin.x - x,
               this.dragOrigin.y - y
            );
            this.dragOrigin.x = x;
            this.dragOrigin.y = y;
         }
      };

      this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
      {
         this.viewport.cursor = new Cursor( StdCursor.OpenHand );
         this.dragging = false;
      };
      this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
      {
         if ( this.parent && this.parent.onPreviewWheelZoom )
            this.parent.onPreviewWheelZoom( delta, x, y, modifiers );
      };
      this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this.viewport );
         let result = this.getImage();

         if ( result == null )
         {
            g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
         }
         else
         {
            result.selectedRect = (new Rect( x0, y0, x1, y1 )).translated( this.scrollPosition );
            g.drawBitmap( x0, y0, result.render() );
            result.resetRectSelection();
         }

         g.end();
      };

      this.initScrollBars();
   }

   getImage()
   {
      return this.displayImage;
   }

   doUpdateImage( image )
   {
      this.displayImage = image;
      this.initScrollBars();
      this.viewport.update();
   }

   initScrollBars()
   {
      let image = this.getImage();
      if ( image == null || image.width <= 0 || image.height <= 0 )
      {
         this.setHorizontalScrollRange( 0, 0 );
         this.setVerticalScrollRange( 0, 0 );
      }
      else
      {
         this.setHorizontalScrollRange( 0, Math.max( 0, image.width - this.viewport.width ) );
         this.setVerticalScrollRange( 0, Math.max( 0, image.height - this.viewport.height ) );
      }
      this.viewport.update();
   }
};



var StarStretchDialog = class extends Dialog
{
   constructor()
   {
      super();

      this.windowTitle = "Star Stretch " + VERSION;
      this.userResizable = true;

      this.title = new Label( this );
      this.title.text = "Star Stretch " + VERSION + ": Linear to Non-Linear Stretch\n of a Stars Only Image";
      this.title.textAlignment = TextAlignment.Center;
      this.title.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0;";
      this.title.minHeight = 40;
      this.title.maxHeight = 50;

      this.description = new TextBox( this );
      this.description.text =
         "Please select your combined stars only image to stretch\n" +
         "Default value is a stretch of " + StarStretchParameters.amount + "\n" +
         "Default color boost value is " + StarStretchParameters.satAmount + "\n\n" +
         "Written by Franklin Marek. Copyright 2026";
      this.description.readOnly = true;
      this.description.backgroundColor = 0xd3d3d3;
      this.description.maxHeight = 100;
      this.description.minWidth = 400;

      let activeWindow = ImageWindow.activeWindow;
      if ( activeWindow != null && !activeWindow.isNull )
         StarStretchParameters.targetView = activeWindow.mainView;
      else
         StarStretchParameters.targetView = null;

      this.viewList = new ViewList( this );
      this.viewList.getAll();
      if ( StarStretchParameters.targetView )
         this.viewList.currentView = StarStretchParameters.targetView;

      this.viewList.onViewSelected = view =>
      {
         StarStretchParameters.targetView = view;
      };

      this.AmountControl = new NumericControl( this );
      this.AmountControl.label.text = "Stretch Amount:";
      this.AmountControl.label.width = 120;
      this.AmountControl.setRange( 0, 8 );
      this.AmountControl.setPrecision( 2 );
      this.AmountControl.slider.setRange( 0, 100 );
      this.AmountControl.setValue( StarStretchParameters.amount );
      this.AmountControl.toolTip = "<p>Adjust above 5 with caution.</p>";
      this.AmountControl.onValueUpdated = value =>
      {
         StarStretchParameters.amount = value;
      };

      this.SaturationAmountControl = new NumericControl( this );
      this.SaturationAmountControl.label.text = "Color Boost Amount:";
      this.SaturationAmountControl.label.width = 120;
      this.SaturationAmountControl.setRange( 0, 2 );
      this.SaturationAmountControl.setPrecision( 2 );
      this.SaturationAmountControl.slider.setRange( 0, 200 );
      this.SaturationAmountControl.setValue( StarStretchParameters.satAmount );
      this.SaturationAmountControl.toolTip = "<p>Adjust the color saturation amount.</p>";
      this.SaturationAmountControl.onValueUpdated = value =>
      {
         StarStretchParameters.satAmount = value;
         StarStretchParameters.updateSaturationLevel();
      };

      this.SCNRCheckBox = new CheckBox( this );
      this.SCNRCheckBox.text = "Remove Green via SCNR (Optional)";
      this.SCNRCheckBox.checked = StarStretchParameters.removeGreen;
      this.SCNRCheckBox.toolTip = "<p>Enable or disable green cast removal using SCNR.</p>";
      this.SCNRCheckBox.onCheck = checked =>
      {
         StarStretchParameters.removeGreen = checked;
      };

      this.showPreviewCheckBox = new CheckBox( this );
      this.showPreviewCheckBox.text = "Show Preview";
      this.showPreviewCheckBox.checked = StarStretchParameters.showPreview;
      this.showPreviewCheckBox.toolTip = "<p>Enable or disable preview of the stretch.</p>";
      this.showPreviewCheckBox.onCheck = checked =>
      {
         StarStretchParameters.showPreview = checked;
         this.previewControl.visible = checked;
         this.zoomSizer.visible = checked;

         if ( checked && StarStretchParameters.targetView )
         {
            let selectedImage = StarStretchParameters.targetView.image;
            if ( selectedImage )
            {
               this.buildPreviewBaseImage();
               this.updatePreviewZoom();
            }
         }

         this.adjustToContents();
      };

      this.newInstanceButton = new ToolButton( this );
      this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
      this.newInstanceButton.setScaledFixedSize( 24, 24 );
      this.newInstanceButton.toolTip = "New Instance";
      this.newInstanceButton.onMousePress = () =>
      {
         StarStretchParameters.save();
         this.newInstance();
      };

      this.zoomLabel = new Label( this );
      this.zoomLabel.text = "Zoom: ";
      this.zoomLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

      this.zoomComboBox = new ComboBox( this );
      this.zoomComboBox.addItem( "1:1" );
      this.zoomComboBox.addItem( "1:2" );
      this.zoomComboBox.addItem( "1:4" );
      this.zoomComboBox.addItem( "1:8" );
      this.zoomComboBox.addItem( "Fit to Preview" );
      this.zoomComboBox.currentItem = 2;
      this.zoomComboBox.minWidth = 120;
      this.zoomComboBox.onItemSelected = index =>
      {
         if ( StarStretchParameters.showPreview )
            this.updatePreviewZoom();
      };

      this.previewRefreshButton = new PushButton( this );
      this.previewRefreshButton.text = "Refresh Preview";
      this.previewRefreshButton.minWidth = 120;
      this.previewRefreshButton.onClick = () =>
      {
         this.refreshPreview();
      };

      this.zoomSizer = new HorizontalSizer;
      this.zoomSizer.margin = 4;
      this.zoomSizer.spacing = 4;
      this.zoomSizer.add( this.zoomLabel );
      this.zoomSizer.add( this.zoomComboBox );
      this.zoomSizer.addSpacing( 12 );
      this.zoomSizer.add( this.previewRefreshButton );

      this.execButton = new PushButton( this );
      this.execButton.text = "Execute";
      this.execButton.width = 80;
      this.execButton.onClick = () =>
      {
         this.applyStretchToMainImage();
         this.ok();
      };

      this.execButtonSizer = new HorizontalSizer;
      this.execButtonSizer.margin = 8;
      this.execButtonSizer.add( this.newInstanceButton );
      this.execButtonSizer.addSpacing( 12 );
      this.execButtonSizer.add( this.zoomSizer );
      this.execButtonSizer.addStretch();
      this.execButtonSizer.add( this.execButton );

      this.previewControl = new ScrollControl( this );
      this.previewControl.setMinWidth( 300 );
      this.previewControl.setMinHeight( 300 );
      this.previewControl.visible = false;
      this.previewBaseImage = null;

      this.onPreviewWheelZoom = ( delta, x, y, modifiers ) =>
      {
         if ( !StarStretchParameters.showPreview )
            return;

         let i = this.zoomComboBox.currentItem;

         if ( delta > 0 )
            i = Math.max( 0, i - 1 );
         else if ( delta < 0 )
            i = Math.min( this.zoomComboBox.numberOfItems - 1, i + 1 );

         if ( i != this.zoomComboBox.currentItem )
         {
            this.zoomComboBox.currentItem = i;
            this.updatePreviewZoom();
         }
      };

      this.leftSizer = new VerticalSizer;
      this.leftSizer.margin = 8;
      this.leftSizer.spacing = 8;
      this.leftSizer.add( this.title );
      this.leftSizer.addSpacing( 8 );
      this.leftSizer.add( this.description );
      this.leftSizer.addSpacing( 8 );
      this.leftSizer.add( this.viewList );
      this.leftSizer.addSpacing( 8 );
      this.leftSizer.add( this.AmountControl );
      this.leftSizer.addSpacing( 8 );
      this.leftSizer.add( this.SaturationAmountControl );
      this.leftSizer.addSpacing( 8 );
      this.leftSizer.add( this.SCNRCheckBox );
      this.leftSizer.addSpacing( 8 );
      this.leftSizer.add( this.showPreviewCheckBox );
      this.leftSizer.addSpacing( 8 );
      this.leftSizer.add( this.execButtonSizer );
      this.leftSizer.addStretch();
      this.leftSizer.minWidth = 300;

      this.mainSizer = new HorizontalSizer;
      this.mainSizer.margin = 8;
      this.mainSizer.spacing = 8;
      this.mainSizer.add( this.leftSizer );
      this.mainSizer.add( this.previewControl );

      this.sizer = this.mainSizer;

      this.onShow = () =>
      {
         this.previewControl.visible = StarStretchParameters.showPreview;
         this.zoomSizer.visible = StarStretchParameters.showPreview;
         this.adjustToContents();
      };

      this.adjustToContents();
   }


   buildPreviewBaseImage()
   {
      if ( !StarStretchParameters.targetView )
         return;

      let src = StarStretchParameters.targetView.image;

      let window = new ImageWindow(
         src.width,
         src.height,
         src.numberOfChannels,
         src.bitsPerSample,
         src.isReal,
         src.isColor
      );

      window.mainView.beginProcess();
      window.mainView.image.assign( src );
      window.mainView.endProcess();

      applyPixelMath( window.mainView, StarStretchParameters.amount );

      if ( !isGrayscale( window.mainView ) )
      {
         applyColorSaturation( window.mainView );
         if ( StarStretchParameters.removeGreen )
            applySCNR( window.mainView );
      }

      this.previewBaseImage = new Image( window.mainView.image );
      window.forceClose();
   }

   updatePreviewZoom()
   {
      if ( this.previewBaseImage == null )
         return;

      let selectedImage = this.previewBaseImage;

      let window = new ImageWindow(
         selectedImage.width,
         selectedImage.height,
         selectedImage.numberOfChannels,
         selectedImage.bitsPerSample,
         selectedImage.isReal,
         selectedImage.isColor
      );

      window.mainView.beginProcess();
      window.mainView.image.assign( selectedImage );
      window.mainView.endProcess();

      let P = new IntegerResample;

      switch ( this.zoomComboBox.currentItem )
      {
      case 0:
         P.zoomFactor = -1;
         break;
      case 1:
         P.zoomFactor = -2;
         break;
      case 2:
         P.zoomFactor = -4;
         break;
      case 3:
         P.zoomFactor = -8;
         break;
      case 4:
         {
            let previewWidth = Math.max( this.previewControl.width, 1 );
            let widthScale = Math.floor( selectedImage.width / previewWidth );
            P.zoomFactor = -Math.max( widthScale, 1 );
         }
         break;
      default:
         P.zoomFactor = -2;
         break;
      }

      P.executeOn( window.mainView );

      let resizedImage = new Image( window.mainView.image );
      window.forceClose();

      this.previewControl.doUpdateImage( resizedImage );
   }

   applyStretchToMainImage()
   {
      if ( StarStretchParameters.targetView )
      {
         applyPixelMath( StarStretchParameters.targetView, StarStretchParameters.amount );

         if ( !isGrayscale( StarStretchParameters.targetView ) )
         {
            applyColorSaturation( StarStretchParameters.targetView );
            if ( StarStretchParameters.removeGreen )
               applySCNR( StarStretchParameters.targetView );
         }

         console.show();
         disableSTF( StarStretchParameters.targetView );
         console.noteln( "Star Stretch Process Completed!" );
      }
      else
      {
         console.warningln( "No target view is specified." );
      }
   }

   refreshPreview()
   {
      if ( !StarStretchParameters.showPreview || !StarStretchParameters.targetView )
         return;

      this.buildPreviewBaseImage();
      this.updatePreviewZoom();
   }

   createTemporaryImage( selectedImage )
   {
      let window = new ImageWindow(
         selectedImage.width,
         selectedImage.height,
         selectedImage.numberOfChannels,
         selectedImage.bitsPerSample,
         selectedImage.isReal,
         selectedImage.isColor
      );

      window.mainView.beginProcess();
      window.mainView.image.assign( selectedImage );
      window.mainView.endProcess();

      let P = new IntegerResample;
      switch ( this.zoomComboBox.currentItem )
      {
      case 0:
         P.zoomFactor = -1;
         break;
      case 1:
         P.zoomFactor = -2;
         break;
      case 2:
         P.zoomFactor = -4;
         break;
      case 3:
         P.zoomFactor = -8;
         break;
      case 4:
         {
            let previewWidth = this.previewControl.width;
            let widthScale = Math.floor( selectedImage.width / previewWidth );
            P.zoomFactor = -Math.max( widthScale, 1 );
         }
         break;
      default:
         P.zoomFactor = -2;
         break;
      }

      P.executeOn( window.mainView );

      let resizedImage = new Image( window.mainView.image );

      if ( resizedImage.width > 0 && resizedImage.height > 0 )
      {
         this.previewControl.doUpdateImage( resizedImage );
         this.previewControl.initScrollBars();
      }
      else
      {
         console.criticalln( "Resized image has invalid dimensions." );
      }

      window.forceClose();
      return resizedImage;
   }
};

function disableSTF( targetView )
{
   let stf = new ScreenTransferFunction;

   stf.STF = [
      [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
      [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
      [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
      [0.00000, 1.00000, 0.50000, 0.00000, 1.00000]
   ];

   stf.executeOn( targetView, false );
   console.writeln( "STF has been disabled." );
}

// Function to check if the view is grayscale
function isGrayscale(view) {
   return !view.image.isColor;
}

// Modify the main execution logic
function main()
{
   console.show();
   console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
   console.warningln( " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );

   if ( Parameters.isGlobalTarget )
   {
      console.criticalln( "Star Stretch could not run in global context." );
      return;
   }

   StarStretchParameters.load();
   StarStretchParameters.updateSaturationLevel();

   let dialog = new StarStretchDialog();
   dialog.execute();
}

main();
