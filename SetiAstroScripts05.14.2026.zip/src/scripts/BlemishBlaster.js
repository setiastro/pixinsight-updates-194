#engine v8

#feature-id BlemishBlaster : SetiAstro > Blemish Blaster
#feature-icon  blemishblaster.svg
#feature-info This script allows blemish removal in astrophotographic images by averaging the surrounding area to replace the selected spot.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Blemish Blaster
 * Version: V2.4.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows blemish removal in astrophotographic images by averaging
 * the surrounding area to replace the selected spot.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define TITLE   "Blemish Blaster"
#define VERSION "V2.4.1"

let parameters = {
    targetWindow:    null,
    previewZoomLevel: "Fit to Preview",
    autoSTFApplied:  false,
    drawingMode:     "Circle",
    save: function()
    {
        Parameters.set( "previewZoomLevel", this.previewZoomLevel );
        Parameters.set( "autoSTFApplied",   this.autoSTFApplied ? "true" : "false" );
        if ( this.targetWindow )
            Parameters.set( "targetWindow", this.targetWindow.mainView.id );
    },
    load: function()
    {
        if ( Parameters.has( "previewZoomLevel" ) )
            this.previewZoomLevel = Parameters.getString( "previewZoomLevel" );
        if ( Parameters.has( "autoSTFApplied" ) )
            this.autoSTFApplied = Parameters.getBoolean( "autoSTFApplied" );
        if ( Parameters.has( "targetWindow" ) )
        {
            let windowId = Parameters.getString( "targetWindow" );
            let window = ImageWindow.windowById( windowId );
            if ( window && !window.isNull )
                this.targetWindow = window;
        }
    }
};

// ============================================================================
// Satellite trail detection helpers
// ============================================================================

function detectAndDrawSatelliteTrail( parent, startX, startY )
{
    const searchRadius = 20;
    const brightnessThreshold = 1.5 * parent.displayImage.median();
    let allTrailPoints = [{ x: startX, y: startY }];

    const imageWidth  = parent.displayImage.width;
    const imageHeight = parent.displayImage.height;
    const maxSteps = 10 * Math.floor(
        Math.sqrt( imageWidth * imageWidth + imageHeight * imageHeight ) / searchRadius );

    searchTrail( parent, startX, startY, searchRadius, brightnessThreshold, -1, allTrailPoints, maxSteps );
    searchTrail( parent, startX, startY, searchRadius, brightnessThreshold,  1, allTrailPoints, maxSteps );

    allTrailPoints.sort( (a, b) => (a.x - b.x) || (a.y - b.y) );

    if ( allTrailPoints.length > 1 )
    {
        parent.satelliteTrails.push( { start: allTrailPoints[0], end: allTrailPoints[allTrailPoints.length - 1] } );
        parent.viewport.update();
    }
}

function searchTrail( parent, startX, startY, searchRadius, brightnessThreshold, directionMultiplier, trailPoints, maxSteps )
{
    let endX = startX;
    let endY = startY;
    let steps = 0;

    while ( steps < maxSteps )
    {
        const direction = findTrailDirection(
            parent, endX, endY, searchRadius, brightnessThreshold,
            directionMultiplier * Math.PI, Math.PI );

        if ( !direction ) break;

        let nextX = Math.round( endX + directionMultiplier * direction.dx );
        let nextY = Math.round( endY + directionMultiplier * direction.dy );

        if ( !isPointWithinImageBounds( parent.displayImage, nextX, nextY ) ) break;

        let brightestY = nextY;
        let brightestBrightness = getPointBrightness( parent.displayImage, nextX, nextY );

        for ( let offsetY = -5; offsetY <= 5; offsetY++ )
        {
            let checkY = nextY + offsetY;
            if ( isPointWithinImageBounds( parent.displayImage, nextX, checkY ) )
            {
                let brightness = getPointBrightness( parent.displayImage, nextX, checkY );
                if ( brightness > brightestBrightness )
                {
                    brightestBrightness = brightness;
                    brightestY = checkY;
                }
            }
        }

        nextY = brightestY;

        endX = nextX;
        endY = nextY;

        if ( isBrightPoint( parent.displayImage, nextX, nextY, brightnessThreshold ) )
            trailPoints.push( { x: endX, y: endY } );

        steps++;
    }
}

function findTrailDirection( parent, startX, startY, searchRadius, brightnessThreshold, startAngle, angleRange )
{
    const numDirections = 18;
    const angleIncrement = angleRange / numDirections;
    let bestDirection = null;
    let bestSumBrightness = 0;

    for ( let i = 0; i <= numDirections; i++ )
    {
        const angle = startAngle + i * angleIncrement;
        const dir = { dx: Math.cos( angle ), dy: Math.sin( angle ) };

        let sumBrightness = 0;
        let validPoints = 0;

        for ( let step = -searchRadius; step <= searchRadius; step++ )
        {
            let x = startX + step * dir.dx;
            let y = startY + step * dir.dy;
            if ( isPointWithinImageBounds( parent.displayImage, x, y ) )
            {
                sumBrightness += getPointBrightness( parent.displayImage, x, y );
                validPoints++;
            }
        }

        if ( validPoints > 0 ) sumBrightness /= validPoints;

        if ( sumBrightness > bestSumBrightness )
        {
            bestSumBrightness = sumBrightness;
            bestDirection = dir;
        }
    }

    return (bestDirection && bestSumBrightness > brightnessThreshold) ? bestDirection : null;
}

function isPointWithinImageBounds( image, x, y )
{
    return x >= 0 && x < image.width && y >= 0 && y < image.height;
}

function getPointBrightness( image, x, y )
{
    let brightness = 0;
    for ( let c = 0; c < image.numberOfChannels; c++ )
        brightness += image.sample( x, y, c );
    return brightness / image.numberOfChannels;
}

function isBrightPoint( image, x, y, threshold )
{
    return getPointBrightness( image, x, y ) > threshold;
}

function isPointInShape( x, y, shape )
{
    let crossings = 0;
    for ( let i = 0; i < shape.length; i++ )
    {
        let x1 = shape[i].x;
        let y1 = shape[i].y;
        let x2 = shape[(i + 1) % shape.length].x;
        let y2 = shape[(i + 1) % shape.length].y;
        if ( ((y1 <= y && y < y2) || (y2 <= y && y < y1)) &&
             (x < (x2 - x1) * (y - y1) / (y2 - y1) + x1) )
            crossings++;
    }
    return crossings % 2 !== 0;
}

function calculateFreehandCenterAndRadius( shape )
{
    let sumX = 0, sumY = 0;
    for ( let i = 0; i < shape.length; i++ ) { sumX += shape[i].x; sumY += shape[i].y; }
    let centerX = sumX / shape.length;
    let centerY = sumY / shape.length;
    let maxDistance = 0;
    for ( let i = 0; i < shape.length; i++ )
    {
        let d = Math.sqrt( Math.pow( shape[i].x - centerX, 2 ) + Math.pow( shape[i].y - centerY, 2 ) );
        if ( d > maxDistance ) maxDistance = d;
    }
    return { centerX: centerX, centerY: centerY, radius: maxDistance };
}

// Standalone replacement for Image.prototype.extractCircle (can't extend core classes in V8)
function extractCircleFromImage( image, x, y, radius )
{
    let circleImage = new Image(
        radius * 2, radius * 2,
        image.numberOfChannels,
        image.bitsPerSample,
        image.isReal );

    for ( let dx = -radius; dx < radius; dx++ )
        for ( let dy = -radius; dy < radius; dy++ )
            if ( Math.sqrt( dx * dx + dy * dy ) <= radius )
            {
                let sampleX = x + dx;
                let sampleY = y + dy;
                if ( sampleX >= 0 && sampleX < image.width && sampleY >= 0 && sampleY < image.height )
                    for ( let c = 0; c < image.numberOfChannels; c++ )
                        circleImage.setSample( image.sample( sampleX, sampleY, c ), dx + radius, dy + radius, c );
            }
    return circleImage;
}

// ============================================================================
// MedianCalculator
// ============================================================================

function MedianCalculator()
{
    this.calculate = function( arr )
    {
        arr.sort( (a, b) => a - b );
        const mid = Math.floor( arr.length / 2 );
        return arr.length % 2 === 0
            ? (arr[mid - 1] + arr[mid]) / 2
            : arr[mid];
    };
}

// ============================================================================
// Star helpers
// ============================================================================

function starCentroid( img_x, img_y, radius, image )
{
    let maxBrightness = -Infinity;
    let brightestPoint = { x: img_x, y: img_y };

    for ( let y = Math.max( 0, img_y - radius ); y < Math.min( image.height, img_y + radius ); y++ )
        for ( let x = Math.max( 0, img_x - radius ); x < Math.min( image.width, img_x + radius ); x++ )
            if ( Math.sqrt( Math.pow( x - img_x, 2 ) + Math.pow( y - img_y, 2 ) ) <= radius )
            {
                let brightness = image.sample( x, y );
                if ( brightness > maxBrightness )
                {
                    maxBrightness = brightness;
                    brightestPoint = { x: x, y: y };
                }
            }

    let FWHM = calculateFWHM( brightestPoint.x, brightestPoint.y, image );
    return { x: brightestPoint.x, y: brightestPoint.y, FWHM: FWHM };
}

function calculateFWHM( starX, starY, image )
{
    let intensityProfile = [];
    let radius = 50;

    for ( let r = 0; r <= radius; r++ )
    {
        let sum = 0, count = 0;
        for ( let theta = 0; theta < 360; theta++ )
        {
            let rad = (theta * Math.PI) / 180;
            let x = Math.round( starX + r * Math.cos( rad ) );
            let y = Math.round( starY + r * Math.sin( rad ) );
            if ( x >= 0 && x < image.width && y >= 0 && y < image.height )
            {
                sum += image.sample( x, y, 0 );
                count++;
            }
        }
        intensityProfile.push( sum / count );
    }

    let maxIntensity = Math.max( ...intensityProfile );
    let halfMaxIntensity = maxIntensity / 2;

    for ( let r = 0; r < intensityProfile.length; r++ )
        if ( intensityProfile[r] <= halfMaxIntensity )
            return r;

    return radius;
}

// Freehand geometry helpers
function getMinDistanceToEdge( x, y, shape )
{
    let minDistance = Infinity;
    for ( let i = 0; i < shape.length; i++ )
    {
        let d = pointLineDistance(
            x, y,
            shape[i].x, shape[i].y,
            shape[(i + 1) % shape.length].x,
            shape[(i + 1) % shape.length].y );
        if ( d < minDistance ) minDistance = d;
    }
    return minDistance;
}

function pointLineDistance( px, py, x1, y1, x2, y2 )
{
    let A = px - x1, B = py - y1, C = x2 - x1, D = y2 - y1;
    let dot = A * C + B * D;
    let len_sq = C * C + D * D;
    let param = len_sq !== 0 ? dot / len_sq : -1;
    let xx, yy;
    if ( param < 0 ) { xx = x1; yy = y1; }
    else if ( param > 1 ) { xx = x2; yy = y2; }
    else { xx = x1 + param * C; yy = y1 + param * D; }
    return Math.sqrt( Math.pow( px - xx, 2 ) + Math.pow( py - yy, 2 ) );
}

// ============================================================================
// configurePixelMath helper
// ============================================================================

function configurePixelMath( P )
{
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages  = false;
    P.generateOutput        = true;
    P.singleThreaded        = false;
    P.optimization          = true;
    P.use64BitWorkingImage  = false;
    P.rescale               = false;
    P.rescaleLower          = 0;
    P.rescaleUpper          = 1;
    P.truncate              = true;
    P.truncateLower         = 0;
    P.truncateUpper         = 1;
    P.createNewImage        = false;
    P.showNewImage          = false;
    P.newImageId            = "";
    P.newImageWidth         = 0;
    P.newImageHeight        = 0;
    P.newImageAlpha         = false;
    P.newImageColorSpace    = PixelMath.SameAsTarget;
    P.newImageSampleFormat  = PixelMath.SameAsTarget;
}

// ============================================================================
// ScrollControl
// ============================================================================

var ScrollControl = class extends ScrollBox
{
    constructor( parent )
    {
        super( parent );

        this.autoScroll   = true;
        this.tracking     = true;

        this.displayImage       = null;
        this.displayImageWindow = null;
        this.dragging           = false;
        this.dragOrigin         = new Point( 0, 0 );
        this.debugPoints        = [];
        this.currentCircle      = null;
        this.currentLine        = null;
        this.satelliteTrails    = [];
        this.freehandShapes     = [];
        this.currentFreehandShape = null;
        this.blemishPoints      = [];

        this.viewport.cursor = new Cursor( StdCursor.Cross );

        this.zoom         = 1;
        this.scale        = 1;
        this.zoomOutLimit = -5;
        this.minZoomFactor = 0.05;
        this.maxZoomFactor = 4;

        this.currentMousePosition = { x: 0, y: 0 };

        this.tempImageStack = [];
        this.undoStack      = [];
        this.redoStack      = [];

        this.executeCounter = 0;

        // ---- Viewport events ----

        this.viewport.onResize = () =>
        {
            this.initScrollBars();
        };

        this.onHorizontalScrollPosUpdated = x =>
        {
            this.viewport.update();
        };

        this.onVerticalScrollPosUpdated = y =>
        {
            this.viewport.update();
        };

        this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
        {
            let zoomFactor = this.scale;
            let adjustedX = (x / zoomFactor) + this.scrollPosition.x;
            let adjustedY = (y / zoomFactor) + this.scrollPosition.y;

            if ( modifiers === 1 ) // Shift
            {
                if ( parameters.drawingMode === "Circle" )
                    this.currentCircle = { x: adjustedX, y: adjustedY, radius: 0 };
                else if ( parameters.drawingMode === "Freehand" )
                    this.currentFreehandShape = [{ x: adjustedX, y: adjustedY }];
            }
            else if ( modifiers === 4 ) // Ctrl
            {
                detectAndDrawSatelliteTrail( this, adjustedX, adjustedY );
            }
            else if ( modifiers === 2 ) // Alt
            {
                if ( !this.currentLine )
                    this.currentLine = { start: { x: adjustedX, y: adjustedY }, end: null };
                else
                {
                    this.currentLine.end = { x: adjustedX, y: adjustedY };
                    this.satelliteTrails.push( this.currentLine );
                    this.currentLine = null;
                }
            }
            else if ( button === 2 ) // Right click
            {
                this.removeClosestElement( adjustedX, adjustedY );
            }
            else
            {
                this.viewport.cursor = new Cursor( StdCursor.ClosedHand );
                this.dragOrigin.x = x;
                this.dragOrigin.y = y;
                this.dragging = true;
            }
        };

        this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
        {
            let zoomFactor = this.scale;
            let adjustedX = (x / zoomFactor) + this.scrollPosition.x;
            let adjustedY = (y / zoomFactor) + this.scrollPosition.y;

            this.currentMousePosition = { x: adjustedX, y: adjustedY };

            if ( this.currentCircle )
            {
                let dx = adjustedX - this.currentCircle.x;
                let dy = adjustedY - this.currentCircle.y;
                this.currentCircle.radius = Math.sqrt( dx * dx + dy * dy );
            }

            if ( this.currentFreehandShape )
                this.currentFreehandShape.push( { x: adjustedX, y: adjustedY } );

            if ( this.currentLine && modifiers === 2 )
                this.currentLine.end = { x: adjustedX, y: adjustedY };

            if ( this.dragging )
            {
                let dx = (this.dragOrigin.x - x) / this.scale;
                let dy = (this.dragOrigin.y - y) / this.scale;
                this.scrollPosition = new Point(
                    this.scrollPosition.x + dx,
                    this.scrollPosition.y + dy );
                this.dragOrigin.x = x;
                this.dragOrigin.y = y;
            }

            this.viewport.update();
        };

        this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
        {
            this.viewport.cursor = new Cursor( StdCursor.Cross );
            this.dragging = false;

            if ( this.currentCircle && this.currentCircle.radius > 0 )
            {
                this.placeBlemishPoint( this.currentCircle.x, this.currentCircle.y, this.currentCircle.radius );
                this.currentCircle = null;
            }

            if ( this.currentFreehandShape && this.currentFreehandShape.length > 2 )
            {
                this.currentFreehandShape.push( this.currentFreehandShape[0] );
                this.placeFreehandShape( this.currentFreehandShape );
                this.currentFreehandShape = null;
            }

            if ( this.currentLine && this.currentLine.end )
            {
                this.satelliteTrails.push( this.currentLine );
                this.currentLine = null;
            }
        };

        this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
        {
            if ( !this.displayImage ) return;
            let refPoint = new Point( x, y );
            if ( delta > 0 )
                this.UpdateZoom( this.zoom - 1, refPoint );
            else if ( delta < 0 )
                this.UpdateZoom( this.zoom + 1, refPoint );
        };

        this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this.viewport );
            let result = this.getImage();
            let zoomFactor = this.scale;

            if ( result == null || result.isNull || result.isEmpty )
            {
                g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
            }
            else
            {
                g.scaleTransformation( zoomFactor );
                g.translateTransformation( -this.scrollPosition.x, -this.scrollPosition.y );
                g.drawBitmap( 0, 0, result.render() );

                g.pen = new Pen( 0xffffff00, 1 );
                if ( this.currentCircle )
                    g.drawCircle( this.currentCircle.x, this.currentCircle.y, this.currentCircle.radius );
                else
                    g.drawCircle( this.currentMousePosition.x, this.currentMousePosition.y, 0 );

                if ( this.currentLine && this.currentLine.end )
                {
                    g.pen = new Pen( 0xff00ff00, 1 );
                    g.drawLine( this.currentLine.start.x, this.currentLine.start.y,
                                this.currentLine.end.x,   this.currentLine.end.y );
                }
                else if ( this.currentLine )
                {
                    g.pen = new Pen( 0xff00ff00, 1 );
                    g.drawLine( this.currentLine.start.x, this.currentLine.start.y,
                                this.currentMousePosition.x, this.currentMousePosition.y );
                }

                if ( this.satelliteTrails.length > 0 )
                {
                    g.pen = new Pen( 0xff00ff00, 1 );
                    this.satelliteTrails.forEach( trail =>
                    {
                        g.drawLine( trail.start.x, trail.start.y, trail.end.x, trail.end.y );
                    } );
                }

                if ( this.blemishPoints.length > 0 )
                {
                    g.pen = new Pen( 0xff00ff00, 1 );
                    this.blemishPoints.forEach( point =>
                    {
                        g.drawCircle( point.x, point.y, point.radius );
                    } );
                }

                if ( this.freehandShapes.length > 0 )
                {
                    g.pen = new Pen( 0xff00ff00, 1 );
                    this.freehandShapes.forEach( shape =>
                    {
                        for ( let i = 0; i < shape.length - 1; i++ )
                            g.drawLine( shape[i].x, shape[i].y, shape[i+1].x, shape[i+1].y );
                    } );
                }

                if ( this.currentFreehandShape && this.currentFreehandShape.length > 1 )
                {
                    g.pen = new Pen( 0xff00ff00, 1 );
                    for ( let i = 0; i < this.currentFreehandShape.length - 1; i++ )
                        g.drawLine(
                            this.currentFreehandShape[i].x,   this.currentFreehandShape[i].y,
                            this.currentFreehandShape[i+1].x, this.currentFreehandShape[i+1].y );
                }
            }

            g.end();
        };

        this.initScrollBars();
    }

    getImage() { return this.displayImage; }

    doUpdateImage( image )
    {
        this.displayImage = image;
        this.initScrollBars();
        if ( this.viewport ) this.viewport.update();
    }

    SetZoomOutLimit()
    {
        if ( this.displayImage )
        {
            let scaleX = Math.ceil( this.displayImage.width  / this.viewport.width );
            let scaleY = Math.ceil( this.displayImage.height / this.viewport.height );
            this.zoomOutLimit = -Math.max( scaleX, scaleY ) + 2;
        }
    }

    UpdateZoom( newZoom, refPoint )
    {
        newZoom = Math.max( this.zoomOutLimit, Math.min( this.maxZoomFactor, newZoom ) );
        if ( newZoom === this.zoom && this.scaledImage ) return;

        if ( refPoint == null )
            refPoint = new Point( this.viewport.width / 2, this.viewport.height / 2 );

        let imgx = this.maxHorizontalScrollPosition > 0
            ? (refPoint.x + this.scrollPosition.x) / this.scale
            : null;
        let imgy = this.maxVerticalScrollPosition > 0
            ? (refPoint.y + this.scrollPosition.y) / this.scale
            : null;

        this.zoom = newZoom;
        this.scaledImage = null;

        this.scale = this.zoom > 0 ? this.zoom : 1 / (-this.zoom + 2);

        if ( this.displayImage && imgx !== null && imgy !== null )
        {
            this.scrollPosition.x = imgx * this.scale - refPoint.x;
            this.scrollPosition.y = imgy * this.scale - refPoint.y;
        }

        this.viewport.update();
    }

    initScrollBars( scrollPoint )
    {
        let image = this.getImage();
        if ( image == null || image.width <= 0 || image.height <= 0 )
        {
            this.setHorizontalScrollRange( 0, 0 );
            this.setVerticalScrollRange(   0, 0 );
            this.scrollPosition = new Point( 0, 0 );
        }
        else
        {
            let zf = this.scale;
            this.setHorizontalScrollRange( 0, Math.max( 0, 3 * image.width  * zf ) );
            this.setVerticalScrollRange(   0, Math.max( 0, 3 * image.height * zf ) );
            if ( scrollPoint )
                this.scrollPosition = scrollPoint;
            else
                this.scrollPosition = new Point(
                    Math.min( this.scrollPosition.x, 3 * image.width  * zf ),
                    Math.min( this.scrollPosition.y, 3 * image.height * zf ) );
        }
        if ( this.viewport ) this.viewport.update();
    }

    zoomIn()  { this.UpdateZoom( this.zoom + 1 ); if ( this.viewport ) this.viewport.update(); }
    zoomOut() { this.UpdateZoom( this.zoom - 1 ); if ( this.viewport ) this.viewport.update(); }

    placeBlemishPoint( x, y, radius )
    {
        this.blemishPoints.push( { x: x, y: y, radius: radius } );
        if ( this.viewport ) this.viewport.update();
    }

    placeFreehandShape( shape )
    {
        this.freehandShapes.push( shape );
        if ( this.viewport ) this.viewport.update();
    }

    removeClosestElement( x, y )
    {
        let closestDistance = Infinity;
        let closestIndex = -1;
        let closestType  = '';

        for ( let i = 0; i < this.blemishPoints.length; i++ )
        {
            let d = Math.sqrt( Math.pow( this.blemishPoints[i].x - x, 2 ) + Math.pow( this.blemishPoints[i].y - y, 2 ) );
            if ( d < closestDistance ) { closestDistance = d; closestIndex = i; closestType = 'blemish'; }
        }

        for ( let i = 0; i < this.satelliteTrails.length; i++ )
        {
            let trail = this.satelliteTrails[i];
            let d = Math.min(
                Math.sqrt( Math.pow( trail.start.x - x, 2 ) + Math.pow( trail.start.y - y, 2 ) ),
                Math.sqrt( Math.pow( trail.end.x   - x, 2 ) + Math.pow( trail.end.y   - y, 2 ) ) );
            if ( d < closestDistance ) { closestDistance = d; closestIndex = i; closestType = 'trail'; }
        }

        for ( let i = 0; i < this.freehandShapes.length; i++ )
        {
            let shape = this.freehandShapes[i];
            for ( let j = 0; j < shape.length - 1; j++ )
            {
                let d = this.distanceToSegment( { x: x, y: y }, shape[j], shape[j+1] );
                if ( d < closestDistance ) { closestDistance = d; closestIndex = i; closestType = 'freehand'; }
            }
        }

        if      ( closestType === 'blemish'  ) this.blemishPoints.splice( closestIndex, 1 );
        else if ( closestType === 'trail'    ) this.satelliteTrails.splice( closestIndex, 1 );
        else if ( closestType === 'freehand' ) this.freehandShapes.splice( closestIndex, 1 );

        if ( this.viewport ) this.viewport.update();
    }

    distanceToSegment( p, v, w )
    {
        const l2 = Math.pow( v.x - w.x, 2 ) + Math.pow( v.y - w.y, 2 );
        if ( l2 === 0 ) return Math.sqrt( Math.pow( p.x - v.x, 2 ) + Math.pow( p.y - v.y, 2 ) );
        const t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
        if ( t < 0 ) return Math.sqrt( Math.pow( p.x - v.x, 2 ) + Math.pow( p.y - v.y, 2 ) );
        if ( t > 1 ) return Math.sqrt( Math.pow( p.x - w.x, 2 ) + Math.pow( p.y - w.y, 2 ) );
        return Math.sqrt(
            Math.pow( p.x - (v.x + t * (w.x - v.x)), 2 ) +
            Math.pow( p.y - (v.y + t * (w.y - v.y)), 2 ) );
    }

    applyBlemishRemoval()
    {
        if ( typeof this.displayImageWindow.mainView.id === 'string' )
        {
            this.undoStack.push( {
                imageId:         this.displayImageWindow.mainView.id,
                blemishPoints:   JSON.parse( JSON.stringify( this.blemishPoints ) ),
                satelliteTrails: JSON.parse( JSON.stringify( this.satelliteTrails ) ),
                freehandShapes:  JSON.parse( JSON.stringify( this.freehandShapes ) )
            } );
        }

        this.redoStack = [];
        this.executeCounter++;

        let tempImageWindow = new ImageWindow(
            this.displayImage.width,
            this.displayImage.height,
            this.displayImage.numberOfChannels,
            this.displayImage.bitsPerSample,
            this.displayImage.isReal,
            false,
            "TempImage"
        );

        tempImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
        tempImageWindow.mainView.image.assign( this.displayImage );
        tempImageWindow.mainView.endProcess();

        let image      = tempImageWindow.mainView.image;
        let numChannels = image.numberOfChannels;
        let selectedChannel = parameters.selectedChannel || 0;

        let channelsToProcess = [];
        if ( selectedChannel === 0 || numChannels === 1 )
            for ( let i = 0; i < numChannels; i++ ) channelsToProcess.push( i );
        else
            channelsToProcess = [selectedChannel - 1];

        // ---- Blemish / star correction ----
        if ( parameters.correctStar )
        {
            for ( let point of this.blemishPoints )
            {
                let x = point.x, y = point.y, radius = point.radius;
                let starCenter = starCentroid( x, y, radius, image );
                if ( !starCenter ) continue;

                let starX = starCenter.x, starY = starCenter.y;
                let starFWHM = 0.75 * starCenter.FWHM;
                let surroundingRadius = radius * Math.sqrt( 3 );
                let angle = Math.PI / 3;
                let dx = [], dy = [];
                for ( let i = 0; i < 6; i++ ) { dx.push( Math.cos( angle * i ) * surroundingRadius ); dy.push( Math.sin( angle * i ) * surroundingRadius ); }

                let circleMedians = {};
                let medianCalculator = new MedianCalculator();
                for ( let c of channelsToProcess ) circleMedians[c] = [];

                for ( let i = 0; i < 7; i++ )
                {
                    let sx = i === 0 ? starX : Math.round( starX + dx[i-1] );
                    let sy = i === 0 ? starY : Math.round( starY + dy[i-1] );

                    if ( sx >= 0 && sx < image.width && sy >= 0 && sy < image.height )
                    {
                        let circlePixels = {};
                        for ( let c of channelsToProcess ) circlePixels[c] = [];

                        for ( let dxC = -starFWHM; dxC <= starFWHM; dxC += 3 )
                            for ( let dyC = -starFWHM; dyC <= starFWHM; dyC += 3 )
                                if ( Math.sqrt( dxC*dxC + dyC*dyC ) <= starFWHM )
                                {
                                    let cx = sx + dxC, cy = sy + dyC;
                                    if ( cx >= 0 && cx < image.width && cy >= 0 && cy < image.height )
                                        for ( let c of channelsToProcess )
                                            circlePixels[c].push( image.sample( cx, cy, c ) );
                                }

                        for ( let c of channelsToProcess )
                            circleMedians[c].push( medianCalculator.calculate( circlePixels[c] ) );
                    }
                    else
                    {
                        for ( let c of channelsToProcess ) circleMedians[c].push( Number.POSITIVE_INFINITY );
                    }
                }

                let centerMedians = [];
                for ( let c of channelsToProcess ) centerMedians[c] = circleMedians[c][0];

                let closestCircles = [];
                for ( let i = 1; i < 7; i++ )
                    for ( let c of channelsToProcess )
                        closestCircles.push( { index: i, distance: Math.abs( circleMedians[c][i] - centerMedians[c] ) } );
                closestCircles.sort( (a, b) => a.distance - b.distance );
                let selectedCircles = closestCircles.slice( 0, 3 );

                let sampleValues = [];
                for ( let dxC = -surroundingRadius; dxC <= surroundingRadius; dxC++ )
                    for ( let dyC = -surroundingRadius; dyC <= surroundingRadius; dyC++ )
                    {
                        let distCenter = Math.sqrt( dxC*dxC + dyC*dyC );
                        if ( distCenter > 0 && distCenter <= radius )
                        {
                            let featherValue = this.parent.featherSlider.value;
                            let featherProfile = distCenter <= starFWHM
                                ? Math.pow( distCenter / starFWHM, 2 ) : 1;
                            let edgeFeatherFactor = distCenter <= radius/2 ? 1
                                : (distCenter <= radius ? 1 - (distCenter - radius/2) / (radius/2) : 0);
                            let combinedFeatherFactor = featherValue * featherProfile * edgeFeatherFactor;

                            let medianPixel = {};
                            for ( let c of channelsToProcess ) medianPixel[c] = [];
                            let validSurrounding = 0;

                            for ( let circle of selectedCircles )
                            {
                                let sx = Math.round( starX + dxC + dx[circle.index-1] );
                                let sy = Math.round( starY + dyC + dy[circle.index-1] );
                                if ( sx >= 0 && sx < image.width && sy >= 0 && sy < image.height )
                                {
                                    for ( let c of channelsToProcess )
                                    {
                                        let sv = image.sample( sx, sy, c );
                                        if ( sv <= 2 * centerMedians[c] ) medianPixel[c].push( sv );
                                    }
                                    validSurrounding++;
                                }
                            }

                            if ( validSurrounding > 0 )
                            {
                                for ( let c of channelsToProcess )
                                {
                                    medianPixel[c].sort( (a, b) => a - b );
                                    let n = medianPixel[c].length;
                                    medianPixel[c] = n % 2 === 0
                                        ? (medianPixel[c][n/2-1] + medianPixel[c][n/2]) / 2
                                        : medianPixel[c][Math.floor(n/2)];
                                }
                                let cx = Math.round( starX + dxC );
                                let cy = Math.round( starY + dyC );
                                if ( cx >= 0 && cx < image.width && cy >= 0 && cy < image.height )
                                    for ( let c of channelsToProcess )
                                    {
                                        let orig = image.sample( cx, cy, c );
                                        sampleValues.push( { cx: cx, cy: cy, c: c,
                                            newSample: combinedFeatherFactor * medianPixel[c] + (1 - combinedFeatherFactor) * orig } );
                                    }
                            }
                        }
                    }

                this._applySampleValuesBatched( tempImageWindow, image, sampleValues, 100 );
            }
        }
        else
        {
            for ( let point of this.blemishPoints )
            {
                let x = point.x, y = point.y, radius = point.radius;
                let centerRadius     = radius;
                let surroundingRadius = radius * Math.sqrt( 3 );
                let angle = Math.PI / 3;
                let dx = [], dy = [];
                for ( let i = 0; i < 6; i++ ) { dx.push( Math.cos( angle*i ) * surroundingRadius ); dy.push( Math.sin( angle*i ) * surroundingRadius ); }

                let circleMedians = {};
                let medianCalculator = new MedianCalculator();
                for ( let c of channelsToProcess ) circleMedians[c] = [];

                for ( let i = 0; i < 7; i++ )
                {
                    let sx = i === 0 ? x : Math.round( x + dx[i-1] );
                    let sy = i === 0 ? y : Math.round( y + dy[i-1] );

                    if ( sx >= 0 && sx < image.width && sy >= 0 && sy < image.height )
                    {
                        let circlePixels = {};
                        for ( let c of channelsToProcess ) circlePixels[c] = [];

                        for ( let dxC = -centerRadius; dxC <= centerRadius; dxC += 3 )
                            for ( let dyC = -centerRadius; dyC <= centerRadius; dyC += 3 )
                                if ( Math.sqrt( dxC*dxC + dyC*dyC ) <= centerRadius )
                                {
                                    let cx = sx + dxC, cy = sy + dyC;
                                    if ( cx >= 0 && cx < image.width && cy >= 0 && cy < image.height )
                                        for ( let c of channelsToProcess )
                                            circlePixels[c].push( image.sample( cx, cy, c ) );
                                }

                        for ( let c of channelsToProcess )
                            circleMedians[c].push( medianCalculator.calculate( circlePixels[c] ) );
                    }
                    else
                    {
                        for ( let c of channelsToProcess ) circleMedians[c].push( Number.POSITIVE_INFINITY );
                    }
                }

                let centerMedians = [];
                for ( let c of channelsToProcess ) centerMedians[c] = circleMedians[c][0];

                let closestCircles = [];
                for ( let i = 1; i < 7; i++ )
                    for ( let c of channelsToProcess )
                        closestCircles.push( { index: i, distance: Math.abs( circleMedians[c][i] - centerMedians[c] ) } );
                closestCircles.sort( (a, b) => a.distance - b.distance );
                let selectedCircles = closestCircles.slice( 0, 3 );

                let sampleValues = [];
                for ( let dxC = -centerRadius; dxC <= centerRadius; dxC++ )
                    for ( let dyC = -centerRadius; dyC <= centerRadius; dyC++ )
                        if ( Math.sqrt( dxC*dxC + dyC*dyC ) <= centerRadius )
                        {
                            let featherValue  = this.parent.featherSlider.value;
                            let opacityValue  = this.parent.opacitySlider.value;
                            let distCenter    = Math.sqrt( dxC*dxC + dyC*dyC );
                            let featherFactor = featherValue === 0 ? 1
                                : Math.min( 1, (1/featherValue) * (centerRadius - distCenter) / centerRadius );

                            let medianPixel = {};
                            for ( let c of channelsToProcess ) medianPixel[c] = [];
                            let validSurrounding = 0;

                            for ( let circle of selectedCircles )
                            {
                                let sx = Math.round( x + dxC + dx[circle.index-1] );
                                let sy = Math.round( y + dyC + dy[circle.index-1] );
                                if ( sx >= 0 && sx < image.width && sy >= 0 && sy < image.height )
                                {
                                    for ( let c of channelsToProcess )
                                        medianPixel[c].push( image.sample( sx, sy, c ) );
                                    validSurrounding++;
                                }
                            }

                            if ( validSurrounding > 0 )
                            {
                                for ( let c of channelsToProcess )
                                {
                                    medianPixel[c].sort( (a, b) => a - b );
                                    let n = medianPixel[c].length;
                                    medianPixel[c] = n % 2 === 0
                                        ? (medianPixel[c][n/2-1] + medianPixel[c][n/2]) / 2
                                        : medianPixel[c][Math.floor(n/2)];
                                }
                                let cx = Math.round( x + dxC );
                                let cy = Math.round( y + dyC );
                                if ( cx >= 0 && cx < image.width && cy >= 0 && cy < image.height )
                                    for ( let c of channelsToProcess )
                                    {
                                        let orig = image.sample( cx, cy, c );
                                        sampleValues.push( { cx: cx, cy: cy, c: c,
                                            newSample: opacityValue * (featherFactor * medianPixel[c] + (1-featherFactor) * orig) + (1-opacityValue) * orig } );
                                    }
                            }
                        }

                this._applySampleValuesBatched( tempImageWindow, image, sampleValues, 100 );
            }
        }

        // ---- Freehand shapes ----
        for ( let shape of this.freehandShapes )
        {
            let { centerX, centerY, radius } = calculateFreehandCenterAndRadius( shape );
            let centerRadius      = radius;
            let surroundingRadius = radius * Math.sqrt( 3 );
            let angle = Math.PI / 3;
            let dx = [], dy = [];
            for ( let i = 0; i < 6; i++ ) { dx.push( Math.cos( angle*i ) * surroundingRadius ); dy.push( Math.sin( angle*i ) * surroundingRadius ); }

            let circleMedians = {};
            let medianCalculator = new MedianCalculator();
            for ( let c of channelsToProcess ) circleMedians[c] = [];

            for ( let i = 0; i < 7; i++ )
            {
                let sx = i === 0 ? centerX : Math.round( centerX + dx[i-1] );
                let sy = i === 0 ? centerY : Math.round( centerY + dy[i-1] );

                if ( sx >= 0 && sx < image.width && sy >= 0 && sy < image.height )
                {
                    let circlePixels = {};
                    for ( let c of channelsToProcess ) circlePixels[c] = [];

                    for ( let dxC = -centerRadius; dxC <= centerRadius; dxC++ )
                        for ( let dyC = -centerRadius; dyC <= centerRadius; dyC++ )
                            if ( Math.sqrt( dxC*dxC + dyC*dyC ) <= centerRadius )
                            {
                                let cx = sx + dxC, cy = sy + dyC;
                                if ( cx >= 0 && cx < image.width && cy >= 0 && cy < image.height )
                                    for ( let c of channelsToProcess )
                                        circlePixels[c].push( image.sample( cx, cy, c ) );
                            }

                    for ( let c of channelsToProcess )
                        circleMedians[c].push( medianCalculator.calculate( circlePixels[c] ) );
                }
                else
                {
                    for ( let c of channelsToProcess ) circleMedians[c].push( Number.POSITIVE_INFINITY );
                }
            }

            let centerMedians = [];
            for ( let c of channelsToProcess ) centerMedians[c] = circleMedians[c][0];

            let closestCircles = [];
            for ( let i = 1; i < 7; i++ )
                for ( let c of channelsToProcess )
                    closestCircles.push( { index: i, distance: Math.abs( circleMedians[c][i] - centerMedians[c] ) } );
            closestCircles.sort( (a, b) => a.distance - b.distance );
            let selectedCircles = closestCircles.slice( 0, 3 );

            let sampleValues = [];
            let featherValue = this.parent.featherSlider.value;
            let opacityValue = this.parent.opacitySlider.value;

            for ( let dxC = -centerRadius; dxC <= centerRadius; dxC++ )
                for ( let dyC = -centerRadius; dyC <= centerRadius; dyC++ )
                {
                    let cx = Math.round( centerX + dxC );
                    let cy = Math.round( centerY + dyC );
                    if ( isPointInShape( cx, cy, shape ) && cx >= 0 && cx < image.width && cy >= 0 && cy < image.height )
                    {
                        let minDist      = getMinDistanceToEdge( cx, cy, shape );
                        let featherFactor = featherValue === 0 ? 1 : Math.min( 1, (1/featherValue) * minDist / centerRadius );

                        let medianPixel = {};
                        for ( let c of channelsToProcess ) medianPixel[c] = [];
                        let validSurrounding = 0;

                        for ( let circle of selectedCircles )
                        {
                            let sx = Math.round( cx + dx[circle.index-1] );
                            let sy = Math.round( cy + dy[circle.index-1] );
                            if ( sx >= 0 && sx < image.width && sy >= 0 && sy < image.height )
                            {
                                for ( let c of channelsToProcess )
                                    medianPixel[c].push( image.sample( sx, sy, c ) );
                                validSurrounding++;
                            }
                        }

                        if ( validSurrounding > 0 )
                        {
                            for ( let c of channelsToProcess )
                            {
                                medianPixel[c].sort( (a, b) => a - b );
                                let n = medianPixel[c].length;
                                medianPixel[c] = n % 2 === 0
                                    ? (medianPixel[c][n/2-1] + medianPixel[c][n/2]) / 2
                                    : medianPixel[c][Math.floor(n/2)];
                            }
                            for ( let c of channelsToProcess )
                            {
                                let orig = image.sample( cx, cy, c );
                                sampleValues.push( { cx: cx, cy: cy, c: c,
                                    newSample: opacityValue * (featherFactor * medianPixel[c] + (1-featherFactor) * orig) + (1-opacityValue) * orig } );
                            }
                        }
                    }
                }

            this._applySampleValuesBatched( tempImageWindow, image, sampleValues, 100 );
        }

        // ---- Satellite trails (2 passes) ----
        for ( let iteration = 0; iteration < 2; iteration++ )
        {
            for ( let trail of this.satelliteTrails )
            {
                let startX = trail.start.x, startY = trail.start.y;
                let endX   = trail.end.x,   endY   = trail.end.y;
                let dx = endX - startX, dy = endY - startY;
                let length = Math.sqrt( dx*dx + dy*dy );
                let stepX = length === 0 ? 0 : dx / length;
                let stepY = length === 0 ? 0 : dy / length;
                let satelliteSize    = this.parent.satelliteSizeSlider.value;
                let perpendicularLength = 2 * satelliteSize * iteration;

                let sampleValues = [];
                for ( let i = 0; i <= length; i++ )
                {
                    let currentX = startX + i * stepX;
                    let currentY = startY + i * stepY;

                    let upperUpperX = currentX - 2 * perpendicularLength * stepY;
                    let upperUpperY = currentY + 2 * perpendicularLength * stepX;
                    let upperX      = currentX -     perpendicularLength * stepY;
                    let upperY      = currentY +     perpendicularLength * stepX;
                    let lowerX      = currentX +     perpendicularLength * stepY;
                    let lowerY      = currentY -     perpendicularLength * stepX;
                    let lowerLowerX = currentX + 2 * perpendicularLength * stepY;
                    let lowerLowerY = currentY - 2 * perpendicularLength * stepX;

                    let half = Math.floor( satelliteSize / 2 );
                    for ( let dxS = -half; dxS <= half; dxS++ )
                        for ( let dyS = -half; dyS <= half; dyS++ )
                        {
                            let mx = Math.round( currentX + dxS );
                            let my = Math.round( currentY + dyS );
                            if ( mx >= 0 && mx < image.width && my >= 0 && my < image.height )
                            {
                                let uux = Math.round( upperUpperX + dxS ), uuy = Math.round( upperUpperY + dyS );
                                let ux  = Math.round( upperX      + dxS ), uy  = Math.round( upperY      + dyS );
                                let lx  = Math.round( lowerX      + dxS ), ly  = Math.round( lowerY      + dyS );
                                let llx = Math.round( lowerLowerX + dxS ), lly = Math.round( lowerLowerY + dyS );

                                let collect = (px, py) =>
                                {
                                    let row = [];
                                    if ( px >= 0 && px < image.width && py >= 0 && py < image.height )
                                        for ( let c = 0; c < numChannels; c++ ) row.push( image.sample( px, py, c ) );
                                    return row;
                                };

                                let uuPx = collect( uux, uuy );
                                let uPx  = collect( ux,  uy  );
                                let mPx  = []; for ( let c = 0; c < numChannels; c++ ) mPx.push( image.sample( mx, my, c ) );
                                let lPx  = collect( lx,  ly  );
                                let llPx = collect( llx, lly );

                                let mc = new MedianCalculator();
                                for ( let c = 0; c < numChannels; c++ )
                                {
                                    let combined = [];
                                    if ( uuPx[c] !== undefined ) combined.push( uuPx[c] );
                                    if ( uPx[c]  !== undefined ) combined.push( uPx[c] );
                                    combined.push( mPx[c] );
                                    if ( lPx[c]  !== undefined ) combined.push( lPx[c] );
                                    if ( llPx[c] !== undefined ) combined.push( llPx[c] );
                                    let v = mc.calculate( combined );
                                    if ( isFinite( v ) ) sampleValues.push( { mx: mx, my: my, c: c, value: v } );
                                }
                            }
                        }
                }

                let batchSize = 50;
                for ( let i = 0; i < sampleValues.length; i += batchSize )
                {
                    tempImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
                    for ( let j = i; j < i + batchSize && j < sampleValues.length; j++ )
                    {
                        let s = sampleValues[j];
                        try { image.setSample( s.value, s.mx, s.my, s.c ); } catch (e) {}
                    }
                    try { tempImageWindow.mainView.endProcess(); } catch (e) {}
                }
            }
        }

        // Push to temp stack if not the main image
        if ( typeof tempImageWindow.mainView.id === 'string' &&
             tempImageWindow.mainView.id !== parameters.targetWindow.mainView.id )
            this.tempImageStack.push( tempImageWindow.mainView.id );

        console.noteln( "Ready for more blemish removal." );

        this.displayImage       = tempImageWindow.mainView.image;
        this.displayImageWindow = tempImageWindow;
        this.doUpdateImage( this.displayImage );

        this.blemishPoints   = [];
        this.satelliteTrails = [];
        this.freehandShapes  = [];
        this.refreshPreview();
    }

    // Internal helper: apply sample value batches to a temp window
    _applySampleValuesBatched( tempImageWindow, image, sampleValues, batchSize )
    {
        for ( let i = 0; i < sampleValues.length; i += batchSize )
        {
            tempImageWindow.mainView.beginProcess( UndoFlag.NoSwapFile );
            for ( let j = i; j < i + batchSize && j < sampleValues.length; j++ )
            {
                let s = sampleValues[j];
                try { image.setSample( s.newSample, s.cx, s.cy, s.c ); } catch (e) {}
            }
            try { tempImageWindow.mainView.endProcess(); } catch (e) {}
        }
    }

    undoLastBlemishRemoval()
    {
        if ( this.undoStack.length > 0 )
        {
            let lastState = this.undoStack.pop();
            this.redoStack.push( {
                imageId:         this.displayImageWindow.mainView.id,
                blemishPoints:   this.blemishPoints,
                satelliteTrails: this.satelliteTrails,
                freehandShapes:  this.freehandShapes
            } );

            let window = ImageWindow.windowById( lastState.imageId );
            if ( window && !window.isNull )
            {
                this.displayImage       = window.mainView.image;
                this.displayImageWindow = window;
                this.blemishPoints      = lastState.blemishPoints   || [];
                this.satelliteTrails    = lastState.satelliteTrails  || [];
                this.freehandShapes     = lastState.freehandShapes   || [];
                this.doUpdateImage( this.displayImage );
                this.refreshPreview();
                console.writeln( "Last blemish removal undone." );
            }
            else
            {
                console.writeln( "Image window not found or already closed: " + lastState.imageId );
            }
        }
        else
        {
            console.writeln( "No blemish removals to undo." );
        }
    }

    applyChangesToMainImage()
    {
        if ( parameters.autoSTFApplied )
        {
            let originalMedian = parameters.originalMedian;
            let originalMin    = parameters.originalMin;

            let pixelMath1 = new PixelMath;
            if ( parameters.targetWindow.mainView.image.numberOfChannels === 1 )
                pixelMath1.expression =
                    "((Med($T)-1)*" + originalMedian + "*$T)/(Med($T)*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
            else
            {
                pixelMath1.expression =
                    "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                    "((MedianColor-1)*" + originalMedian + "*$T)/(MedianColor*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
                pixelMath1.symbols = "L, MedianColor, S";
            }
            pixelMath1.useSingleExpression = true;
            configurePixelMath( pixelMath1 );
            pixelMath1.use64BitWorkingImage = true;
            pixelMath1.executeOn( this.displayImageWindow.mainView );

            let pixelMath2 = new PixelMath;
            if ( parameters.targetWindow.mainView.image.numberOfChannels === 1 )
                pixelMath2.expression = "($T*(1-" + originalMin + ")+" + originalMin + ")";
            else
            {
                pixelMath2.expression =
                    "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                    "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                    "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                    "BlackPoint = MinColor;\n" +
                    "($T*(1-" + (0.87*originalMin) + ")+" + (0.87*originalMin) + ")";
                pixelMath2.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
            }
            pixelMath2.useSingleExpression = true;
            configurePixelMath( pixelMath2 );
            pixelMath2.use64BitWorkingImage = true;
            pixelMath2.executeOn( this.displayImageWindow.mainView );

            let pixelMath3 = new PixelMath;
            pixelMath3.expression = this.displayImageWindow.mainView.id;
            pixelMath3.useSingleExpression = true;
            configurePixelMath( pixelMath3 );
            pixelMath3.executeOn( parameters.targetWindow.mainView );

            if ( parameters.targetWindow )
            {
                let tmpImage = this.parent.createAndDisplayTemporaryImage(
                    parameters.targetWindow.mainView.image, true );
                this.displayImage       = tmpImage;
                this.displayImageWindow = parameters.targetWindow;
                this.initScrollBars();
                this.viewport.update();
                parameters.autoSTFApplied = true;
            }
        }
        else
        {
            let pixelMath = new PixelMath;
            pixelMath.expression = this.displayImageWindow.mainView.id;
            pixelMath.useSingleExpression = true;
            configurePixelMath( pixelMath );
            pixelMath.executeOn( parameters.targetWindow.mainView );
        }

        console.noteln( "Blemish Removal on Main Image Complete!\nReady to remove more blemishes!" );
    }

    refreshPreview() { this.viewport.update(); }
};

// ============================================================================
// MiniViewport
// ============================================================================

var MiniViewport = class extends Control
{
    constructor( parent )
    {
        super( parent );

        this.feather = 0.5;
        this.opacity = 1.0;

        this.setFixedSize( 100, 100 );

        this.onPaint = ( x0, y0, x1, y1 ) =>
        {
            let g = new Graphics( this );
            g.fillRect( 0, 0, this.width, this.height, new Brush( 0xff000000 ) );

            let centerX = this.width  / 2;
            let centerY = this.height / 2;
            let radius  = 25;

            for ( let y = 0; y < this.height; y++ )
                for ( let x = 0; x < this.width; x++ )
                {
                    let distance = Math.sqrt( (x-centerX)*(x-centerX) + (y-centerY)*(y-centerY) );
                    if ( distance <= radius )
                    {
                        let featherFactor = this.feather === 0 ? 1
                            : Math.min( 1, (1/this.feather) * (radius - distance) / radius );
                        let alpha    = Math.floor( this.opacity * 255 * featherFactor );
                        let alphaHex = alpha.toString(16).padStart( 2, '0' );
                        let color    = parseInt( '0x' + alphaHex + 'ffffff', 16 );
                        g.pen = new Pen( color );
                        g.drawPoint( x, y );
                    }
                }

            g.end();
        };
    }

    updatePreview( feather, opacity )
    {
        this.feather = feather === 0 ? 1 : feather;
        this.opacity = opacity;
        this.update();
    }
};

// ============================================================================
// BlemishEraserDialog
// ============================================================================

var BlemishEraserDialog = class extends Dialog
{
    constructor()
    {
        super();

        let selectedImages = [];

        // ---- Title ----
        this.title_Lbl = new Label( this );
        this.title_Lbl.frameStyle   = FrameStyle.Box;
        this.title_Lbl.margin       = 6;
        this.title_Lbl.useRichText  = true;
        this.title_Lbl.text         = "<b>" + TITLE + " " + VERSION + "</b>";
        this.title_Lbl.textAlignment = TextAlignment.Center;

        // ---- Instructions ----
        this.instructionBox = new Label( this );
        this.instructionBox.frameStyle  = FrameStyle.Box;
        this.instructionBox.margin      = 6;
        this.instructionBox.useRichText = true;
        this.instructionBox.text =
            "<b>Instructions:</b><br>" +
            "1. Select the image.<br>" +
            "2. Use AutoSTF if needed.<br>" +
            "3. Shift-click and drag to draw a circle or freehand.<br>" +
            "3a. CTRL-click and drag to define Satellite Trail Removal Line.<br>" +
            "3b. Alt-click to auto find the Satellite Trail Removal Line<br>" +
            "4. Right-click to remove a point.<br>" +
            ".....Multiple Areas Allowed!<br>" +
            "5. Click Execute to apply blemish removal.<br>" +
            "6. Click Apply to Main Image to save changes.";
        this.instructionBox.textAlignment = TextAlignment.Left;

        // ---- Image selection ----
        let currentWindowName = ImageWindow.activeWindow.mainView.id;

        this.imageLabel = new Label( this );
        this.imageLabel.text = "Select Image:";
        this.imageLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.windowSelector_Cb = new ComboBox( this );
        this.windowSelector_Cb.toolTip = "Select the window you want to use.";

        for ( let i = 0; i < ImageWindow.windows.length; i++ )
        {
            this.windowSelector_Cb.addItem( ImageWindow.windows[i].mainView.id );
            if ( ImageWindow.windows[i].mainView.id === currentWindowName )
            {
                this.windowSelector_Cb.currentItem = i;
                let win = ImageWindow.windowById( currentWindowName );
                if ( win && !win.isNull )
                    parameters.targetWindow = win;
            }
        }

        this.windowSelector_Cb.onItemSelected = index =>
        {
            if ( index >= 0 )
            {
                let win = ImageWindow.windowById( this.windowSelector_Cb.itemText( index ) );
                if ( win && !win.isNull )
                {
                    parameters.targetWindow = win;
                    let selectedImage = win.mainView.image;
                    if ( selectedImage )
                    {
                        if ( !isImageInSelectedList( win.mainView.id ) )
                            selectedImages.push( win.mainView.id );

                        let tmpImage = this.createAndDisplayTemporaryImage( selectedImage );
                        this.previewControl.displayImage       = tmpImage;
                        this.previewControl.displayImageWindow = win;
                        this.previewControl.initScrollBars();
                        this.previewControl.viewport.update();
                    }
                }
            }
        };

        this.imageSelectionSizer = new HorizontalSizer;
        this.imageSelectionSizer.spacing = 4;
        this.imageSelectionSizer.add( this.imageLabel );
        this.imageSelectionSizer.add( this.windowSelector_Cb, 1 );

        // ---- AutoSTF button ----
        this.autoSTFButton = new PushButton( this );
        this.autoSTFButton.text    = "AutoSTF";
        this.autoSTFButton.toolTip = "Apply AutoSTF to the preview image.";
        this.autoSTFButton.icon    = ":/icons/burn.png";
        this.autoSTFButton.onClick = () =>
        {
            if ( parameters.targetWindow )
            {
                let selectedImage = parameters.targetWindow.mainView.image;
                if ( selectedImage )
                {
                    let tmpImage = this.createAndDisplayTemporaryImage( selectedImage, true );
                    this.previewControl.displayImage       = tmpImage;
                    this.previewControl.displayImageWindow = parameters.targetWindow;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                    parameters.autoSTFApplied = true;
                }
            }
            this.previewControl.applyBlemishRemoval();
        };

        // ---- Drawing mode checkboxes ----
        this.drawingModeSizer = new HorizontalSizer;
        this.drawingModeSizer.spacing = 4;

        this.circleCheckbox = new CheckBox( this );
        this.circleCheckbox.text    = "Circle";
        this.circleCheckbox.checked = (parameters.drawingMode === "Circle");
        this.circleCheckbox.onCheck = checked =>
        {
            if ( checked )
            {
                parameters.drawingMode   = "Circle";
                parameters.correctStar   = false;
                this.freehandCheckbox.checked       = false;
                this.correctStarCheckbox.checked    = false;
            }
        };
        this.drawingModeSizer.add( this.circleCheckbox );

        this.freehandCheckbox = new CheckBox( this );
        this.freehandCheckbox.text    = "Freehand";
        this.freehandCheckbox.checked = (parameters.drawingMode === "Freehand");
        this.freehandCheckbox.onCheck = checked =>
        {
            if ( checked )
            {
                parameters.drawingMode   = "Freehand";
                parameters.correctStar   = false;
                this.circleCheckbox.checked      = false;
                this.correctStarCheckbox.checked = false;
            }
        };
        this.drawingModeSizer.add( this.freehandCheckbox );

        this.correctStarCheckbox = new CheckBox( this );
        this.correctStarCheckbox.text    = "Correct Star (Experimental!)";
        this.correctStarCheckbox.checked = parameters.correctStar || false;
        this.correctStarCheckbox.onCheck = checked =>
        {
            parameters.correctStar = checked;
            if ( checked )
            {
                this.circleCheckbox.checked   = false;
                this.freehandCheckbox.checked = false;
            }
        };
        this.drawingModeSizer.add( this.correctStarCheckbox );

        // ---- Feather / Opacity sliders ----
        this.featherSlider = new NumericControl( this );
        this.featherSlider.label.text = "Feather:";
        this.featherSlider.setRange( 0.01, 1 );
        this.featherSlider.setPrecision( 2 );
        this.featherSlider.slider.setRange( 0, 100 );
        this.featherSlider.setValue( 0.5 );
        this.featherSlider.onValueUpdated = value =>
        {
            this.miniViewport.updatePreview( value, this.opacitySlider.value );
        };

        this.opacitySlider = new NumericControl( this );
        this.opacitySlider.label.text = "Opacity:";
        this.opacitySlider.setRange( 0, 1 );
        this.opacitySlider.setPrecision( 2 );
        this.opacitySlider.slider.setRange( 0, 100 );
        this.opacitySlider.setValue( 1 );
        this.opacitySlider.onValueUpdated = value =>
        {
            this.miniViewport.updatePreview( this.featherSlider.value, value );
        };

        // ---- Channel dropdown ----
        this.channelDropdownLabel = new Label( this );
        this.channelDropdownLabel.text = "Perform Blemish Blaster On:";
        this.channelDropdownLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.channelDropdown = new ComboBox( this );
        this.channelDropdown.addItem( "All Channels" );
        this.channelDropdown.addItem( "Red" );
        this.channelDropdown.addItem( "Green" );
        this.channelDropdown.addItem( "Blue" );
        this.channelDropdown.currentItem = 0;
        this.channelDropdown.onItemSelected = index =>
        {
            parameters.selectedChannel = index;
        };

        this.channelDropdownSizer = new HorizontalSizer;
        this.channelDropdownSizer.spacing = 6;
        this.channelDropdownSizer.add( this.channelDropdownLabel );
        this.channelDropdownSizer.add( this.channelDropdown );
        this.channelDropdownSizer.addStretch();

        // ---- Execute / Undo / Apply buttons ----
        this.executeButton = new PushButton( this );
        this.executeButton.text    = "Execute";
        this.executeButton.toolTip = "Apply blemish removal to all marked points.";
        this.executeButton.icon    = ":/icons/ok.png";
        this.executeButton.onClick = () => { this.previewControl.applyBlemishRemoval(); };

        this.undoButton = new PushButton( this );
        this.undoButton.text    = "Undo";
        this.undoButton.toolTip = "Undo the last blemish removal.";
        this.undoButton.icon    = ":/icons/undo.png";
        this.undoButton.onClick = () => { this.previewControl.undoLastBlemishRemoval(); };

        this.applyButton = new PushButton( this );
        this.applyButton.text    = "Apply to Main Image";
        this.applyButton.toolTip = "Apply the changes to the main image.";
        this.applyButton.icon    = ":/icons/execute.png";
        this.applyButton.onClick = () => { this.previewControl.applyChangesToMainImage(); };

        // ---- Labels ----
        this.authorshipLabel = new Label( this );
        this.authorshipLabel.text =
            "<p style='text-align:center;'>Written by Franklin Marek 2026.<br>" +
            "<a href='http://www.setiastro.com'>www.setiastro.com</a></p>";
        this.authorshipLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.authorshipLabel.useRichText   = true;

        this.blemishLabel = new Label( this );
        this.blemishLabel.text = "<p style='text-align:center;'>Blemish Area Options</p>";
        this.blemishLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.blemishLabel.useRichText   = true;

        this.satelliteLabel = new Label( this );
        this.satelliteLabel.text = "<p style='text-align:center;'>Satellite Trail Options</p>";
        this.satelliteLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
        this.satelliteLabel.useRichText   = true;

        // ---- Satellite size slider ----
        this.satelliteSizeSlider = new NumericControl( this );
        this.satelliteSizeSlider.label.text = "Satellite Trail Width:";
        this.satelliteSizeSlider.setRange( 1, 20 );
        this.satelliteSizeSlider.setPrecision( 0 );
        this.satelliteSizeSlider.slider.setScaledMinWidth( 250 );
        this.satelliteSizeSlider.setValue( 5 );

        // ---- New Instance / Exit buttons ----
        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "New Instance";
        this.newInstanceButton.onMousePress = () => { this.newInstance(); };

        this.exitButton = new PushButton( this );
        this.exitButton.text    = "Exit";
        this.exitButton.icon    = ":/toolbar/file-exit.png";
        this.exitButton.toolTip = "Close the dialog and clean up.";
        this.exitButton.onClick = () =>
        {
            let msg = new MessageBox(
                "Are you sure you want to exit? All temporary images will be closed.",
                "Confirm Exit", StdIcon.Question, StdButton.Yes, StdButton.No );
            if ( msg.execute() === StdButton.Yes )
                this.cleanupAndClose();
        };

        // ---- MiniViewport ----
        this.miniViewport = new MiniViewport( this );

        let miniViewportSizer = new HorizontalSizer;
        miniViewportSizer.spacing = 6;
        miniViewportSizer.addStretch();
        miniViewportSizer.add( this.miniViewport );
        miniViewportSizer.addStretch();

        // ---- Preview control ----
        this.previewControl = new ScrollControl( this );
        this.previewControl.setMinWidth(  900 );
        this.previewControl.setMinHeight( 700 );

        // ---- Zoom buttons ----
        this.zoomInButton = new PushButton( this );
        this.zoomInButton.text    = "";
        this.zoomInButton.icon    = this.scaledResource( ":/icons/zoom-in.png" );
        this.zoomInButton.toolTip = "Zoom In";
        this.zoomInButton.onClick = () => { this.previewControl.zoomIn(); };

        this.zoomOutButton = new PushButton( this );
        this.zoomOutButton.text    = "";
        this.zoomOutButton.icon    = this.scaledResource( ":/icons/zoom-out.png" );
        this.zoomOutButton.toolTip = "Zoom Out";
        this.zoomOutButton.onClick = () => { this.previewControl.zoomOut(); };

        this.zoomLabel = new Label( this );
        this.zoomLabel.text = "Buttons to Zoom In/Out or Use Mouse Wheel";

        this.zoomSizer = new HorizontalSizer;
        this.zoomSizer.spacing = 6;
        this.zoomSizer.add( this.zoomInButton );
        this.zoomSizer.add( this.zoomOutButton );
        this.zoomSizer.add( this.zoomLabel );
        this.zoomSizer.addStretch();

        // ---- Left panel ----
        let leftPanel = new VerticalSizer;
        leftPanel.spacing = 6;
        leftPanel.margin  = 6;
        leftPanel.add( this.title_Lbl );
        leftPanel.add( this.instructionBox );
        leftPanel.add( this.imageSelectionSizer );
        leftPanel.add( this.autoSTFButton );
        leftPanel.addStretch();
        leftPanel.add( this.blemishLabel );
        leftPanel.add( this.drawingModeSizer );
        leftPanel.add( this.featherSlider );
        leftPanel.add( this.opacitySlider );
        leftPanel.add( this.channelDropdownSizer );

        let executeUndoSizer = new HorizontalSizer;
        executeUndoSizer.spacing = 6;
        executeUndoSizer.add( this.executeButton );
        executeUndoSizer.add( this.undoButton );

        leftPanel.add( miniViewportSizer );
        leftPanel.addStretch();
        leftPanel.add( this.satelliteLabel );
        leftPanel.add( this.satelliteSizeSlider );
        leftPanel.addStretch();
        leftPanel.add( executeUndoSizer );
        leftPanel.add( this.applyButton );
        leftPanel.add( this.authorshipLabel );

        let instanceExitSizer = new HorizontalSizer;
        instanceExitSizer.spacing = 6;
        instanceExitSizer.add( this.newInstanceButton );
        instanceExitSizer.add( this.exitButton );
        leftPanel.add( instanceExitSizer );

        // ---- Right panel ----
        let rightPanel = new VerticalSizer;
        rightPanel.spacing = 6;
        rightPanel.margin  = 6;
        rightPanel.add( this.zoomSizer );
        rightPanel.add( this.previewControl, 1 );

        // ---- Main sizer ----
        let mainSizer = new HorizontalSizer;
        mainSizer.spacing = 6;
        mainSizer.margin  = 6;
        mainSizer.add( leftPanel );
        mainSizer.add( rightPanel, 1 );

        this.sizer = mainSizer;
        this.adjustToContents();
        this.windowTitle = TITLE;

        // ---- Helper: is image in selected list ----
        function isImageInSelectedList( imageId )
        {
            for ( let i = 0; i < selectedImages.length; i++ )
                if ( selectedImages[i] === imageId ) return true;
            return false;
        }

        // ---- onShow ----
        this.onShow = () =>
        {
            let activeWindow = ImageWindow.activeWindow;

            if ( this.windowSelector_Cb.currentItem >= 0 )
            {
                let win = ImageWindow.windowById(
                    this.windowSelector_Cb.itemText( this.windowSelector_Cb.currentItem ) );

                if ( !isImageInSelectedList( activeWindow.mainView.id ) )
                    selectedImages.push( activeWindow.mainView.id );

                if ( win && !win.isNull )
                {
                    let selectedImage = win.mainView.image;
                    if ( selectedImage )
                    {
                        let tmpImage = this.createAndDisplayTemporaryImage( selectedImage );
                        this.previewControl.displayImage       = tmpImage;
                        this.previewControl.displayImageWindow = win;
                        this.previewControl.initScrollBars();
                        this.previewControl.viewport.update();
                    }
                }
            }
            else
            {
                if ( !isImageInSelectedList( activeWindow.mainView.id ) )
                    selectedImages.push( activeWindow.mainView.id );
            }
        };

        // ---- onClose ----
        this.onClose = () =>
        {
            parameters.save();
            this.cleanupAndClose();
        };

        // ---- cleanupAndClose (stored for exit button access) ----
        this.cleanupAndClose = () =>
        {
            while ( this.previewControl.undoStack.length > 0 )
            {
                let imageId = this.previewControl.undoStack.pop().imageId;
                if ( !isImageInSelectedList( imageId ) )
                {
                    let win = ImageWindow.windowById( imageId );
                    if ( win && !win.isNull ) win.forceClose();
                }
            }

            while ( this.previewControl.tempImageStack.length > 0 )
            {
                let imageId = this.previewControl.tempImageStack.pop();
                if ( typeof imageId === 'string' && !isImageInSelectedList( imageId ) )
                {
                    let win = ImageWindow.windowById( imageId );
                    if ( win && !win.isNull ) win.forceClose();
                }
            }

            console.writeln( "Cleanup complete. Closing dialog." );
            this.cancel();
        };
    }

    createAndDisplayTemporaryImage( selectedImage, applyAutoSTF )
    {
        let window = new ImageWindow(
            selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        window.mainView.beginProcess( UndoFlag.NoSwapFile );
        window.mainView.image.assign( selectedImage );
        window.mainView.endProcess();

        if ( applyAutoSTF )
        {
            let imageMin = window.mainView.image.minimum();
            parameters.originalMin = imageMin;

            let pixelMath1 = new PixelMath;
            if ( selectedImage.numberOfChannels === 1 )
                pixelMath1.expression = "($T-min($T))/(1-min($T))";
            else
            {
                pixelMath1.expression =
                    "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                    "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                    "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                    "BlackPoint = MinColor;\n" +
                    "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
                pixelMath1.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
            }
            pixelMath1.useSingleExpression = true;
            pixelMath1.executeOn( window.mainView );

            let imageMedian = window.mainView.image.median();
            parameters.originalMedian = imageMedian;
            let targetMedian = 0.25;

            let pixelMath2 = new PixelMath;
            if ( selectedImage.numberOfChannels === 1 )
                pixelMath2.expression = "((Med($T)-1)*0.25*$T)/(Med($T)*(0.25+$T-1)-0.25*$T)";
            else
            {
                pixelMath2.expression =
                    "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                    "((MedianColor-1)*" + targetMedian + "*$T)/(MedianColor*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
                pixelMath2.symbols = "L, MedianColor, S";
            }
            pixelMath2.useSingleExpression = true;
            pixelMath2.executeOn( window.mainView );
        }

        let resizedImage = new Image( window.mainView.image );

        if ( resizedImage.width > 0 && resizedImage.height > 0 )
        {
            this.previewControl.displayImage       = resizedImage;
            this.previewControl.displayImageWindow = window;
            this.previewControl.doUpdateImage( resizedImage );
            this.previewControl.initScrollBars();
        }
        else
        {
            console.writeln( "Resized image has invalid dimensions." );
        }

        window.forceClose();
        return resizedImage;
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( "   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ " );
    console.warningln(  " _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         " );
    let dialog = new BlemishEraserDialog();
    dialog.execute();
}

main();
