#engine v8

#feature-id BlindSolver : SetiAstro > Blind Solver 2000
#feature-icon  blindsolver2000.svg
#feature-info This script allows users to query the astrometrynet client to perform a blind astrometric solve then optionally run Image Solver

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Blind Solver 2000
 * Version: V3
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows users to query the astrometrynet client to perform a
 * blind astrometric solve then optionally run Image Solver
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#define VERSION     "V3"
#define TITLE       "Blind Solver 2000"
#define DESCRIPTION "A script to upload an image to astrometry.net for blind plate-solving."

// ============================================================================
// Platform helpers
// ============================================================================

function getCmdExec()
{
    let p = CoreApplication.platform;
    if ( p === "MSWINDOWS" || p === "Windows" )
        return "cmd.exe";
    return "/bin/sh";
}

function getScriptExt()
{
    let p = CoreApplication.platform;
    if ( p === "MSWINDOWS" || p === "Windows" )
        return ".bat";
    return ".sh";
}

function isWindows()
{
    let p = CoreApplication.platform;
    return p === "MSWINDOWS" || p === "Windows";
}

function isMac()
{
    let p = CoreApplication.platform;
    return p === "MACOSX" || p === "macOS";
}

function isLinux()
{
    return CoreApplication.platform === "Linux";
}

// ============================================================================
// Dialog
// ============================================================================

var BlindImageSolverDialog = class extends Dialog
{
    constructor()
    {
        super();

        console.hide();

        // ---- Persistent settings helpers ----
        this._loadApiKey  = () => String( Settings.read( "blindsolve/astrometryApiKey", DataType.String ) || "" );
        this._saveApiKey  = key  => Settings.write( "blindsolve/astrometryApiKey", DataType.String, key );
        this._loadAstapPath = () => String( Settings.read( "blindsolve/astapPath", DataType.String ) || "" );
        this._saveAstapPath = path => Settings.write( "blindsolve/astapPath", DataType.String, path );

        let savedApiKey   = this._loadApiKey();
        let savedAstapPath = this._loadAstapPath();

        // ---- Image selection ----
        this.imageSelectionLabel = new Label( this );
        this.imageSelectionLabel.text = "Select Image:";
        this.imageSelectionLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.imageSelectionDropdown = new ComboBox( this );
        this.imageSelectionDropdown.editEnabled = false;

        let windows = ImageWindow.windows;
        let activeWindowId = ImageWindow.activeWindow.mainView.id;
        for ( let i = 0; i < windows.length; ++i )
        {
            this.imageSelectionDropdown.addItem( windows[i].mainView.id );
            if ( windows[i].mainView.id === activeWindowId )
                this.imageSelectionDropdown.currentItem = i;
        }

        this.imageSelectionSizer = new HorizontalSizer;
        this.imageSelectionSizer.spacing = 4;
        this.imageSelectionSizer.add( this.imageSelectionLabel );
        this.imageSelectionSizer.add( this.imageSelectionDropdown, 100 );

        // ---- API key ----
        this.apiKeyLabel = new Label( this );
        this.apiKeyLabel.text = "Astrometry.net API Key:";
        this.apiKeyLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.apiKeyInput = new Edit( this );
        this.apiKeyInput.text = savedApiKey;

        this.apiKeySizer = new HorizontalSizer;
        this.apiKeySizer.spacing = 4;
        this.apiKeySizer.add( this.apiKeyLabel );
        this.apiKeySizer.add( this.apiKeyInput, 100 );

        // ---- ASTAP path ----
        this.astapLabel = new Label( this );
        this.astapLabel.text = "ASTAP Executable Path:";
        this.astapLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.astapInput = new Edit( this );
        this.astapInput.readOnly = true;
        this.astapInput.text = savedAstapPath;

        this.astapSetupButton = new ToolButton( this );
        this.astapSetupButton.icon = this.scaledResource( ":/icons/wrench.png" );
        this.astapSetupButton.setScaledFixedSize( 24, 24 );
        this.astapSetupButton.toolTip = "<p>Select folder containing ASTAP executable.</p>";
        this.astapSetupButton.onClick = () =>
        {
            if ( isMac() )
            {
                let fileDialog = new OpenFileDialog;
                fileDialog.caption = "Select ASTAP Executable";
                fileDialog.filter = "Executable Files (*)";
                fileDialog.initialPath = this.astapInput.text || File.systemTempDirectory;
                if ( fileDialog.execute() )
                {
                    let newPath = fileDialog.fileName;
                    this.astapInput.text = newPath;
                    this._saveAstapPath( newPath );
                }
            }
            else
            {
                let pathDialog = new GetDirectoryDialog;
                pathDialog.initialPath = this.astapInput.text || File.systemTempDirectory;
                if ( pathDialog.execute() )
                {
                    let folder = pathDialog.directory;
                    let newPath = isWindows()
                        ? folder + "/astap.exe"
                        : folder + "/astap";
                    this.astapInput.text = newPath;
                    this._saveAstapPath( newPath );
                }
            }
        };

        this.astapPathSizer = new HorizontalSizer;
        this.astapPathSizer.spacing = 4;
        this.astapPathSizer.add( this.astapInput, 100 );
        this.astapPathSizer.add( this.astapSetupButton );

        this.astapMainSizer = new VerticalSizer;
        this.astapMainSizer.spacing = 4;
        this.astapMainSizer.add( this.astapLabel );
        this.astapMainSizer.add( this.astapPathSizer );

        // ---- Linear data checkbox ----
        this.linearDataCheckbox = new CheckBox( this );
        this.linearDataCheckbox.text = "Auto Detect Linear Data";
        this.linearDataCheckbox.checked = true;

        // ---- Start button ----
        this.startButton = new PushButton( this );
        this.startButton.text = "Start Plate Solve";
        this.startButton.onClick = () =>
        {
            this._saveApiKey( this.apiKeyInput.text.trim() );
            this.startPlateSolve();
        };

        // ---- Status label ----
        this.statusText = new Label( this );
        this.statusText.text = "";
        this.statusText.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        // ---- Results panel (hidden until a solve succeeds) ----
        this.resultsLabel = new Label( this );
        this.resultsLabel.text = "Blind Solve Result:";
        this.resultsLabel.styleSheet = "font-weight: bold;";

        this.resultsRA = new Label( this );
        this.resultsRA.text = "RA:";
        this.resultsRA.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.resultsDec = new Label( this );
        this.resultsDec.text = "Dec:";
        this.resultsDec.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.resultsScale = new Label( this );
        this.resultsScale.text = "Scale:";
        this.resultsScale.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.resultsNote = new Label( this );
        this.resultsNote.text = "WCS keywords written to image header.";
        this.resultsNote.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.resultsWarning = new Label( this );
        this.resultsWarning.text =
            "Image Solver is no longer callable from a script in PI ≥ 1.9.4.\n" +
            "Please open Image Solver to complete the process.\n" +
            "All correct seed parameters have been pushed to Image Solver.";
        this.resultsWarning.styleSheet = "font-weight: bold; color: #cc6600;";
        this.resultsWarning.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

        this.launchSolverButton = new PushButton( this );
        this.launchSolverButton.text = "How to Open Image Solver →";
        this.launchSolverButton.toolTip =
            "<p>Shows instructions for opening Image Solver.<br/>" +
            "The blind solve coordinates are already in the FITS header<br/>" +
            "and will be loaded automatically when Image Solver opens.</p>";
        this.launchSolverButton.onClick = () => { this._launchImageSolver(); };

        this.resultsSizer = new VerticalSizer;
        this.resultsSizer.spacing = 4;
        this.resultsSizer.margin = 4;
        this.resultsSizer.add( this.resultsLabel );
        this.resultsSizer.add( this.resultsRA );
        this.resultsSizer.add( this.resultsDec );
        this.resultsSizer.add( this.resultsScale );
        this.resultsSizer.add( this.resultsNote );
        this.resultsSizer.add( this.resultsWarning );
        this.resultsSizer.addSpacing( 4 );
        this.resultsSizer.add( this.launchSolverButton );

        // Store calibration data for the launch button to use
        this._lastCalibration = null;

        // Hide results panel initially
        this.resultsLabel.visible   = false;
        this.resultsRA.visible      = false;
        this.resultsDec.visible     = false;
        this.resultsScale.visible   = false;
        this.resultsNote.visible    = false;
        this.resultsWarning.visible = false;
        this.launchSolverButton.visible = false;

        // ---- Close button ----
        this.closeButton = new PushButton( this );
        this.closeButton.text = "Close";
        this.closeButton.onClick = () => this.cancel();

        // ---- New Instance button ----
        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip = "<p>Create a new instance of this process.</p>";
        this.newInstanceButton.onMousePress = () =>
        {
            this.newInstance();
        };

        this.newInstanceButtonSizer = new HorizontalSizer;
        this.newInstanceButtonSizer.spacing = 6;
        this.newInstanceButtonSizer.add( this.newInstanceButton );
        this.newInstanceButtonSizer.addStretch();

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.spacing = 6;
        this.buttonSizer.add( this.startButton );
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.closeButton );

        // ---- Main sizer ----
        this.sizer = new VerticalSizer;
        this.sizer.margin = 6;
        this.sizer.spacing = 6;
        this.sizer.add( this.imageSelectionSizer );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.apiKeySizer );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.astapMainSizer );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.linearDataCheckbox );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.statusText );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.resultsLabel );
        this.sizer.add( this.resultsRA );
        this.sizer.add( this.resultsDec );
        this.sizer.add( this.resultsScale );
        this.sizer.add( this.resultsNote );
        this.sizer.add( this.resultsWarning );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.launchSolverButton );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.buttonSizer );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.newInstanceButtonSizer );

        this.windowTitle = TITLE + " - " + VERSION;
        this.adjustToContents();
        this.setFixedSize();
    }

    // ---- Show solve results in UI ----

    _showResults( calibrationData )
    {
        this._lastCalibration = calibrationData;

        this.resultsLabel.text = "Blind Solve Result:";
        this.resultsRA.text    = "RA:    " + calibrationData.ra.toFixed(6) + "°";
        this.resultsDec.text   = "Dec:   " + calibrationData.dec.toFixed(6) + "°";
        this.resultsScale.text = "Scale: " + calibrationData.pixscale.toFixed(4) + " arcsec/px";
        this.resultsNote.text  =
            "WCS keywords written to image header.\n" +
            "Epoch: " + ( calibrationData.obsDateStr || "today" ) +
            "  (JD " + ( calibrationData.epochJD || "N/A" ) + ")";

        this.resultsLabel.visible       = true;
        this.resultsRA.visible          = true;
        this.resultsDec.visible         = true;
        this.resultsScale.visible       = true;
        this.resultsNote.visible        = true;
        this.resultsWarning.visible     = true;
        this.launchSolverButton.visible = true;

        // Unlock size so dialog can expand to show results
        this.setVariableSize();
        this.adjustToContents();
        this.setFixedSize();
    }

    // ---- Launch Image Solver instructions ----
    // console.executeScript() cannot be called from a running JS script because
    // the PixInsight JS engine is non-reentrant. Show instructions instead so
    // the user can open Image Solver in one click from the Script menu — it will
    // automatically read the WCS keywords already written to the FITS header.

    _launchImageSolver()
    {
        if ( !this._lastCalibration )
            return;

        let cal = this._lastCalibration;

        new MessageBox(
            "<p><b>Open Image Solver to complete the astrometric solution:</b></p>" +
            "<p>Script &gt; Astrometry &gt; ImageSolver</p>" +
            "<p>The following values have been written to the image FITS header " +
            "and will be loaded automatically:</p>" +
            "<p><b>RA</b> = " + cal.ra.toFixed(6) + "°<br/>" +
            "<b>Dec</b> = " + cal.dec.toFixed(6) + "°<br/>" +
            "<b>Scale</b> = " + cal.pixscale.toFixed(4) + " arcsec/px<br/>" +
            "<b>Epoch</b> = " + ( cal.obsDateStr || "today" ) + "</p>" +
            "<p>Just click <b>OK</b> in Image Solver to run the full solution.</p>",
            TITLE, StdIcon.Information, StdButton.Ok
        ).execute();
    }

    // ---- Session key ----

    getSessionKey( apiKey )
    {
        let sessionKey = null;
        let loginUrl = "http://nova.astrometry.net/api/login";
        let requestData = "request-json={\\\"apikey\\\":\\\"" + apiKey + "\\\"}";
        let responseFilename = File.systemTempDirectory + "/astrometry_login_response.json";

        if ( File.exists( responseFilename ) )
            File.remove( responseFilename );

        let CMD_EXEC = getCmdExec();
        let scriptFilePath, curlCommand, scriptContent;

        if ( isMac() )
        {
            scriptFilePath = File.systemTempDirectory + "/login_curl.sh";
            curlCommand = "/usr/bin/curl -X POST -d \"" + requestData + "\" " + loginUrl + " -o " + responseFilename;
            scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
        }
        else if ( isWindows() )
        {
            scriptFilePath = File.systemTempDirectory + "/login_curl.bat";
            curlCommand = "curl -X POST -d \"" + requestData + "\" " + loginUrl + " -o " + responseFilename;
            scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
        }
        else
        {
            scriptFilePath = File.systemTempDirectory + "/login_curl.sh";
            curlCommand = "/usr/bin/curl -X POST -d \"" + requestData + "\" " + loginUrl + " -o " + responseFilename;
            scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
        }

        try
        {
            File.writeTextFile( scriptFilePath, scriptContent );
            console.noteln( "Login script file created: " + scriptFilePath );
            console.flush();
        }
        catch ( error )
        {
            console.criticalln( "Failed to create login script file: " + error.message );
            console.flush();
            return null;
        }

        let process = new ExternalProcess;

        try
        {
            console.show();
            console.writeln( "Executing script file using: " + CMD_EXEC + " " + scriptFilePath );
            console.flush();

            if ( isWindows() )
                process.start( CMD_EXEC, ["/c", scriptFilePath] );
            else
                process.start( CMD_EXEC, [scriptFilePath] );

            let maxWaitTime = 15000;
            let waitTime = 0;

            while ( !File.exists( responseFilename ) )
            {
                if ( waitTime >= maxWaitTime )
                {
                    console.criticalln( "Timeout waiting for response file." );
                    return null;
                }
                console.noteln( "Waiting for the login process to complete..." );
                console.flush();
                msleep( 1000 );
                waitTime += 1000;
            }

            if ( File.exists( responseFilename ) )
            {
                let jsonResponse = JSON.parse( File.readFile( responseFilename ) );
                console.writeln( "Raw JSON response: " + JSON.stringify( jsonResponse ) );
                console.flush();

                if ( jsonResponse.status === "success" )
                {
                    sessionKey = jsonResponse.session;
                    console.noteln( "Login successful, session key: " + sessionKey );
                }
                else
                {
                    console.warningln( "Login failed. Response: " + JSON.stringify( jsonResponse, null, 2 ) );
                }
                File.remove( responseFilename );
            }
            else
            {
                console.warningln( "Login script file did not execute as expected." );
                console.flush();
            }
        }
        catch ( error )
        {
            console.warningln( "An error occurred while starting the login script file process: " + error.message );
            console.flush();
        }

        if ( File.exists( scriptFilePath ) )
        {
            File.remove( scriptFilePath );
            console.noteln( "Script file cleaned up: " + scriptFilePath );
        }

        return sessionKey;
    }

    // ---- Start plate solve ----

    startPlateSolve()
    {
        this.statusText.text = "Starting...";
        this.startButton.enabled = false;

        // Hide results from any previous run
        this._lastCalibration = null;
        this.resultsLabel.visible       = false;
        this.resultsRA.visible          = false;
        this.resultsDec.visible         = false;
        this.resultsScale.visible       = false;
        this.resultsNote.visible        = false;
        this.resultsWarning.visible     = false;
        this.launchSolverButton.visible = false;
        this.setVariableSize();
        this.adjustToContents();
        this.setFixedSize();

        let imageFile = this.saveImageAsJpg();
        if ( !imageFile )
        {
            this.statusText.text = "Error saving image.";
            this.startButton.enabled = true;
            return;
        }
        console.noteln( "Image saved successfully: " + imageFile );
        console.flush();

        if ( this.astapInput.text.trim() !== "" )
        {
            this.statusText.text = "Attempting ASTAP plate solve...";
            let outputFiles = this.runASTAPPlateSolve( imageFile );
            if ( outputFiles )
            {
                let calibrationData = this.parseASTAPCalibration( outputFiles );
                if ( calibrationData )
                {
                    this.applyAstrometricSolution( calibrationData );
                    this.statusText.text = "Blind solve complete (ASTAP). See results below.";
                    console.hide();
                    this.startButton.enabled = true;
                    return;
                }
                else
                {
                    console.warningln( "Failed to parse ASTAP calibration data. Falling back to astrometry.net." );
                }
            }
            else
            {
                console.warningln( "ASTAP plate solve failed. Falling back to astrometry.net." );
            }
        }

        let apiKey = this.apiKeyInput.text.trim();
        if ( !apiKey )
        {
            this.statusText.text = "API key is required.";
            this.startButton.enabled = true;
            return;
        }

        let sessionKey = this.getSessionKey( apiKey );
        if ( !sessionKey )
        {
            this.statusText.text = "Error obtaining session key.";
            this.startButton.enabled = true;
            return;
        }

        this.statusText.text = "Uploading image to astrometry.net...";
        let subid = this.uploadImageToAstrometry( imageFile, sessionKey );
        if ( !subid )
        {
            this.statusText.text = "Error uploading image.";
            this.startButton.enabled = true;
            return;
        }

        this.statusText.text = "Submission successful. Waiting for solution...";
        let jobID = this.pollSubmissionStatus( subid );
        if ( !jobID )
        {
            this.statusText.text = "Error retrieving submission status.";
            this.startButton.enabled = true;
            return;
        }

        this.statusText.text = "Solution found. Retrieving calibration data...";
        let calibrationData = this.getJobCalibration( jobID );
        if ( !calibrationData )
        {
            this.statusText.text = "Error retrieving calibration data.";
            this.startButton.enabled = true;
            return;
        }

        this.applyAstrometricSolution( calibrationData );
        this.statusText.text = "Blind solve complete (astrometry.net). See results below.";
        console.hide();
        this.startButton.enabled = true;
    }

    // ---- Save image as JPG ----

    saveImageAsJpg()
    {
        let selectedWindow = ImageWindow.activeWindow;
        let jpgPath = File.systemTempDirectory + "/temp_image.jpg";

        let exportImage = new ImageWindow(
            selectedWindow.mainView.image.width,
            selectedWindow.mainView.image.height,
            3,
            16,
            false,
            false,
            selectedWindow.mainView.id + "_temp"
        );

        exportImage.mainView.beginProcess( UndoFlag.NoSwapFile );
        exportImage.mainView.image.assign( selectedWindow.mainView.image );
        exportImage.mainView.endProcess();

        if ( this.linearDataCheckbox.checked )
        {
            console.noteln( "Auto Linear data checkbox is checked. Verifying and Stretching if needed..." );

            let medianValue = exportImage.mainView.image.median();

            if ( medianValue < 0.1 )
            {
                console.noteln( "Image median is less than 0.1. Applying PixelMath transformation..." );

                let P = new PixelMath;
                P.expression =
                    "C = -2.8  ;  //Shadow Clipping (Default value -2.8)\n" +
                    "B = 0.25  ;  //Background value (Higher the value, more stretched)\n" +
                    "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
                    "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
                P.expression1 = "";
                P.expression2 = "";
                P.expression3 = "";
                P.useSingleExpression = true;
                P.symbols = "C,B,c";
                P.clearImageCacheAndExit = false;
                P.cacheGeneratedImages = false;
                P.generateOutput = true;
                P.singleThreaded = false;
                P.optimization = true;
                P.use64BitWorkingImage = false;
                P.rescale = false;
                P.rescaleLower = 0;
                P.rescaleUpper = 1;
                P.truncate = true;
                P.truncateLower = 0;
                P.truncateUpper = 1;
                P.createNewImage = false;
                P.showNewImage = false;
                P.newImageId = "";
                P.newImageWidth = 0;
                P.newImageHeight = 0;
                P.newImageAlpha = false;
                P.newImageColorSpace = PixelMath.SameAsTarget;
                P.newImageSampleFormat = PixelMath.SameAsTarget;
                P.executeOn( exportImage.mainView );
            }
            else
            {
                console.noteln( "Image median is >= 0.1. Skipping PixelMath transformation." );
            }
        }

        exportImage.saveAs( jpgPath, false, false, false, false );
        exportImage.close();
        console.noteln( "Image saved successfully: " + jpgPath );
        return jpgPath;
    }

    // ---- Upload to astrometry.net ----

    uploadImageToAstrometry( imageFile, sessionKey )
    {
        let subid = null;
        let responseFilename = File.systemTempDirectory + "/astrometry_response.json";

        if ( File.exists( responseFilename ) )
            File.remove( responseFilename );

        let CMD_EXEC = getCmdExec();
        let scriptFilePath, curlCommand, scriptContent;

        if ( isMac() )
        {
            scriptFilePath = File.systemTempDirectory + "/run_curl.sh";
            curlCommand =
                "/usr/bin/curl -v -F \"request-json={\\\"publicly_visible\\\": \\\"y\\\", \\\"allow_modifications\\\": \\\"d\\\", \\\"session\\\": \\\"" + sessionKey + "\\\", \\\"allow_commercial_use\\\": \\\"d\\\"}\"" +
                " -F \"file=@" + imageFile + "\" " +
                "http://nova.astrometry.net/api/upload -o " + responseFilename;
            scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
        }
        else if ( isWindows() )
        {
            scriptFilePath = File.systemTempDirectory + "/run_curl.bat";
            curlCommand =
                "curl -v -F \"request-json={\\\"publicly_visible\\\": \\\"y\\\", \\\"allow_modifications\\\": \\\"d\\\", \\\"session\\\": \\\"" + sessionKey + "\\\", \\\"allow_commercial_use\\\": \\\"d\\\"}\"" +
                " -F \"file=@" + imageFile + "\" " +
                "http://nova.astrometry.net/api/upload -o " + responseFilename;
            scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
        }
        else
        {
            scriptFilePath = File.systemTempDirectory + "/run_curl.sh";
            curlCommand =
                "/usr/bin/curl -v -F \"request-json={\\\"publicly_visible\\\": \\\"y\\\", \\\"allow_modifications\\\": \\\"d\\\", \\\"session\\\": \\\"" + sessionKey + "\\\", \\\"allow_commercial_use\\\": \\\"d\\\"}\"" +
                " -F \"file=@" + imageFile + "\" " +
                "http://nova.astrometry.net/api/upload -o " + responseFilename;
            scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
        }

        console.writeln( "Script content:" );
        console.writeln( scriptContent );
        console.flush();

        try
        {
            File.writeTextFile( scriptFilePath, scriptContent );
            console.noteln( "Curl script file created: " + scriptFilePath );
            console.flush();
        }
        catch ( error )
        {
            console.criticalln( "Failed to create curl script file: " + error.message );
            console.flush();
            return null;
        }

        let process = new ExternalProcess;

        try
        {
            console.show();
            console.writeln( "Executing curl script file using: " + CMD_EXEC + " " + scriptFilePath );
            console.flush();

            if ( isWindows() )
                process.start( CMD_EXEC, ["/c", scriptFilePath] );
            else
                process.start( CMD_EXEC, [scriptFilePath] );

            let maxWaitTime = 15000;
            let waitTime = 0;

            while ( !File.exists( responseFilename ) )
            {
                if ( waitTime >= maxWaitTime )
                {
                    console.criticalln( "Timeout waiting for curl response file." );
                    return null;
                }
                console.noteln( "Waiting for the curl process to complete..." );
                console.flush();
                msleep( 1000 );
                waitTime += 1000;
            }

            if ( File.exists( responseFilename ) )
            {
                let jsonResponse = JSON.parse( File.readFile( responseFilename ) );
                console.writeln( "Raw JSON response: " + JSON.stringify( jsonResponse ) );
                console.flush();

                if ( jsonResponse.status === "success" )
                {
                    subid = jsonResponse.subid;
                    console.noteln( "Submission successful, subid: " + subid );
                }
                else
                {
                    console.warningln( "Submission failed. Response: " + JSON.stringify( jsonResponse, null, 2 ) );
                }
                File.remove( responseFilename );
            }
            else
            {
                console.warningln( "Curl script did not execute as expected." );
                console.flush();
            }
        }
        catch ( error )
        {
            console.warningln( "An error occurred while starting the curl script process: " + error.message );
            console.flush();
        }

        if ( File.exists( scriptFilePath ) )
        {
            File.remove( scriptFilePath );
            console.noteln( "Curl script file cleaned up: " + scriptFilePath );
        }

        return subid;
    }

    // ---- Poll submission status ----

    pollSubmissionStatus( subid )
    {
        let jobID = null;
        let retries = 0;
        const maxRetries = 90;
        let CMD_EXEC = getCmdExec();
        let SCRIPT_EXT = getScriptExt();

        while ( retries < maxRetries )
        {
            let responseFilename = File.systemTempDirectory + "/astrometry_submission_status.json";
            if ( File.exists( responseFilename ) )
                File.remove( responseFilename );

            let curlCommand = "curl -X GET http://nova.astrometry.net/api/submissions/" + subid + " -o " + responseFilename;
            let scriptFilePath = File.systemTempDirectory + "/status_curl" + SCRIPT_EXT;

            let scriptContent;
            if ( isWindows() )
                scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
            else
                scriptContent = "#!/bin/bash\n" + curlCommand + "\n";

            try
            {
                File.writeTextFile( scriptFilePath, scriptContent );
                console.noteln( "Status check script file created: " + scriptFilePath );
                console.flush();
            }
            catch ( error )
            {
                console.criticalln( "Failed to create status check script file: " + error.message );
                console.flush();
                return null;
            }

            let process = new ExternalProcess;

            try
            {
                console.writeln( "Executing status check script file: " + scriptFilePath );
                console.flush();

                if ( isWindows() )
                    process.start( CMD_EXEC, ["/c", scriptFilePath] );
                else
                    process.start( CMD_EXEC, [scriptFilePath] );

                let processTimeout = 0;

                while ( process.isRunning || !File.exists( responseFilename ) )
                {
                    console.noteln( "Waiting for the status check process to complete..." );
                    console.flush();
                    msleep( 10000 );
                    processTimeout += 10000;
                    if ( processTimeout >= 30000 )
                    {
                        console.warningln( "Process timeout reached." );
                        break;
                    }
                }

                if ( File.exists( responseFilename ) )
                {
                    let jsonResponse = JSON.parse( File.readFile( responseFilename ) );
                    console.writeln( "Raw JSON response: " + JSON.stringify( jsonResponse ) );
                    console.flush();

                    if ( jsonResponse.jobs && jsonResponse.jobs.length > 0 && jsonResponse.jobs[0] !== null )
                    {
                        jobID = jsonResponse.jobs[0];
                        console.noteln( "Job ID found: " + jobID );
                        File.remove( responseFilename );
                        return jobID;
                    }
                    else
                    {
                        console.warningln( "Job ID not found or is null. Response: " + JSON.stringify( jsonResponse ) );
                    }
                    File.remove( responseFilename );
                }
                else
                {
                    console.warningln( "Status check script file did not execute as expected." );
                    console.writeln( "Standard Output: " + process.readStandardOutput() );
                    console.writeln( "Standard Error: "  + process.readStandardError() );
                    console.flush();
                }
            }
            catch ( error )
            {
                console.warningln( "An error occurred while starting the status check script file process: " + error.message );
                console.flush();
            }

            console.noteln( "Waiting for submission to be processed... (Retry " + (retries + 1) + ")" );
            console.flush();
            msleep( 10000 );
            retries++;
        }

        console.warningln( "Max retries reached. Submission status check failed." );
        console.flush();
        return null;
    }

    // ---- Get job calibration ----

    getJobCalibration( jobID )
    {
        let calibrationData = null;
        let retries = 0;
        const maxRetries = 90;
        const waitTime = 10000;
        let success = false;
        let CMD_EXEC = getCmdExec();
        let SCRIPT_EXT = getScriptExt();

        let responseFilename = File.systemTempDirectory + "/astrometry_job_calibration.json";
        if ( File.exists( responseFilename ) )
            File.remove( responseFilename );

        let scriptFilePath = File.systemTempDirectory + "/calibration_curl" + SCRIPT_EXT;

        while ( retries < maxRetries && !success )
        {
            let curlCommand = "curl -X GET http://nova.astrometry.net/api/jobs/" + jobID + "/calibration/ -o " + responseFilename;

            let scriptContent;
            if ( isWindows() )
                scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
            else
                scriptContent = "#!/bin/bash\n" + curlCommand + "\n";

            try
            {
                File.writeTextFile( scriptFilePath, scriptContent );
                console.noteln( "Calibration check script file created: " + scriptFilePath );
                console.flush();
            }
            catch ( error )
            {
                console.criticalln( "Failed to create calibration check script file: " + error.message );
                console.flush();
                return null;
            }

            let process = new ExternalProcess;

            try
            {
                console.writeln( "Executing calibration check script file using: " + CMD_EXEC + " " + scriptFilePath );
                console.flush();

                if ( isWindows() )
                    process.start( CMD_EXEC, ["/c", scriptFilePath] );
                else
                    process.start( CMD_EXEC, [scriptFilePath] );

                while ( process.isRunning || !File.exists( responseFilename ) )
                {
                    console.noteln( "Waiting for the calibration check process to complete (Retry " + (retries + 1) + "/" + maxRetries + ")..." );
                    console.flush();
                    msleep( waitTime );
                    retries++;
                }

                if ( File.exists( responseFilename ) )
                {
                    let jsonResponse = JSON.parse( File.readFile( responseFilename ) );
                    console.writeln( "Raw JSON response: " + JSON.stringify( jsonResponse ) );
                    console.flush();

                    if ( jsonResponse && jsonResponse.ra )
                    {
                        calibrationData = jsonResponse;
                        console.noteln( "Calibration data retrieved successfully." );
                        success = true;
                        File.remove( responseFilename );
                    }
                    else
                    {
                        console.warningln( "Calibration data not available or incomplete. Response: " + JSON.stringify( jsonResponse ) );
                    }
                }
                else
                {
                    console.warningln( "Calibration check script file did not execute as expected." );
                    console.writeln( "Standard Output: " + process.readStandardOutput() );
                    console.writeln( "Standard Error: "  + process.readStandardError() );
                    console.flush();
                }
            }
            catch ( error )
            {
                console.warningln( "An error occurred while starting the calibration check script process: " + error.message );
                console.flush();
            }

            if ( !success && retries >= maxRetries )
            {
                console.warningln( "Max retries reached. Calibration data retrieval failed." );
                console.flush();
                break;
            }
        }

        if ( File.exists( scriptFilePath ) )
        {
            File.remove( scriptFilePath );
            console.noteln( "Calibration check script file cleaned up: " + scriptFilePath );
        }

        return calibrationData;
    }

    // ---- Apply astrometric solution ----

    applyAstrometricSolution( calibrationData )
    {
        let tempJpg = File.systemTempDirectory + "/temp_image.jpg";
        let tempWcs = File.systemTempDirectory + "/temp_image.wcs";
        let tempIni = File.systemTempDirectory + "/temp_image.ini";

        [tempJpg, tempWcs, tempIni].forEach( filePath =>
        {
            if ( File.exists( filePath ) )
            {
                try { File.remove( filePath ); console.noteln( "Deleted temporary file: " + filePath ); }
                catch ( e ) { console.warningln( "Could not delete temporary file: " + filePath ); }
            }
        } );

        console.noteln( "applyAstrometricSolution received calibrationData: " + JSON.stringify( calibrationData, null, 2 ) );

        let selectedWindow = ImageWindow.activeWindow;
        if ( selectedWindow.isNull )
        {
            console.warningln( "No active image window found." );
            return;
        }

        console.writeln( "Astrometric Solution:" );
        console.writeln( "RA: "           + calibrationData.ra.toFixed(6) );
        console.writeln( "Dec: "          + calibrationData.dec.toFixed(6) );
        console.writeln( "Pixel Scale: "  + calibrationData.pixscale.toFixed(6) + " arcsec/pixel" );
        console.writeln( "Orientation: "  + calibrationData.orientation.toFixed(6) + " degrees" );
        console.writeln( "Parity: "       + calibrationData.parity );
        console.flush();

        try
        {
            let view = selectedWindow.mainView;
            let resolution    = calibrationData.pixscale;
            let raStr         = calibrationData.ra.toFixed(6);
            let decStr        = calibrationData.dec.toFixed(6);
            let resolutionStr = resolution.toFixed(12);

            // Try to get observation date from existing FITS header keywords.
            // Check DATE-OBS, DATE-BEG, DATE in that order, fall back to today.
            let obsDateStr = null;
            let existingKws = selectedWindow.keywords;
            let dateCandidates = ["DATE-OBS", "DATE-BEG", "DATE"];
            for ( let kw of existingKws )
            {
                if ( dateCandidates.indexOf( kw.name.trim().toUpperCase() ) !== -1 )
                {
                    let v = kw.value.trim().replace( /'/g, "" ).trim();
                    if ( v.length >= 10 ) // at minimum YYYY-MM-DD
                    {
                        obsDateStr = v;
                        console.noteln( "Observation date from header (" + kw.name.trim() + "): " + obsDateStr );
                        break;
                    }
                }
            }

            // Fall back to today if no header date found
            if ( !obsDateStr )
            {
                let now = new Date();
                obsDateStr = now.getFullYear() + "-" +
                    String( now.getMonth() + 1 ).padStart( 2, "0" ) + "-" +
                    String( now.getDate() ).padStart( 2, "0" ) + "T" +
                    String( now.getHours() ).padStart( 2, "0" ) + ":" +
                    String( now.getMinutes() ).padStart( 2, "0" ) + ":" +
                    String( now.getSeconds() ).padStart( 2, "0" );
                console.noteln( "No observation date in header — using today: " + obsDateStr );
            }

            // Convert ISO date string to Julian Date for ImageSolver metadata_epoch
            function isoToJD( isoStr )
            {
                // Parse at minimum YYYY-MM-DD, optionally with time
                let d = new Date( isoStr );
                if ( isNaN( d.getTime() ) )
                    return (Date.now() / 86400000 + 2440587.5); // fallback: today
                return d.getTime() / 86400000 + 2440587.5;
            }

            let epochJD = isoToJD( obsDateStr ).toFixed(6);
            console.noteln( "Epoch JD: " + epochJD );

            let keywords = [
                new FITSKeyword( "CTYPE1",   "RA---TAN",  "Coordinate type for axis 1" ),
                new FITSKeyword( "CTYPE2",   "DEC--TAN",  "Coordinate type for axis 2" ),
                new FITSKeyword( "CRVAL1",   raStr,       "Reference value for axis 1" ),
                new FITSKeyword( "CRVAL2",   decStr,      "Reference value for axis 2" ),
                new FITSKeyword( "CRPIX1",   (view.image.width  / 2 + 0.5).toFixed(6), "Reference pixel for axis 1" ),
                new FITSKeyword( "CRPIX2",   (view.image.height / 2 + 0.5).toFixed(6), "Reference pixel for axis 2" ),
                new FITSKeyword( "CD1_1",    (-Math.cos( calibrationData.orientation * Math.PI / 180 ) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 1_1" ),
                new FITSKeyword( "CD1_2",    ( Math.sin( calibrationData.orientation * Math.PI / 180 ) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 1_2" ),
                new FITSKeyword( "CD2_1",    (-Math.sin( calibrationData.orientation * Math.PI / 180 ) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 2_1" ),
                new FITSKeyword( "CD2_2",    (-Math.cos( calibrationData.orientation * Math.PI / 180 ) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 2_2" ),
                new FITSKeyword( "RADECSYS", "ICRS",      "Coordinate reference system" ),
                new FITSKeyword( "DATE-OBS", "'" + obsDateStr + "'", "Observation date" )
            ];
            selectedWindow.keywords = keywords;
            console.noteln( "Astrometric solution applied to image header successfully." );

            // Bring the target window to front.
            selectedWindow.bringToFront();

            this.statusText.text = "Step 1 complete — open Image Solver to finish.";

            console.writeln( "RA    = " + calibrationData.ra.toFixed(6) );
            console.writeln( "Dec   = " + calibrationData.dec.toFixed(6) );
            console.writeln( "Scale = " + calibrationData.pixscale.toFixed(4) + " arcsec/px" );
            console.writeln( "Epoch = " + obsDateStr + " (JD " + epochJD + ")" );

            // Pass epoch through to results panel and launch button
            calibrationData.epochJD     = epochJD;
            calibrationData.obsDateStr  = obsDateStr;

            this._showResults( calibrationData );
        }
        catch ( error )
        {
            console.criticalln( "Failed to apply astrometric solution." );
            if ( typeof error === "object" && error !== null )
                console.criticalln( "Error details: " + JSON.stringify( error, null, 2 ) );
            else
                console.criticalln( "Unknown error occurred during astrometric solution application." );
        }
    }

    // ---- ASTAP plate solve ----

    runASTAPPlateSolve( jpgFile )
    {
        console.show();
        let astapFullPath = this.astapInput.text.trim();

        if ( astapFullPath === "" )
        {
            console.warningln( "ASTAP executable path not provided." );
            return null;
        }

        if ( isMac() && astapFullPath.endsWith( ".app" ) )
        {
            astapFullPath = astapFullPath + "/Contents/MacOS/ASTAP";
            console.writeln( "Adjusted ASTAP path for macOS: " + astapFullPath );
        }

        if ( !File.exists( astapFullPath ) )
        {
            console.criticalln( "ASTAP executable not found at: " + astapFullPath );
            return null;
        }

        let localCMD_EXEC = isWindows() ? "cmd.exe" : "/bin/sh";

        let lastSep = Math.max( astapFullPath.lastIndexOf("/"), astapFullPath.lastIndexOf("\\") );
        if ( lastSep === -1 )
        {
            console.criticalln( "Could not determine parent folder from: " + astapFullPath );
            return null;
        }

        let astapFolder  = astapFullPath.substring( 0, lastSep );
        let astapExeName = astapFullPath.substring( lastSep + 1 );

        let scriptFilePath, scriptContent;

        if ( isWindows() )
        {
            scriptFilePath = File.systemTempDirectory + "/run_astap.bat";
            scriptContent  = "@echo on\r\n";
            scriptContent += "cd /d \"" + astapFolder + "\"\r\n";
            scriptContent += "\"" + astapExeName + "\" -f \"" + jpgFile + "\" -r 179 -fov 0 -z 0 -wcs\r\n";
            scriptContent += "exit\r\n";
        }
        else
        {
            scriptFilePath = File.systemTempDirectory + "/run_astap.sh";
            scriptContent  = "#!/bin/sh\n";
            scriptContent += "cd \"" + astapFolder + "\"\n";
            scriptContent += "./" + astapExeName + " -f \"" + jpgFile + "\" -r 179 -fov 0 -z 0 -wcs\n";
            scriptContent += "exit\n";
        }

        try
        {
            File.writeTextFile( scriptFilePath, scriptContent );
            console.writeln( "ASTAP script file created: " + scriptFilePath );
            scriptContent.split( /\r?\n/ ).forEach( line => console.writeln( "  " + line ) );
        }
        catch ( error )
        {
            console.criticalln( "Failed to create ASTAP script file: " + error.message );
            return null;
        }

        let process = new ExternalProcess;
        let processFinished = false;

        process.onStarted = () =>
        {
            console.noteln( "ASTAP process started: " + localCMD_EXEC + " " + scriptFilePath );
        };
        process.onStandardOutputDataAvailable = () =>
        {
            console.writeln( "ASTAP STDOUT: " + String( process.stdout ) );
        };
        process.onStandardErrorDataAvailable = () =>
        {
            console.criticalln( "ASTAP STDERR: " + String( process.stderr ) );
        };
        process.onError = code =>
        {
            console.criticalln( "ASTAP process error code: " + code );
        };
        process.onFinished = () =>
        {
            console.noteln( "ASTAP process finished." );
            processFinished = true;
        };

        try
        {
            if ( isWindows() )
                process.start( localCMD_EXEC, ["/c", scriptFilePath] );
            else
                process.start( localCMD_EXEC, [scriptFilePath] );

            while ( process.isStarting )
                CoreApplication.processEvents();
            while ( process.isRunning )
                CoreApplication.processEvents();
        }
        catch ( error )
        {
            console.criticalln( "Error starting ASTAP process: " + error.message );
            return null;
        }

        let wcsFile = jpgFile
            .replace( /\.jpg$/i,  ".wcs" )
            .replace( /\.fits$/i, ".wcs" )
            .replace( /\.tiff$/i, ".wcs" );

        let maxWaitTime = 180000;
        let waited = 0;

        while ( !File.exists( wcsFile ) && waited < maxWaitTime )
        {
            msleep( 2000 );
            CoreApplication.processEvents();
            waited += 2000;
            if ( processFinished ) break;
        }

        if ( File.exists( wcsFile ) )
        {
            console.noteln( "ASTAP .wcs file found: " + wcsFile );
        }
        else
        {
            console.warningln( "ASTAP did not output a .wcs file after waiting " + (waited/1000) + " seconds." );

            let iniFile = jpgFile
                .replace( /\.jpg$/i,  ".ini" )
                .replace( /\.fits$/i, ".ini" )
                .replace( /\.tiff$/i, ".ini" );

            if ( File.exists( iniFile ) )
            {
                console.noteln( "ASTAP INI file found: " + iniFile );
                let iniText = File.readFile( iniFile ).toString();
                console.writeln( "INI file contents:\n" + iniText );

                let pltsolvdMatch = iniText.match( /PLTSOLVD\s*=\s*(\w)/i );
                if ( pltsolvdMatch )
                {
                    let pltsolvd = pltsolvdMatch[1].toUpperCase();
                    if ( pltsolvd === "F" )
                        console.warningln( "ASTAP solve failed according to INI file." );
                    else
                        console.noteln( "ASTAP solve reported success in INI file." );
                }
                else
                {
                    console.warningln( "PLTSOLVD keyword not found in INI file." );
                }

                try { File.remove( iniFile ); console.noteln( "Deleted INI file: " + iniFile ); }
                catch ( e ) { console.warningln( "Could not delete INI file: " + iniFile ); }
            }
            else
            {
                console.warningln( "Neither .wcs nor .ini file was produced by ASTAP." );
            }
        }

        return { jpgFile: jpgFile, wcsFile: wcsFile };
    }

    // ---- Parse ASTAP calibration ----

    parseASTAPCalibration( outputFiles )
    {
        let calibrationData = null;

        if ( File.exists( outputFiles.wcsFile ) )
        {
            try
            {
                let rawWcsText = File.readFile( outputFiles.wcsFile ).toString();
                console.writeln( "Raw .wcs file text:\n" + rawWcsText );

                const cardLength = 80;
                let cards = [];
                for ( let i = 0; i < rawWcsText.length; i += cardLength )
                {
                    let card = rawWcsText.substring( i, i + cardLength ).trim();
                    if ( card !== "" )
                        cards.push( card );
                }
                console.writeln( "Total cards found: " + cards.length );
                for ( let i = 0; i < cards.length; i++ )
                    console.writeln( "Card " + i + ": " + cards[i] );

                let wcsHeader = {};
                for ( let i = 0; i < cards.length; i++ )
                {
                    let card = cards[i];
                    if ( card.startsWith( "END" ) ) break;
                    if ( card.indexOf( "=" ) === -1 ) continue;

                    let key      = card.substring( 0, 8 ).trim().toUpperCase();
                    let valueStr = card.substring( 10, 80 ).trim();
                    let valuePart = valueStr.split("/")[0].trim();

                    if ( valuePart.startsWith("'") && valuePart.endsWith("'") )
                        valuePart = valuePart.substring( 1, valuePart.length - 1 );

                    wcsHeader[key] = valuePart;
                    console.writeln( "Parsed card " + i + ": " + key + " = " + valuePart );
                }
                console.noteln( "Final parsed header:\n" + JSON.stringify( wcsHeader, null, 2 ) );

                if ( !wcsHeader["CRVAL1"] || !wcsHeader["CRVAL2"] || !wcsHeader["CD1_1"] )
                {
                    console.warningln( "Required WCS keywords not found in header." );
                    return null;
                }

                let ra    = parseFloat( wcsHeader["CRVAL1"] );
                let dec   = parseFloat( wcsHeader["CRVAL2"] );
                let cd1_1 = parseFloat( wcsHeader["CD1_1"] );
                let cd1_2 = parseFloat( wcsHeader["CD1_2"] );
                let pixelScaleDeg = Math.sqrt( cd1_1 * cd1_1 + cd1_2 * cd1_2 );
                let pixscale = pixelScaleDeg * 3600;

                calibrationData = { ra: ra, dec: dec, pixscale: pixscale, orientation: 0, parity: 1 };
                console.noteln( "Calibration data computed:\n" + JSON.stringify( calibrationData, null, 2 ) );
                return calibrationData;
            }
            catch ( error )
            {
                console.warningln( "Error parsing .wcs file: " + error.message );
                return null;
            }
        }
        else
        {
            console.warningln( "No .wcs file found." );
            return null;
        }
    }
};

// ============================================================================
// Main
// ============================================================================

let dialog = new BlindImageSolverDialog();
dialog.execute();
